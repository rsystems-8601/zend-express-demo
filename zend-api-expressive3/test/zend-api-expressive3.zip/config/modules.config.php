<?php
  // In config/modules.config.php
  return [
    'Zend\Db', // <-- This line
    'Zend\Form',
    /* ... */
  ];  