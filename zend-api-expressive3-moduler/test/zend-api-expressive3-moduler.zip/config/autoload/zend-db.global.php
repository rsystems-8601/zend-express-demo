<?php
use Zend\Db\ConfigProvider;

return (new ConfigProvider())();
