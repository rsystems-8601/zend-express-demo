import { Component, OnInit, OnDestroy, AfterViewInit } from '@angular/core';
import * as $ from 'jquery';
import { UserService } from 'src/app/services/user.service';
// import {AuthService} from '../../services/auth.service';
// import {UserDetails} from '../../interfaces/IUserDetailsResult';
import { ApplicationModuleListEnum, EventEmiterTypeEnum, ModalPopupSizeEnum, MobileSources } from '../../helpers/enums/common-enums';
import { IGoals } from '../../models/goal';
import { CommonService } from 'src/app/services/common.service';
import { ConnectMessageService } from 'src/app/services/connect-message.service';
import { EventEmiterService } from 'src/app/services/event.emmiter.service';
import { SharedDataService } from 'src/app/services/shared-data.service';
import { MatDialog, MatDialogConfig } from '@angular/material';
import { SurveyCreatorComponent } from '../shared/survey-creator/survey-creator.component';
import { SurveyService } from 'src/app/services/survey.service';
import 'bootstrap/dist/js/bootstrap.bundle';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.scss']
})

export class MainComponent implements OnInit, OnDestroy, AfterViewInit {
  title = 'iCoachFirst';
  // userInfo: UserDetails;
  public chart: any;
  showGoals = false;
  errorMessage: string;
  goals: IGoals[];
  IsAuthenticated = true;
  connectModuleId: number = ApplicationModuleListEnum.Connect;
  coachModuleId: number = ApplicationModuleListEnum.Coach;
  learnModuleId: number = ApplicationModuleListEnum.Learn;
  dashboardReportModuleId: number = ApplicationModuleListEnum.Analyze;
  assessModuleId: number = ApplicationModuleListEnum.Assess;
  adminModuleId: number = ApplicationModuleListEnum.Admin;
  configurationModuleId: number = ApplicationModuleListEnum.Configuration;
  pollModuleId: number = ApplicationModuleListEnum.Poll;
  videoChatModuleId: number = ApplicationModuleListEnum.VideoChat;
  appModuleId = 0;
  // isOpenMainLeftContainer: boolean = false;
  videoCurrentlyPlaying = false;
  showFullScreen = false;

  subscription: Subscription;
  subscriptionRData: any;
  centerPanelCSS = '';
  showFlyMenu = false;
  constructor(
    private userService: UserService,
    // private authService: AuthService
    private connectMessageService: ConnectMessageService,
    private commonService: CommonService,
    private _eventEmiter: EventEmiterService,
    private sharedDataService: SharedDataService,
    private dialog: MatDialog,
    private surveyService: SurveyService
  ) {
    this.connectMessageService.setupPubNub();
  }


  ngAfterViewInit(): void {
    // $('.owl-example').owlCarousel(
    //   {
    //     responsive: {
    //       0: {
    //         items: 1
    //       },
    //       600: {
    //         items: 2
    //       },
    //       1000: {
    //         items: 3
    //       }
    //     }
    //   }
    // );

    // for (let i = 0; i < this.goals.length; i++) {
    //   this.initChart(this.buildGauge(), i, +this.goals[i].GoalPercentageComplete);
    // }
  }

  ngOnInit(): void {
    // this.userInfo = this.userService.getUserDetails().UserDetails;

    // this.trackService.getGoals().subscribe(
    //   goals =>  {
    //     this.goals = goals;
    //   },
    //   errors => this.errorMessage = <any>errors
    // );

    this.configureMSTeamView();
    // Implementing themeing
    const color = this.userService.getUserDetails().UserDetails.ThemeColor;
    if (color) {
      this.commonService.changeThemeColor(color);
    } else {
      // set default color for all user
      this.commonService.changeThemeColor('51677F');
    }
    this.startSurvey();
    this.handleVideoShowHide();
    this.videoCurrentlyPlaying = false;

    this.subscription = this._eventEmiter.subscribe(newGroupEvent => {
      if (newGroupEvent.actionType === 'SubscribeVideoChat' || newGroupEvent.actionType === 'openVideoChatPanel') {
        if (newGroupEvent.subscriptionData !== undefined) {
          this.subscriptionRData = newGroupEvent.subscriptionData;
        }
        this.onSetLeftContainerVisibility(this.videoChatModuleId);
        this.handleVideoShowHide();
        this.videoCurrentlyPlaying = true;
      } else if (newGroupEvent.actionType === 'endVideoChat') {
        this.videoCurrentlyPlaying = false;
        this.onSetLeftContainerVisibility(0);
      }
    });
  }

  configureMSTeamView() {
    const appSource = this.sharedDataService.getMobileViewConfiguration();
    if (appSource != null && appSource.Source === MobileSources.MSTeam) {
      this.centerPanelCSS = 'icf_msteam';
      if (appSource.Command.toLocaleLowerCase() === 'dashboard' || appSource.Command.toLocaleLowerCase() === 'none') {
        this.showFlyMenu = false;
      } else {
        this.showFlyMenu = true;
      }
    } else {
      this.centerPanelCSS = 'leftmenu_margin';
      this.showFlyMenu = false;
    }
    this.sharedDataService.getAppModuleIdSubject().subscribe(resp => {
      this.onSetLeftContainerVisibility(resp);
    });
  }

  ngOnDestroy() {
    this._eventEmiter.unsubscribe(this.subscription);
  }

  renderGoals() {
    this.showGoals = true;
    $('#goals').addClass('selected');
    $('#pending').removeClass('selected');
  }

  renderPendingTasks() {
    this.showGoals = false;
    $('#goals').removeClass('selected');
    $('#pending').addClass('selected');
  }

  onSetLeftContainerVisibility(appModuleId) {
    if (this.videoCurrentlyPlaying && appModuleId === 0) {
      // When video chat is going on, show video chat panel when no panel is visible.
      this.appModuleId = 9;
      this.sharedDataService.setSelectedAppModuleId(this.appModuleId);
    } else {
      this.appModuleId = appModuleId;
      this.sharedDataService.setSelectedAppModuleId(this.appModuleId);
    }

    if (this.appModuleId > 0) {
      this._eventEmiter.emit({ actionType: EventEmiterTypeEnum.ModuleOpened });
    } else {
      this._eventEmiter.emit({ actionType: EventEmiterTypeEnum.ModuleClosed });
    }
    this.handleVideoShowHide();
  }

  // logout() {
  //   this.authService.logout();
  // }

  startSurvey() {
    this.surveyService.getPulseSurveyDetails().subscribe(resp => {
      resp.reverse().forEach(surveyDetails => {
        const dialogConfig = new MatDialogConfig();
        dialogConfig.width = ModalPopupSizeEnum.PulseSurveyModalWidth + 'px';
        dialogConfig.disableClose = true;
        dialogConfig.data = surveyDetails;
        this.dialog.open(SurveyCreatorComponent, dialogConfig);
      });
    });
  }

  handleVideoShowHide(): boolean {
    if (this.appModuleId > 0) {
      if (this.appModuleId === this.videoChatModuleId) {
        this.videoCurrentlyPlaying = true;
        return true;
      } else {
        return false;
      }
    } else {
      this.videoCurrentlyPlaying = false;
      return false;
    }
  }

  onFullScreenVideoPanel() {
    if (this.handleVideoShowHide()) {
      if (this.showFullScreen) {
        return 'whitebg leftcontainer100 display';
      } else {
        return 'whitebg leftcontainer display';
      }
    } else {
      return 'nodisplay';
    }
  }

  onFullScreenVideoPanelFunc(showFullScreen: boolean) {
    this.showFullScreen = showFullScreen;
    this.onFullScreenVideoPanel();
  }

  openMenu() {
    const appSource = this.sharedDataService.getMobileViewConfiguration();
    if (appSource) {
      switch (appSource.Command.toLocaleLowerCase()) {
        case 'none':
          this.onSetLeftContainerVisibility(ApplicationModuleListEnum.None);
          break;
        case 'analyze':
          this.onSetLeftContainerVisibility(ApplicationModuleListEnum.Analyze);
          break;
        case 'assess':
          this.onSetLeftContainerVisibility(ApplicationModuleListEnum.Assess);
          break;
        case 'coach':
          this.onSetLeftContainerVisibility(ApplicationModuleListEnum.Coach);
          break;
        case 'connect':
          this.onSetLeftContainerVisibility(ApplicationModuleListEnum.Connect);
          break;
        case 'learn':
          this.onSetLeftContainerVisibility(ApplicationModuleListEnum.Learn);
          break;
        case 'configuration':
          this.onSetLeftContainerVisibility(ApplicationModuleListEnum.Configuration);
          break;
        case 'poll':
          this.onSetLeftContainerVisibility(ApplicationModuleListEnum.Poll);
          break;
      }

    }
  }
}
