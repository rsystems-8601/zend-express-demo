import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MobileRoutingComponent } from './mobile-routing.component';

describe('MobileRoutingComponent', () => {
  let component: MobileRoutingComponent;
  let fixture: ComponentFixture<MobileRoutingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MobileRoutingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MobileRoutingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
