import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { UserService } from 'src/app/services/user.service';
import { IcftoasterService } from 'src/app/services/icftoaster.service';

// Dummy Component used for routing user from v5 to v6.
@Component({
  selector: 'app-routing',
  templateUrl: './routing.component.html',
  styleUrls: ['./routing.component.scss']
})
export class RoutingComponent implements OnInit {

  constructor(
    private router: Router,
    private userService: UserService,
    private toast: IcftoasterService,
    private route: ActivatedRoute
  ) { }

  ngOnInit() {
    this.userService.fetchUserDetails(userInfo => {
      if (userInfo.IsAuthSuccess === 'True' && this.route.snapshot.params['command'] && this.route.snapshot.params['command'] === 'manage') {
        this.router.navigate(['/iCoachFirst/manage/manage', this.route.snapshot.params['coacheeId']]);
      } else if (userInfo.IsAuthSuccess === 'True') {
        this.router.navigate(['/iCoachFirst/dashboard']);
      } else {
        this.toast.error(userInfo.LoginError);
      }
    });
  }

}
