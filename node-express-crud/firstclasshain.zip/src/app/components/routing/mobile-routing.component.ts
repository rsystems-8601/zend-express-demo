import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mobile-routing',
  templateUrl: './mobile-routing.component.html',
  styleUrls: ['./mobile-routing.component.scss']
})
export class MobileRoutingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
