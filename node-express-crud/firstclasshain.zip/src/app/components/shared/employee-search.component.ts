import { Component, OnInit, Input, OnDestroy, ElementRef, ViewChild } from '@angular/core';
import { FormControl, } from '@angular/forms';
import { Observable, Subscription } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import { Router } from '@angular/router';
import { EmployeeSearchService } from '../../services/employee-search.service';
import { IEmployeeSearchRequest } from '../../models/requests/employee-search-request';

import { UserService } from 'src/app/services/user.service';
import { EventEmiterService } from 'src/app/services/event.emmiter.service';
import { UserDetails } from 'src/app/models/user-details-result';
import { ManageUrlRequest } from 'src/app/models/requests/url-builder/manage-url-request';
import * as $ from 'jquery';
import { IEmployeeSearch } from 'src/app/models/response/iemployee-search-response';
import { CommonService } from 'src/app/services/common.service';
import { SharedDataService } from 'src/app/services/shared-data.service';

@Component({
  selector: 'app-employee-search',
  templateUrl: './employee-search.component.html',
  styleUrls: ['./employee-search.component.scss'],
  providers: [EmployeeSearchService]
})
export class EmployeeSearchComponent implements OnInit, OnDestroy {

  @Input() callingSource: string;
  request = {} as IEmployeeSearchRequest;
  employeeControl = new FormControl();
  employeesList: IEmployeeSearch[] = [];
  cachedEmployeeList: IEmployeeSearch[] = [];
  employeeSelected = '';
  filteredOptions: Observable<IEmployeeSearch[]>;
  userInfo: UserDetails;
  manageUrl: string;
  serachEmpIdOnKeyDown: any;
  selectedSearch: string;
  private subscription: Subscription;
  onlineUsers = [];
  onlineUsersCollection: Subscription;
  @ViewChild('autoCompleteInput') el2Search: ElementRef;

  constructor(private _service: EmployeeSearchService,
    private userService: UserService,
    private _eventEmiter: EventEmiterService,
    private router: Router,
    private commonService: CommonService,
    private sharedDataService: SharedDataService,
  ) {

    this.subscription = this._eventEmiter.subscribe(data => {

      if (data.keyName === 'resetAutoComplete') {
        this.resetUI();
      }
    });
  }

  ngOnInit() {
    this.userInfo = this.userService.getUserDetails().UserDetails;
    this.cachedEmployeeList = this.commonService.getEmployeeSearchData();
    if (this.cachedEmployeeList.length === 0) {
      this.getEmployeeList();
    } else {
      if (this.callingSource === 'Dashboard') {
        this.employeesList = this.cachedEmployeeList.filter(e => e.EmpID !== this.userInfo.EmpId);
      } else {
        this.employeesList = this.cachedEmployeeList;
      }
    }

    this.filteredOptions = this.employeeControl.valueChanges
      .pipe(
        startWith(''),
        map(value => value.length >= 3 ? this._filter(value) : [])
      );

    
  }

  ngOnDestroy() {
    this._eventEmiter.unsubscribe(this.subscription);
  }

  getEmployeeList() {
    this.request.EmpId = this.userInfo.EmpId;
    this.request.RowOffSet = 4;
    this.request.RecordCount = 7;
    this.request.SearchCriteria = '';
    this.request.IsRequiredAllData = true; // This is to get all the employee list in the organisation.

    this._service.getEmployeeSearch(this.request).subscribe(data => {
      this.employeesList = data.EmployeeListForProvideFeedbackResult;
      this.commonService.setEmployeeSearchData(this.employeesList);

      if (this.callingSource === 'Dashboard') {
        this.employeesList = this.employeesList.filter(e => e.EmpID !== this.userInfo.EmpId);
      }

      // data.EmployeeListForProvideFeedbackResult.forEach(employee => {
      //   this.employeesList.push(employee);
      // });
    });
  }

  private _filter(value: string): IEmployeeSearch[] {
    const filterValue = value.toLowerCase();
    if (filterValue) {
      this.GetOnlineOfflineUsers();
      return this.employeesList.filter(option => (option.FirstName + ' ' + option.LastName + ' ' + option.EmailID).toLowerCase().includes(filterValue));
    } else {
      this._eventEmiter.emit({ observerData: null, keyName: this.callingSource });
      return this.employeesList;
    }
  }

  GetOnlineOfflineUsers() {
    this.onlineUsersCollection = this.sharedDataService.getOnlineUsersCollection().subscribe(response => {
      this.onlineUsers = response;
        if (this.employeesList !== undefined && this.employeesList.length > 0) {
          this.employeesList.forEach(teamMember => {
            // if (team.groupType === 'myteam') {
              const userOnline = this.onlineUsers.find(obj => obj === teamMember.EmailID.trim());
              if (userOnline !== undefined) {
                teamMember.isUserOnline = true;
              } else {
                teamMember.isUserOnline = false;
              }
            // }
          });
        }
    });
  }

  onEmployeeSelectionChanged(selectedEmployee): any {
    if (this.callingSource === 'Task' || this.callingSource === 'goalLinking') {
      this._eventEmiter.emit({ observerData: selectedEmployee, keyName: 'AddObserver' });
    } else if (this.callingSource === 'ReportTo' || this.callingSource === 'OriginalChannelPartner'
      || this.callingSource === 'DottedLineTo' || this.callingSource === 'Notification' || this.callingSource === 'calllingSourceAssignment'
      || this.callingSource === 'calllingSourceFeedbackRequest') {
      this._eventEmiter.emit({ observerData: selectedEmployee, keyName: this.callingSource });
    } else {
      // this.openManageInIframe(selectedEmployee);
      this.chnageFocus();
      this.openManage(selectedEmployee);
      this.resetUI();
    }
  }

  resetUI() {
    this.employeeSelected = '';
  }

  chnageFocus() {
    if (window.document.getElementsByClassName('designationIndex').length > 0) {
      const userFocus: any = window.document.getElementsByClassName('designationIndex')[0];
      userFocus.focus();
      userFocus.blur();
    }
  }

  createManageUrlRequest(selectedEmployee: any): ManageUrlRequest {
    const request = {} as ManageUrlRequest;
    this.userInfo = this.userService.getUserDetails().UserDetails;
    request.CoachId = this.userInfo.EmpId;
    request.CoacheeId = selectedEmployee['EmpID'];
    request.EmployeeId = selectedEmployee['EmployeeID'];
    request.MemberOrgId = this.userInfo.MemberOrgID;
    request.Source = 'icf6';
    request.RedirectTo = 'dashboard';
    request.ICF5IFramePageToOpen = 'manage';
    return request;
  }

  openManage(selectedEmployee: any) {
    // opens manage act for the selected user
    this.router.navigate(['/iCoachFirst/manage/manage', selectedEmployee['EmpID']]);
  }

  searchOnEnter(e: any) {
    const code = e.keyCode || e.which;
    if (code === 13) {
      if (typeof this.serachEmpIdOnKeyDown !== 'undefined' && this.serachEmpIdOnKeyDown > 0) {
        this.chnageFocus();
        $('.dashboard_user').trigger('click');
        this.resetUI();
        this.router.navigate(['/iCoachFirst/manage/manage', this.serachEmpIdOnKeyDown]);
      }
    }
  }

  setOnEnter(e: any) {
    if (this.el2Search.nativeElement.value === '') {
      this._eventEmiter.emit({ observerData: null, keyName: this.callingSource });
      return;
    }

    if (e.srcElement.attributes[14] !== undefined && e.srcElement.attributes[14].nodeValue > 0) {
      this.serachEmpIdOnKeyDown = e.srcElement.attributes[14].nodeValue;
    } else if (e.srcElement.attributes[4] !== undefined && e.srcElement.attributes[4].nodeValue > 0) {
      this.serachEmpIdOnKeyDown = e.srcElement.attributes[4].nodeValue;
    } else if (e.srcElement.attributes[4] !== undefined) {
      if (window.document.getElementsByClassName('mat-active') !== undefined) {
        if (window.document.getElementsByClassName('mat-active')[0] !== undefined) {
          this.serachEmpIdOnKeyDown = window.document.getElementsByClassName('mat-active')[0].getAttribute('id');
        }
      }
    }
  }

}
