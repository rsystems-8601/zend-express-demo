import { Component, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { DialogData } from '../../../models/dialog-data';

@Component({
  selector: 'app-custom-modal',
  templateUrl: './iframe-modal.component.html',
  styleUrls: ['./iframe-modal.component.scss']
})
export class IframeModalComponent {

  constructor(public dialogRef: MatDialogRef<IframeModalComponent>,
    @Inject(MAT_DIALOG_DATA) public dialogData: DialogData) { }

  close() {
    if (this.dialogData.url.indexOf('MyProfile') > -1) {
      this.dialogRef.close('success');
    } else {
      this.dialogRef.close();
    }
  }

}
