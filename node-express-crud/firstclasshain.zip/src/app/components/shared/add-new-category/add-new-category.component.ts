import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material';
import { SolicitMultiRaterFeedbackService } from 'src/app/services/solicit-multi-rater-feedback.service';
import { IcftoasterService } from 'src/app/services/icftoaster.service';

@Component({
  selector: 'app-add-new-category',
  templateUrl: './add-new-category.component.html',
  styleUrls: ['./add-new-category.component.scss']
})
export class AddNewCategoryComponent implements OnInit {

  category: string;
  invalid = false;
  constructor(
    public self: MatDialogRef<AddNewCategoryComponent>,
    private solicitService: SolicitMultiRaterFeedbackService,
    private toast: IcftoasterService
  ) { }

  ngOnInit() {
  }

  submit(): void {
    if (this.category && this.category.trim()) {
      this.saveNewCategory(this.category);
    } else {
      this.invalid = true;
      return;
    }
  }

  close(): void {
    this.self.close();
  }

  saveNewCategory(category: string): void {
    this.solicitService.saveSolicitFeedbackCategory(category).subscribe(resp => {
      if (resp.ResponseCode.toLowerCase() === 'success' && resp.Status) {
        this.self.close(this.category);
      } else if (resp.ResponseCode.toLowerCase() === 'duplicate' && !resp.Status) {
        this.toast.error('Category Already Exists');
      } else {
        this.toast.error('OperationFailedMessage');
      }
    });
  }

}
