import { Component, OnInit, Inject } from '@angular/core';
import { KeyValuePair } from 'src/app/models/key-value-pair';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';

@Component({
  selector: 'app-generic-popup',
  templateUrl: './generic-popup.component.html',
  styleUrls: ['./generic-popup.component.scss']
})
export class GenericPopupComponent implements OnInit {

  popupData: KeyValuePair[] = [];
  constructor(
    @Inject(MAT_DIALOG_DATA) public data: KeyValuePair[],
    public dialogRef: MatDialogRef<GenericPopupComponent>
  ) { }

  ngOnInit() {
    this.popupData = this.data;
  }

  closePopup() {
    this.dialogRef.close();
  }

}
