import { Component, Inject, OnInit, OnDestroy } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { DialogData } from '../../../models/dialog-data';
import { Router } from '@angular/router';
import { EventEmiterService } from 'src/app/services/event.emmiter.service';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-custom-noborder--modal',
  templateUrl: './iframe-noborder-modal.component.html',
  styleUrls: ['./iframe-noborder-modal.component.scss']
})
export class IframeNoborderModalComponent implements OnInit, OnDestroy {

  isProfileModal = true;
  callBackComplete: boolean;

  constructor(
    public dialogRef: MatDialogRef<IframeNoborderModalComponent>,
    private router: Router,
    private _eventEmiter: EventEmiterService,
    @Inject(MAT_DIALOG_DATA) public dialogData: DialogData,
    private authService: AuthService
  ) {
    if (this.dialogData.url.indexOf('MyProfile') === -1) {
      this.isProfileModal = false;
    }
  }

  ngOnInit(): void {
    if (!this.isProfileModal) {
      window.addEventListener('message', this.handleIframeTask.bind(this), false);
      this.callBackComplete = false;
    }
  }

  close() {
    if (this.isProfileModal) {
      this.dialogRef.close('success');
    } else {
      this.dialogRef.close();
    }
  }
  handleIframeTask(e) {

    window.removeEventListener('message', () => { });
    // Member variable this.callBackComplete will be false if user refreshes the url
    // and it will be true if user open this same component again and again
    // so added the check using variable
    if (!this.callBackComplete) {
      if (e.data.redirectTo === undefined) {
        // the redirectTo will be undefined if user directly refreshes the url
        // added because this func is getting fired first if user refreshes url directly.
        return;
      }

      if (e.data.redirectTo && e.data.redirectTo === 'logout') {
        this.authService.commonLogout();
      }

      // to redirect from icf6 task rating pop up to close the pop up and refresh the pending rating list in background.
      if (e.data.source === 'Save') {
        this.callBackComplete = true;
        this.dialogRef.close();
        this._eventEmiter.emit({ actionType: 'ReloadActData' });
      } else if (e.data.source === 'Close') {
        this.dialogRef.close();
      } else {
        // If userdirectly refreshes the url the redirect value will will be undefined.
        this.router.navigate(['/iCoachFirst/dashboard']);
      }
    }

  }


  ngOnDestroy() {
    this.callBackComplete = true;
    window.removeEventListener('message', () => { });
  }

}
