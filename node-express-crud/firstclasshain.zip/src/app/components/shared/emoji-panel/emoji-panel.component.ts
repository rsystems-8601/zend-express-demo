import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-emoji-panel',
  templateUrl: './emoji-panel.component.html',
  styleUrls: ['./emoji-panel.component.scss'],
})

export class EmojiPanelComponent implements OnInit {
  constructor() { }
  @Input() result = {};
  @Input() showEmojis = false;
  @Output() onEmojiSelect: EventEmitter<string> = new EventEmitter();

  imagePath = 'assets/images/emoji/';
  extension = '.png';
  emojiList = [];

  codePoint(emojiCodePoint: number) {
    return String.fromCodePoint(emojiCodePoint);
  }
  onClick(index: number) {
    const emoji = this.emojiList[index];
    this.onEmojiSelect.emit(emoji);
  }

  ngOnInit() {
    this.emojiList = [
      '1f600', '1f601', '1f642', '1f60d', '1f61c', '1f914', '1f610', '1f641', '1f615', '2764',
      '1f4a4', '1f44c', '1f44d', '1f44e', '2615', '1f30d', '1f3c6', '1f197', '2614', '2708'
    ];
  }

}

