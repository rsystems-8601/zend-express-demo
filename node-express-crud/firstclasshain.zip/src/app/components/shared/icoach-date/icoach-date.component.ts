import { Component, Input, forwardRef, AfterViewInit, ViewChild, ElementRef, Output, EventEmitter } from '@angular/core';
import { DateConfig } from 'src/app/models/date-config';
import { NG_VALUE_ACCESSOR, FormControl, ControlValueAccessor } from '@angular/forms';
import { CalendarService } from 'src/app/services/calendar.service';
import { DatePipe } from '@angular/common';
import { EventEmiterService } from 'src/app/services/event.emmiter.service';
import { Subscription } from 'rxjs';

export const CUSTOM_INPUT_CONTROL_VALUE_ACCESSOR: any = {
  provide: NG_VALUE_ACCESSOR,
  // tslint:disable-next-line: no-use-before-declare
  useExisting: forwardRef(() => IcoachDateComponent),
  multi: true
};

@Component({
  selector: 'app-icoach-date',
  templateUrl: './icoach-date.component.html',
  styleUrls: ['./icoach-date.component.scss'],
  providers: [CUSTOM_INPUT_CONTROL_VALUE_ACCESSOR],
})
export class IcoachDateComponent implements ControlValueAccessor, AfterViewInit {

  @Input()
  public name: string;

  @Input()
  public minDate: string;

  @Input()
  public required: string;

  @Input()
  public model: string;

  @Input()
  public id: string;

  @Input()
  public inputClasses: string;

  @Input()
  public iconClasses: string;

  @Input()
  public placeholder: string;

  @Input()
  public isDiv = false;

  @Output()
  notifyParent: EventEmitter<any> = new EventEmitter();


  // current form control input. helpful in validating and accessing form control
  @Input() c: FormControl = new FormControl();

  // The internal data model for form control value access
  private innerValue: any = '';

  // get reference to the input element
  @ViewChild('input') inputRef: ElementRef;

  //private _picker: BsDatepickerDirective;
  // errors for the form control will be stored in this array
  errors: Array<any> = ['This field is required'];

  bsConfig: DateConfig;
  subscription: Subscription;

  constructor(
    private calendarService: CalendarService,
    private datePipe: DatePipe,
    private _eventEmiter: EventEmiterService
  ) {
    this.bsConfig = this.calendarService.getCalendarConfig();
  }


  // Lifecycle hook. angular.io for more info
  ngAfterViewInit() {
    if (!this.isDiv) {
      // set placeholder default value when no input given to pH property
      if (this.placeholder === undefined || this.placeholder === '') {
        this.placeholder = 'MM/DD/YYYY';
      }
      // RESET the custom input form control UI when the form control is RESET
      this.c.valueChanges.subscribe(
        () => {
          // check condition if the form control is RESET
          if (this.c.value === '' || this.c.value === null || this.c.value === undefined) {
            this.innerValue = '';
            // this.inputRef.nativeElement.value = '';
          }
        }
      );
    }

    this.subscription = this._eventEmiter.subscribe(data => {
      if (data.keyName === 'resetDate') {
        this.resetUI();
      }
    });

  }

  // get accessor
  get value(): any {
    return this.innerValue;
  }

  // set accessor including call the onchange callback
  set value(v: any) {
    if (v !== this.innerValue) {
      this.innerValue = v;
    }
  }

  // propagate changes into the custom form control
  propagateChange = (_: any) => {

  }

  writeValue(value: any): void {
    this.innerValue = value;
  }
  registerOnChange(fn: any): void {
    this.propagateChange = fn;
  }
  registerOnTouched(): void {

  }


  // event fired when input value is changed . later propagated up to the form control using the custom value accessor interface
  // To notify the parent component regarding the change in the value in case of div component
  onChange(pop: any) {
    this.model = this.datePipe.transform(pop._bsValue, 'MM/dd/yyyy');
    pop._bsValue = this.model;
    this.innerValue = this.model;
    this.propagateChange(this.model);
    this.notifyParent.emit(pop);
  }

  onShowPicker(event) {
    const dayHoverHandler = event.dayHoverHandler;
    const hoverWrapper = (hoverEvent) => {
      const { cell, isHovered } = hoverEvent;

      if ((isHovered &&
        !!navigator.platform &&
        /iPad|iPhone|iPod/.test(navigator.platform)) &&
        'ontouchstart' in window
      ) {
        (this.bsConfig as any)._datepickerRef.instance.daySelectHandler(cell);
      }

      return dayHoverHandler(hoverEvent);
    };
    event.dayHoverHandler = hoverWrapper;
  }

  resetUI() {
    this.model = '';
  }

}
