import { Component, OnInit } from '@angular/core';

// Custom
import { UserService } from '../../../services/user.service';
import { UserProfileService } from '../../../services/user-profile.service';
import { AuthService } from '../../../services/auth.service';

import { MatDialog, MatDialogConfig } from '@angular/material';
import { IUserProfileUrlRequest } from 'src/app/models/requests/url-builder/user-profile-url-request';
import { UserDetails } from 'src/app/models/user-details-result';
import { IframeModalComponent } from '../iframe-modal/iframe-modal.component';
import { LanguageSelectionComponent } from '../../user-settings/language-selection/language-selection.component';
import { LocalizationService } from 'src/app/services/localization.service';
import { TalentCulture } from '../../../models/response/talentCulture';
import { environment } from 'src/environments/environment';
import { IcftoasterService } from 'src/app/services/icftoaster.service';
import { EventEmiterService } from 'src/app/services/event.emmiter.service';

@Component({
  selector: 'app-head-panel',
  styleUrls: ['./head-panel.component.scss'],
  templateUrl: './head-panel.component.html'
})

export class HeadPanelComponent implements OnInit {
  userInfo: UserDetails;
  isClassicViewVisible = false;
  ProfileImage: string;
  CompanyLogo: string;
  Name: string;
  Designation: string;
  calllingSourceDashboard = 'Dashboard';
  constructor(private userService: UserService,
    private authService: AuthService,
    private profileService: UserProfileService,
    private dialog: MatDialog,
    private localizationService: LocalizationService,
    private _eventEmiter: EventEmiterService,
    private toast: IcftoasterService) { }

  ngOnInit() {
    this.userInfo = this.userService.getUserDetails().UserDetails;
    if (this.userInfo.EnableClassicView) {
      this.isClassicViewVisible = true;
    }
    this.ProfileImage = this.userInfo.ProfileImageName === '' ? 'assets/images/blank_image.png' : this.userInfo.ProfileImageName;
    this.CompanyLogo = this.userInfo.FileName === '' ? 'assets/images/logo.png' : this.userInfo.FileName;
    this.Name = this.userInfo.Name;
    this.Designation = this.userInfo.Designation;
  }

  logout() {
    this.authService.commonLogout();
  }
  openMyProfileMatPop(pagePath: string) {
    const request = {} as IUserProfileUrlRequest;
    request.EmpId = this.userInfo.EmpId;
    request.EmpName = this.userInfo.Name;
    request.MemberOrgID = this.userInfo.MemberOrgID;
    request.IsMyProfile = true;
    request.Source = 'icf6';
    request.PagePath = pagePath;
    request.eid = this.userInfo.EmployeeId;
    request.Culture = 'en';

    const reportUrl = this.profileService.getUserProfilePageUrl(request);
    const dialogConfig = new MatDialogConfig();
    dialogConfig.width = 900 + 'px';
    dialogConfig.disableClose = true;
    dialogConfig.data = { url: reportUrl };
    const dialogRef = this.dialog.open(IframeModalComponent, dialogConfig);
    dialogRef.afterClosed().subscribe(value => {
      if (value) {
        this.userService.fetchUserAllDetails(userInfoReturn => {
          this._eventEmiter.emit({ keyName: 'ReloadProfileImage', observerData: userInfoReturn });
          this.ProfileImage = userInfoReturn.UserDetails.ProfileImageName === '' ? 'assets/images/blank_image.png' : userInfoReturn.UserDetails.ProfileImageName;
          this.Name = userInfoReturn.UserDetails.Name;
          this.Designation = userInfoReturn.UserDetails.Designation;
        });
      }
    });
  }
  openLanguageSelectionMatPop() {
    let culturalData: TalentCulture[] = null;
    this.localizationService.getCultureSupportDetails().subscribe(data => {
      culturalData = data;
      const dialogConfig = new MatDialogConfig();
      dialogConfig.width = 700 + 'px';
      // dialogConfig.data = {localeList: culturalData };
      dialogConfig.disableClose = true;
      const modalRef = this.dialog.open(LanguageSelectionComponent, dialogConfig);
      modalRef.componentInstance.data = culturalData;
    });
  }

  // Switch back to Classic View (v5)
  switchToClassicView() {
    const loginId = this.userInfo.EncryptedEmailID;
    const orgId = this.userInfo.MemberOrgID;
    const culture = this.localizationService.getCutureCode();
    this.authService.switchToClassicView(loginId, orgId, culture).subscribe(success => {
      if (success.status === 'ok' && success.result === 'done') {
        window.location.href = `${environment.domainName}/talentfirst/talentfirstv3/Dashboard.aspx`;
      } else {
        this.toast.error('Common_Error_ContactAdmin');
      }
    });
  }
}
