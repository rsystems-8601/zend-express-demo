import { Component, OnInit, Output, EventEmitter, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
// Custom
import { AuthService } from '../../../services/auth.service';
import { ApplicationModuleListEnum } from '../../../helpers/enums/common-enums';
import { RolesService } from 'src/app/services/roles.service';
import { EventEmiterService } from 'src/app/services/event.emmiter.service';
import { Subscription } from 'rxjs';
// import { EventEmitter } from 'events';
import { UserDetails, ListMenuConfiguration } from 'src/app/models/user-details-result';
import { UserService } from '../../../services/user.service';
import { LocalizationService } from 'src/app/services/localization.service';
import { environment } from 'src/environments/environment';
import { IcftoasterService } from 'src/app/services/icftoaster.service';
import { AdminUrlBuilderService } from 'src/app/services/admin-url-builder.service';
import { SharedDataService } from 'src/app/services/shared-data.service';
import { AdminUrlRequest } from 'src/app/models/requests/url-builder/admin-url-request';
import { ConnectMessageService } from 'src/app/services/connect-message.service';

@Component({
  selector: 'app-left-panel',
  templateUrl: './left-panel.component.html',
  styleUrls: ['./left-panel.component.scss']
})

export class LeftPanelComponent implements OnInit, OnDestroy {
  connectModuleId: number = ApplicationModuleListEnum.Connect;
  coachModuleId: number = ApplicationModuleListEnum.Coach;
  learnModuleId: number = ApplicationModuleListEnum.Learn;
  dashboardReportModuleId: number = ApplicationModuleListEnum.Analyze;
  assessModuleId: number = ApplicationModuleListEnum.Assess;
  configurationModuleId: number = ApplicationModuleListEnum.Configuration;
  pollModuleId: number = ApplicationModuleListEnum.Poll;
  videoChatModuleId: number = ApplicationModuleListEnum.VideoChat;
  menuLable: string;
  menuItemClass: string;
  listMenuConfiguration: ListMenuConfiguration[];
  listMenuConfigurationPrimary: ListMenuConfiguration[];
  listMenuConfigurationAdmin: ListMenuConfiguration[];
  newConnectMessage = false;
  selectedModuleId = 0;
  isClassicViewVisible = false;
  notificationLable: String = '';
  userCulture: String = '';
  IsAdmin: Boolean = false;

  @Output() setLeftContainerVisibility: EventEmitter<number> = new EventEmitter<number>();

  private subscription: Subscription;

  userInfo: UserDetails;

  constructor(private authService: AuthService,
    private router: Router,
    private roleService: RolesService,
    private _eventEmiter: EventEmiterService,
    private userService: UserService,
    private localizationService: LocalizationService,
    private toast: IcftoasterService,
    private adminUrlBuilderService: AdminUrlBuilderService,
    private sharedDataService: SharedDataService,
    private connectService: ConnectMessageService) { }

  ngOnInit() {
    this.subscribeEvents();
    this.userInfo = this.userService.getUserDetails().UserDetails;
    if (this.userInfo.EnableClassicView) {
      this.isClassicViewVisible = true;
    }

    this.listMenuConfiguration = this.userService.getUserDetails().UserDetails.V6MenuConfigurationJson;
    this.listMenuConfigurationPrimary = this.listMenuConfiguration.filter(
      objData => (objData.MenuLabelName !== 'Administration' && objData.MenuLabelName !== 'Employee Roster' && objData.MenuLabelName !== 'Configuration') && objData.OnOffValue);
    this.listMenuConfigurationAdmin = this.listMenuConfiguration.filter(objData => (objData.MenuLabelName === 'Administration' || objData.MenuLabelName === 'Employee Roster' || objData.MenuLabelName === 'Configuration') && objData.OnOffValue);

    this.listMenuConfigurationPrimary.forEach((menu: ListMenuConfiguration) => {
      if (menu.ModuleName === 'videoChat') {
        menu.customHideVideoChatModule = true;
      } else {
        menu.customHideVideoChatModule = false;
      }
    });

    this.selectLeftPanelIcon();
    this.IsAdmin = this.userService.getUserDetails().UserDetails.IsAdmin;
  }

  ngOnDestroy() {
    this._eventEmiter.unsubscribe(this.subscription);
  }

  logout() {
    this.connectService.unSubscribe();
    this.authService.commonLogout();
  }
  onSetLeftContainerVisibility(moduleName: string) {
    if (moduleName === '') {
      this.selectedModuleId = 0;
      this._eventEmiter.emit({ keyName: 'GoToHome' });
      this.router.navigate(['/iCoachFirst/dashboard']);
    } else {
      if (this.roleService.hasPermission(moduleName)) {
        if (moduleName === 'CNT') {
          this.selectedModuleId = this.connectModuleId;
        } else if (moduleName === 'CDR') {
          this.selectedModuleId = this.coachModuleId;
        } else if (moduleName === 'TRN') {
          this.selectedModuleId = this.learnModuleId;
        } else if (moduleName === 'PRF') {
          this.selectedModuleId = this.assessModuleId;
        } else if (moduleName === 'DSHRPT') {
          this.selectedModuleId = this.dashboardReportModuleId;
        } else if (moduleName === 'Config') {
          this.selectedModuleId = this.configurationModuleId;
        } else if (moduleName === 'videoChat') {
          this.selectedModuleId = this.videoChatModuleId;
        } else if (moduleName.toLocaleLowerCase() === 'poll') {
          this.selectedModuleId = this.pollModuleId;
        }
        this.setLeftContainerVisibility.emit(this.selectedModuleId);
      }
    }
  }
  isCustomText(menu: ListMenuConfiguration) {
    if (menu.EnableValue) {
      return this.menuLable = menu.CustomLabelText;
    }
    return this.menuLable = menu.MenuLabelName;
  }
  isNotificationsSelected(menu: ListMenuConfiguration) {
    if (menu.MenuLabelName === 'Notifications') {
      return this.notificationLable = 'New';
    }
  }
  iconClass(menu: ListMenuConfiguration) {
    if (menu.MenuIcon === '') {
      switch (menu.MenuLabelName) {
        case ('Home'):
          return 'fas fa-home';
        case ('Notifications'):
          return 'fas fa-bell';
        case ('Coach'):
          return 'fas fa-users';
        case ('Learn'):
          return 'fas fa-graduation-cap';
        case ('Assess'):
          return 'far fa-edit';
        case ('Analyze'):
          return 'fas fa-chart-bar';
        case ('Poll'):
          return 'fas fa-poll-h';
      }
    }
  }
  menuClass(menu: ListMenuConfiguration) {
    switch (menu.MenuLabelName) {
      case ('Home'):
        if (this.selectedModuleId === 0) {
          this.menuItemClass = 'selected';
        } else {
          this.menuItemClass = '';
        }
        break;
      case ('Notifications'):
        if (this.selectedModuleId === this.connectModuleId) {
          this.menuItemClass = 'position-relative selected';
        } else {
          this.menuItemClass = 'position-relative';
        }
        break;
      case ('Coach'):
        if (this.selectedModuleId === this.coachModuleId) {
          this.menuItemClass = 'selected';
        } else {
          this.menuItemClass = '';
        }
        break;
      case ('Learn'):
        if (this.selectedModuleId === this.learnModuleId) {
          this.menuItemClass = 'selected';
        } else {
          this.menuItemClass = '';
        }
        break;
      case ('Assess'):
        if (this.selectedModuleId === this.assessModuleId) {
          this.menuItemClass = 'selected';
        } else {
          this.menuItemClass = '';
        }
        break;
      case ('Analyze'):
        if (this.selectedModuleId === this.dashboardReportModuleId) {
          this.menuItemClass = 'selected';
        } else {
          this.menuItemClass = '';
        }
        break;
      case ('videoChat'):
        if (this.selectedModuleId === this.videoChatModuleId) {
          this.menuItemClass = 'selected';
        } else {
          this.menuItemClass = '';
        }
        break;
      case ('Poll'):
        if (this.selectedModuleId === this.pollModuleId) {
          this.menuItemClass = 'selected';
        } else {
          this.menuItemClass = '';
        }
        break;
    }
    return this.menuItemClass;
  }

  openAdminmenuItem(menu: ListMenuConfiguration) {
    if (menu.MenuLabelName === 'Administration') {
      this.selectedModuleId = 0;
      this.setLeftContainerVisibility.emit(this.selectedModuleId);
      const adminUrl = this.adminUrlBuilderService.adminInIframeUrl(this.createUrlRequest());
      const queryParam = encodeURI(adminUrl);
      this.sharedDataService.setData(adminUrl);
      this.sharedDataService.setRedirectionValue(this.getRedirectionValueFromIframe());
      this.router.navigate(['/iCoachFirst/admin/admin-viewer'], { queryParams: { encodedUrl: queryParam } });
    } else if (menu.MenuLabelName === 'Employee Roster') {
      this.selectedModuleId = 0;
      this.setLeftContainerVisibility.emit(this.selectedModuleId);
      this.router.navigate(['/iCoachFirst/admin/employee-roster']);
    } else if (menu.ModuleName === 'Config') {
      this.selectedModuleId = this.configurationModuleId;
      this.setLeftContainerVisibility.emit(this.selectedModuleId);
      // this.router.navigate(['/iCoachFirst/admin/configuration']);
    } else if (menu.MenuLabelName.toLocaleLowerCase() === 'poll') {
      this.selectedModuleId = 0;
      this.setLeftContainerVisibility.emit(this.selectedModuleId);
      this.router.navigate(['/iCoachFirst/poll/report']);
    } else {
      this.selectedModuleId = 0;
      this.setLeftContainerVisibility.emit(this.selectedModuleId);
    }
  }

  createUrlRequest(): AdminUrlRequest {
    const request = {} as AdminUrlRequest;
    this.userInfo = this.userService.getUserDetails().UserDetails;
    request.CoachId = this.userInfo.EmpId;
    request.EmployeeId = this.userInfo.EmployeeId;
    request.MemberOrgId = this.userInfo.MemberOrgID;
    request.Source = 'icf6';
    request.RedirectTo = this.getRedirectionValueFromIframe();
    request.ICF5IFramePageToOpen = 'manage';
    request.Culture = this.localizationService.getICF6CultreFromLocalStorage().CultureCode;
    return request;
  }

  navigateToHome() {
    this.selectedModuleId = 0;
    this._eventEmiter.emit({ keyName: 'GoToHome' });
    this.router.navigate(['/iCoachFirst/dashboard']);
  }

  subscribeEvents() {

    this.subscription = this._eventEmiter.subscribe(event => {

      if (event.actionType === 'newmessagereceived') {
        if (this.selectedModuleId !== this.connectModuleId) {
          this.newConnectMessage = true;
        }
      } else if (event.actionType === 'messageread') {
        this.newConnectMessage = false;
      } else if (event.actionType === 'openVideoChatPanel' || event.actionType === 'SubscribeVideoChat') {
        this.listMenuConfigurationPrimary.forEach((menu: ListMenuConfiguration) => {
          if (menu.ModuleName === 'videoChat') {
            menu.customHideVideoChatModule = false;
            menu.MenuIcon = 'assets/images/video_icon.gif';
            this.selectedModuleId = this.videoChatModuleId;
            this.onSetLeftContainerVisibility(menu.ModuleName);
          }
        });
      } else if (event.actionType === 'endVideoChat') {
        this.listMenuConfigurationPrimary.forEach((menu: ListMenuConfiguration) => {
          if (menu.ModuleName === 'videoChat') {
            menu.customHideVideoChatModule = true;
          }
        });
      }
    });
  }

  // Switch back to Classic View (v5)
  switchToClassicView() {
    const loginId = this.userInfo.EncryptedEmailID;
    const orgId = this.userInfo.MemberOrgID;
    const culture = this.localizationService.getCutureCode();
    this.authService.switchToClassicView(loginId, orgId, culture).subscribe(success => {
      if (success.status === 'ok' && success.result === 'done') {
        window.location.href = `${environment.domainName}/talentfirst/talentfirstv3/Dashboard.aspx`;
      } else {
        this.toast.error('Common_Error_ContactAdmin');
      }
    });
  }

  getRedirectionValueFromIframe(): string {
    const url = window.location.href;
    return url.split(environment.iframeRedirectionHostName)[1];
  }

  selectLeftPanelIcon(): void {
    const url = window.location.href;
    if (url.includes('learn')) {
      this.selectedModuleId = this.learnModuleId;
    } else if (url.includes('assessment')) {
      this.selectedModuleId = this.assessModuleId;
    } else if (url.includes('manage')) {
      this.selectedModuleId = this.coachModuleId;
    }
  }


}
