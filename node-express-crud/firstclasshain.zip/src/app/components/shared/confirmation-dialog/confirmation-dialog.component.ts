import { Component, OnInit, Input } from '@angular/core';
import { MatDialogRef } from '@angular/material';

@Component({
  selector: 'app-confirmation-dialog',
  templateUrl: './confirmation-dialog.component.html',
  styleUrls: ['./confirmation-dialog.component.scss']
})
export class ConfirmationDialogComponent implements OnInit {

  @Input() title: string;
  @Input() message: string;
  @Input() btnOkText: string;
  @Input() btnCancelText: string;

  constructor(public dialogRef: MatDialogRef<ConfirmationDialogComponent>) {



  }

  ngOnInit() {
    this.submitConfirmOnEnter();
  }

  public decline() {
    this.dialogRef.close(false);
  }

  public accept() {
    this.dialogRef.close(true);
  }

  public dismiss() {
    this.dialogRef.close();
  }

  public submitConfirmOnEnter() {
    setTimeout(function () {
      if (document.getElementsByClassName('cdk-overlay-backdrop')[0] !== undefined) {
        let btm: any = document.getElementsByClassName('cdk-overlay-backdrop')[0];
        btm.click();
      }

      document.addEventListener('keyup', function (event: any) {
        if (event.keyCode === 13) {

          if (document.getElementsByClassName('icoachpopupDialogYes')[0] !== undefined) {
            let bt: any = document.getElementsByClassName('icoachpopupDialogYes')[0];
            bt.click();
          }
        }
      });
    }, 400);
  }

  ngAfterViewInit() {


  }

}
