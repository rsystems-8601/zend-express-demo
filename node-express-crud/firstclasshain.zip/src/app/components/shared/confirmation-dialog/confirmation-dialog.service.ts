import { Injectable } from '@angular/core';
import { ConfirmationDialogComponent } from './confirmation-dialog.component';
import { MatDialog, MatDialogConfig } from '@angular/material';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ConfirmationDialogService {

  constructor(private dialog: MatDialog) { }

  public confirm(
    message: string,
    btnOkText: string = 'Common_OK',
    btnCancelText: string = 'Common_Cancel',
    dialogSize: string = '400px'): Observable<any> {

    const dialogConfig = new MatDialogConfig();
    dialogConfig.width = dialogSize;
    dialogConfig.disableClose = true;
    const modalRef = this.dialog.open(ConfirmationDialogComponent, dialogConfig);
    modalRef.componentInstance.title = '';
    modalRef.componentInstance.message = message;
    modalRef.componentInstance.btnOkText = btnOkText;
    modalRef.componentInstance.btnCancelText = btnCancelText;

    return modalRef.afterClosed();
  }
}
