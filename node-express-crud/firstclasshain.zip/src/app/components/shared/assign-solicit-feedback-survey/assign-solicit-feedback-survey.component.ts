import { Component, OnInit, Inject } from '@angular/core';
import { Subscription } from 'rxjs';
import { EventEmiterService } from 'src/app/services/event.emmiter.service';
import { FormGroup, FormBuilder, Validators, FormArray } from '@angular/forms';
import { MatDialogRef, MatDialog, MatDialogConfig, MAT_DIALOG_DATA } from '@angular/material';
import { SolicitMultiRaterFeedbackService } from 'src/app/services/solicit-multi-rater-feedback.service';
import { CategoryList, SurveyList, SolicitMultiRaterFeedback, MembersList } from 'src/app/models/response/feedback/solicit-multi-rater-feedback';
import { AddNewCategoryComponent } from '../add-new-category/add-new-category.component';
import { IcftoasterService } from 'src/app/services/icftoaster.service';
import { User } from 'src/app/models/response/user-response';
import { UserService } from 'src/app/services/user.service';
import { UtilityService } from 'src/app/services/utility.service';
import { CommonService } from 'src/app/services/common.service';

@Component({
  selector: 'app-assign-solicit-feedback-survey',
  templateUrl: './assign-solicit-feedback-survey.component.html',
  styleUrls: ['./assign-solicit-feedback-survey.component.scss'],
  providers: [SolicitMultiRaterFeedbackService]
})
export class AssignSolicitFeedbackSurveyComponent implements OnInit {

  callingSource = 'Task';
  subscription: Subscription;
  arrayItems: any[] = [];
  assignSolicitMultirateForm: FormGroup;
  categoryList: CategoryList[] = [];
  addedEmp: any;
  submitted = false;
  selectedEmp: any;
  invalidEmpSelection = false;
  surveyList: SurveyList[] = [];
  msteam_popup_css = '';
  constructor(
    private eventEmiter: EventEmiterService,
    private fb: FormBuilder,
    public self: MatDialogRef<AssignSolicitFeedbackSurveyComponent>,
    private solicitService: SolicitMultiRaterFeedbackService,
    private dialog: MatDialog,
    public toast: IcftoasterService,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private commonService: CommonService,
    private userService: UserService,
    private utilityService: UtilityService
  ) { }

  ngOnInit() {
    this.solicitService.getSolicitFeedbackCategory().subscribe(resp => {
      this.categoryList = resp;
    });
    this.solicitService.getSurvey().subscribe(resp => {
      this.surveyList = resp;
    });
    this.assignSolicitMultirateForm = this.fb.group({
      solicitType: ['chat', Validators.required],
      category: [''],
      chatMsg: ['', Validators.required],
      selectedMembers: this.fb.array([], Validators.required),
      survey: [''],
      privacy: ['TeamMemberCanSee', Validators.required]
    });

    this.assignSolicitMultirateForm.get('category').setValue('', { onlySelf: true });
    this.selectedEmp = this.data.feedbackUserDetails;
    this.subscribeEvents();

    if (this.commonService.getMSTeamViewConfig()) {
      this.msteam_popup_css = 'icf_msteam';
    } else {
      this.msteam_popup_css = '';
    }
  }

  get f() {
    return this.assignSolicitMultirateForm.controls;
  }

  get selectedMembers() {
    return this.f.selectedMembers as FormArray;
  }

  resetForm(): void {
    // Resetting the members list as for Chat user can select only one member.
    this.arrayItems = [];
    this.addedEmp = null;
    // To reset the employee search field & rest of the form
    this.eventEmiter.emit({ keyName: 'resetAutoComplete' });
    this.f.category.setValue('', { onlySelf: true });
    while (this.selectedMembers.length !== 0) {
      this.selectedMembers.removeAt(0);
    }
    this.f.chatMsg.setValue('', { onlySelf: true });
    this.f.survey.setValue('', { onlySelf: true });
    this.f.privacy.setValue('TeamMemberCanSee', { onlySelf: true });
  }

  addSelectedMember(): void {
    if (!this.addedEmp) {
      this.invalidEmpSelection = true;
      return;
    } else {
      const index = this.arrayItems.findIndex(x => x.EmpID === this.addedEmp.EmpID);
      if (index === -1) {
        const obj = {
          EmpID: this.addedEmp.EmpID,
          FirstName: this.addedEmp.FirstName,
          LastName: this.addedEmp.LastName,
          ProfileImageName: this.addedEmp.ProfileImageName,
          Category: this.f.category.value
        };
        this.arrayItems.push(obj);
        this.selectedMembers.push(this.fb.control(obj));
      }
      this.addedEmp = null;
      this.invalidEmpSelection = false;
      this.assignSolicitMultirateForm.get('category').setValue('', { onlySelf: true });
      // To reset the employee search field
      this.eventEmiter.emit({ keyName: 'resetAutoComplete' });
    }
  }

  removeSelectedMember(id: number) {
    const index = this.arrayItems.findIndex(x => x.EmpID === id);
    if (index >= 0) {
      this.arrayItems.splice(index, 1);
      this.selectedMembers.removeAt(index);
    }
  }

  subscribeEvents(): void {
    this.subscription = this.eventEmiter.subscribe(event => {
      if (event.keyName === 'AddObserver') {
        this.addedEmp = event.observerData;
      }
    });

    this.f.solicitType.valueChanges.subscribe((val) => {
      if (val === 'chat') {
        this.f.chatMsg.setValidators(Validators.required);
        this.f.survey.clearValidators();
      } else {
        this.f.chatMsg.clearValidators();
        this.f.survey.setValidators(Validators.required);
      }
      this.resetForm();
    });

    this.assignSolicitMultirateForm.valueChanges.subscribe(() => {
      this.submitted = false;
    });
  }

  onSubmit(): void {
    this.submitted = true;
    if (this.assignSolicitMultirateForm.invalid) {
      return;
    }
    const solicitFeedbackRequest = {} as SolicitMultiRaterFeedback;
    const userInfo: User = this.userService.getUserDetails().UserDetails;
    const formValues = this.assignSolicitMultirateForm.value;
    solicitFeedbackRequest.FeedbackId = 0;
    solicitFeedbackRequest.commentedBy = userInfo.EmpId;
    if (formValues.solicitType === 'chat') {
      solicitFeedbackRequest.managerId = formValues.selectedMembers[0].EmpID; // Selected Feedback From
    } else {
      // TODO: Passing EmpID is first employee for demo purpose only
      solicitFeedbackRequest.managerId = formValues.selectedMembers[0].EmpID; // Selected Feedback From
    }
    solicitFeedbackRequest.RepId = this.selectedEmp.EmpId; // Selected Team Member
    solicitFeedbackRequest.AllowComments = true;
    solicitFeedbackRequest.IsSolicited = true;
    solicitFeedbackRequest.ForRepEyes = formValues.privacy === 'TeamMemberCanSee' ? true : false;
    solicitFeedbackRequest.IsPrivate = false;
    solicitFeedbackRequest.Comments = this.utilityService.escapeSpecialCharacters(formValues.chatMsg);
    solicitFeedbackRequest.SessionID = 0;
    solicitFeedbackRequest.RequestAcknowledgement = false;
    solicitFeedbackRequest.SolicitType = formValues.solicitType;
    solicitFeedbackRequest.SolicitTypeId = formValues.solicitType === 'chat' ? 83 : 84;
    solicitFeedbackRequest.EmpCategoryAssociation = [];
    solicitFeedbackRequest.EmpCategoryAssociation = this.createEmpAssociationArray(formValues.selectedMembers);
    solicitFeedbackRequest.SurveyCycleId = formValues.survey ? formValues.survey : 0;
    this.solicitService.saveSolicitMultiRaterFeedback(solicitFeedbackRequest).subscribe(response => {
      if (response.IsRequestSaved) {
        this.toast.success('Feedback_Created');
        this.close();
      } else {
        this.toast.error('OperationFailedMessage');
      }
    });
  }

  createEmpAssociationArray(selectedList: any): MembersList[] {
    const list: MembersList[] = [];
    selectedList.forEach(element => {
      const obj = {} as MembersList;
      obj.EmpId = element.EmpID;
      if (element.Category) {
        obj.CategoryId = this.categoryList.find(x => x.CategoryName === element.Category).CategoryId;
      } else {
        obj.CategoryId = 0;
      }
      list.push(obj);
    });
    return list;
  }

  close(): void {
    this.self.close();
  }

  openCreateNewCategoryDialog(): void {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.width = '555px';
    dialogConfig.disableClose = true;
    const addNewDialog = this.dialog.open(AddNewCategoryComponent, dialogConfig);
    addNewDialog.afterClosed().subscribe(resp => {
      if (resp) {
        this.afterSaveNewCategory(resp);
      }
    });
  }

  afterSaveNewCategory(category: string) {
    this.solicitService.getSolicitFeedbackCategory().subscribe(list => {
      this.categoryList = list;
      this.assignSolicitMultirateForm.get('category').setValue(category, { onlySelf: true });
    });
  }

  createNewSurvey(): void {
    this.commonService.createNewSurvey();
    this.self.close();
  }

}
