import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { AuthService } from 'src/app/services/auth.service';
import { IcftoasterService } from 'src/app/services/icftoaster.service';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.scss']
})
export class ForgotPasswordComponent implements OnInit {

  forgotPasswordForm: FormGroup;
  submitted = false;
  passwordReset = false;
  constructor(private formBuilder: FormBuilder,
    private authService: AuthService,
    private toast: IcftoasterService) { }

  ngOnInit() {
    this.forgotPasswordForm = this.formBuilder.group({
      emailId: ['', [Validators.required, Validators.email]]
    });
    this.forgotPasswordForm.valueChanges.subscribe(() => {
      this.submitted = false;
    });
  }

  onSubmit() {
    this.submitted = true;
    if (this.f.emailId.invalid) {
      return;
    } else {
      // do successful forget password
      this.authService.isSSOEnabled(this.f.emailId.value).subscribe(isEnabled => {
        if (!isEnabled) {
          // If SSO is not enabled, user can reset his/her password by own
          // else only Administrator can reset the password.
          this.authService.forgotPassword(this.f.emailId.value, 1).subscribe(valid => {
            if (valid) {
              this.passwordReset = true;
              this.toast.success('ForgotPassword_PasswordReset');
            } else {
              this.passwordReset = false;
              this.toast.error('Reset Failed');
            }
          });
        } else {
          this.passwordReset = false;
          this.toast.error('Please contact your administrator.');
        }
      });

    }

  }

  get f() {
    return this.forgotPasswordForm.controls;
  }

}
