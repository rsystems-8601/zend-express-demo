import { Component, OnInit } from '@angular/core';
import { UserService } from '../../services/user.service';
import 'bootstrap';
import { EventEmiterService } from 'src/app/services/event.emmiter.service';
import { Subscription } from 'rxjs';
import { ActService } from 'src/app/services/act.service';
import { LeaderBoardData } from 'src/app/models/response/act-response';
import { ILeaderBoardUrlRequest } from 'src/app/models/requests/url-builder/leader-board-url-request';
import { environment } from 'src/environments/environment';
import { MatDialog, MatDialogConfig } from '@angular/material';
import { IframeModalComponent } from '../shared/iframe-modal/iframe-modal.component';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  activeSlideIndex = 0;
  leaderBoardDetails: LeaderBoardData;
  userName: string;
  userProfilePicUrl: string;
  designation: string;
  subscription: Subscription;
  userDetails: any;
  domain: string = `${environment.domainName}`;
  // basePath: string = `${environment.quickFeedbackHistoryPagePath}`;
  basePath: string;
  constring: string;
  competencyBenchmarkPagePath = `${environment.competencyBenchmarkPagePath}`;
  url: string;


  constructor(private userService: UserService,
    private _eventEmiter: EventEmiterService,
    private actService: ActService, private dialog: MatDialog) { }

  ngOnInit() {
    this.userDetails = this.userService.getUserDetails().UserDetails;
    if (this.userDetails !== undefined) {
      this.userName = this.userDetails.Name;
      this.userProfilePicUrl = this.userDetails.ProfileImageName;
      this.designation = this.userDetails.Designation;

      this.subscription = this._eventEmiter.subscribe(data => {
        if (data.keyName === 'ReloadProfileImage') {
          this.userName = data.observerData.UserDetails.Name;
          this.userProfilePicUrl = data.observerData.UserDetails.ProfileImageName;
          this.designation = data.observerData.UserDetails.Designation;
        }
      });
    }
    this.getLeaderBoardDetails();
  }

  getLeaderBoardDetails() {
    this.actService.getLeaderBoardDetails().subscribe(response => {
      this.leaderBoardDetails = response;
    });
  }

  getMeterImage(customValue: string) {
    //if (leaderBoardName === 'Engagement' || leaderBoardName === 'Tasks Feedbacks') {
    //Round off to nearest 0.5
    var engagementMeter = Math.round(parseFloat(customValue) * 2) / 2;
    var className = this.getMeterCss(engagementMeter);
    return className;

    //}
  }

  getMeterCss(ratingMeter: number) {
    if (ratingMeter === 0)
      return "rating0";
    else if (ratingMeter === 0.5)
      return "rating05";
    else if (ratingMeter === 1)
      return "rating10";
    else if (ratingMeter === 1.5)
      return "rating15";
    else if (ratingMeter === 2)
      return "rating20";
    else if (ratingMeter === 2.5)
      return "rating25";
    else if (ratingMeter === 3)
      return "rating30";
    else if (ratingMeter === 3.5)
      return "rating35";
    else if (ratingMeter === 4)
      return "rating40";
    else if (ratingMeter === 4.5)
      return "rating45";
    else if (ratingMeter === 5)
      return "rating50";
    else
      return "rating0";
  }

  openMyLeaderBoard(leaderBoardName: string, isDefault: boolean) {
    if (isDefault) {
      if (leaderBoardName === 'Engagement')
        this.constring = 'Value=engagementstats&module=connect'
      else if (leaderBoardName === 'Tasks Feedbacks')
        this.constring = 'Value=approvalRatingStats&module=connect'
      if (leaderBoardName === 'Learning Credit')
        this.constring = 'Value=learningcreditstats&module=connect'
      else if (leaderBoardName === 'Endorsement')
        this.constring = 'Value=endorsementstats&module=connect'
      else if (leaderBoardName === 'Coaching & Feedback')
        this.constring = 'Value=coachingfeedback&module=connect'
    }
    else
      this.constring = 'Value=customLB&leaderBoard=' + leaderBoardName + '&lbValue=0&module=connect'

    const request = {} as ILeaderBoardUrlRequest;
    request.EmpId = this.userDetails.EmpId;
    request.EmpName = this.userDetails.Name;
    request.MemberOrgID = this.userDetails.MemberOrgID;

    request.Source = 'icf6';
    request.PagePath = leaderBoardName;
    request.EmployeeId = this.userDetails.EmployeeId;
    request.Culture = 'en';

    const reportUrl = this.getLeaderBoardUrl(request);
    const dialogConfig = new MatDialogConfig();
    dialogConfig.width = 900 + 'px';
    dialogConfig.disableClose = true;
    dialogConfig.data = { url: reportUrl };
    this.dialog.open(IframeModalComponent, dialogConfig);

  }

  getLeaderBoardUrl(request: ILeaderBoardUrlRequest): string {
    this.basePath = `${environment.quickFeedbackHistoryPagePath}`;

    this.url = this.domain + this.basePath + this.constring + '&EmpId=' + request.EmpId + '&MemberOrgId='
      + request.MemberOrgID + '&source=' + request.Source + '&Culture=' + request.Culture + '&eid=' + request.EmployeeId;

    return this.url;
  }


}
