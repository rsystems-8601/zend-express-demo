import { Component, OnInit, OnDestroy } from '@angular/core';
import { slideInAnimation } from 'src/app/helpers/app.animation';
import { Router } from '@angular/router';
import { UserService } from '../../../services/user.service';
import { UserDetails } from '../../../models/user-details-result';
// import { ActService } from '../../../services/act.service';
import { ActSources } from 'src/app/models/response/act-response';
import { ActSourceService } from 'src/app/services/act-source.service';
import { Subscription } from 'rxjs';
import { EventEmiterService } from 'src/app/services/event.emmiter.service';
import { SharedDataService } from 'src/app/services/shared-data.service';

@Component({
  selector: 'app-act',
  templateUrl: './act.component.html',
  styleUrls: ['./act.component.scss'],
  animations: [slideInAnimation]
})
export class ActComponent implements OnInit, OnDestroy {
  liveDocumentSize = document.body.clientWidth;
  numberToDisplayItems: any;
  activeLinkIndex = 0;
  subscription: Subscription;
  inititalSources: ActSources[] = [];
  otherSources: ActSources[] = [];
  dataSources: ActSources[]; // Object[];
  // loading = true;
  userInfo: UserDetails;
  isVisiblePlusButton: boolean;

  constructor(private router: Router, private userService: UserService, private _eventEmiter: EventEmiterService,
    private actSourceService: ActSourceService, private sharedDataService: SharedDataService) {

    // alert(window.screen.width);
    // Need to improve this code by creating separate web api for source menu/sub menu in used in deashboard
    this.userInfo = this.userService.getUserDetails().UserDetails;
    this.isVisiblePlusButton = true;

    if (this.liveDocumentSize < 1024) {
      this.numberToDisplayItems = Math.round((this.liveDocumentSize - 230) / 140); // 5;
    } else {
      this.numberToDisplayItems = Math.round((this.liveDocumentSize - 530) / 140); // 5;
    }


  }

  onResize() {
    this.liveDocumentSize = document.body.clientWidth;
    if (this.liveDocumentSize < 1024) {
      this.numberToDisplayItems = Math.round((this.liveDocumentSize - 230) / 140); // 5;
    } else {
      this.numberToDisplayItems = Math.round((this.liveDocumentSize - 530) / 140); // 5;
    }
    // As we are resizing the page, user should not be navigated to first if if index number is not found.
    this.getSourcesData(false);
  }
  ngOnInit() {
    // Here true is passed because this is called on application load or refresh, hence redirection to first tab is allowed.
    this.getSourcesData(true);
    this.subscription = this._eventEmiter.subscribe(data => {
      if (data.keyName === 'GoToHome') {
        this.selectAllPending();
      } else if (data.keyName === 'fromNotificationForAct') {
        this.selectSpecificTab(data);
      }
    });
    // if (this.dataSources !== undefined && this.dataSources.length > this.numberToDisplayItems) {
    //   this.isVisiblePlusButton = true;
    // } else {
    //   this.isVisiblePlusButton = false;
    // }
  }

  ngOnDestroy() {
    this._eventEmiter.unsubscribe(this.subscription);
  }

  updateActiveLinkIndex(selectedSource) {
    if (this.inititalSources.find(x => x === selectedSource)) {
      if(selectedSource.Key === 'Training')
      {
          this.sharedDataService.setSelectedView(undefined);
      }

      this.activeLinkIndex = this.inititalSources.findIndex(x => x === selectedSource);
    }
  }

  getSourcesData(redirect: boolean) {
    // this.actService.getSourceTypes().subscribe((actList: ActSources[]) => {
    this.actSourceService.getActSources((actList: ActSources[]) => {

      this.dataSources = actList;
      this.inititalSources = this.deepClone(actList);
      this.otherSources = this.deepClone(actList);

      if (this.inititalSources.length > this.numberToDisplayItems) {
        this.inititalSources.splice(this.numberToDisplayItems, this.inititalSources.length);
      }

      if (this.otherSources.length > 0) {
        this.otherSources.splice(0, this.numberToDisplayItems);
      }

      const newUrl = decodeURI(this.router.url);
      const pathUrl = newUrl.split('/');
      const currentPath = pathUrl[pathUrl.length - 1];

      let indexNumber = -1;
      if (newUrl.includes('edit-task')) {
        indexNumber = this.inititalSources.findIndex(x => 'tasks' === x.Key.toLowerCase());
        // this.router.navigate(['/iCoachFirst/dashboard']);
        // this.activeLinkIndex = 0;
      } else if (newUrl.includes('editGoal')) {
        indexNumber = this.inititalSources.findIndex(x => 'goals' === x.Key.toLowerCase());
      } else if (newUrl.includes('folder')) {
        indexNumber = this.inititalSources.findIndex(x => currentPath.toLowerCase() === x.Key.toLowerCase());
        if (indexNumber === -1) {
          indexNumber = this.otherSources.findIndex(x => currentPath.toLowerCase() === x.Key.toLowerCase());
          if (indexNumber > -1) {
            this.otherSourceClicked(this.otherSources[indexNumber]);
            return true;
          }
        }
      } else {
        indexNumber = this.inititalSources.findIndex(x => currentPath.toLowerCase() === x.Key.toLowerCase());
        if (indexNumber === -1) {
          // To check if user has requested for sources(this.otherSources) other than visible sources(this.initialSources)
          indexNumber = this.otherSources.findIndex(x => currentPath.toLowerCase() === x.Key.toLowerCase());
          if (indexNumber > -1) {
            this.otherSourceClicked(this.otherSources[indexNumber]);
            return true;
          }
        }
      }

      // below check is for cluster Competencies if user directly refreshes url for on competencies page
      // They work on Id basis and not on Keys.
      if (indexNumber === -1) {
        indexNumber = this.inititalSources.findIndex(x => x.Id ? currentPath === x.Id.toString() : false);
        if (indexNumber > -1) {
          this.activeLinkIndex = indexNumber;
        } else {
          indexNumber = this.otherSources.findIndex(x => x.Id ? currentPath === x.Id.toString() : false);
          if (indexNumber > -1) {
            this.otherSourceClicked(this.otherSources[indexNumber]);
            return true;
          }
        }
      }

      if (redirect) {
        // Including special case when routing is done from either IPad or MS Teams
        if (indexNumber === -1 && newUrl.includes('switch/mobile')) {
          this.activeLinkIndex = indexNumber === -1 ? 0 : indexNumber;
        } else if (indexNumber === -1 && newUrl !== '/iCoachFirst/dashboard') {
          this.router.navigate(['/iCoachFirst/dashboard']);
          this.activeLinkIndex = 0;
        } else {
          this.activeLinkIndex = indexNumber === -1 ? 0 : indexNumber;
        }
      }

    });
  }


  deepClone(oldArray: Object[]) {
    const newArray: any = [];
    oldArray.forEach((item) => {
      newArray.push(Object.assign({}, item));
    });
    return newArray;
  }

  otherSourceClicked(selectedSource) {

    if (this.otherSources.find(x => x === selectedSource)) {
      this.otherSources.splice(this.otherSources.findIndex(x => x === selectedSource),
        0,
        this.inititalSources[this.numberToDisplayItems - 1]);
    }

    this.inititalSources.splice(this.numberToDisplayItems - 1, 1);
    this.inititalSources.push(selectedSource);

    if (this.otherSources.find(x => x === selectedSource)) {
      this.otherSources.splice(this.otherSources.findIndex(x => x === selectedSource), 1);
    }

    this.activeLinkIndex = this.numberToDisplayItems - 1;

  }

  // updateDataSource(sourceData: ActSources[]) {
  //   this.dataSources = sourceData;
  // }

  /**
   * Sets the activeIndex to 0 when user clicks on Home in left menu panel.
   */
  selectAllPending() {
    this.activeLinkIndex = 0;
  }

  selectSpecificTab(data: any) {
    let indexNumber = -1;
    if (data.ItemType === 'Task') {
      indexNumber = this.inititalSources.findIndex(x => 'tasks' === x.Key.toLowerCase());
    } else if (data.ItemType === 'Goal') {
      indexNumber = this.inititalSources.findIndex(x => 'goals' === x.Key.toLowerCase());
    }

    if (indexNumber === -1) {
      this.router.navigate(['/iCoachFirst/dashboard']);
      this.activeLinkIndex = 0;
    } else {
      this.activeLinkIndex = indexNumber;
    }
  }

}
