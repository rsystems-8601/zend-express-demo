import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddAdditionalManagerComponent} from './add-additional-manager.component';

describe('AddAdditionalManagerComponent', () => {
  let component: AddAdditionalManagerComponent;
  let fixture: ComponentFixture<AddAdditionalManagerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddAdditionalManagerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddAdditionalManagerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
