import { Component, OnInit, Inject, OnDestroy } from '@angular/core';
import { EventEmiterService } from '../../../services/event.emmiter.service';
import { IcftoasterService } from '../../../services/icftoaster.service';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { Subscription } from 'rxjs';
import { AdditionalManagerRequest } from 'src/app/models/requests/additional-manager-request';
import { EmployeeAdditionalManagerService } from 'src/app/services/employee-additional-manager.service';
import { UserDetails } from 'src/app/models/user-details-result';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-add-additional-manager',
  templateUrl: './add-additional-manager.component.html',
  styleUrls: ['./add-additional-manager.component.scss']
})
export class AddAdditionalManagerComponent implements OnInit, OnDestroy {

  additionalManagerList: Array<AdditionalManagerRequest>;
  selectedObserver: any;
  submitted = false;
  calllingSource = 'DottedLineTo';
  private subscription: Subscription;
  existingAddManagerCount = 0;
  userInfo: UserDetails;

  constructor(
    private empAdditionalManagerService: EmployeeAdditionalManagerService,
    private _eventEmiter: EventEmiterService,
    private toast: IcftoasterService,
    public dialogRef: MatDialogRef<AddAdditionalManagerComponent>,
    @Inject(MAT_DIALOG_DATA) public data,
    private userService: UserService,
  ) { }

  ngOnInit() {
    this.userInfo = this.userService.getUserDetails().UserDetails;
    this.additionalManagerList = [];
    this.getEmpAdditionalManager();
    this.subscription = this._eventEmiter.subscribe(observer => {
      if (observer.keyName === 'DottedLineTo') {
        this.selectedObserver = observer.observerData;
      }
    });
  }

  ngOnDestroy() {
    this._eventEmiter.unsubscribe(this.subscription);
  }

  addEmpAdditionalManager() {
    if (this.selectedObserver && this.selectedObserver !== undefined) {

      if (this.isAddMgrExist()) {
        this.toast.error('GoalStats_Error_EmployeeAlreadAdded', '');
        return;
      }
      if (this.selectedObserver.EmpID === this.userInfo.ManagerId) {
        this.toast.error('Real manager can not be additional manager', '');
        return;
      }
      const additionalMgrDetails = {} as AdditionalManagerRequest;
      additionalMgrDetails.ManagerId = this.selectedObserver.EmpID;
      additionalMgrDetails.Name = this.selectedObserver.FirstName + ' ' + this.selectedObserver.LastName;
      additionalMgrDetails.FirstName = this.selectedObserver.FirstName;
      additionalMgrDetails.LastName = this.selectedObserver.LastName;
      additionalMgrDetails.EmailId = this.selectedObserver.EmailId;
      additionalMgrDetails.ProfilePicUrl = this.selectedObserver.ProfileImageName;
      this.additionalManagerList.push(additionalMgrDetails);

      this.selectedObserver = null;
      this._eventEmiter.emit({ keyName: 'resetAutoComplete' });
    } else {
      this.toast.error('Login_InvalidUser', '');
    }
  }

  saveEmpAdditionalManager() {

    if (this.additionalManagerList.length === 0 && this.existingAddManagerCount === 0) {
      this.toast.error('Add_At_Least_One_Additional_Manager', '');
      return false;
    }

    this.empAdditionalManagerService.saveEmployeeAdditionalManager(this.additionalManagerList).subscribe(response => {
      // const responseObj = JSON.parse(JSON.stringify(response));
      if (response) {
        this.toast.success('Common_UpdateSuccess', '');
        this.cancel();
      } else {
        this.toast.error('Common_Error_TechnicalIssueDuringSave', '');
      }
    });
  }

  getEmpAdditionalManager() {
    this.empAdditionalManagerService.getEmployeeAdditionalManager().subscribe(response => {
      const addManagers = JSON.parse(JSON.stringify(response));
      if (addManagers && addManagers.length > 0) {
        this.existingAddManagerCount = addManagers.length;
        addManagers.forEach(addManager => {
          const addManagerDetails = {} as AdditionalManagerRequest;
          addManagerDetails.ManagerId = addManager.ManagerId;
          addManagerDetails.Name = addManager.FirstName + ' ' + addManager.LastName;
          addManagerDetails.FirstName = addManager.FirstName;
          addManagerDetails.LastName = addManager.LastName;
          addManagerDetails.EmailId = addManager.EmailId;
          addManagerDetails.ProfilePicUrl = addManager.ProfileImageName;
          this.additionalManagerList.push(addManagerDetails);
        });
      }
    });
  }

  isAddMgrExist() {
    let filteredAddManagers;
    if (this.additionalManagerList && this.additionalManagerList.length > 0) {
      filteredAddManagers = this.additionalManagerList.filter(addManager => addManager.ManagerId === this.selectedObserver.EmpID);
    }
    if (filteredAddManagers && filteredAddManagers.length > 0) {
      return true;
    }
    return false;

  }

  removeAddMgr(additionalManager: AdditionalManagerRequest) {
    this.additionalManagerList = this.additionalManagerList.filter(addManager => addManager.ManagerId !== additionalManager.ManagerId);
  }

  cancel() {
    this.dialogRef.close();
  }

}
