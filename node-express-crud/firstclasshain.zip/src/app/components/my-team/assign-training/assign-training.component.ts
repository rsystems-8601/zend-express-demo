import { Component, OnInit, Inject } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { UserDetails } from 'src/app/models/user-details-result';
import { IAssignTrainingResponse } from '../../../models/response/iassign-training-response';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialogConfig, MatDialog } from '@angular/material';
import { IAssignTrainingCatalogRequest, AdvancedSearchRequest } from '../../../models/requests/iassign-training-catalog-request';
import { IAssignTrainingCatalogResponse } from '../../../models/response/iassign-training-catalog-response';
import { LearnSelectAllComponent } from '../../learn/modal-popup/assign/select-all/select-all.component';
import { LearnBaseResponse, FeaturedTrainings, Categories } from '../../../models/response/learn/learn-response';
import { LearnModalPopupEnum } from '../../../helpers/enums/learn-enums';
import { TrainingContentComponent } from '../../learn/modal-popup/training-content/training-content.component';
import { LearnService } from 'src/app/services/learn.service';
import { environment } from 'src/environments/environment';
import { CommonService } from 'src/app/services/common.service';

@Component({
  selector: 'app-assign-training',
  templateUrl: './assign-training.component.html',
  styleUrls: ['./assign-training.component.scss']
})
export class AssignTrainingComponent implements OnInit {

  featuredTrainingList: Array<FeaturedTrainings> = [];
  categoryList: Array<Categories> = [];
  trainings: Array<LearnBaseResponse> = [];

  userInfo: UserDetails;
  trainingCategories: IAssignTrainingResponse[] = [];
  trainingCatalogList: IAssignTrainingCatalogResponse[] = [];
  assignTrainingForm: FormGroup;
  requestTrainingCatalog = {} as IAssignTrainingCatalogRequest;
  requestAdvanceSearch = {} as AdvancedSearchRequest;
  trainingInfo: LearnBaseResponse;
  coacheeId: number;
  domain = `${environment.domainName}`;
  msteam_popup_css = '';
  constructor(private formBuilder: FormBuilder,
    private dialog: MatDialog,
    public dialogRef: MatDialogRef<AssignTrainingComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private learnService: LearnService,
    private commonService: CommonService) { }

  ngOnInit() {
    this.getLearnData();
    this.setupFormControls();
    this.coacheeId = this.data;
    if (this.commonService.getMSTeamViewConfig()) {
      this.msteam_popup_css = 'icf_msteam';
    } else {
      this.msteam_popup_css = '';
    }
  }

  getLearnData() {
    this.learnService.getLearnData().subscribe(resultData => {
      const learnData = JSON.parse(JSON.stringify(resultData));
      this.featuredTrainingList = learnData.FeaturedTrainings;
      this.categoryList = learnData.Categories;
    },
      () => {
      }
    );
  }

  private setupFormControls() {
    this.assignTrainingForm = this.formBuilder.group({
      ddlTrainingCategories: ['', Validators.required]
    });
  }

  // convenience getter for easy access to form fields
  get f() {
    return this.assignTrainingForm.controls;
  }

  getTrainings() {
    // tslint:disable-next-line:radix
    const categoryId = parseInt(this.f.ddlTrainingCategories.value);
    this.trainings = this.categoryList.find(x => x.CategoryId === categoryId).ListTrainingDataResult;
  }

  openPreviewModalPopup(contentId: number) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.data = this.trainings.find(x => x.ContentId === contentId);
    if (dialogConfig.data.TypeName === 'Video' || dialogConfig.data.TypeName === 'Document') {
      dialogConfig.width = LearnModalPopupEnum.PreviewModalWidth + 'px';
      dialogConfig.height = LearnModalPopupEnum.PreviewModalHeight + 'px';
      // dialogConfig.disableClose = true;
      this.dialog.open(TrainingContentComponent, dialogConfig);
    } else {
      // window.open(dialogConfig.data.ReviewLink, '_blank');
      // window.focus();
      if (dialogConfig.data.TypeName === 'eLearning') {
        dialogConfig.data.ReviewLink = dialogConfig.data.ReviewLink.replace('https://DomainName', this.domain);
      }
      window.open(dialogConfig.data.ReviewLink, '_blank');
      window.focus();
    }
  }

  openAssignTraining(contentId: number) {
    const dialogConfig = new MatDialogConfig();
    // dialogConfig.data = { training: this.featuredTrainingList.find(x => x.ContentId === contentId), coacheeId: this.coacheeId, isAssignedFromLeftPanel: true };
    dialogConfig.data = { training: this.trainings.find(x => x.ContentId === contentId), coacheeId: this.coacheeId, isAssignedFromLeftPanel: true };
    dialogConfig.width = LearnModalPopupEnum.SelectAllModalWidth + 'px';
    dialogConfig.disableClose = true;
    this.dialog.open(LearnSelectAllComponent, dialogConfig);
  }

  getArray(averageRating: number, isShowFilledStar: boolean): any[] {
    return this.commonService.getStarRatingArray(averageRating, isShowFilledStar);
}

  assignTrainingPopUpClose() {
    this.dialogRef.close();
  }

}
