import { Component, OnInit, Output, EventEmitter, ViewChild, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
// import { MyTeamService } from '../../services/my-team.service';
import { UserService } from 'src/app/services/user.service';
import { UserProfileService } from '../../services/user-profile.service';
import { UserDetails, ListFeedbackType } from 'src/app/models/user-details-result';
// import { IMyTeamRequest } from '../../models/requests/my-team-request';
import { IMyTeamResponse } from '../../models/response/imyteam-response';
import { User } from '../../models/response/user-response';
import { MatDialog, MatDialogConfig } from '@angular/material';
import { AssignTaskComponent } from '../tasks/assign-task/assign-task.component';
import { ApplicationModuleListEnum } from '../../helpers/enums/common-enums';
import { PopoverDirective } from 'ngx-smart-popover';
import { AssignCoachingReportComponent } from '../my-team/assign-report/assign-coaching-report.component';
import { AssignTrainingComponent } from '../my-team/assign-training/assign-training.component';
import { AssignQuickFeedbackComponent } from '../quick-feedback/assign-quick-feedback/assign-quick-feedback.component';
import { SolicitFeedbackComponent } from '../quick-feedback/solicit-feedback/solicit-feedback.component';
import { MyNotesComponent } from './my-notes/my-notes.component';
import { IUserProfileUrlRequest } from 'src/app/models/requests/url-builder/user-profile-url-request';
import { IframeModalComponent } from '../shared/iframe-modal/iframe-modal.component';
import { BaseRequest } from 'src/app/models/requests/base-request';
import { ManageUrlRequest } from 'src/app/models/requests/url-builder/manage-url-request';
import { SharedDataService } from 'src/app/services/shared-data.service';
import { LocalizationService } from 'src/app/services/localization.service';
import { FeedbackHistoryComponent } from '../quick-feedback/feedback-history/feedback-history.component';
import { QuickFeedbackHistoryUrlRequest } from 'src/app/models/requests/url-builder/quick-feedback-history-url-request';
import { AddAdditionalManagerComponent } from './add-additional-manager/add-additional-manager.component';
import { IGroup } from '../connect/connect-interfaces';
import { ConnectMessageService } from 'src/app/services/connect-message.service';
import { EventEmiterService } from 'src/app/services/event.emmiter.service';
import { CreateGroupComponent } from '../connect/create-group/create-group.component';
import { Subscription } from 'rxjs';
import { CommonService } from 'src/app/services/common.service';
import { AssignCoachingReportService } from 'src/app/services/assign-coaching-report.service';
import { ICoachingReportResponse } from 'src/app/models/response/icoaching-report-response';
import { DynamicReportUrlRequest } from 'src/app/models/requests/url-builder/dynamic-report-url-request';
// import { DynamicReportUrlBuilderService } from 'src/app/services/dynamic-report-url-builder.service';
// import { ConnectapiService } from 'src/app/services/connectapi.service';
import { RolesService } from 'src/app/services/roles.service';
import { environment } from 'src/environments/environment';
import { SuggestedAction2Component } from './suggested-action2/suggested-action2.component';
import { AssignSolicitFeedbackSurveyComponent } from '../shared/assign-solicit-feedback-survey/assign-solicit-feedback-survey.component';
import { ConfirmationDialogService } from '../shared/confirmation-dialog/confirmation-dialog.service';
import { IcftoasterService } from 'src/app/services/icftoaster.service';


@Component({
  selector: 'app-my-team',
  templateUrl: './my-team.component.html',
  styleUrls: ['./my-team.component.scss']
})
export class MyTeamComponent implements OnInit, OnDestroy {

  myTeamList: IMyTeamResponse[] = [];
  teamList: User[] = [];
  coachesList: User[] = [];
  peersList: User[] = [];
  userInfo: UserDetails;
  coacheeData: User;
  coacheeId = 0;
  isFlyoutOpen = false;
  isCreateNewTeamRole = false;
  applicationModuleId: number = ApplicationModuleListEnum.None;
  videoChatModuleId: number = ApplicationModuleListEnum.VideoChat;
  selectedTeamMember: User;
  manageUrl: string;
  activeItemName = '';
  hasPermissionToAddAdditionalMgr = false;
  coachingReportList: ICoachingReportResponse[] = [];
  reportUrl: string;
  @ViewChild('teamPopover') teamPopover: PopoverDirective;
  @ViewChild('coachPopover') coachPopover: PopoverDirective;
  @ViewChild('peersPopover') peersPopover: PopoverDirective;
  @ViewChild('customGroupPopover') customGroupPopover: PopoverDirective;

  flyoutMenuItem: ListFeedbackType;
  // tslint:disable-next-line:no-output-on-prefix
  @Output() setLeftContainerVisibility: EventEmitter<number> = new EventEmitter<number>();

  // Custom group Changes start
  teamGroups: IGroup[] = [];
  selectedGroupIndex: number;
  subscription: Subscription;
  listFeedback: any = [];
  isRealTimeChatEnabled = false;
  isDottedLineTo = false;
  isDottedManagerAllowedCssClass = 'display';

  isMyTeamVisible = true;
  isManagerVisible = true;
  isPeersVisible = true;
  ShowEmployeeAlertFlag = true;
  onlineUsers = [];
  onlineUsersCollection: Subscription;

  // Custom group Changes end

  // private _myTeamService: MyTeamService,
  constructor(private userService: UserService,
    private sharedDataService: SharedDataService,
    private coachingReportService: AssignCoachingReportService,
    // private dynamicUrlBuilderService: DynamicReportUrlBuilderService,
    private localizationService: LocalizationService,
    private router: Router,
    private dialog: MatDialog, private profileService: UserProfileService,
    // Custom group Changes start
    private connectMessageService: ConnectMessageService,
    private _eventEmiter: EventEmiterService,
    private commonService: CommonService,
    private roleService: RolesService,
    private confirmationDialogService: ConfirmationDialogService,
    private toast: IcftoasterService
  ) { }

  ngOnInit() {

    this.onlineUsersCollection = this.sharedDataService.getOnlineUsersCollection().subscribe(response => {

      this.onlineUsers = response;
      if (this.teamGroups !== undefined && this.teamGroups.length > 0) {
        this.teamGroups.forEach(team => {
          // if (team.groupType === 'myteam') {
            team.LstMember.forEach(teamMember => {
              const userOnline = this.onlineUsers.find(obj => obj === teamMember.EmailId.trim());
              if (userOnline !== undefined) {
                teamMember.isUserOnline = true;
              } else {
                teamMember.isUserOnline = false;
              }
            });
          // }
        });
      }
    });

    this.commonService.suggestActionCCHideBubble.subscribe(resp => {

      if (this.teamGroups !== undefined && this.teamGroups.length > 0) {
        this.teamGroups.forEach(team => {
          if (team.groupType === 'myteam') {
            team.LstMember.forEach(teamMember => {
              if (teamMember.EmpId === Number(resp.selectedRepId)) {
                teamMember.ShowEmployeeAlertFlag = resp.value;
              }
            });
          }
        });
      }

    });

    this.setUpData();
    this.setupTeamGroups();
    this.subscribeEvents();
    if (this.teamPopover !== undefined) {
      window.addEventListener('closePopover', () => {
        if (window.document.querySelectorAll('[role="popover"]')) {
          const popoverDiv: any = document.querySelectorAll('[role="popover"]');
          if (popoverDiv[0].style.opacity) {
            this.teamPopover.hide();
          }
        }
      });
    }
  }

  setUpData() {
    this.hasPermissionToAddAdditionalMgr = this.connectMessageService.hasPermissionToAddAdditionalMgr;
    this.userInfo = this.userService.getUserDetails().UserDetails;
    this.listFeedback = this.userService.getUserDetails().ListFeedbackType;
    this.isRealTimeChatEnabled = this.userService.getUserDetails().RealTimeChatEnabled;
    if (this.userInfo.CreateNewTeamEnable) {
      this.isCreateNewTeamRole = true;
    }
  }

  // getMyTeamList() {
  //   const request = {} as IMyTeamRequest;
  //   this.userInfo = this.userService.getUserDetails().UserDetails;
  //   request.EmpId = this.userInfo.EmpId;
  //   request.EmployeeId = this.userInfo.EmployeeId;
  //   request.SearchText = '';

  //   this._myTeamService.getMyTeamList(request).subscribe(data => {
  //     this.myTeamList = data;

  //     const teams = this.myTeamList.filter(v => v.ListType.toString() === 'Team');

  //     if (teams.length > 0) {
  //       teams[0].Users.forEach(user => {
  //         this.teamList.push(user);
  //       });
  //     }
  //     const coaches = this.myTeamList.filter(v => v.ListType.toString() === 'Coaches');
  //     this.coachesList = [];
  //     if (coaches.length > 0) {
  //       this.hasPermissionToAddAdditionalMgr = coaches[0].HasPermissionToAddAdditionalMgr;
  //       coaches[0].Users.forEach(user => {
  //         this.coachesList.push(user);
  //       });
  //     }

  //     const peers = this.myTeamList.filter(v => v.ListType.toString() === 'Peers');

  //     if (peers.length > 0) {
  //       peers[0].Users.forEach(user => {
  //         this.peersList.push(user);
  //       });
  //     }

  //     this.setupGroups();
  //   });

  // }

  openMainComponentLeftContainer(appModuleId: number = 0) {
    this.setLeftContainerVisibility.emit(appModuleId);
  }

  hidePopUpForMobile(appModuleId: number = 0) {
    const isMobileDevice = this.commonService.detectMobileDevice();

    if (isMobileDevice) {
      this.setLeftContainerVisibility.emit(appModuleId);
    }
  }


  // Modal Popup open for Assign Task START
  openAssignTaskModalPopup(popoverType: string) {

    const userDetails = this.userService.getUserDetails().UserDetails;
    this.commonService.closeleftMenuForiPad();
    const dialogConfig = new MatDialogConfig();
    dialogConfig.data = {
      taskAssignerEmpId: userDetails.EmpId,
      taskAssigneeEmpId: this.coacheeId
    };
    dialogConfig.width = '600px';
    dialogConfig.disableClose = true;
    const dialogRef = this.dialog.open(AssignTaskComponent, dialogConfig);
    this.closePopover(popoverType);
    dialogRef.afterClosed().subscribe(value => {

      if (value === 'success') {
        // TODO Reload selected team member data

      }
    });
  }
  // Modal Popup open for Assign Task END

  // Modal Popup open for Assign Coaching Report START
  openAssignCoachingReportModalPopup(IsRepInitiated: boolean, popovertype: string, itemName: string) {
    // Open report directly when user has access to only one report.
    const request = new BaseRequest();
    this.userInfo = this.userService.getUserDetails().UserDetails;
    request.EmployeeId = this.userInfo.EmployeeId;
    request.MemberOrgId = this.userInfo.MemberOrgID;
    request.RepId = this.coacheeId;
    this.commonService.closeleftMenuForiPad();
    this.closePopover(popovertype);

    if (IsRepInitiated) {
      this.coachingReportService.getReportsForPeerRepInitiated(request).subscribe(data => {
        this.coachingReportList = data.filter(t => t.IsDynamic === true);
        if (this.coachingReportList !== undefined && this.coachingReportList.length === 1) {
          // this.teamPopover.hide();
          // this.openReport(this.coachingReportList[0], IsRepInitiated);
          this.commonService.openReport(this.coachingReportList[0], IsRepInitiated, this.coacheeData);
        } else {
          this.modalDataForAssignCoaching(IsRepInitiated, this.coachingReportList, 'Act_Source_RequestCoaching');
        }
      });

    } else {

      let coachMessage: string;
      this.flyoutMenuItem = this.roleService.getFlyoutMenuItem(itemName);
      if (this.flyoutMenuItem.EnableValue) {
        coachMessage = this.flyoutMenuItem.CustomLabelText;
      }
      this.coachingReportService.getReportsForEmployee(request).subscribe(data => {
        this.coachingReportList = data;
        if (this.coachingReportList !== undefined && this.coachingReportList.length === 1) {
          this.teamPopover.hide();
          // this.openReport(this.coachingReportList[0], IsRepInitiated);
          this.commonService.openReport(this.coachingReportList[0], IsRepInitiated, this.coacheeData);
        } else {
          this.modalDataForAssignCoaching(IsRepInitiated, this.coachingReportList, coachMessage);
        }
      });
    }
  }
  // Modal Popup open for Assign Coaching Report END

  private modalDataForAssignCoaching(IsRepInitiated: boolean, reports: ICoachingReportResponse[], reqFeedbackPopUpTitle = '') {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.width = '800px';
    const dataToPass = new BaseRequest();
    dataToPass.RepId = this.coacheeId;
    dataToPass.IsRepInitiated = IsRepInitiated;
    dialogConfig.data = {
      dataToPass: dataToPass,
      coacheeData: this.coacheeData,
      filterType: '',
      feedbackPopUpTitle: (reqFeedbackPopUpTitle !== '') ? reqFeedbackPopUpTitle : 'Coaching Conversations',
      coachingAssignments: reports
    };
    dialogConfig.disableClose = true;
    this.dialog.open(AssignCoachingReportComponent, dialogConfig);
    this.teamPopover.hide();
    // dialogRef.afterClosed().subscribe(value => {

    // });
  }
  /*
    private openReport(report: ICoachingReportResponse, IsRepInitiated: boolean) {
      this.reportUrl = this.dynamicUrlBuilderService.newReportUrl(this.createUrlRequest(report, IsRepInitiated));
      const queryParam = encodeURI(this.reportUrl);
      this.sharedDataService.setData(this.reportUrl);
      this.sharedDataService.setRedirectionValue(this.getRedirectionValueFromIframe());
      this.router.navigate(['/iCoachFirst/report/dynamicreport', report.ReportName], { queryParams: { encodedUrl: queryParam } });
    }
    private createUrlRequest(reportItem: ICoachingReportResponse, IsRepInitiated: boolean): DynamicReportUrlRequest {
      const request = {} as DynamicReportUrlRequest;
      this.userInfo = this.userService.getUserDetails().UserDetails;
      request.EmpReportId = reportItem.EmpReportId;
      if (IsRepInitiated) {
        request.IsMgr = 'F';
        request.CoachId = this.coacheeData.EmployeeId;
        request.CoacheeId = this.userInfo.EmpId;
        request.CoachName = this.coacheeData.Name;
        request.CoacheeName = this.userInfo.Name;
      } else {
        request.IsMgr = 'T';
        request.CoachId = this.userInfo.EmpId;
        request.CoacheeId = this.coacheeId;
        request.CoachName = this.userInfo.Name;
        request.CoacheeName = this.coacheeData.Name;
      }
      request.ReportName = reportItem.ReportName;
      request.ReportId = reportItem.ReportId;
      request.IsRepInitiated = IsRepInitiated;
      request.MemberOrgID = this.userInfo.MemberOrgID;
      request.PagePath = reportItem.PagePath;
      request.Source = 'icf6';
      request.RedirectTo = 'dashboard';
      request.Culture = this.localizationService.getICF6CultreFromLocalStorage().CultureCode;
      return request;
    }
  */
  // Modal Popup open for Assign Training Report START
  openAssignTrainingModalPopup(popoverType: string) {
    if (this.roleService.hasPermission('TRN')) {
      const dialogConfig = new MatDialogConfig();
      dialogConfig.width = '600px';
      dialogConfig.data = this.coacheeId;
      dialogConfig.disableClose = true;
      this.dialog.open(AssignTrainingComponent, dialogConfig);
      this.closePopover(popoverType);
      this.commonService.closeleftMenuForiPad();
    }
  }
  // Modal Popup open for Assign Training Report END

  getCoacheeId(coacheeData: User, type: string, userType: string) {
    this.isDottedLineTo = false;
    this.isDottedManagerAllowedCssClass = 'display';
    this.coacheeData = coacheeData;
    this.coacheeId = coacheeData.EmpId;
    this.isFlyoutOpen = true;
    this.selectedTeamMember = coacheeData;
    if (type === 'manage' && userType !== undefined) {
      // this.openManageInIframe(type);
      this.openManage(type);
    }
    if (coacheeData.IsAdditionalManager !== undefined && coacheeData.IsAdditionalManagerReqApproved !== undefined && coacheeData.IsAdditionalManager && !coacheeData.IsAdditionalManagerReqApproved) {
    } else if (coacheeData.IsAdditionalManager !== undefined && coacheeData.IsAdditionalManagerReqApproved !== undefined && coacheeData.IsAdditionalManager && coacheeData.IsAdditionalManagerReqApproved) {
      this.isDottedLineTo = true;
      this.isDottedManagerAllowedCssClass = this.checkDottedLineManager();
    } else {

    }
  }

  checkDottedLineManager(): string {
    if (this.isDottedLineTo) {
      if (this.userInfo.AllowDottedManagerRequestCoaching) {
        return 'display';
      } else {
        return 'nodisplay';
      }
    }
    return 'display';
  }

  //  Clone method so make changes both side  iCoachFirst\src\app\components\manage\manage.component.ts :: shoryCutOpenAssignQuickFeedback
  openAssignQuickFeedback(popoverType: string) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.width = '600px';
    dialogConfig.disableClose = true;
    this.commonService.closeleftMenuForiPad();
    const userDetails = this.userService.getUserDetails().UserDetails;
    dialogConfig.data = {
      ManagerId: userDetails.EmpId,
      RepId: this.coacheeId,
      CommentedBy: userDetails.EmpId,
      IsRequestFeedback: false,
      // IsOutOfHierarchy: false,
      feedbackUserDetails: this.coacheeData,
      feedbackPopUpTitle: 'LeftPanel_MyTeam_QuickFeedback'
    };
    this.dialog.open(AssignQuickFeedbackComponent, dialogConfig);
    this.closePopover(popoverType);
  }

  openSolicitFeedback(popoverType: string) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.width = '600px';
    dialogConfig.disableClose = true;
    dialogConfig.data = this.selectedTeamMember;
    this.dialog.open(SolicitFeedbackComponent, dialogConfig);
    this.closePopover(popoverType);
    this.commonService.closeleftMenuForiPad();
  }

  openMyNotesMatPopup(popoverType: string) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.width = '600px';
    dialogConfig.disableClose = true;
    dialogConfig.data = this.coacheeData;
    this.dialog.open(MyNotesComponent, dialogConfig);
    this.closePopover(popoverType);
    this.commonService.closeleftMenuForiPad();
  }

  //  Clone method so make changes both side  iCoachFirst\src\app\components\manage\manage.component.ts :: shoryCutopenMyProfileMatPop
  openMyProfileMatPop(popoverType: string) {
    const request = {} as IUserProfileUrlRequest;
    request.EmpId = this.coacheeId;
    request.EmpName = this.coacheeData.Name;
    request.MemberOrgID = this.userInfo.MemberOrgID;
    request.Source = 'icf6';
    request.PagePath = 'MyProfile';
    request.Culture = this.localizationService.getICF6CultreFromLocalStorage().CultureCode;
    const dialogConfig = new MatDialogConfig();
    dialogConfig.width = 900 + 'px';
    dialogConfig.disableClose = true;
    this.commonService.closeleftMenuForiPad();

    // if (this.coacheeData.EmployeeId === undefined) {
    //   // Get employee table Id
    //   this.connectApiService.GetEmployeeId(this.coacheeId).subscribe(internalEmpId => {

    //     request.eid = this.userInfo.EmployeeId; // internalEmpId;
    //     const reportUrl = this.profileService.getUserProfilePageUrl(request);
    //     dialogConfig.data = { url: reportUrl };
    //     this.dialog.open(IframeModalComponent, dialogConfig);
    //   });

    // } else {
    request.eid = this.userInfo.EmployeeId; // this.coacheeData.EmployeeId;
    const reportUrl = this.profileService.getUserProfilePageUrl(request);
    dialogConfig.data = { url: reportUrl };
    this.dialog.open(IframeModalComponent, dialogConfig);
    this.closePopover(popoverType);
    return false;
  }

  openCompetencyBenchmarkMatPop(popoverType: string) {
    const request = {} as DynamicReportUrlRequest;
    request.CoachId = this.userInfo.EmpId;
    request.MemberOrgID = this.userInfo.MemberOrgID;
    request.CoacheeId = this.coacheeId;
    request.Source = 'icf6';
    request.RedirectTo = 'manage';
    this.commonService.closeleftMenuForiPad();
    request.Culture = this.localizationService.getICF6CultreFromLocalStorage().CultureCode;
    const dialogConfig = new MatDialogConfig();
    dialogConfig.width = 900 + 'px';
    dialogConfig.disableClose = true;
    const reportUrl = this.profileService.getCompetencyBenchmarkPageUrl(request);
    const queryParam = encodeURI(reportUrl);
    this.sharedDataService.setData(reportUrl);
    this.sharedDataService.setRedirectionValue(this.getRedirectionValueFromIframe());
    this.router.navigate(['/iCoachFirst/report/competencybenchmark', request.CoacheeId], { queryParams: { encodedUrl: queryParam } });
    this.closePopover(popoverType);
  }

  requestQuickFeedback(popoverType: string) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.width = '600px';
    dialogConfig.disableClose = true;

    const userDetails = this.userService.getUserDetails().UserDetails;
    dialogConfig.data = {
      ManagerId: this.coacheeId,
      RepId: userDetails.EmpId,
      CommentedBy: userDetails.EmpId,
      IsRequestFeedback: true,
      // IsOutOfHierarchy: (this.coacheeId === userDetails.ManagerId) ? false : true,
      feedbackUserDetails: this.coacheeData,
      feedbackPopUpTitle: 'LeftPanel_MyTeam_RequestQuickFeedback'
    };
    this.dialog.open(AssignQuickFeedbackComponent, dialogConfig);
    this.closePopover(popoverType);
  }

  openQuickFeedbackHistory(popoverType: string) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.width = '900px';
    dialogConfig.disableClose = false;
    this.commonService.closeleftMenuForiPad();

    const request = {} as QuickFeedbackHistoryUrlRequest;
    request.EmpId = this.userInfo.EmpId;
    request.RepId = this.coacheeId;
    request.MemberOrgID = this.userInfo.MemberOrgID;
    request.Value = 'feedbackhistory';
    request.Module = 'connect';
    request.Source = 'icf6';
    request.Culture = 'en';

    dialogConfig.data = request;
    this.dialog.open(FeedbackHistoryComponent, dialogConfig);
    this.closePopover(popoverType);

  }

  createManageUrlRequest(): ManageUrlRequest {
    const request = {} as ManageUrlRequest;
    this.userInfo = this.userService.getUserDetails().UserDetails;
    request.CoachId = this.userInfo.EmpId;
    request.CoacheeId = this.coacheeId;
    request.EmployeeId = this.coacheeData.EmployeeId;
    request.MemberOrgId = this.userInfo.MemberOrgID;
    request.Source = 'icf6';
    request.RedirectTo = 'dashboard';
    request.ICF5IFramePageToOpen = 'manage';
    request.Culture = this.localizationService.getICF6CultreFromLocalStorage().CultureCode;
    return request;
  }

  openManage(type: string) {
    this.router.navigate(['/iCoachFirst/manage/manage', this.coacheeId]);
    if (type === 'flyout') {
      this.teamPopover.hide();
      this.commonService.closeleftMenuForiPad();
    }
  }

  addAdditionalManager() {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.width = '600px';
    dialogConfig.disableClose = true;
    const dialogRef = this.dialog.open(AddAdditionalManagerComponent, dialogConfig);
    dialogRef.afterClosed().subscribe(() => {
      this._eventEmiter.emit({ actionType: 'reloadGroups' });
      // this.setupTeamGroups();
    });
  }

  // Changes for Custom Groups

  subscribeEvents() {
    this.subscription = this._eventEmiter.subscribe(newGroupEvent => {
      if (newGroupEvent.actionType === 'updateGroups') {
        this.teamGroups = this.connectMessageService.getAllGroups();
        this.teamGroups.forEach(team => {
          if (team.groupType === 'mycoaches') {
            const coaches = this.listFeedback.filter(x => x.MenuLabelName === 'Coaches')[0];
            team.GroupName = coaches.EnableValue ? coaches.CustomLabelText : team.GroupName;
            this.isManagerVisible = coaches.OnOffValue;
          } else if (team.groupType === 'myteam') {
            const myteam = this.listFeedback.filter(x => x.MenuLabelName === 'Team')[0];
            team.GroupName = myteam.EnableValue ? myteam.CustomLabelText : team.GroupName;
            this.isMyTeamVisible = myteam.OnOffValue;
          } else if (team.groupType === 'managerteam') {
            const managerteam = this.listFeedback.filter(x => x.MenuLabelName === 'Peers')[0];
            team.GroupName = managerteam.EnableValue ? managerteam.CustomLabelText : team.GroupName;
            this.isPeersVisible = managerteam.OnOffValue;
          }
        });

        // Filtering out the Team List on basis of company specific configuration.
        this.teamGroups = this.teamGroups.filter(team => {
          if (team.groupType === 'mycoaches' && !this.isManagerVisible) {
            return false;
          } else if (team.groupType === 'myteam' && !this.isMyTeamVisible) {
            return false;
          } else if (team.groupType === 'managerteam' && !this.isPeersVisible) {
            return false;
          } else {
            return true;
          }
        });
      }
    });
  }

  isPanelVisible(group: IGroup): boolean {
    if (group.groupType === undefined && !this.userInfo.CreateNewTeamEnable) {
      return false;
    } else {
      return true;
    }
  }

  setupTeamGroups() {
    // TODO CALL CONNECT SERVICE API
    // this.teamGroups = [];
    // this.teamGroups = this.connectMessageService.getAllGroups();
    // call API in case new groups are avilable
    this.connectMessageService.getCustomConnectGroups();

    // this.setupDefaultGroups();
    // const customGroups = this.connectMessageService.getCustomGroups();
    // if (customGroups.length > 0) {
    //   this.teamGroups = this.teamGroups.concat(customGroups);
    // }
  }

  // private setupDefaultGroups() {

  //   if (this.teamList.length > 0) {

  //     const myTeamGroupChannel = this.userInfo.EmailId.trim() + '-group-channel'; // My Team Channel

  //     const teamGroup: IGroup = {
  //       GroupName: 'My Team',
  //       GroupId: 0, // For Default Group
  //       groupType: 'myteam',
  //       ChannelName: myTeamGroupChannel, // My Team Channel
  //       LstMember: this.teamList
  //     };
  //     this.teamGroups.push(teamGroup);
  //   }

  //   if (this.peersList.length > 0) {

  //     const myManagerTeamGroupChannel = this.userInfo.ManagerEmailID.trim() + '-group-channel'; // My Team Channel

  //     const teamGroup: IGroup = {
  //       GroupName: 'My Manager Team',
  //       GroupId: 0, // For Default Group
  //       groupType: 'managerteam',
  //       ChannelName: myManagerTeamGroupChannel, // My manager Team Channel
  //       LstMember: this.peersList
  //     };
  //     this.teamGroups.push(teamGroup);
  //   }

  //   if (this.coachesList.length > 0) {

  //     const myCoachesGroupChannel = this.userInfo.EmailId.trim() + '-coaches-' + 'group-channel'; // My Team Channel

  //     const teamGroup: IGroup = {
  //       GroupName: 'My Coaches',
  //       GroupId: 0, // For Default Group
  //       groupType: 'mycoaches',
  //       ChannelName: myCoachesGroupChannel, // My Coaches Team Channel
  //       LstMember: this.coachesList
  //     };
  //     this.teamGroups.push(teamGroup);
  //   }
  // }

  createTeamClick() {
    const dialogConfig = new MatDialogConfig();
    // dialogConfig.data = {
    //   group: null
    // };
    dialogConfig.width = '600px';
    const dialogRef = this.dialog.open(CreateGroupComponent, dialogConfig);
    dialogRef.afterClosed().subscribe(value => {
      if (value === 'success') {
      }
    });
  }

  groupClick(index: number) {

    // if (this.selectedGroupIndex === index) {
    //   return;
    // }

    this.selectedGroupIndex = index;
    if (this.userInfo.CreateNewTeamEnable) {
      this.openGroupChat(this.teamGroups[index]);
    }
  }

  openGroupChat(group) {

    this.connectMessageService.setSelectedTeam(group);
    if (this.roleService.hasPermission('CNT')) {
      this.router.navigate(['/iCoachFirst/connect/conversations', group.GroupId]);
    } else {
      this.router.navigate(['/iCoachFirst/connect/resources', group.GroupId]);
    }

    this._eventEmiter.emit({ actionType: 'newgroupselected' });
    this._eventEmiter.emit({ actionType: 'messageread' });
  }

  //  Clone method so make changes both side  iCoachFirst\src\app\components\manage\manage.component.ts :: shoryCutopenChat
  openChat(origin) {
    this.connectMessageService.openChat(this.coacheeData);
    this.commonService.closeleftMenuForiPad();
    if (origin === 'coach') {
      this.coachPopover.hide();
    } else if (origin === 'peers') {
      this.peersPopover.hide();
    } else if (origin === 'custom') {
      this.customGroupPopover.hide();
    } else {
      this.teamPopover.hide();
    }
  }

  excludeLoginUser(group: IGroup, member: User) {

    if (group.ChannelName.includes('-coaches-')
      && (group.ChannelName !== this.userInfo.EmailId.trim() + '-coaches-' + 'group-channel')) {

      return true;
    }
    return member.EmpId !== this.userInfo.EmpId;

  }

  closePopover(popoverType: string) {
    if (popoverType === 'teamPopover') {
      this.teamPopover.hide();
    } else if (popoverType === 'coachPopover') {
      this.coachPopover.hide();
    } else if (popoverType === 'peersPopover') {
      this.peersPopover.hide();
    } else if (popoverType === 'customGroupPopover') {
      this.customGroupPopover.hide();
    }
  }

  ngOnDestroy(): void {
    window.removeEventListener('closePopover', () => { });
    this.onlineUsersCollection.unsubscribe();
  }

  getRedirectionValueFromIframe(): string {
    const url = window.location.href;
    return url.split(environment.iframeRedirectionHostName)[1];
  }

  openSuggestedActions(event: CustomEvent, teammember: User) {
    event.preventDefault();
    event.stopPropagation();
    this.selectedTeamMember = teammember;
    const dialogConfig = new MatDialogConfig();
    dialogConfig.data = {
      repDetails: teammember
    };
    dialogConfig.width = '800px';
    dialogConfig.disableClose = true;
    this.dialog.open(SuggestedAction2Component, dialogConfig);
  }

  openAssignSolicitFeedbackSurvey(popovertype: string) {
    event.preventDefault();
    event.stopPropagation();
    const dialogConfig = new MatDialogConfig();
    dialogConfig.data = {
      feedbackUserDetails: this.coacheeData
    };
    dialogConfig.width = '700px';
    dialogConfig.disableClose = true;
    this.dialog.open(AssignSolicitFeedbackSurveyComponent, dialogConfig);
    this.closePopover(popovertype);
  }

  openVideoChatActions(event: CustomEvent, teammember: User, itemName: string) {
    event.preventDefault();
    event.stopPropagation();
    this.videoChatRequest(itemName, teammember);
  }

  startVideoChat(event: CustomEvent, itemName: string) {
    event.preventDefault();
    event.stopPropagation();
    this.videoChatRequest(itemName, this.coacheeData);
  }

  videoChatRequest(itemName: string, teammember: User) {
    this.flyoutMenuItem = this.roleService.getFlyoutMenuItem(itemName);
      if (this.flyoutMenuItem.OnOffValue && teammember.isUserOnline) {
      const retreiveDetails = this.sharedDataService.getVideoSessionDetails();
      if (retreiveDetails === undefined) { // new chat start request
        const confirmBoxText = this.commonService.prepareParameterizedConfim(['Request_for_VideoChat', teammember.Name]);
        this.confirmationDialogService.confirm(confirmBoxText, 'Common_Yes', 'Common_No').subscribe(value => {
          if (value) {
            this.selectedTeamMember = teammember;
            this.openVideoChat();
          }
        });
      } else { // add request to the already going chat
        const videoChatUsers = this.sharedDataService.getVideoChatUsersCollection();
        let emailFound = false;
        videoChatUsers.forEach(data => {
          if (data === teammember.EmailId.trim()) {
            emailFound = true;
          }
        });
        if (!emailFound) {
          const confirmBoxText = this.commonService.prepareParameterizedConfim(['AdditionalRequest_for_VideoChat', teammember.Name]);
          this.confirmationDialogService.confirm(confirmBoxText, 'Common_Yes', 'Common_No').subscribe(value => {
            if (value) {
              this.selectedTeamMember = teammember;
              this.openVideoChat();
              this.connectMessageService.sendMessageToUser(this.sharedDataService.getVideoSessionDetails(), this.selectedTeamMember.EmailId.trim());
            }
          });
        } else {
          this.toast.error('VideoChat_InProgress', '');
        }
      }
    }
  }

  openVideoChat() {
    this._eventEmiter.emit({ actionType: 'openVideoChatPanel' });
    this.sharedDataService.setVideoChatUsersCollection(this.selectedTeamMember.EmailId.trim());
    // // this opens video chat in the main window
    // this.router.navigate(['/iCoachFirst/learn/videochat']);
    // this.commonService.closeleftMenuForiPad();
    // this.closePopover(popoverType);
    // this.openVideoChatComponentLeftContainer(ApplicationModuleListEnum.None);
  }

  openVideoChatComponentLeftContainer(appModuleId: number) {
    this.setLeftContainerVisibility.emit(appModuleId);
  }
}
