import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SharedDataService } from 'src/app/services/shared-data.service';
import { CommonService } from 'src/app/services/common.service';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-competency-benchmark-viewer',
  templateUrl: './competency-benchmark-viewer.component.html',
  styleUrls: ['./competency-benchmark-viewer.component.scss']
})
export class CompetencyBenchmarkComponent implements OnInit, OnDestroy {

  competencyBenchmarkUrl: string;
  ignoreModelForBackHistory = ['report/dynamicreport'];
  coacheeId: number;
  userDetails: any;
  callBackComplete: boolean;
  constructor(private sharedDataService: SharedDataService,
    private route: ActivatedRoute,
    private router: Router,
    private commonService: CommonService,
    private authService: AuthService
  ) { }

  ngOnInit() {
    window.addEventListener('message', this.handleIframeTask.bind(this));
    this.callBackComplete = false;
    this.route.params.subscribe(params => {
      if (params.coacheeid) {
        const reportUrl = this.sharedDataService.getData();
        if (reportUrl !== undefined) {
          this.competencyBenchmarkUrl = reportUrl;
        } else {
          this.route.queryParams.subscribe(param => {
            // Defaults to 0 if no query param provided.
            const encodedUrl = param['encodedUrl'];
            if (encodedUrl !== undefined) {
              this.competencyBenchmarkUrl = decodeURI(encodedUrl);
            } else {
              this.router.navigate(['/iCoachFirst/dashboard']);
            }
          });
        }
      }
    });
  }

  handleIframeTask(e: any) {
    window.removeEventListener('message', () => { });
    // Member variable this.callBackComplete will be false if user refreshes the url
    // and it will be true if user open this same component again and again
    // so added the check using variable
    if (!this.callBackComplete) {
      if (e.data.redirectTo === undefined) {
        // the redirectTo will be undefined if user directly refreshes the url
        // added because this func is getting fired first if user refreshes url directly.
        return;
      }
      if (e.data.redirectTo) {
        if (e.data.redirectTo === 'logout') {
          this.authService.commonLogout();
          return;
        } else {
          this.callBackComplete = true;
          let redirect = this.sharedDataService.getRedirectionValue();
          if (redirect !== undefined) {
            redirect = decodeURIComponent(redirect);
            this.router.navigate([`/${redirect}`]);
          } else {
            this.router.navigate(['/iCoachFirst/dashboard']);
          }
        }
      }
    }
  }

  ngOnDestroy() {
    this.callBackComplete = true;
    window.removeEventListener('message', () => { });
  }

  closePopupOnIframe() {
    this.commonService.closePopupOnIframe();
  }

}
