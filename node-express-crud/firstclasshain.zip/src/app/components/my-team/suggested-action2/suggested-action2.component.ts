import { Component, OnInit, Inject, ElementRef, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { KeyValuePair } from 'src/app/models/key-value-pair';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialogConfig, MatDialog } from '@angular/material';
import { MyTeamService } from 'src/app/services/my-team.service';
import { ScheduleCoachingConversationRequest } from 'src/app/models/requests/my-team-request';
import { UserService } from 'src/app/services/user.service';
import { User } from 'src/app/models/response/user-response';
import { DatePipe } from '@angular/common';
import { TranslatePipe } from 'src/app/pipes/translate.pipe';
import { IcftoasterService } from 'src/app/services/icftoaster.service';
import { environment } from 'src/environments/environment';
import { SharedDataService } from 'src/app/services/shared-data.service';
import { Router } from '@angular/router';
import { CommonService } from 'src/app/services/common.service';
import { LocalizationService } from 'src/app/services/localization.service';
import { IframeModalComponent } from '../../shared/iframe-modal/iframe-modal.component';
import { DynamicReportUrlRequest } from 'src/app/models/requests/url-builder/dynamic-report-url-request';
import { DynamicReportUrlBuilderService } from 'src/app/services/dynamic-report-url-builder.service';
import { ICoachingReportResponse } from '../../../models/response/icoaching-report-response';

@Component({
  selector: 'app-suggested-action2',
  templateUrl: './suggested-action2.component.html',
  styleUrls: ['./suggested-action2.component.scss']
})
export class SuggestedAction2Component implements OnInit {

  converstaionType: string;
  scheduleForm: FormGroup;
  minDate: Date = new Date();
  timeArray: KeyValuePair[] = [];
  submitted = false;
  userInfo: User;
  teammember: User;
  ScheduledInfo: string;
  CCReviewCycleTitle: string;
  IsCoachingConversationPending = false;
  IsInitiatedReviewPending = false;
  IsPeriodicReviewPending = false;
  reportUrl: string;
  remindMeLaterArr: KeyValuePair[] = [];
  remindLaterForm: FormGroup;
  InitiatedReviewReportName = '';
  CoachingConversationReportName = '';
  PendingPeriodReviewReportName = '';

  @ViewChild('coachingInfo') private ref: ElementRef;

  NoRMLOffer = false;
  RMLWaitOver = false;
  RMLDisabled = false;
  ccReviewReport: ICoachingReportResponse;

  constructor(
    private fb: FormBuilder,
    public dialogRef: MatDialogRef<SuggestedAction2Component>,
    private myTeamService: MyTeamService,
    private userService: UserService,
    private datePipe: DatePipe,
    private translatePipe: TranslatePipe,
    private toast: IcftoasterService,
    private sharedDataService: SharedDataService,
    private router: Router,
    private commonService: CommonService,
    private localizationService: LocalizationService,
    private dialog: MatDialog,
    private dynamicUrlBuilderService: DynamicReportUrlBuilderService,
    @Inject(MAT_DIALOG_DATA) public data
  ) {

  }

  ngOnInit() {
    this.userInfo = this.userService.getUserDetails().UserDetails;
    this.teammember = this.data.repDetails;
    this.myTeamService.getReviewCycleDetails(this.teammember.EmpId).subscribe(response => {

      this.NoRMLOffer = response.CoachingConversationReviewData.NoRMLOffer;
      this.RMLWaitOver = response.CoachingConversationReviewData.RMLDateOver;
      this.IsCoachingConversationPending = response.IsCoachingConversationEnabled;
      this.IsInitiatedReviewPending = response.IsInitiateReviewCycleEnabled;
      this.RMLDisabled = (this.NoRMLOffer || (!this.RMLWaitOver));
      this.CCReviewCycleTitle = response.CoachingConversationReviewData.CycleName;
      this.teammember.CoachingConversationCycleId = response.CoachingConversationReviewData.CycleId;
      this.ccReviewReport  = response.CoachingConversationReviewData.ReviewReport;
      this.ccReviewReport.EmpReportId=response.CoachingConversationReviewData.EmpReportId;
      if (!response.IsScheduled) {
        this.ScheduledInfo = '';
        this.scheduleForm = this.fb.group({
          'startDate': ['', Validators.required],
          'startTime': ['', Validators.required],
          'endDate': ['', Validators.required],
          'endTime': ['', Validators.required],
          'location': [''],
          'notes': ['']
        });

        this.generateTime();

        this.scheduleForm.valueChanges.subscribe(() => {
          this.submitted = false;
          this.f.endDate.setErrors(null);
        });
      } else {
        // Conversation is already scheduled
        const value = this.translatePipe.transform(response.FormattedText);
        let str = value.replace('^^', '<span class="anchor-text-color">' + response.StartDateTime + '</span>');
        str = str.replace('**', '<span class="anchor-text-color">' + response.EndDateTime + '</span>');
        this.ScheduledInfo = str;
      }

      for (let i = 0; i <= response.CycleCloseRemainingDays; i++) {
        this.remindMeLaterArr.push({ Key: i.toString(), Value: i.toString() });
      }
      this.remindLaterForm = this.fb.group({
        remindLater: ''
      });
    });


  }

  conversationChange(type: string) {
    if (type === 'Schedule' && this.ScheduledInfo) {
      this.converstaionType = 'AlreadyScheduled';
      setTimeout(() => {
        this.ref.nativeElement.innerHTML = this.ScheduledInfo;
      }, 200);
    } else {
      this.converstaionType = type;
    }
  }

  closeConversation() {
    this.converstaionType = '';
  }

  get f() {
    return this.scheduleForm.controls;
  }

  onSubmit() {
    this.submitted = true;
    if (this.scheduleForm.invalid) {
      return;
    }

    if (this.validateDate()) {
      const values = this.scheduleForm.value;
      const startStr = this.datePipe.transform(new Date(`${values.startDate} ${values.startTime}`), 'yyyy-MM-dd HH:mm:ss');
      const endStr = this.datePipe.transform(new Date(`${values.endDate} ${values.endTime}`), 'yyyy-MM-dd HH:mm:ss');
      const req: ScheduleCoachingConversationRequest = {
        PeriodicReviewId: 0,
        SelectedEmployee: this.teammember,
        StartDateTime: startStr,
        EndDateTime: endStr,
        Notes: this.f.notes.value,
        ScheduleLocation: this.f.location.value,
        RemindMeLaterDays: 0,
        MemberOrgId: this.userInfo.MemberOrgID,
        LoggedInEmpId: this.userInfo.EmployeeId,
        CreatedBy: this.userInfo.EmployeeId,
        RepId: this.teammember.EmpId
      };
      this.myTeamService.createScheduleForCoachingConversation(req).subscribe(response => {
        if (response.IsScheduled) {
          this.toast.success('DashboardPopUpPage_ScheduledCoachingConversationRequestCreatedSuccessfully');
          this.teammember.ShowEmployeeAlertFlag=false;
        } else {
          this.toast.error('OperationFailedMessage');
        }
        this.closeDialog();
      });
    }
  }

  validateDate(): boolean {
    const values = this.scheduleForm.value;
    const startDate = new Date(values.startDate);
    const endDate = new Date(values.endDate);

    if (startDate.getTime() > endDate.getTime()) {
      this.f.endDate.setErrors({ 'lesser': true });
      return false;
    } else if (startDate.getTime() === endDate.getTime()) {
      const startIdx = this.timeArray.findIndex(x => x.Value === values.startTime);
      const endIdx = this.timeArray.findIndex(x => x.Value === values.endTime);
      if (startIdx > endIdx) {
        this.f.endDate.setErrors({ 'lesser': true });
        return false;
      } else {
        return true;
      }
    } else {
      return true;
    }
  }

  closeDialog() {
    this.dialogRef.close();
  }

  openReprotInDynamicReportViewer(url: string) {
    const queryParam = encodeURI(url);
    const reportName = this.commonService.getUrlParameter(url, 'ReportName');
    this.closeDialog();
    this.sharedDataService.setData(url);
    this.sharedDataService.setRedirectionValue(this.getRedirectionValueFromIframe());
    this.router.navigate(['/iCoachFirst/report/dynamicreport', reportName], { queryParams: { encodedUrl: queryParam } });
  }

  openReportInIframeModal(url: string) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.width = 900 + 'px';
    dialogConfig.disableClose = true;
    dialogConfig.data = { url: url };
    this.dialog.open(IframeModalComponent, dialogConfig);
  }

  openCoachingConversationReport() {
    this.getDynamicReportUrl(this.ccReviewReport);
    this.closeDialog();
  }

  createUrlRequest(reportItem: ICoachingReportResponse): DynamicReportUrlRequest {
    const request = {} as DynamicReportUrlRequest;
    this.userInfo = this.userService.getUserDetails().UserDetails;
    
    request.EmpReportId = reportItem.EmpReportId;
    if (reportItem.IsDynamic) {
      request.IsMgr = 'T';
        request.CoachId = this.userInfo.EmpId;
        request.CoacheeId = this.teammember.EmpId;
        request.CoachName = this.userInfo.Name;
        request.CoacheeName = this.teammember.Name;
    } else {
      request.CoachId = this.userInfo.EmployeeId;
    }
    request.ReportName = reportItem.ReportName;
    request.ReportId = reportItem.ReportId;
    request.IsRepInitiated = false;
    request.MemberOrgID = this.userInfo.MemberOrgID;
    request.PagePath = reportItem.PagePath;
    request.Source = 'icf6';
    request.RedirectTo = 'fromDashboard';
    request.Culture = this.localizationService.getICF6CultreFromLocalStorage().CultureCode;
    return request;
  }
  

  getDynamicReportUrl(report: ICoachingReportResponse)
  {
    this.reportUrl = this.dynamicUrlBuilderService.newReportUrl(this.createUrlRequest(report));
    this.reportUrl = this.reportUrl + "&iscoachingconversation=T&cycleid=" +this.teammember.CoachingConversationCycleId
      // const url = JSON.parse(JSON.stringify(this.reportUrl));
      // const queryParam = encodeURI(this.commonService.updateUrlParameter(url, 'ICF6redirectTo', this.getRedirectionValueFromIframe()));
      const queryParam = encodeURI(this.reportUrl);
      //this.coachingReportPopUpClose();
      this.sharedDataService.setData(this.reportUrl);
      this.sharedDataService.setRedirectionValue(this.getRedirectionValueFromIframe());
      this.router.navigate(['/iCoachFirst/report/dynamicreport', report.ReportName], { queryParams: { encodedUrl: queryParam } });
  }

  openInitiateReviewReport() {
    const url1 = `${environment.domainName}/Talentfirst/${this.teammember.InitiatedReviewReportName}`;
    const url = this.createUrl(url1, 'RepInitiated');
    if (this.teammember.InitiatedReviewReportPath.includes('ReviewReport')) {
      this.openReprotInDynamicReportViewer(url);
    } else {
      this.openReportInIframeModal(url);
    }
  }

  openPeriodicReviewReport() {
    const url1 = `${environment.domainName}/Talentfirst/${this.teammember.PendingPeriodReviewReportName}`;
    const url = this.createUrl(url1, 'Periodic');
    if (this.teammember.PendingPeriodReviewReportPath.includes('ReviewReport')) {
      this.openReprotInDynamicReportViewer(url);
    } else {
      this.openReportInIframeModal(url);
    }
  }

  createUrl(url: string, type: string) {
    let paramType = '';
    let cycleId = '';
    if (type === 'Coaching') {
      paramType = 'iscoachingconversation=T';
      cycleId = `&cycleid=${this.teammember.CoachingConversationCycleId}`;
    } else if (type === 'RepInitiated') {
      paramType = 'IsInitiate=T';
      cycleId = `&cycleid=${this.teammember.InitiatedReviewCycleId}`;
    } else if (type === 'Periodic') {
      paramType = 'IsReview=T';
      cycleId = `&cycleid=${this.teammember.PeriodReviewCycleId}`;
    }
    const culture = this.localizationService.getCutureCode();
    return url + '?' + paramType + cycleId + '&EmpId=' + this.teammember.ManagerId + '&MemberOrgId=' + this.userInfo.MemberOrgID
      + '&source=icf6' + '&ICF6redirectTo=dashboard' + '&culture=' + culture;

  }

  getRedirectionValueFromIframe(): string {
    const url = window.location.href;
    return url.split(environment.iframeRedirectionHostName)[1];
  }

  remindLater() {

    if (this.RMLDisabled && this.remindLaterForm.invalid) {
      return;
    }

    const req = {
      SelectedEmployee: this.teammember,
      ManagerId: this.teammember.ManagerId,
      EmpId: this.teammember.EmpId
    };

    this.myTeamService.saveCoachingConversationRemindMeLater(req).subscribe(response => {
      if (response) {
        this.toast.success('Common_RemindMeLater_InformationSavedSuccessfully');
        this.teammember.ShowEmployeeAlertFlag=false;
        this.closeDialog();
      } else {
        this.toast.error('OperationFailedMessage');
      }
      this.converstaionType = '';
    });
  }

  generateTime() {
    this.timeArray = [
      { Key: '12:00 AM', Value: '12:00 AM' },
      { Key: '12:30 AM', Value: '12:30 AM' },
      { Key: '01:00 AM', Value: '01:00 AM' },
      { Key: '01:30 AM', Value: '01:30 AM' },
      { Key: '02:00 AM', Value: '02:00 AM' },
      { Key: '02:30 AM', Value: '02:30 AM' },
      { Key: '03:00 AM', Value: '03:00 AM' },
      { Key: '03:30 AM', Value: '03:30 AM' },
      { Key: '04:00 AM', Value: '04:00 AM' },
      { Key: '04:30 AM', Value: '04:30 AM' },
      { Key: '05:00 AM', Value: '05:00 AM' },
      { Key: '05:30 AM', Value: '05:30 AM' },
      { Key: '06:00 AM', Value: '06:00 AM' },
      { Key: '06:30 AM', Value: '06:30 AM' },
      { Key: '07:00 AM', Value: '07:00 AM' },
      { Key: '07:30 AM', Value: '07:30 AM' },
      { Key: '08:00 AM', Value: '08:00 AM' },
      { Key: '08:30 AM', Value: '08:30 AM' },
      { Key: '09:00 AM', Value: '09:00 AM' },
      { Key: '09:30 AM', Value: '09:30 AM' },
      { Key: '10:00 AM', Value: '10:00 AM' },
      { Key: '10:30 AM', Value: '10:30 AM' },
      { Key: '11:00 AM', Value: '11:00 AM' },
      { Key: '11:30 AM', Value: '11:30 AM' },
      { Key: '12:00 PM', Value: '12:00 PM' },
      { Key: '12:30 PM', Value: '12:30 PM' },
      { Key: '01:00 PM', Value: '01:00 PM' },
      { Key: '01:30 PM', Value: '01:30 PM' },
      { Key: '02:00 PM', Value: '02:00 PM' },
      { Key: '02:30 PM', Value: '02:30 PM' },
      { Key: '03:00 PM', Value: '03:00 PM' },
      { Key: '03:30 PM', Value: '03:30 PM' },
      { Key: '04:00 PM', Value: '04:00 PM' },
      { Key: '04:30 PM', Value: '04:30 PM' },
      { Key: '05:00 PM', Value: '05:00 PM' },
      { Key: '05:30 PM', Value: '05:30 PM' },
      { Key: '06:00 PM', Value: '06:00 PM' },
      { Key: '06:30 PM', Value: '06:30 PM' },
      { Key: '07:00 PM', Value: '07:00 PM' },
      { Key: '07:30 PM', Value: '07:30 PM' },
      { Key: '08:00 PM', Value: '08:00 PM' },
      { Key: '08:30 PM', Value: '08:30 PM' },
      { Key: '09:00 PM', Value: '09:00 PM' },
      { Key: '09:30 PM', Value: '09:30 PM' },
      { Key: '10:00 PM', Value: '10:00 PM' },
      { Key: '10:30 PM', Value: '10:30 PM' },
      { Key: '11:00 PM', Value: '11:00 PM' },
      { Key: '11:30 PM', Value: '11:30 PM' }
    ];
  }

}
