import { Component, OnInit, Inject } from '@angular/core';
import { Router } from '@angular/router';
import { BaseRequest } from '../../../models/requests/base-request';
import { UserDetails } from 'src/app/models/user-details-result';
import { UserService } from 'src/app/services/user.service';
import { ICoachingReportResponse } from '../../../models/response/icoaching-report-response';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialogConfig, MatDialog } from '@angular/material';
import { DynamicReportUrlRequest } from 'src/app/models/requests/url-builder/dynamic-report-url-request';
import { SharedDataService } from 'src/app/services/shared-data.service';
import { DynamicReportUrlBuilderService } from 'src/app/services/dynamic-report-url-builder.service';
import { StaticReportUrlBuilderService } from 'src/app/services/static-report-url-builder.service';
import { LocalizationService } from 'src/app/services/localization.service';
import { User } from 'src/app/models/response/user-response';
import { ReportType, ModalPopupSizeEnum } from 'src/app/helpers/enums/common-enums';
import { AssignCoachingReportService } from 'src/app/services/assign-coaching-report.service';
import { LearnService } from 'src/app/services/learn.service';
import { environment } from 'src/environments/environment';
import { CreateCertifyRequest } from 'src/app/models/requests/create-certify-request';
import { SurveyService } from 'src/app/services/survey.service';
import { SurveyCreatorComponent } from '../../shared/survey-creator/survey-creator.component';
import { IcftoasterService } from 'src/app/services/icftoaster.service';
import { CommonService } from 'src/app/services/common.service';

@Component({
  selector: 'app-assign-coaching-report',
  templateUrl: './assign-coaching-report.component.html',
  styleUrls: ['./assign-coaching-report.component.scss']
})
export class AssignCoachingReportComponent implements OnInit {


  userInfo: UserDetails;
  createCertifyRequest: CreateCertifyRequest;
  candAssId: number;
  certifyId: string;
  coachingReportList: ICoachingReportResponse[] = [];
  coachingFeedbackTypeList: ICoachingReportResponse[] = [];
  certificationAssessmentTypeList: ICoachingReportResponse[] = [];
  planTypeList: ICoachingReportResponse[] = [];
  reviewTypeList: ICoachingReportResponse[] = [];
  reportUrl: string;
  parentData: BaseRequest;
  coacheeData: User;
  filtertype: string;
  ReportType = ReportType;
  feedbackPopUpTitle: string;
  msteam_popup_css = '';

  constructor(private userService: UserService,
    private coachingReportService: AssignCoachingReportService,
    private router: Router,
    private learnService: LearnService,
    private sharedDataService: SharedDataService,
    private dynamicUrlBuilderService: DynamicReportUrlBuilderService,
    private staticUrlBuilderService: StaticReportUrlBuilderService,
    private localizationService: LocalizationService,
    public dialogRef: MatDialogRef<AssignCoachingReportComponent>,
    private surveyService: SurveyService,
    private dialog: MatDialog,
    private toast: IcftoasterService,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private commonService: CommonService
    ) { }

  ngOnInit() {
    this.parentData = this.data.dataToPass;
    this.coacheeData = this.data.coacheeData;
    this.filtertype = this.data.filterType;
    this.feedbackPopUpTitle = this.data.feedbackPopUpTitle ? this.data.feedbackPopUpTitle : 'Coaching Conversations';
    this.coachingReportList = this.data.coachingAssignments ? this.data.coachingAssignments : [];
    this.getReports();
    this.createCertifyRequest = { CertifyId: 0, QuizType: '', HostName: '', SelectedEmployeeId: 0, LoggedEmpId: 0 };
    if (this.commonService.getMSTeamViewConfig()) {
      this.msteam_popup_css = 'icf_msteam';
    } else {
      this.msteam_popup_css = '';
    }

  }

  openReport(report: ICoachingReportResponse, type: Number) {
    if (type === 1 && report.Flag === 'CASS') {
      this.userInfo = this.userService.getUserDetails().UserDetails;
      this.certifyId = report.AssessFlag.toString().split('|')[1];
      this.createCertifyRequest.SelectedEmployeeId = this.coacheeData.EmpId;
      this.createCertifyRequest.CertifyId = Number(this.certifyId);
      this.createCertifyRequest.QuizType = 'certify';
      this.createCertifyRequest.HostName = `${environment.domainUrl}`;
      this.createCertifyRequest.LoggedEmpId = this.userInfo.EmployeeId;
      this.learnService.getCandidateAssessmentIdForCertify(this.createCertifyRequest).subscribe(response => {
        if (response.CandidateAssessmentId > 0) {
           this.coachingReportPopUpClose();
           this.openPulseSurvey(response.CandidateAssessmentId, false);
        /*
          const request: any = {
            CandAssId: response.CandidateAssessmentId,
            RedirectTo: 'fromAssignPopup',
            Culture: this.localizationService.getCutureCode(),
            MemberOrgId: this.userInfo.MemberOrgID
          };
          this.reportUrl = this.staticUrlBuilderService.openSurveyAssessmentForNonCompleted(request);
          const queryParam = encodeURI(this.reportUrl);
          this.coachingReportPopUpClose();
          this.sharedDataService.setData(this.reportUrl);
          this.sharedDataService.setRedirectionValue(this.getRedirectionValueFromIframe());
          this.router.navigate(['/iCoachFirst/report/dynamicreport', report.ReportName], { queryParams: { encodedUrl: queryParam } });
          */
        }
      });
    } else if (report.IsDynamic) {
      this.reportUrl = this.dynamicUrlBuilderService.newReportUrl(this.createUrlRequest(report));
      // const url = JSON.parse(JSON.stringify(this.reportUrl));
      // const queryParam = encodeURI(this.commonService.updateUrlParameter(url, 'ICF6redirectTo', this.getRedirectionValueFromIframe()));
      const queryParam = encodeURI(this.reportUrl);
      this.coachingReportPopUpClose();
      this.sharedDataService.setData(this.reportUrl);
      this.sharedDataService.setRedirectionValue(this.getRedirectionValueFromIframe());
      this.router.navigate(['/iCoachFirst/report/dynamicreport', report.ReportName], { queryParams: { encodedUrl: queryParam } });
    } else {
      this.reportUrl = this.staticUrlBuilderService.newReportUrl(this.createUrlRequest(report));
      const queryParam = encodeURI(this.reportUrl);
      this.coachingReportPopUpClose();
      this.sharedDataService.setData(this.reportUrl);
      this.sharedDataService.setRedirectionValue(this.getRedirectionValueFromIframe());
      this.router.navigate(['/iCoachFirst/report/dynamicreport', report.ReportName], { queryParams: { encodedUrl: queryParam } });
    }
  }

  createUrlRequest(reportItem: ICoachingReportResponse): DynamicReportUrlRequest {
    const request = {} as DynamicReportUrlRequest;
    this.userInfo = this.userService.getUserDetails().UserDetails;
    request.EmpReportId = reportItem.EmpReportId;
    if (reportItem.IsDynamic) {
      if (this.parentData.IsRepInitiated) {
        request.IsMgr = 'F';
        request.CoachId = this.coacheeData.EmpId;
        request.CoacheeId = this.userInfo.EmpId;
        request.CoachName = this.coacheeData.Name;
        request.CoacheeName = this.userInfo.Name;
      } else {
        request.IsMgr = 'T';
        request.CoachId = this.userInfo.EmpId;
        request.CoacheeId = this.parentData.RepId;
        request.CoachName = this.userInfo.Name;
        request.CoacheeName = this.coacheeData.Name;
      }
    } else {
      if (this.parentData.IsRepInitiated) {
        request.IsMgr = 'F';
        request.CoachId = this.coacheeData.EmployeeId;
        request.CoacheeId = this.userInfo.EmpId;
        request.CoachName = this.coacheeData.Name;
        request.CoacheeName = this.userInfo.Name;
      } else {
        request.IsMgr = 'T';
        request.CoachId = this.userInfo.EmployeeId;
        request.CoacheeId = this.parentData.RepId;
        request.CoachName = this.userInfo.Name;
        request.CoacheeName = this.coacheeData.Name;
      }
    }
    request.ReportName = reportItem.ReportName;
    request.ReportId = reportItem.ReportId;
    request.IsRepInitiated = this.parentData.IsRepInitiated;
    request.MemberOrgID = this.userInfo.MemberOrgID;
    request.PagePath = reportItem.PagePath;
    request.Source = 'icf6';
    request.RedirectTo = 'fromAssignPopup';
    request.Culture = this.localizationService.getICF6CultreFromLocalStorage().CultureCode;
    request.IsDynamic = reportItem.IsDynamic;
    return request;
  }

  getReports() {
    const request = new BaseRequest();
    this.userInfo = this.userService.getUserDetails().UserDetails;
    request.EmployeeId = this.userInfo.EmployeeId;
    request.MemberOrgId = this.userInfo.MemberOrgID;
    request.RepId = this.parentData.RepId;

    if (this.coachingReportList !== undefined && this.coachingReportList.length > 0) {
      this.populateReportList(this.coachingReportList);
    } else if (this.parentData.IsRepInitiated) {
      this.coachingReportService.getReportsForPeerRepInitiated(request).subscribe(data => {
        this.coachingReportList = data.filter(t => t.IsDynamic === true);
        if (this.coachingReportList.length > 0) {
          this.populateReportList(this.coachingReportList);
        }
      });

    } else {
      this.coachingReportService.getReportsForEmployee(request).subscribe(response => {
        // ICF6-560 IsDynamic check is not applicable for Certificate & Assessment type
        if (this.filtertype !== ReportType.CertificationAssessment) {
          this.coachingReportList = response.filter(t => t.IsDynamic === true);
        } else {
          this.coachingReportList = response;
        }

        if (this.coachingReportList.length > 0) {
          this.populateReportList(this.coachingReportList);
        }
      });
    }
  }

  private populateReportList(coachingReportList: ICoachingReportResponse[]) {
    const coachingFeedBack = coachingReportList.filter(v => v.CertifyType.trim().toUpperCase() === 'F');

    if (coachingFeedBack.length > 0) {
      this.coachingFeedbackTypeList = coachingFeedBack;
    }
    const certificationAssessment = coachingReportList.filter(v => v.CertifyType.trim().toUpperCase() === 'C');

    if (certificationAssessment.length > 0) {
      this.certificationAssessmentTypeList = certificationAssessment;
    }

    const plans = coachingReportList.filter(v => v.CertifyType.trim().toUpperCase() === 'P');

    if (plans.length > 0) {
      this.planTypeList = plans;
    }

    const reviews = coachingReportList.filter(v => v.CertifyType.trim().toUpperCase() === 'R');

    if (reviews.length > 0) {
      this.reviewTypeList = reviews;
    }

    // Showing tabs based on report type
    if (this.filtertype !== undefined) {
      if (this.filtertype === ReportType.Coaching) {
        this.certificationAssessmentTypeList = [];
        this.planTypeList = [];
        this.reviewTypeList = [];
      } else if (this.filtertype === ReportType.CertificationAssessment) {
        this.coachingFeedbackTypeList = [];
        this.planTypeList = [];
        this.reviewTypeList = [];
      } else if (this.filtertype === ReportType.Plans) {
        this.coachingFeedbackTypeList = [];
        this.certificationAssessmentTypeList = [];
        this.reviewTypeList = [];
      } else if (this.filtertype === ReportType.Reviews) {
        this.coachingFeedbackTypeList = [];
        this.certificationAssessmentTypeList = [];
        this.planTypeList = [];
      }
    }
  }

  coachingReportPopUpClose() {
    this.dialogRef.close();
  }

  getRedirectionValueFromIframe(): string {
    const url = window.location.href;
    return url.split(environment.iframeRedirectionHostName)[1];
  }
  openPulseSurvey(candidateAssessmentId: number,  isPulseSurvey: boolean = false) {
    const EmpId = this.userService.getUserDetails().UserDetails.EmpId;
    this.surveyService.getPulseSurveyDetails(candidateAssessmentId, isPulseSurvey).subscribe(resp => {
      if (resp.length > 0) {
        resp[0].EmpId = EmpId;
        const dialogConfig = new MatDialogConfig();
        dialogConfig.width = ModalPopupSizeEnum.PulseSurveyModalWidth + 'px';
        dialogConfig.disableClose = true;
        dialogConfig.data = resp[0];
        this.dialog.open(SurveyCreatorComponent, dialogConfig).afterClosed().subscribe((response) => {
          if (response === 'complete' || response === 'Inprogress') {
            // this.reloadAllPending();
          }
        });
      } else if (resp.length === 0) {
        this.toast.error('OperationFailedMessage');
      }
    });
  }
}
