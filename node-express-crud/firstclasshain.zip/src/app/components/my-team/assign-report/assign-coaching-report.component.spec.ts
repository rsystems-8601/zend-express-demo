import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AssignCoachingReportComponent } from './assign-coaching-report.component';

describe('AssignCoachingReportComponent', () => {
  let component: AssignCoachingReportComponent;
  let fixture: ComponentFixture<AssignCoachingReportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssignCoachingReportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssignCoachingReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
