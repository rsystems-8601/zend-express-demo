import { Component, OnInit, Inject, ViewChild, ElementRef } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { Review_Journal } from '../../../helpers/enums/common-enums';
import { UserDetails } from 'src/app/models/user-details-result';
import { UserService } from 'src/app/services/user.service';
import { SaveEditorRequest, Editor } from 'src/app/models/requests/my-notes-request';
import {MyNotesService} from 'src/app/services/my-notes.service';
import { Guid } from 'guid-typescript';
import { IcftoasterService } from 'src/app/services/icftoaster.service';
import { User } from 'src/app/models/response/user-response';
import { MyNotesResponse } from 'src/app/models/response/my-notes-response';
import { CommonService } from 'src/app/services/common.service';

@Component({
  selector: 'app-my-notes',
  templateUrl: './my-notes.component.html',
  styleUrls: ['./my-notes.component.scss']
})
export class MyNotesComponent implements OnInit {

  coacheeData: User;
  performanceJournalEntry: string;
  userInfo: UserDetails;
  performanceJournalResponse: MyNotesResponse[] = [];
  msteam_popup_css = '';

  @ViewChild('scrollMe') private myScrollContainer: ElementRef;

  constructor(private userService: UserService, private myNotesService: MyNotesService,
    private toast: IcftoasterService,
     public dialogRef: MatDialogRef<MyNotesComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private commonService: CommonService) { }

  ngOnInit() {
    this.coacheeData = this.data;
    this.getPerformanceJournal(this.coacheeData.EmpId);
    if (this.commonService.getMSTeamViewConfig()) {
      this.msteam_popup_css = 'icf_msteam';
    } else {
      this.msteam_popup_css = '';
    }
  }

  // tslint:disable-next-line:use-life-cycle-interface
  ngAfterViewChecked() {
    this.myScrollContainer.nativeElement.scrollTop = this.myScrollContainer.nativeElement.scrollHeight;
  }

  myNotesPopUpClose() {
    this.dialogRef.close();
  }

  savePerformanceJournal() {
    if (!(this.performanceJournalEntry === undefined) && !(this.performanceJournalEntry.trim() === '')) {
    const request = {} as SaveEditorRequest;
    const editor = {} as Editor;
    request.Editors = [];
    this.userInfo = this.userService.getUserDetails().UserDetails;
    editor.CKEditorId = 'editor-tfGUID-' + Guid.create().toString();
    editor.CKEditorContent = this.performanceJournalEntry;
    editor.ReviewType = Review_Journal.REVIEW_LEFTPANEL_JOURNAL.toString();
    request.CreatedBy = this.userInfo.EmpId;
    request.MemberOrgId = this.userInfo.MemberOrgID;
    request.RepId = this.coacheeData.EmpId;
    request.LoggedInEmpId = this.userInfo.EmpId;
    request.IsNonEditorData = true;
    request.Editors.push(editor);

    this.myNotesService.savePerformanceJournal(request).subscribe(data => {
          if (data === true) {
            this.toast.success('Common_UpdateSuccess');
            this.performanceJournalEntry = undefined;
            this.getPerformanceJournal(this.coacheeData.EmpId);
          } else {
            this.toast.error('Something went wrong. Please try again.');
          }
        });
      } else {
          this.toast.error('Please enter some data.');
    }
  }

  getPerformanceJournal(coacheeId: number) {
    this.myNotesService.getPerformanceJournal(coacheeId).subscribe(data => {
      if (data.length > 0) {
        this.userInfo = this.userService.getUserDetails().UserDetails;
        this.performanceJournalResponse = data.filter(t => t.ManagerId === this.userInfo.EmpId);
      } else {
        this.performanceJournalResponse = [];
      }
    });
  }

  deletePerformanceJournal(performanceJournal: MyNotesResponse) {
    this.myNotesService.deletePerformanceJournalById(performanceJournal.Id).subscribe(success => {
      if (success) {
        this.toast.success('Record deleted successfully.');
        this.getPerformanceJournal(this.coacheeData.EmpId);
      } else {
        this.toast.error('Something went wrong. Please try again.');
      }
    });
  }

}
