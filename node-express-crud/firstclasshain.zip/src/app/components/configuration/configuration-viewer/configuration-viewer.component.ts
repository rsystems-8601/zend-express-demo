import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SharedDataService } from 'src/app/services/shared-data.service';
import { CommonService } from 'src/app/services/common.service';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-configuration-viewer',
  templateUrl: './configuration-viewer.component.html',
  styleUrls: ['./configuration-viewer.component.scss']
})

export class ConfigurationViewerComponent implements OnInit, OnDestroy {
  name: string;
  url: string;
  callBackComplete: boolean;
  ToggleGoalButtonAngular = false;
  showHeader = true;

  constructor(
    private route: ActivatedRoute,
    private sharedDataService: SharedDataService,
    private router: Router,
    private commonService: CommonService,
    private authService: AuthService
  ) {
    this.name = '';
    this.url = '';
  }

  ngOnInit() {
    window.addEventListener('message', this.handleIframeTask.bind(this), false);
    this.callBackComplete = false;
    this.route.params.subscribe(params => {
      if (params.name) {
        this.name = params.name;
        const reportUrl = this.sharedDataService.getData();
        if (reportUrl !== undefined) {
          this.url = reportUrl;
        } else {
          this.router.navigate(['/iCoachFirst/dashboard']);
        }
      }
    });
  }

  closePopupOnIframe() {
    this.commonService.closePopupOnIframe();
  }

  handleIframeTask(e) {
    window.removeEventListener('message', () => { });
    // Member variable this.callBackComplete will be false if user refreshes the url
    // and it will be true if user open this same component again and again
    // so added the check using variable
    if (!this.callBackComplete) {
      if (e.data.redirectTo === undefined && e.data.lockAngularScreen === undefined) {
        this.ToggleGoalButtonAngular = false;
        // the redirectTo will be undefined if user directly refreshes the url
        // added because this func is getting fired first if user refreshes url directly.
        return;
      }
      if (e.data.redirectTo && e.data.redirectTo === 'logout') {
        this.authService.commonLogout();
      }

      if (e.data.redirectTo === 'dashboard') {
        this.callBackComplete = true;
        let redirect = this.sharedDataService.getRedirectionValue();
        if (redirect !== undefined) {
          redirect = decodeURIComponent(redirect);
          this.router.navigate([`/${redirect}`]);
        } else {
          // If userdirectly refreshes the url the redirect value will will be undefined.
          this.router.navigate(['/iCoachFirst/dashboard']);
        }
      } else if (e.data.lockAngularScreen !== undefined) {
        this.ToggleGoalButtonAngular = e.data.lockAngularScreen;
      }
    }
  }

  ngOnDestroy() {
    this.callBackComplete = true;
    window.removeEventListener('message', () => { });
  }

}
