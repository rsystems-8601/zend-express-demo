import { Component, OnInit, EventEmitter, Output } from '@angular/core';
import { ConfigurationService } from 'src/app/services/configuration.service';
import { Router } from '@angular/router';
import { SharedDataService } from 'src/app/services/shared-data.service';
//import { environment } from 'src/environments/environment';
import { UserService } from 'src/app/services/user.service';
import { User } from 'src/app/models/response/user-response';
import { AdminUrlBuilderService } from 'src/app/services/admin-url-builder.service';
// import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-configuration',
  templateUrl: './configuration.component.html',
  styleUrls: ['./configuration.component.scss']
})
export class ConfigurationComponent implements OnInit {

  Candidates: string;
  adminConfigurations: Array<any> = [];
  filteredAdminConfigurations: Array<any> = [];
  @Output() setLeftContainerVisibility: EventEmitter<number> = new EventEmitter<number>();
  user: User;
  constructor(
    private configurationService: ConfigurationService,
    private router: Router,
    private sharedDataService: SharedDataService,
    private userService: UserService,
    private adminUrlBuilderService: AdminUrlBuilderService
  ) { }

  ngOnInit() {
    this.configurationService.getInitailConfigurationData()
      .subscribe(response => {
        this.adminConfigurations = response[0].Configuration;
        this.filteredAdminConfigurations = this.adminConfigurations;
      });

    this.user = this.userService.getUserDetails().UserDetails;
  }

  onSearch(val: string) {
    if (val) {
      this.filteredAdminConfigurations = this.adminConfigurations.filter(x => x.Label.toLowerCase().includes(val.toLowerCase()));
    } else {
      this.filteredAdminConfigurations = this.adminConfigurations;
    }
  }

  onSetLeftContainerVisibility(appModuleId: number = 0) {
    this.setLeftContainerVisibility.emit(appModuleId);
  }

  openConfiguration(config: any) {

    if(config.Key === 'UpdateEmployeeList' || config.Key === 'UpdateEmployeeRoster'){
      this.openStaticLinks(config.Url);
      return;
    }
    // const path = environment.domainName;
   this.Candidates = 'Candidates';
    const req = {
      memberOrgId: this.user.MemberOrgID,
      employeeId: this.user.EmpId,
      url: config.Url,
      EmpName: this.user.Name,
      source: 'icf6',
      EmployeeId: this.user.EmployeeId,
      FromLink: this.Candidates
    };

    this.sharedDataService.setData(this.adminUrlBuilderService.openAdminV2Page(req));
    this.router.navigate(['/iCoachFirst/configuration/admin', config.Label]);
  }

  openStaticLinks(pageurl) {
    if (pageurl !== '') {
      this.router.navigate(['/iCoachFirst/' + pageurl]);
    }
  }

  
}
