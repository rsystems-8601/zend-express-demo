import { Component, OnInit, OnDestroy, ViewChild, ViewEncapsulation } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ActService } from 'src/app/services/act.service';
import { ActRequest } from 'src/app/models/requests/act-request';
import { ActResponseResolved, ActResponse, Act } from 'src/app/models/response/act-response';
import { EventEmiterService } from 'src/app/services/event.emmiter.service';
import { UserService } from '../../../services/user.service';
import { PaginationApiService } from '../../../services/pagination-api.service';
import { PageRequest } from '../../../models/requests/page-request';
import { environment } from 'src/environments/environment';
import { Subscription } from 'rxjs';
import { SharedDataService } from 'src/app/services/shared-data.service';

@Component({
  selector: 'app-all-pending',
  templateUrl: './all-pending.component.html',
  styleUrls: ['./all-pending.component.scss'],
  encapsulation: ViewEncapsulation.None
})

export class AllPendingComponent implements OnInit, OnDestroy {
  responseData: Act[];
  parameterType: string;
  responseLoadData: any;
  itemExpired: boolean;
  showAssignTask: boolean;
  loadingStart = true;
  loadingPointer = 1;
  lastScrolledStatus = 0;
  sourceType = 'All Pending';
  IsTaskRatingActionAllowed = false;
  IsGoalRatingActionAllowed = false;
  taskStatusPreference: string;
  ItemOptions : any;

  private subscription: Subscription;

  @ViewChild('allPendingScrollGetList') container: any;

  constructor(private route: ActivatedRoute, private actService: ActService,
    private _eventEmiter: EventEmiterService,
    private userService: UserService,
    private paginationApiService: PaginationApiService,
    private sharedDataService: SharedDataService
  ) {

  }

  ngOnInit() {
    this.IsTaskRatingActionAllowed = this.userService.getUserDetails().UserDetails.IsTaskRatingActionAllowed;
    this.IsGoalRatingActionAllowed = this.userService.getUserDetails().UserDetails.IsGoalRatingActionAllowed;

    if(!this.ItemOptions) {
      this.ItemOptions = {
        IsGridViewOption : false,
        IsDisabled: false,
        IsExpired: false
      }
    }

    this.subscription = this._eventEmiter.subscribe(data => {

      if (data.actionType === 'AssignOrCloseQuickFeedback' ||
        data.actionType === 'AssignTraining' ||
        data.actionType === 'ReloadActData') {

        this.reloadActData();
      }
    });

    this.route.params.subscribe(params => {
      if (params.type) {
        this.sourceType = params.type;
        this.getActData();
      } else {
        this.getActData();
      }
    });

    
  }

  ngOnDestroy() {
    this._eventEmiter.unsubscribe(this.subscription);
  }

  getActData() {

    const resolvedact: ActResponseResolved = this.route.snapshot.data['getAct'];
    // the loader comes for infinite time if nothing comes in response, hence adding check
    this.responseData = resolvedact ? (resolvedact.actResponse ? resolvedact.actResponse.ActData : []) : [];
    this.taskStatusPreference = resolvedact ? (resolvedact.actResponse ? resolvedact.actResponse.TaskStatusPreference : '') : '';
    // this._eventEmiter.emit(resolvedact.actResponse.Sources);
    // this.errorMesaage = resolvedGoals.error;
    this.route.params.subscribe(params => {
      if (params.type) {
        this.parameterType = params.type;
      }
    });
    
    const viewType = this.sharedDataService.getSelectedView();
    if (this.parameterType === 'Training') {
      if(viewType === "true" || viewType === undefined){
      this.ItemOptions = {
        IsGridViewOption : true,
        IsDisabled: false,
        IsExpired: false
      }
    } else {
      this.ItemOptions = {
        IsGridViewOption : false,
        IsDisabled: false,
        IsExpired: false
      }
    }
  }

    
    
  }

  reloadActData() {
    
    const userDetails = this.userService.getUserDetails();
    const request = new ActRequest();
    request.EmpId = userDetails.UserDetails.EmpId;
    request.RecordCount = 0;
    request.RowOffSet = 1;
    request.SourceType = this.sourceType;
    request.PageRequest = new PageRequest();
    request.PageRequest.PageNumber = 0;
    request.PageRequest.PageSize = environment.defaultActPageSize;

    /// For Manage
    if (userDetails.CoacheeDetails !== undefined && userDetails.IsRepView) {
      request.RepId = userDetails.CoacheeDetails.UserDetails.EmpId;

      this.actService.getManageAct(request).subscribe((actList: ActResponse) => {
        this.responseData = actList.ActData;
      });
    } else {
      this.actService.getAll(request).subscribe((actList: ActResponse) => {
        this.responseData = actList.ActData;
      });
    }
  }

  refresh() {
    // this.lastScrolledStatus = this.paginationApiService.getIndexOfDiv(this.container);
    // if (this.loadingStart && this.lastScrolledStatus > 0) {
    //   this.loadingStart = false;
    //   this.view_actList(this.loadingPointer);
    // }
  }

  view_actList(loadingPointer) {
    this.paginationApiService.view_actList(loadingPointer, this.sourceType).subscribe(actList => {
      if (actList.ActData.length > 0) {
        if (this.responseData) {
          const responseObject = this.responseData.concat(actList.ActData);
          this.responseData = responseObject;
          this._eventEmiter.emit(actList.Sources);
          this.loadingStart = true;
          this.loadingPointer++;
          this.container.nativeElement.scrollTop = ((this.container.nativeElement.scrollHeight) - 20);
        }
      }
    });
  }

    onViewTypeClick(selViewOption='grid') {

      if(selViewOption === 'grid'){
          this.ItemOptions = {
            IsGridViewOption : true,
            IsDisabled: false,
            IsExpired: false
          }
    }
    else{
      this.ItemOptions = {
        IsGridViewOption : false,
        IsDisabled: false,
        IsExpired: false
      }
    }

    this.sharedDataService.setSelectedView(String(this.ItemOptions.IsGridViewOption));
  }

}
