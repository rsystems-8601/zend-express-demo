import { Component, OnInit } from '@angular/core';
import { UserService } from '../../../services/user.service';
import { AssignTaskComponent } from 'src/app/components/tasks/assign-task/assign-task.component';
import { MatDialogConfig, MatDialog } from '@angular/material';
import { EventEmiterService } from 'src/app/services/event.emmiter.service';
import { CreateGoalComponent } from '../../goals/create-goal/create-goal.component';
import { RolesService } from '../../..//services/roles.service';

@Component({
  selector: 'app-welcome-user',
  templateUrl: './welcome-user.component.html',
  styleUrls: ['./welcome-user.component.scss']
})


export class WelcomeUserComponent implements OnInit {

  userName: string;
  userProfilePicUrl: string;
  designation: string;
  selectedRepId = 0;
  goalType = 'I';
  isLearnEnable = false;
  isTaskEnable = true;
  flyoutMenuItem: any;

  constructor(
    private _eventEmiter: EventEmiterService,
    private userService: UserService,
    private dialog: MatDialog,
    private roleservice: RolesService
  ) {


  }

  ngOnInit() {
    const userDetails = this.userService.getUserDetails().UserDetails;
    this.userName = userDetails.Name;
    this.userProfilePicUrl = userDetails.ProfileImageName;
    this.designation = userDetails.Designation;
    this.isLearnEnable = this.roleservice.hasPermission('TRN');
    this.flyoutMenuItem = this.roleservice.getFlyoutMenuItem('AssignTask');
    if (this.flyoutMenuItem.OnOffValue === false) {
      this.isTaskEnable = false;
    }
  }

  assignTask() {

    const userDetails = this.userService.getUserDetails();
    let taskAssigneeEmpId = 0;
    let taskAssignerEmpId = 0;

    if (userDetails.IsRepView !== undefined && userDetails.IsRepView) {
      taskAssigneeEmpId = userDetails.CoacheeDetails.UserDetails.EmpId;
      taskAssignerEmpId = userDetails.UserDetails.EmpId;
    } else {
      taskAssigneeEmpId = taskAssignerEmpId = userDetails.UserDetails.EmpId;
    }

    const dialogConfig = new MatDialogConfig();
    dialogConfig.data = {
      taskAssignerEmpId: taskAssignerEmpId,
      taskAssigneeEmpId: taskAssigneeEmpId
    };

    dialogConfig.disableClose = true;
    dialogConfig.width = '600px';
    const dialogRef = this.dialog.open(AssignTaskComponent, dialogConfig);

    dialogRef.afterClosed().subscribe(value => {

      if (value.Type === 'success') {
        this._eventEmiter.emit({ actionType: 'ReloadActData' });
      }
    });

  }


  openCreateGoalPopUp() {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.data = { selectedRepId: this.selectedRepId, goalType: this.goalType };
    dialogConfig.width = '600px';
    dialogConfig.disableClose = true;
    const dialogRef = this.dialog.open(CreateGoalComponent, dialogConfig);

    dialogRef.afterClosed().subscribe(value => {

      if (value === 'success') {
        this._eventEmiter.emit({ actionType: 'ReloadActData' });
      }
    });
  }



}
