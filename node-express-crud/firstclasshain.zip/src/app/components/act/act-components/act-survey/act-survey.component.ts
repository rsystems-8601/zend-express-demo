import { Component} from '@angular/core';
import { ActBaseComponent } from '../act-base/act-base.component';

@Component({
  selector: 'app-act-survey',
  templateUrl: './act-survey.component.html',
  styleUrls: ['./act-survey.component.scss']
})
export class ActSurveyComponent extends ActBaseComponent {

}
