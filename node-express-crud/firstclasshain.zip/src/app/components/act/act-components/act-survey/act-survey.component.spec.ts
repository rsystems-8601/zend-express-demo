import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ActSurveyComponent } from './act-survey.component';

describe('ActSurveyComponent', () => {
  let component: ActSurveyComponent;
  let fixture: ComponentFixture<ActSurveyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ActSurveyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ActSurveyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
