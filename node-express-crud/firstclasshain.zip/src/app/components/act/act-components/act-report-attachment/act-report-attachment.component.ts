import { Component, OnInit, Inject } from '@angular/core';
import { ActService } from 'src/app/services/act.service';
import { UserService } from 'src/app/services/user.service';
import { IcftoasterService } from 'src/app/services/icftoaster.service';
import { ReportAttachDocRequest, DeleteAttachDocRequest } from 'src/app/models/requests/act-request';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { LocalizationService } from 'src/app/services/localization.service';
import { UserDetails } from 'src/app/models/user-details-result';
import { UserAttachmentResponse } from 'src/app/models/response/act-response';
import { CommonEnum } from 'src/app/helpers/enums/common-enums';

@Component({
  selector: 'app-act-report-attachment',
  templateUrl: './act-report-attachment.component.html',
  styleUrls: ['./act-report-attachment.component.scss']
})
export class ActReportAttachmentComponent implements OnInit {

  reportAttachDocRequest = {} as ReportAttachDocRequest;
  reportRequestParam = { empReportId: '' };
  attachReportDocForm: FormGroup;
  submitted = false;
  selectedFile: any;
  allAttachments: any;
  userDetails: UserDetails;
  userAttachmentList: UserAttachmentResponse[];
  CommonEnum = CommonEnum;

  constructor(private userService: UserService,
    private toast: IcftoasterService,
    private actService: ActService,
    public dialogRef: MatDialogRef<ActReportAttachmentComponent>,
    @Inject(MAT_DIALOG_DATA) public data,
    private formBuilder: FormBuilder,
    private localizationService: LocalizationService
  ) { }

  ngOnInit() {
    this.userDetails = this.userService.getUserDetails().UserDetails;

    this.attachReportDocForm = this.formBuilder.group({
      docTitle: ['', Validators.required],
      docFileName: ['', Validators.required],
    });

    this.getReportAttachmentList();

  }

  get f() {
    return this.attachReportDocForm.controls;
  }

  onSubmit() {
    this.submitted = true;
    if (this.attachReportDocForm.invalid) {
      return;
    }

    this.attachDocument();
  }

  isDraft() {
    if (this.data.Status === 'Active' || this.data.Status === 'Pending' || this.data.Status === 'Draft') {
      return true;
    }

  }

  attachDocument() {
    const af = this.allAttachments[0];
    const reader = new FileReader();
    reader.onload = (function (cb, parentThis) {
      if (cb) {
        return function (_e: any) {
          parentThis.reportAttachDocRequest.EmpReportId = parentThis.data.ItemId;
          parentThis.reportAttachDocRequest.FileName = af.name;
          parentThis.reportAttachDocRequest.DocTitle = parentThis.attachReportDocForm.value.docTitle;
          parentThis.reportAttachDocRequest.CreatedBy = parentThis.userDetails.EmpId;
          parentThis.reportAttachDocRequest.DocData = reader.result.toString().split(',')[1];
          parentThis.reportAttachDocRequest.UniqueNumber = (String)(new Date().valueOf());
          parentThis.reportAttachDocRequest.MemberOrgId = parentThis.userDetails.MemberOrgID;
          parentThis.reportAttachDocRequest.LoginCulture = parentThis.localizationService.getCutureCode();

          parentThis.actService.reportAttachDocument(parentThis.reportAttachDocRequest).subscribe((response) => {
            if (response) {
              parentThis.getReportAttachmentList();
              parentThis.toast.success('Attachment saved successfully.', '');
              parentThis.submitted = false;
              parentThis.attachReportDocForm.reset();

            }
          });
        };
      }
    })(af, this);
    reader.readAsDataURL(af);
  }

  cancelClicked() {

    this.dialogRef.close();
  }

  onFileChanged(event: any) {
    this.selectedFile = event.target.files[0];
    if (!this.validateFile(this.selectedFile.name.toLowerCase())) {
      this.toast.error('Document is not in correct format.');
      return false;
    }
    this.attachReportDocForm.get('docFileName').clearValidators();
    this.attachReportDocForm.get('docFileName').updateValueAndValidity();
    this.allAttachments = event.target.files;
  }

  validateFile(name: String) {
    // const allowedExtensions = ['pdf', 'doc', 'docx', 'ppt', 'pptx', 'png', 'jpeg', 'jpg', 'xls', 'xlsx'];
    const notAllowedExtensions = ['exe', 'js'];
    const fileExtension = name.split('.').pop();
    if (this.isInArray(notAllowedExtensions, fileExtension)) {
      return false;
    }
    return true;
  }

  isInArray(array, word) {
    return array.indexOf(word.toLowerCase()) > -1;
  }

  getReportAttachmentList() {
    this.reportRequestParam.empReportId = this.data.ItemId;
    this.actService.getReportAttachmentList(this.data.ItemId).subscribe((response) => {
      if (response) {
        this.userAttachmentList = response.slice().reverse();
      }
    });
    this.attachReportDocForm.get('docFileName').setValidators([Validators.required]);
    this.attachReportDocForm.get('docFileName').updateValueAndValidity();
  }

  deleteAttachment(attachment: UserAttachmentResponse) {
    const deleteAttachmentRequest = {} as DeleteAttachDocRequest;
    deleteAttachmentRequest.DeletedBy = this.userDetails.EmpId;
    deleteAttachmentRequest.DeletedTableId = attachment.DocId;
    deleteAttachmentRequest.NeedToDeleteFor = CommonEnum.CDRAttachment;
    this.actService.deleteReportAttachment(deleteAttachmentRequest).subscribe((response) => {
      if (response) {
        if (response.DeleteDataForSpecificWorkResult.ResultStatusCode === '1040') {
          this.toast.success('Attachment deleted successfully.');
          this.getReportAttachmentList();
        } else {
          this.toast.error('Error Occured');
        }
      }
    });
  }

}
