import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ActReportAttachmentComponent } from './act-report-attachment.component';

describe('ActReportAttachmentComponent', () => {
  let component: ActReportAttachmentComponent;
  let fixture: ComponentFixture<ActReportAttachmentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ActReportAttachmentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ActReportAttachmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
