import { Component, OnInit, Input, SimpleChanges, OnChanges } from '@angular/core';
import { UserPermissions, ReportType } from 'src/app/helpers/enums/common-enums';
import { UserService } from 'src/app/services/user.service';
import { MatDialogConfig, MatDialog } from '@angular/material';
import { BaseRequest } from 'src/app/models/requests/base-request';
import { AssignCoachingReportComponent } from 'src/app/components/my-team/assign-report/assign-coaching-report.component';

@Component({
  selector: 'app-plans-list',
  templateUrl: './plans-list.component.html',
  styleUrls: ['./plans-list.component.scss']
})
export class PlansListComponent implements OnInit, OnChanges {

  @Input() plansListData: any;
  filteredData: any;
  isRequiredToShowAdd = false;
  userInfo: any;
  UserPermissions = UserPermissions;
  ReportType = ReportType;

  constructor(private userService: UserService, private dialog: MatDialog) { }

  ngOnInit() {

    this.userInfo = this.userService.getUserDetails();
    if (this.userInfo.IsRepView !== undefined && this.userInfo.IsRepView && this.userService.isExistPermission(UserPermissions.CanCoach)) {
      this.isRequiredToShowAdd = true;
    }
    this.setData();
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes !== undefined && this.userInfo !== undefined) {
      this.setData();
    }
  }

  private setData() {
    if (this.userInfo.IsRepView !== undefined && this.userInfo.IsRepView &&
      this.userService.isExistPermission(UserPermissions.UserProvidedPlansOnly)) {

      this.filteredData = this.plansListData.filter(
        objActData => (objActData.CreatedByEmpId === this.userInfo.UserDetails.EmpId));

    }
    else {
      this.filteredData = this.plansListData;
    }
   
  }

  assignPlans() {

    const dialogConfig = new MatDialogConfig();
    dialogConfig.width = '800px';
    const dataToPass = new BaseRequest();
    dataToPass.RepId = this.userInfo.CoacheeDetails.UserDetails.EmpId;
    dataToPass.IsRepInitiated = false;
    dialogConfig.data = {
      dataToPass: dataToPass, coacheeData: { Name: this.userInfo.CoacheeDetails.UserDetails.Name },
      filterType: ReportType.Plans
    };
    dialogConfig.disableClose = true;
    this.dialog.open(AssignCoachingReportComponent, dialogConfig);
  }

}
