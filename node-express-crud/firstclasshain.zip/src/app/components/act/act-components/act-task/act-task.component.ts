import { Component, Input, OnInit } from '@angular/core';
import { TaskRequest, SaveGoalTaskCommentRequest } from 'src/app/models/requests/task-request';
import { UserService } from 'src/app/services/user.service';
import { TaskService } from 'src/app/services/task.service';
import { IcftoasterService } from 'src/app/services/icftoaster.service';
import Images from '../../../../helpers/image-constants';
import * as moment from 'moment';
// import { MatDialog } from '@angular/material';

import { MatDialogConfig, MatDialog } from '@angular/material';
import { TaskFeedbackComponent } from 'src/app/components/tasks/task-feedback/task-feedback.component';
import { IActBaseInterface } from 'src/app/models/act-base';
import { TaskLinkComponent } from 'src/app/components/tasks/task-link/task-link.component';
import { UserPermissions } from 'src/app/helpers/enums/common-enums';
import { ConnectTeamMembersComponent } from 'src/app/components/connect/connect-team-members/connect-team-members.component';
import { UpdateTaskStatusComponent } from 'src/app/components/goals/update-task-status/update-task-status.component';
// import { Router } from '@angular/router';
import { EventEmiterService } from 'src/app/services/event.emmiter.service';

// import { BrowserModule, HAMMER_GESTURE_CONFIG } from '@angular/platform-browser';
// import { GestureConfig } from '@angular/material';

@Component({
  selector: 'app-act-task',
  templateUrl: './act-task.component.html',
  styleUrls: ['./act-task.component.scss'],

  // providers: [
  //   { provide: HAMMER_GESTURE_CONFIG, useClass: GestureConfig },
  // ]
})


export class ActTaskComponent implements OnInit {

  @Input() learningPathData: IActBaseInterface;
  @Input() groupId: number;
  isDatePickerOpen = false;
  taskStatuses: any;
  taskRequest = new TaskRequest();
  isEditAllowed = false;
  saveGoalTaskCommentRequest = new SaveGoalTaskCommentRequest();
  minDate = new Date();
  UserPermissions = UserPermissions;
  isManageView = false;
  repId: number;
  dialogRef4TaskSlider: any;
  constructor(private userService: UserService,
    private taskService: TaskService,
    private toast: IcftoasterService,
    private dialog: MatDialog,
    private _eventEmiter: EventEmiterService
  ) {
    const user = this.userService.getUserDetails();
    if (user !== undefined && user.CoacheeDetails !== undefined && user.IsRepView) {
      this.isManageView = true;
      this.repId = user.CoacheeDetails.UserDetails.EmpId;
    } else {
      this.isManageView = false;
    }

  }

  ngOnInit() {

    const userInfo = this.userService.getUserDetails();
    const EmpId = userInfo.UserDetails.EmpId;

    if (userInfo.IsRepView !== undefined && userInfo.IsRepView &&
      this.userService.isExistPermission(UserPermissions.EditTasks)) {
      this.isEditAllowed = true;
    } else {
      this.isEditAllowed = this.learningPathData.AssignToEmpId === EmpId ? true : false;
    }

    if (this.groupId) {
      this.isEditAllowed = true;
    }

    this.taskRequest.initWithData(this.learningPathData);
    this.taskRequest.StatusDesc = this.taskRequest.TaskPercentValue === null ?
      this.taskRequest.StatusDesc : this.taskRequest.TaskPercentValue + '%';

    if (this.taskRequest.TaskPercentValue === null) {
      this.taskStatuses = userInfo.TaskStatuses;
    } else {

      this.taskStatuses = [];
      for (let i = 0; i <= 100; i++) {
        this.taskStatuses.push({ StatusId: i, Status: i });
      }
    }

  }


  statusChanged(statusObject: any) {
    let direction = null;
    if (!this.taskRequest.StatusId) {
      if (this.taskRequest.TaskPercentValue > statusObject.Status) {
        direction = 'D';
      } else {
        direction = 'U';
      }
    } else {
      if (statusObject.StatusId < parseInt(this.taskRequest.StatusId, 10)) {
        direction = 'U';
      } else {
        direction = 'D';
      }
    }
    const object = {
      direction: direction,
      status: statusObject.Status,
      statusId: statusObject.StatusId,
      statusOption: this.taskRequest.StatusId ? 'C' : 'P',
      previousValue: this.taskRequest.StatusId ? this.taskRequest.StatusDesc : this.taskRequest.TaskPercentValue,
      callback: this.callbackFn
    };

    this.openUpdateTaskModal(object, 'status');
    if (this.taskRequest.StatusId) {
      this.taskRequest.StatusId = statusObject.StatusId;
    } else {
      this.taskRequest.TaskPercentValue = statusObject.StatusId;
      this.taskRequest.PercentComplete = statusObject.StatusId;
    }
    this.taskRequest.StatusDesc = this.taskRequest.StatusId ? statusObject.Status : statusObject.Status + '%';
  }

  openUpdateTaskModal(statusObject: any, changedParam: string) {
    if (this.dialogRef4TaskSlider) {
      this.dialogRef4TaskSlider.close();
    }

    const dialogConfig = new MatDialogConfig();
    dialogConfig.data = {
      updatedtaskstatus: statusObject.status,
      details: this.taskRequest,
      updatedtaskstatusid: statusObject.statusId,
      statuschangedirection: statusObject.direction,
      statusOption: statusObject.statusOption,
      previousValue: statusObject.previousValue,
      callBack: statusObject.callback,
      scope: this
    };
    dialogConfig.width = '600px';
    dialogConfig.disableClose = true;
    this.dialogRef4TaskSlider = this.dialog.open(UpdateTaskStatusComponent, dialogConfig);
    if (changedParam === 'date') {
      this.dialogRef4TaskSlider.afterClosed().subscribe(() => {
        this.updateTask();
      });
    } else if (changedParam === 'status') {
      if (statusObject.status === 'Complete' || statusObject.status === 100) {
        this.dialogRef4TaskSlider.afterClosed().subscribe(() => {
          this.updateTask();
        });
      }
    }
  }

  callbackFn(prevVal: any) {
    if (this.taskRequest.StatusId) {
      this.taskRequest.StatusId = prevVal;
    } else {
      this.taskRequest.TaskPercentValue = prevVal;
      this.taskRequest.PercentComplete = prevVal;
    }
    this.taskRequest.StatusDesc = this.taskRequest.StatusId ? prevVal : prevVal + '%';
  }
  changedDate(pop: any) {
    if (pop.isOpen) {
      setTimeout(() => {
        this.dataChanged(pop);

      }, 300);
    }
  }

  dataChanged(datePicker) {
    const selectedDate = datePicker._bsValue;
    const previousValue = moment(this.taskRequest.DueDate).format('MM/DD/YYYY');
    const object = {
      statusOption: this.taskRequest.StatusId ? 'C' : 'P',
      previousValue: previousValue,
      details: this.taskRequest,
      status: selectedDate,
      statusId: this.taskRequest.StatusId ? this.taskRequest.StatusId : this.taskRequest.TaskPercentValue,
      callback: this.dateChangeCallBack,
      direction: 'N'
    };

    this.openUpdateTaskModal(object, 'date');
    this.taskRequest.DueDate = selectedDate;
  }

  dateChangeCallBack(prevVal: any) {
    this.taskRequest.DueDate = prevVal;
  }
  updateTask() {

    this.taskRequest.StatusOption = this.taskRequest.TaskPercentValue === null ? 'C' : 'P';
    if (this.taskRequest.TaskPercentValue !== null) {
      this.taskRequest.StatusId = String(this.taskRequest.TaskPercentValue);
    }
    this.taskRequest.XMLObserverIds = this.taskRequest.generateObserverXML();
    this.taskService.saveOrUpdateTask(this.taskRequest).subscribe(() => {
      this._eventEmiter.emit({ actionType: 'ReloadActData' });
      // ICF6-643 Removing display of success message from here, as it already
      // been taken care form Update task Status Component
      // const result = response.AssignTaskResult;
      // this.showMessage(result);
    });
  }

  showMessage(result) {

    if (result.ResultStatusCode === '1040') {

      this.toast.success('Common_UpdatedSuccessfully', '', () => {

      });
    } else {
      this.toast.error(result.ErrorMessage);
    }
  }

  getIconName(learningPathData) {

    const ItemType = learningPathData.ItemType;
    let iconName = '';
    if (ItemType === 'Task' || ItemType === 'GoalTask' || ItemType === 'AdminTask') {
      iconName = Images.actIconclasses.taskIcon;
    }
    return iconName;

  }


  showTaskChatComponent() {

    const dialogConfig = new MatDialogConfig();
    dialogConfig.width = 800 + 'px';
    dialogConfig.height = 600 + 'px';
    dialogConfig.disableClose = false;
    dialogConfig.data = { TaskId: this.learningPathData.ItemId, Type: 'Task' };
    this.dialog.open(TaskFeedbackComponent, dialogConfig);

  }

  showTaskLinking() {

    const dialogConfig = new MatDialogConfig();
    dialogConfig.width = 400 + 'px';
    dialogConfig.disableClose = true;
    // { actData: this.learningPathData, groupId: this.groupId };
    dialogConfig.data = { actData: this.learningPathData, groupId: this.groupId };
    this.dialog.open(TaskLinkComponent, dialogConfig);

  }

  openAssignerList() {

    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.width = '600px';
    dialogConfig.data = this.learningPathData;
    const dialogRefTeam = this.dialog.open(ConnectTeamMembersComponent, dialogConfig);

    // let dialogRef;
    dialogRefTeam.afterClosed().subscribe(data => {

      if (data.Action) {

        // data.SelectedTeamMembers
      }
    });

  }
}
