import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ActTaskComponent } from './act-task.component';

describe('ActTaskComponent', () => {
  let component: ActTaskComponent;
  let fixture: ComponentFixture<ActTaskComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ActTaskComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ActTaskComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
