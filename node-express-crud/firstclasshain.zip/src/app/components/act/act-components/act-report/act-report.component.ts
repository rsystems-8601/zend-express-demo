import { Component } from '@angular/core';
import { ActBaseComponent } from '../act-base/act-base.component';

@Component({
  selector: 'app-act-report',
  templateUrl: './act-report.component.html',
  styleUrls: ['./act-report.component.scss']
})
export class ActReportComponent extends ActBaseComponent {

}
