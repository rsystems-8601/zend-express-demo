import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ActReportComponent } from './act-report.component';

describe('ActReportComponent', () => {
  let component: ActReportComponent;
  let fixture: ComponentFixture<ActReportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ActReportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ActReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
