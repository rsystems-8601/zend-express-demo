import { Component, Input } from '@angular/core';
import { ActBaseComponent } from '../act-base/act-base.component';
// import { IActBaseInterface } from '../../interface/IActBaseInterface';

@Component({
  selector: 'app-act-assessment',
  templateUrl: './act-assessment.component.html',
  styleUrls: ['./act-assessment.component.scss']
})
export class ActAssessmentComponent extends ActBaseComponent {
  @Input() ItemOptions = {
    IsGridViewOption : false,
    IsDisabled: false,
    IsExpired: false
  };

  // tslint:disable-next-line: use-life-cycle-interface
  ngOnInit() {
  }
}
