import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ActAssessmentComponent } from './act-assessment.component';

describe('ActAssessmentComponent', () => {
  let component: ActAssessmentComponent;
  let fixture: ComponentFixture<ActAssessmentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ActAssessmentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ActAssessmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
