import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ActService } from 'src/app/services/act.service';
import { UserService } from 'src/app/services/user.service';
import { FolderRequest } from 'src/app/models/requests/act-request';
import { Act } from 'src/app/models/response/act-response';
import { SharedDataService } from 'src/app/services/shared-data.service';

@Component({
  selector: 'app-folder-list',
  templateUrl: './folder-list.component.html',
  styleUrls: ['./folder-list.component.scss']
})
export class FolderListComponent implements OnInit {

  responseData: Act[];
  parameterType: string;
  responseLoadData: any;
  gridViewTypeSelected = true;
  folderId: 0;
  selectedFolders: any[];
  folderItemsOrderEnforced=false;
  folderItemCount=0;
  folderItemEnforceDisabled=false;
  folderDisableCounterId =1;

  constructor(private route: ActivatedRoute, private actService: ActService,
    private userService: UserService,
    private router: Router, private sharedDataService: SharedDataService
  ) 
  {
    this.selectedFolders = [];
  }

  ngOnInit() {
    
    const viewType = this.sharedDataService.getSelectedView();
    if(viewType){
       this.gridViewTypeSelected =viewType === "grid";
    }else{
      this.gridViewTypeSelected =true;
    }
    this.route.params.subscribe(params => {
      if (params.folderId) {
        this.folderId = params.folderId;
        this.getActDataForFolder();

        if (!this.isExistSource()) {
          this.selectedFolders.push({ folderId: this.folderId, folderName: params.folderName });
          this.updateSelectedFolderList(this.folderId, false);
        } else {
          this.updateSelectedFolderList(this.folderId, true);
        }
      }
    });
  }
  
  getActDataForFolder() {
    const userDetails = this.userService.getUserDetails().UserDetails;
    const request = new FolderRequest();
    request.EmpId = userDetails.EmpId;
    request.FolderId = this.folderId;
    this.actService.getFolderAssignmentDetails(request).subscribe(folderData => {
      this.responseData = folderData.FolderItems;
      this.folderItemsOrderEnforced = folderData.EnforceOrderSequence;
      this.folderItemCount=folderData.FolderItems.length;
    });
  }

  isExistSource() {

    const filterData = this.selectedFolders.filter(
      source => source.folderId === this.folderId);
    if (filterData.length > 0) {
      return true;
    }
    return false;
  }

  updateSelectedFolderList(folderId, isPrevClicked) {

    const tempSelectedFolders = [];
    if (isPrevClicked) {

      for (let i = 0; i < this.selectedFolders.length; i++) {

        if (this.selectedFolders[i].folderId <= folderId) {
          tempSelectedFolders.push(this.selectedFolders[i]);
        }
      }

    } else {
      for (let i = 0; i < this.selectedFolders.length; i++) {

        if (this.selectedFolders[i].folderId <= folderId) {
          tempSelectedFolders.push(this.selectedFolders[i]);
        }
      }
    }
    this.selectedFolders = tempSelectedFolders;
  }

  onFolderClick(folder: any) {
    this.router.navigate(['/iCoachFirst/dashboard/folder/', folder.folderId, folder.folderName]);
  }

  onViewTypeClick(isReset = 0,selViewOption='grid') {
    
    if (isReset === 1) {
      //this.resetformData();
    }
    if(selViewOption === 'grid'){
      this.gridViewTypeSelected=true;
    }
    else{
      this.gridViewTypeSelected=false;
    }
    this.sharedDataService.setSelectedView(selViewOption);
  }

  ShowEnforceOrderArrow(itemSeqId:number):boolean
  {
    return (this.gridViewTypeSelected &&  this.folderItemsOrderEnforced && itemSeqId < this.folderItemCount );
  }

  DisableTileToEnforceOrder(isCompleted:boolean,seqId:number):boolean {
    if(this.gridViewTypeSelected && this.folderItemsOrderEnforced)
    {
      if(isCompleted ) {
        this.folderItemEnforceDisabled=false;
        this.folderDisableCounterId=seqId+1;
      }else if(seqId > this.folderDisableCounterId){
        this.folderItemEnforceDisabled=true;
      }else{
        this.folderItemEnforceDisabled=false;
      }
    }
    return this.folderItemEnforceDisabled;
  }

  setPassObject(isCompleted:boolean,seqId:number,isItemExpired:boolean): any  {
    
    const gridViewOptions = {
      IsGridViewOption : this.gridViewTypeSelected,
      IsDisabled: this.DisableTileToEnforceOrder(isCompleted,seqId),
      IsExpired: isItemExpired
    }
    return gridViewOptions;
    
  }
}
