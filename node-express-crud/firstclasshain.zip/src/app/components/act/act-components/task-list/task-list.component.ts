import { Component, OnInit, Input, OnChanges, SimpleChanges } from '@angular/core';
import { AssignTaskComponent } from 'src/app/components/tasks/assign-task/assign-task.component';
import { MatDialogConfig, MatDialog } from '@angular/material';
import { UserService } from 'src/app/services/user.service';
import { EventEmiterService } from 'src/app/services/event.emmiter.service';
import { TaskStatus } from 'src/app/models/user-details-result';
import { UserPermissions } from 'src/app/helpers/enums/common-enums';

@Component({
  selector: 'app-task-list',
  templateUrl: './task-list.component.html',
  styleUrls: ['./task-list.component.scss']
})
export class TaskListComponent implements OnInit, OnChanges {

  @Input() taskListData: any;
  @Input() taskStatusPreferenceFlag: string;
  filteredData: any;
  searchString: string;
  isSearchApply = false;
  searchPanelVisible = false;
  taskStatuses: TaskStatus[];
  UserPermissions = UserPermissions;
  showFilterMenu: boolean;
  selectedPercentage = 0;
  selectedPercentageTo = 0;
  isPercentage: boolean;
  constructor(
    private _eventEmiter: EventEmiterService,
    private userService: UserService,
    private dialog: MatDialog) {

  }

  selectSearcPercentage(i) {
    this.selectedPercentage = i;
  }
  selectSearcPercentageTo(z) {
    this.selectedPercentageTo = z;
  }

  arrayOne(n: number): any[] {
    return Array(n);
  }

  ngOnInit() {
    this.taskStatuses = this.userService.getUserDetails().TaskStatuses;
    this.getUpdatedTask();
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes !== undefined) {
      this.taskStatuses = this.userService.getUserDetails().TaskStatuses;
      this.getUpdatedTask();
    }
  }

  getUpdatedTask() {
    const userDetails = this.userService.getUserDetails();
    if (userDetails.IsRepView !== undefined && userDetails.IsRepView &&
      this.userService.isExistPermission(UserPermissions.TasksUserIsCoachingOnly)) {
      this.filteredData = [];
      this.taskListData.forEach((taskData) => {
        if (taskData.Coaches !== undefined && taskData.Coaches !== null) {
          taskData.Coaches.forEach((coach) => {
            if (coach.ObserverEmpId === userDetails.UserDetails.EmpId) {
              this.filteredData.push(taskData);
            }
          });
        }
      });

      // this.filteredData = this.taskListData.filter(taskData =>
      //  //  taskData.Coaches.filter(t => t.ObserverEmpId === userDetails.UserDetails.EmpId)
      //   ((taskData.CreatedByEmpId === userDetails.UserDetails.EmpId) || (taskData.CreatedByEmpId === userDetails.CoacheeDetails.UserDetails.EmpId))
      // );
    } else {
      this.filteredData = this.taskListData;
    }

    this.showFilterMenu = true;
    if (this.filteredData.length === 0) {
      this.showFilterMenu = false;
    }
  }

  assignTask() {
    const userDetails = this.userService.getUserDetails();
    let taskAssigneeEmpId = 0;
    let taskAssignerEmpId = 0;

    if (userDetails.IsRepView !== undefined && userDetails.IsRepView) {
      taskAssigneeEmpId = userDetails.CoacheeDetails.UserDetails.EmpId;
      taskAssignerEmpId = userDetails.UserDetails.EmpId;
    } else {
      taskAssigneeEmpId = taskAssignerEmpId = userDetails.UserDetails.EmpId;
    }

    const dialogConfig = new MatDialogConfig();
    dialogConfig.data = {
      taskAssignerEmpId: taskAssignerEmpId,
      taskAssigneeEmpId: taskAssigneeEmpId
    };

    dialogConfig.disableClose = true;
    dialogConfig.width = '600px';
    const dialogRef = this.dialog.open(AssignTaskComponent, dialogConfig);

    dialogRef.afterClosed().subscribe(value => {
      if (value !== undefined) {
        if (value.Type === 'success') {
          this._eventEmiter.emit({ actionType: 'ReloadActData' });
        }
      }
    });

  }

  showSearchPanel() {
    this.searchPanelVisible = !this.searchPanelVisible;
  }

  filterTask(statusId) {
    let filterData = [];
    if (statusId !== undefined) {

      if (this.searchString !== undefined && this.searchString !== '') {
        filterData = this.taskListData.filter(
          objActData => (objActData.Status === String(statusId)
            && objActData.ItemName.toLowerCase().includes(this.searchString.toLowerCase())));
        return filterData;
      }
      // tslint:disable-next-line: one-line
      else {
        filterData = this.taskListData.filter(
          objActData => objActData.Status === String(statusId));
        return filterData;
      }
    }
    // tslint:disable-next-line: one-line
    else if (this.searchString !== undefined && this.searchString !== '') {
      filterData = this.taskListData.filter(
        objActData => objActData.ItemName.toLowerCase().includes(this.searchString.toLowerCase()));
      return filterData;
    } else {
      return filterData;
    }
  }

  filterTaskPercentage(selectedPercentage, selectedPercentageTo) {
    let filterData = [];
    if (this.searchString !== undefined && this.searchString !== '') {
      filterData = this.taskListData.filter(
        objActData => objActData.ItemName.toLowerCase().includes(this.searchString.toLowerCase()));
      return filterData;
    } else if (selectedPercentage !== undefined && selectedPercentageTo !== undefined) {
      filterData = this.taskListData.filter(
        objActData => (objActData.TaskPercentValue >= (selectedPercentage)
          && objActData.TaskPercentValue <= (selectedPercentageTo)));
      return filterData;
    } else {
      return filterData;
    }
  }


  onSearchClicked() {
    let searchData: any[] = [];
    let isSelectedStatus = false;
    if (this.selectedPercentage > this.selectedPercentageTo) {
      this.isPercentage = true;
      return;
    } else {
      this.isPercentage = false;
    }
    if (this.taskStatusPreferenceFlag === 'P') {
      searchData = searchData.concat(this.filterTaskPercentage(this.selectedPercentage, this.selectedPercentageTo));
    } else {
      this.taskStatuses.forEach(objStatus => {
        if (objStatus.IsSelected) {
          isSelectedStatus = true;
          searchData = searchData.concat(this.filterTask(objStatus.StatusId));
        }
      });
      if (!isSelectedStatus) {
        searchData = searchData.concat(this.filterTask(undefined));
      }
    }

    if (searchData.length > 0) {
      this.filteredData = searchData;
      this.isSearchApply = true;
      this.searchPanelVisible = false;
    } else {
      this.onClearSearch();
    }
  }

  onClearSearch() {
    this.searchString = '';
    this.isSearchApply = false;
    this.searchPanelVisible = false;
    this.filteredData = this.taskListData;
    this.selectedPercentageTo = 0;
    this.selectedPercentage = 0;
    this.resetStatus();
  }

  private resetStatus() {

    this.taskStatuses.forEach(objStatus => {
      objStatus.IsSelected = false;
    });
  }

}
