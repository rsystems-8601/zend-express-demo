import { Component } from '@angular/core';
import { ActBaseComponent } from '../act-base/act-base.component';

@Component({
  selector: 'app-act-folder',
  templateUrl: './act-folder.component.html',
  styleUrls: ['./act-folder.component.scss']
})
export class ActFolderComponent extends ActBaseComponent {


}
