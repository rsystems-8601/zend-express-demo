import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ActFolderComponent } from './act-folder.component';

describe('ActFolderComponent', () => {
  let component: ActFolderComponent;
  let fixture: ComponentFixture<ActFolderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ActFolderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ActFolderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
