import { Component, OnInit, Input, SimpleChanges, OnChanges } from '@angular/core';
import { UserPermissions, ReportType } from 'src/app/helpers/enums/common-enums';
import { UserService } from 'src/app/services/user.service';
import { MatDialog, MatDialogConfig } from '@angular/material';
import { BaseRequest } from 'src/app/models/requests/base-request';
import { AssignCoachingReportComponent } from 'src/app/components/my-team/assign-report/assign-coaching-report.component';

@Component({
  selector: 'app-reviews-list',
  templateUrl: './reviews-list.component.html',
  styleUrls: ['./reviews-list.component.scss']
})
export class ReviewsListComponent implements OnInit, OnChanges {

  @Input() reviewsListData: any;
  filteredData: any;
  isRequiredToShowAdd = false;
  userInfo: any;
  UserPermissions = UserPermissions;
  ReportType = ReportType;


  constructor(private userService: UserService, private dialog: MatDialog) { }

  ngOnInit() {

    this.userInfo = this.userService.getUserDetails();
    if (this.userInfo.IsRepView !== undefined && this.userInfo.IsRepView && this.userService.isExistPermission(UserPermissions.CanCoach)) {
      this.isRequiredToShowAdd = true;
    }
    this.setData();
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes !== undefined && this.userInfo !== undefined) {
      this.setData();
    }
  }

  private setData() {

    if (this.userInfo.IsRepView !== undefined && this.userInfo.IsRepView &&
      this.userService.isExistPermission(UserPermissions.UserProvidedReviewsOnly)) {

      this.filteredData = this.reviewsListData.filter(
        objActData => (objActData.CreatedByEmpId === this.userInfo.UserDetails.EmpId));

    } else {
      this.filteredData = this.reviewsListData;
    }
  }

  assignReviews() {

    const dialogConfig = new MatDialogConfig();
    dialogConfig.width = '800px';
    const dataToPass = new BaseRequest();
    dataToPass.RepId = this.userInfo.CoacheeDetails.UserDetails.EmpId;
    dataToPass.IsRepInitiated = false;
    dialogConfig.data = {
      dataToPass: dataToPass, coacheeData: { Name: this.userInfo.CoacheeDetails.UserDetails.Name },
      filterType: ReportType.Reviews
    };
    dialogConfig.disableClose = true;
    this.dialog.open(AssignCoachingReportComponent, dialogConfig);
  }

}
