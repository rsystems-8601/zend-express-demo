import { Component, OnInit, Input, SimpleChanges, OnChanges } from '@angular/core';
import { UserService } from 'src/app/services/user.service';
import { UserPermissions, ReportType } from 'src/app/helpers/enums/common-enums';
import { MatDialogConfig, MatDialog } from '@angular/material';
import { BaseRequest } from 'src/app/models/requests/base-request';
import { AssignCoachingReportComponent } from 'src/app/components/my-team/assign-report/assign-coaching-report.component';
import { AssignCoachingReportService } from 'src/app/services/assign-coaching-report.service';
import { ICoachingReportResponse } from 'src/app/models/response/icoaching-report-response';
import { User } from 'src/app/models/response/user-response';
import { CommonService } from 'src/app/services/common.service';
import { ActRequest } from 'src/app/models/requests/act-request';
import { Act, ActResponse } from 'src/app/models/response/act-response';
import { Subscription } from 'rxjs';
import { EventEmiterService } from 'src/app/services/event.emmiter.service';
import { PageRequest } from 'src/app/models/requests/page-request';
import { environment } from 'src/environments/environment';
import { ActService } from 'src/app/services/act.service';
//import { ActService } from 'src/app/services/act.service';


@Component({
  selector: 'app-coaching-list',
  templateUrl: './coaching-list.component.html',
  styleUrls: ['./coaching-list.component.scss']
})
export class CoachingListComponent implements OnInit, OnChanges {

  @Input() reportListData: any;
  filteredData: any[] = [];
  isRequiredToShowAdd = false;
  isProvidedClick = false;
  isReceivedClick = true;
  userInfo: any;
  UserPermissions = UserPermissions;
  ReportType = ReportType;
  coachingReportList: ICoachingReportResponse[] = [];
  reportUrl: string;
  coacheeData = {} as User;
  showCoachingWithUserRealManager = false;
  isShowFilterPopup = false;
  sourceType = 'Coaching';
  responseData: Act[];
  callingSource = 'calllingSourceAssignment';

  selectedObserver: any;
  subscription: Subscription;
  fromDate = '';
  toDate = '';
  statusDraft: string;
  statusSubmitted: string;
  statusAwaitingAcknowledgement: string;
  statusAcknowledged: string;
  qfKeyword: string;
  feedbackListDataOld: any;
  isSearchApply = false;
  selectedStatus: string;

  constructor(
    private userService: UserService,
    private dialog: MatDialog,
    private coachingReportService: AssignCoachingReportService,
    private commonService: CommonService,
    private eventEmiter: EventEmiterService,
    private actService: ActService) { }

  ngOnInit() {

    this.userInfo = this.userService.getUserDetails();
    this.isReceivedClick = true;

    if (this.userInfo.IsRepView !== undefined && this.userInfo.IsRepView && this.userService.isExistPermission(UserPermissions.CanCoach)) {
      this.isRequiredToShowAdd = true;
    }
    if (this.userInfo.IsRepView === undefined || !this.userInfo.IsRepView) {
      if (this.userInfo.UserDetails.ManagerId && this.userInfo.UserDetails.ManagerId > 0) {
        this.showCoachingWithUserRealManager = true;
      }
    }

    this.setData();

    this.subscription = this.eventEmiter.subscribe(observer => {
      if (observer.keyName === this.callingSource) {
        this.selectedObserver = observer.observerData;
      }
    });
  }

  showFilter() {
    this.isShowFilterPopup = !this.isShowFilterPopup;
  }

  filterCoaching() {
    if (this.fromDate > this.toDate) {
      return false;
    }

    this.SetSelectedStatus();
    
    const userDetails = this.userService.getUserDetails();
    const request = new ActRequest();
    request.EmpId = userDetails.UserDetails.EmpId;
    request.RecordCount = 0;
    request.RowOffSet = 1;
    request.SourceType = this.sourceType;
    request.PageRequest = new PageRequest();
    request.PageRequest.PageNumber = 0;
    request.PageRequest.PageSize = environment.defaultActPageSize;

    request.FilterRequest = {
      Status :  this.selectedStatus,
      UserEmpId: (this.selectedObserver ? this.selectedObserver.EmpID : 0),
      Keyword: this.qfKeyword,
      StartDate: this.fromDate,
      EndDate: this.toDate,
      FilterFor: this.isProvidedClick ? 'Provided' : 'Received'
    }

    /// For Calling Manage API
    if (this.isRequiredToShowAdd) {
      if (userDetails !== undefined && userDetails.CoacheeDetails !== undefined && userDetails.IsRepView) {
        request.RepId = userDetails.CoacheeDetails.UserDetails.EmpId;

        this.actService.getManageAct(request).subscribe((actList: ActResponse) => {
      
          this.FillResponseData(actList);
          
        });
      }
    }
    else
    {
    /// For Calling LearningPath API
    this.actService.getAll(request).subscribe((actList: ActResponse) => {

      this.FillResponseData(actList);
      
    });
  }
}

FillResponseData(actList: ActResponse)
{
  this.reportListData = actList.ActData;
  if (this.isReceivedClick) {
    this.onReceivedClickWithOutReset();
  } else {
    this.onProvidedClickWithOutReset();
  }
  this.isShowFilterPopup = false;

  if (this.statusDraft || this.statusSubmitted || this.statusAwaitingAcknowledgement || this.statusAcknowledged 
    || (this.qfKeyword != '' && this.qfKeyword != undefined) 
    || (this.fromDate != '' && this.fromDate !== null)
    || (this.toDate != '' && this.toDate !== null)
    || (this.selectedObserver != null)
  ) {
    this.isSearchApply = true;
  }
  else
  {
    this.isSearchApply = false;
  }
}

  SetSelectedStatus()
  {
    this.selectedStatus = '';
      if(this.statusDraft)
      {
        this.selectedStatus = 'Draft'
      }
    
      if(this.statusSubmitted)
      {
        if(this.selectedStatus == '' || this.selectedStatus == undefined)
        {  
          this.selectedStatus = 'Submitted'
        }
        else
        {
          this.selectedStatus += ',Submitted'
        }
      }   

      if(this.statusAwaitingAcknowledgement)
      {
        if(this.selectedStatus == '' || this.selectedStatus == undefined)
        {  
          this.selectedStatus = 'Awaiting Acknowledgement'
        }
        else
        {
          this.selectedStatus += ',Awaiting Acknowledgement'
        }
      }   

      if(this.statusAcknowledged)
      {
        if(this.selectedStatus == '' || this.selectedStatus == undefined)
        {  
          this.selectedStatus = 'Acknowledged'
        }
        else
        {
          this.selectedStatus += ',Acknowledged'
        }
      }   
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes !== undefined && this.userInfo !== undefined) {
      this.setData();
    }
  }

  private setData() {
     //this.filteredData = this.reportListData;

    if (this.isReceivedClick) {
      this.onReceivedClick();
    } else {
      this.onProvidedClick();
    }
    
  }

  getEmpId() {

    let empId = this.userInfo.UserDetails.EmpId;
    if (this.userInfo.IsRepView !== undefined && this.userInfo.IsRepView) {
      empId = this.userInfo.CoacheeDetails.UserDetails.EmpId;
    }
    return empId;
  }

  onReceivedClick(isReset = 0) {
    if (isReset === 1) {
      this.resetformData();
    }
   
    this.isReceivedClick = true;
    this.isProvidedClick = false;
    this.filterCoaching();
  }

  onProvidedClick(isReset = 0) {
    if (isReset === 1) {
      this.resetformData();
    }

    this.isReceivedClick = false;
    this.isProvidedClick = true;
    this.filterCoaching();
  }

  onReceivedClickWithOutReset() {
    this.isProvidedClick = false;
    this.isReceivedClick = true;

    if (this.userInfo.IsRepView !== undefined && this.userInfo.IsRepView
      && this.userService.isExistPermission(UserPermissions.CoachingProvidedByUserOnly)) {

      this.filteredData = this.reportListData.filter(
        objActData => (objActData.CreatedByEmpId === this.userInfo.UserDetails.EmpId));

    } else {

      this.filteredData = this.reportListData.filter(
        objActData => (objActData.AssignToEmpId === this.getEmpId()));
    }

  }

  onProvidedClickWithOutReset() {
    this.isProvidedClick = true;
    this.isReceivedClick = false;

    this.filteredData = this.reportListData.filter(
      objActData => (objActData.AssignToEmpId !== this.getEmpId()));
  }

  // showToggleBuuton() {

  //   if (this.userInfo.IsRepView !== undefined && this.userInfo.IsRepView &&
  //     !this.userService.isExistPermission(UserPermissions.CoachingProvidedByUserOnly)) {
  //     return false;
  //   } else {
  //     return true;
  //   }
  // }

  assignReport() {

    const dialogConfig = new MatDialogConfig();
    dialogConfig.width = '800px';
    const dataToPass = new BaseRequest();
    dataToPass.RepId = this.userInfo.CoacheeDetails.UserDetails.EmpId;
    dataToPass.IsRepInitiated = false;
    dialogConfig.data = {
      dataToPass: dataToPass, coacheeData: { Name: this.userInfo.CoacheeDetails.UserDetails.Name },
      filterType: ReportType.Coaching
    };

    this.commonService.getCoachingReports(false, this.userInfo.CoacheeDetails.UserDetails).subscribe(resp => {
      this.coachingReportList = resp;
      // Check to open report directly if one report access.
      if (this.coachingReportList !== undefined && this.coachingReportList.length === 1) {
        this.commonService.openReport(this.coachingReportList[0], false, this.userInfo.CoacheeDetails.UserDetails);
      } else {
        dialogConfig.disableClose = true;
        this.dialog.open(AssignCoachingReportComponent, dialogConfig);
      }
    });
  }

  repInitiatedCoachingWithUserRealManager() {
    this.openAssignCoachingReportModalPopup(true);
  }
  // Modal Popup open for Assign Coaching Report START
  openAssignCoachingReportModalPopup(IsRepInitiated: boolean) {
    // Open report directly when user has access to only one report.
    this.coacheeData.Name = '';
    this.coacheeData.EmployeeId = this.userInfo.UserDetails.ManagerEmployeeId;
    this.coacheeData.EmpId = this.userInfo.UserDetails.ManagerId;
    this.coacheeData.EmailId = this.userInfo.UserDetails.ManagerEmailID;

    const request = new BaseRequest();
    request.EmployeeId = this.userInfo.UserDetails.EmployeeId;
    request.MemberOrgId = this.userInfo.UserDetails.MemberOrgID;
    request.RepId = this.coacheeData.EmpId;
    if (IsRepInitiated) {
      this.coachingReportService.getReportsForPeerRepInitiated(request).subscribe(data => {
        this.coachingReportList = data.filter(t => t.IsDynamic === true);
        if (this.coachingReportList !== undefined && this.coachingReportList.length === 1) {
          this.commonService.openReport(this.coachingReportList[0], IsRepInitiated, this.coacheeData);
        } else {
          this.modalDataForAssignCoaching(IsRepInitiated, this.coachingReportList, 'Act_Source_RequestCoaching');
        }
      });

    }
  }
  // Modal Popup open for Assign Coaching Report END

  private modalDataForAssignCoaching(IsRepInitiated: boolean, reports: ICoachingReportResponse[], reqFeedbackPopUpTitle = '') {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.width = '800px';
    const dataToPass = new BaseRequest();
    dataToPass.RepId = this.coacheeData.EmpId;
    dataToPass.IsRepInitiated = IsRepInitiated;
    dialogConfig.data = {
      dataToPass: dataToPass,
      coacheeData: this.coacheeData,
      filterType: '',
      feedbackPopUpTitle: (reqFeedbackPopUpTitle !== '') ? reqFeedbackPopUpTitle : 'Coaching Conversations',
      coachingAssignments: reports
    };
    dialogConfig.disableClose = true;
    this.dialog.open(AssignCoachingReportComponent, dialogConfig);
  }
  /*
    openReport(report: ICoachingReportResponse, IsRepInitiated: boolean) {
      this.reportUrl = this.dynamicUrlBuilderService.newReportUrl(this.createUrlRequest(report, IsRepInitiated));
      const queryParam = encodeURI(this.reportUrl);
      this.sharedDataService.setData(this.reportUrl);
      this.sharedDataService.setRedirectionValue(this.getRedirectionValueFromIframe());
      this.router.navigate(['/iCoachFirst/report/dynamicreport', report.ReportName], { queryParams: { encodedUrl: queryParam } });
    }
    private createUrlRequest(reportItem: ICoachingReportResponse, IsRepInitiated: boolean): DynamicReportUrlRequest {
      const request = {} as DynamicReportUrlRequest;
      // this.userInfo = this.userService.getUserDetails().UserDetails;
      request.EmpReportId = reportItem.EmpReportId;
      if (IsRepInitiated) {
        request.IsMgr = 'F';
        request.CoachId = this.coacheeData.EmployeeId;
        request.CoacheeId = this.userInfo.UserDetails.EmpId;
        request.CoachName = this.coacheeData.Name;
        request.CoacheeName = this.userInfo.UserDetails.Name;
      } else {
        request.IsMgr = 'T';
        request.CoachId = this.userInfo.UserDetails.EmpId;
        request.CoacheeId = this.coacheeData.EmpId;
        request.CoachName = this.userInfo.UserDetails.Name;
        request.CoacheeName = this.coacheeData.Name;
      }
      request.ReportName = reportItem.ReportName;
      request.ReportId = reportItem.ReportId;
      request.IsRepInitiated = IsRepInitiated;
      request.MemberOrgID = this.userInfo.UserDetails.MemberOrgID;
      request.PagePath = reportItem.PagePath;
      request.Source = 'icf6';
      request.RedirectTo = 'dashboard';
      request.Culture = this.localizationService.getICF6CultreFromLocalStorage().CultureCode;
      return request;
    }
   private getRedirectionValueFromIframe(): string {
      const url = window.location.href;
      return url.split(environment.iframeRedirectionHostName)[1];
    }
    */

   resetformData() {
    this.statusDraft = '';
    this.statusSubmitted = '';
    this.statusAwaitingAcknowledgement = '';
    this.statusAcknowledged = '';
    this.selectedStatus = '';
    this.qfKeyword = '';
    this.fromDate = '';
    this.toDate = '';
    this.selectedObserver = null;

    this.eventEmiter.emit({ keyName: 'resetAutoComplete' });
    this.eventEmiter.emit({ keyName: 'resetDate' });
  }

  onClearSearch() {
    if (this.isReceivedClick) {
      this.onReceivedClick(1);
    } else {
      this.onProvidedClick(1);
    }
    
    this.isSearchApply = false;
  }
}
