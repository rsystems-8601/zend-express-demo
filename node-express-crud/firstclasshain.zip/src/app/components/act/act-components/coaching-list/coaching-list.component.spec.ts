import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CoachingListComponent } from './coaching-list.component';

describe('CoachingListComponent', () => {
  let component: CoachingListComponent;
  let fixture: ComponentFixture<CoachingListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CoachingListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CoachingListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
