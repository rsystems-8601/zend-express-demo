import { Component, Input} from '@angular/core';
import { ActBaseComponent } from '../act-base/act-base.component';

@Component({
  selector: 'app-act-training',
  templateUrl: './act-training.component.html',
  styleUrls: ['./act-training.component.scss']
})
export class ActTrainingComponent extends ActBaseComponent {
  @Input() ItemOptions = {
    IsGridViewOption : false,
    IsDisabled: false,
    IsExpired: false }
  ngOnInit() {
    
  }
  
}
