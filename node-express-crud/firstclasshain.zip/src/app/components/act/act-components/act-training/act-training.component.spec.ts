import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ActTrainingComponent } from './act-training.component';

describe('ActTrainingComponent', () => {
  let component: ActTrainingComponent;
  let fixture: ComponentFixture<ActTrainingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ActTrainingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ActTrainingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
