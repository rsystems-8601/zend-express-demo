import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ActPlanComponent } from './act-plan.component';

describe('ActPlanComponent', () => {
  let component: ActPlanComponent;
  let fixture: ComponentFixture<ActPlanComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ActPlanComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ActPlanComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
