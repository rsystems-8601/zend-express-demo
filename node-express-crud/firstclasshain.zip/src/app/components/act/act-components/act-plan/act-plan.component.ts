import { Component, Input } from '@angular/core';
import { ActBaseComponent } from '../act-base/act-base.component';


@Component({
  selector: 'app-act-plan',
  templateUrl: './act-plan.component.html',
  styleUrls: ['./act-plan.component.scss']
})
export class ActPlanComponent extends ActBaseComponent {
  @Input() learningPathData: any;
}

