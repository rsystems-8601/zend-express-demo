import { Component, OnInit, Input, OnDestroy, OnChanges } from '@angular/core';
import { IActBaseInterface } from '../../../../models/act-base';
import Images from '../../../../helpers/image-constants';
import { UserService } from 'src/app/services/user.service';
import { MatDialogConfig, MatDialog } from '@angular/material';
import { QuickFeedbackDetailsComponent } from 'src/app/components/quick-feedback/quick-feedback-details/quick-feedback-details.component';
import { LearnService } from 'src/app/services/learn.service';
import { TrainingDetailRequest, DeleteReportRequest } from 'src/app/models/requests/learn/learn-request';
import { DynamicReportUrlBuilderService } from 'src/app/services/dynamic-report-url-builder.service';
import { SharedDataService } from 'src/app/services/shared-data.service';
import { DynamicReportUrlRequest } from 'src/app/models/requests/url-builder/dynamic-report-url-request';
import { Router } from '@angular/router';
import { IframeNoborderModalComponent } from 'src/app/components/shared/iframe-noborder-modal/iframe-noborder-modal.component';
import { TaskObserverUrlBuilderService } from 'src/app/services/task-observer-url-builder-service';
import { TaskObserverUrlRequest } from 'src/app/models/requests/url-builder/task-observer-url-request';
import { SurveyAssessmentUrlBuilderService } from 'src/app/services/survey-assessment-url-builder.service';
import { SurveyAssessmentUrlRequest } from 'src/app/models/requests/url-builder/survey-assessment-url-request';
import { TrainingContentComponent } from 'src/app/components/learn/modal-popup/training-content/training-content.component';
import { LearnModalPopupEnum } from 'src/app/helpers/enums/learn-enums';
import { LocalizationService } from 'src/app/services/localization.service';
import { IcftoasterService } from 'src/app/services/icftoaster.service';
import { CommonService } from 'src/app/services/common.service';
import { EventEmiterService } from 'src/app/services/event.emmiter.service';
// import { TrainingInvitationUrlRequest } from 'src/app/models/requests/learn/training-invitation-url-request';
import { ActReportAttachmentComponent } from '../act-report-attachment/act-report-attachment.component';
import { ActBaseFeedbackStatus, MemberOrganization, ModalPopupSizeEnum, SourceType, GoalTaskStatus, ItemTypeEnum } from 'src/app/helpers/enums/common-enums';
import { ConfirmationDialogService } from 'src/app/components/shared/confirmation-dialog/confirmation-dialog.service';
import { environment } from 'src/environments/environment';
import { ScormLaunchUrlRequest } from 'src/app/models/requests/learn/scorm-launch-url-request';
import { StaticReportUrlBuilderService } from 'src/app/services/static-report-url-builder.service';
import { GoalRatingComponent } from 'src/app/components/goals/goal-rating/goal-rating.component';
import { TaskRatingComponent } from 'src/app/components/tasks/task-rating/task-rating.component';
import { SurveyService } from 'src/app/services/survey.service';
import { SurveyCreatorComponent } from 'src/app/components/shared/survey-creator/survey-creator.component';
import { NovoActionItems } from 'src/app/models/novo-action-items';
import { NovoActionItemComponent } from 'src/app/components/shared/novo-action-item/novo-action-item.component';

@Component({
  selector: 'app-act-base',
  templateUrl: './act-base.component.html',
  styleUrls: ['./act-base.component.scss']
})

export class ActBaseComponent implements OnInit, OnDestroy, OnChanges {
  @Input() learningPathData: IActBaseInterface;
  @Input() titleTemp: string;
  @Input() folderItemEnforceDisabled = false;
  @Input() ItemOptions = {
    IsGridViewOption: false,
    IsDisabled: false,
    IsExpired: false
  }
  isSingleClick: Boolean = false;
  trainDetailRequest = new TrainingDetailRequest();
  itemType: string;
  userDetails: any;
  enableBackButton: Boolean = false;
  dialogRef: any;
  dialogAct: any;

  constructor(private userService: UserService,
    private dialog: MatDialog,
    private learnService: LearnService,
    private dynamicUrlBuilderService: DynamicReportUrlBuilderService,
    private sharedDataService: SharedDataService, private staticUrlBuilderService: StaticReportUrlBuilderService,
    private router: Router,
    private taskObserverUrlBuilderService: TaskObserverUrlBuilderService,
    private surveyAssessmentUrlBuilderService: SurveyAssessmentUrlBuilderService,
    private localizationService: LocalizationService,
    private toast: IcftoasterService,
    private commonService: CommonService,
    private _eventEmiter: EventEmiterService,
    private confirmationDialogService: ConfirmationDialogService,
    private surveyService: SurveyService,
  ) {
    this.userDetails = this.userService.getUserDetails();
  }

  ngOnInit() {
    localStorage.removeItem('IsAssignedToMe');
  }

  ngOnChanges() {

  }

  getFromOrWithFlag(learningPathData) {
    // const EmpId = this.userDetails.UserDetails.EmpId;
    const EmpId = (this.userDetails.IsRepView !== undefined && this.userDetails.IsRepView) ?
      this.userDetails.CoacheeDetails.UserDetails.EmpId : this.userDetails.UserDetails.EmpId;
    let fromOrWith = 'From';
    if (learningPathData.ItemType === 'CDRReports') {
      fromOrWith = 'With';
    } else if (learningPathData.ItemType === 'Quick Feedback' || learningPathData.ItemType === 'SolicitMultiRaterSurvey') {

      if (learningPathData.ManagerId === EmpId) {
        fromOrWith = 'To';
      } else {
        fromOrWith = 'From';
      }
    } else if (learningPathData.ItemType === 'Feedback Request') {
      if (learningPathData.ManagerId === EmpId) {
        fromOrWith = 'To';
      } else {
        fromOrWith = 'From';
      }
    } else if (learningPathData.ItemType === 'GoalTaskObserver' || learningPathData.ItemType === 'GoalObserver') {
      fromOrWith = 'To';
    }
    return fromOrWith;
  }

  getAssignerOrAssigneeName(learningPathData) {
    // const EmpId = this.userDetails.UserDetails.EmpId;
    const EmpId = (this.userDetails.IsRepView !== undefined && this.userDetails.IsRepView) ?
      this.userDetails.CoacheeDetails.UserDetails.EmpId : this.userDetails.UserDetails.EmpId;
    let assignerName = learningPathData.AssignedToName;
    if (learningPathData.ItemType === 'CDRReports' || learningPathData.ItemType === 'CDPPlan'
      || learningPathData.ItemType === 'Plans' || learningPathData.ItemType === 'Reviews') {
      if (learningPathData.CreatedByEmpId === EmpId) {
        assignerName = learningPathData.AssignedToName;
      } else {
        assignerName = learningPathData.CreatedByName;
      }
    } else if (learningPathData.ItemType === 'Quick Feedback' || learningPathData.ItemType === 'SolicitMultiRaterSurvey') {
      if (learningPathData.ManagerId === EmpId) {
        assignerName = learningPathData.AssignedToName;
      } else {
        assignerName = learningPathData.ManagerName;
      }
    } else if (learningPathData.ItemType === 'Feedback Request') {

      if (learningPathData.ManagerId === EmpId) {
        assignerName = learningPathData.AssignedToName;
      } else {
        assignerName = learningPathData.ManagerName;
      }
    } else if (learningPathData.ItemType === 'GoalTaskObserver' || learningPathData.ItemType === 'GoalObserver') {
      assignerName = learningPathData.AssignedToName;
    } else if (learningPathData.ItemType === 'AdminTask' || learningPathData.ItemType === 'GoalTask') {
      assignerName = learningPathData.CreatedByName;
    } else if (learningPathData.SourceType === 'Training') {
      assignerName = learningPathData.CreatedByName;
    } else {
      assignerName = learningPathData.CreatedByName;
    }
    return assignerName;
  }

  getAssignerOrAssigneeFirstName(learningPathData) {
    let assignerName = learningPathData.AssignedToName;
    if (learningPathData.ItemType === 'GoalTaskObserver' || learningPathData.ItemType === 'GoalObserver') {
      assignerName = learningPathData.AssignedToName.split(' ');
      assignerName = assignerName[0];
    }
    return assignerName;
  }

  deleteReport(learningPathData: IActBaseInterface) {
    const deleteReportRequest = {} as DeleteReportRequest;
    deleteReportRequest.DeletedBy = this.userDetails.UserDetails.EmployeeId;
    deleteReportRequest.ReportType = learningPathData.ItemType;
    deleteReportRequest.ReportId = learningPathData.ItemId;
    this.confirmationDialogService.confirm('Common_Confirm_ReportDelete',
      'Common_Yes',
      'Common_No').subscribe(value => {
        if (value) {
          this.learnService.deleteReportById(deleteReportRequest).subscribe((response) => {
            if (response) {
              if (response === 1) {
                this._eventEmiter.emit({ actionType: 'ReloadActData' });
                this.toast.success('Report deleted successfully.');
              } else {
                this.toast.error('Error Occured');
              }
            }
          });
        }
      });
  }

  showDeleteReport(learningPathData: IActBaseInterface) {
    const ItemType = learningPathData.ItemType;
    const status = learningPathData.Status;
    if (this.router.url.indexOf('/manage') > -1) {
      if (ItemType === 'CDRReports' || ItemType === 'CDPPlan' || ItemType === 'Reviews') {
        if (status === 'Draft') {
          return true;
        }
      }
      else if (ItemType === 'Plans') {
        return this.commonService.isNotExpired(learningPathData.DueDate);
        }
    }
  }

  getAssignerToOrFromImage(learningPathData) {
    // const EmpId = this.userDetails.UserDetails.EmpId;
    const EmpId = (this.userDetails.IsRepView !== undefined && this.userDetails.IsRepView) ?
      this.userDetails.CoacheeDetails.UserDetails.EmpId : this.userDetails.UserDetails.EmpId;
    let assignerFromOrToImage = learningPathData.ToProfilePicUrl;
    // tslint:disable-next-line:max-line-length
    if (learningPathData.ItemType === 'CDRReports' || learningPathData.ItemType === 'CDPPlan'
      || learningPathData.ItemType === 'Plans' || learningPathData.ItemType === 'Reviews') {
      if (learningPathData.CreatedByEmpId === EmpId) {
        assignerFromOrToImage = learningPathData.ToProfilePicUrl;
      } else {
        assignerFromOrToImage = learningPathData.FromProfilePicUrl;
      }
    } else if (learningPathData.ItemType === 'Quick Feedback' || learningPathData.ItemType === 'SolicitMultiRaterSurvey') {
      if (learningPathData.ManagerId === EmpId) {
        assignerFromOrToImage = learningPathData.ToProfilePicUrl;
      } else {
        assignerFromOrToImage = learningPathData.ManagerProfilePicUrl;
      }
    } else if (learningPathData.ItemType === 'Feedback Request') {
      if (learningPathData.ManagerId === EmpId) {
        assignerFromOrToImage = learningPathData.ToProfilePicUrl;
      } else {
        assignerFromOrToImage = learningPathData.ManagerProfilePicUrl;
      }
    } else if (learningPathData.ItemType === 'GoalTaskObserver' || learningPathData.ItemType === 'GoalObserver') {
      assignerFromOrToImage = learningPathData.ToProfilePicUrl;
    } else if (learningPathData.ItemType === 'AdminTask' || learningPathData.ItemType === 'GoalTask') {
      assignerFromOrToImage = learningPathData.FromProfilePicUrl;
    } else {
      assignerFromOrToImage = learningPathData.FromProfilePicUrl;
    }
    if (assignerFromOrToImage === null || assignerFromOrToImage === '') {
      assignerFromOrToImage = Images.login.placeHolderIcon;
    }
    return assignerFromOrToImage;
  }

  isTrainingType(ItemType: string) {
    if (ItemType === 'Document' || ItemType === 'Flip-Chart') {
      return true;
    } else if (ItemType === 'Other') {
      return true;
    } else if (ItemType === 'Link') {
      return true;
    } else if (ItemType === 'Video') {
      return true;
    } else if (ItemType === 'eLearning') {
      return true;
    } else if (ItemType === 'Quiz') {
      return true;
    } else if (ItemType === 'Action Item') {
      return true;
    }
    return false;
  }

  isFolderContainer() {
    return (this.router.url.indexOf('/foldr') > -1)
  }

  getIconName(learningPathData) {
    const ItemType = learningPathData.ItemType;
    let iconName = '';
    if (ItemType === 'CDRReports' || ItemType === 'CDPPlan' || ItemType === 'Plans' || ItemType === 'Reviews') {
      iconName = Images.actIconclasses.reportIcon;
    } else if (ItemType === 'Document' || ItemType === 'Flip-Chart') {
      iconName = Images.actIconclasses.docTrainIcon;
    } else if (ItemType === 'Other') {
      iconName = Images.actIconclasses.otherTrainingIcon;
    } else if (ItemType === 'Link') {
      iconName = Images.actIconclasses.linkTrainIcon;
    } else if (ItemType === 'Video') {
      iconName = Images.actIconclasses.videoTrainingIcon;
    } else if (ItemType === 'eLearning') {
      iconName = Images.actIconclasses.eLearningTrainingIcon;
    } else if (ItemType === 'Quiz') {
      iconName = Images.actIconclasses.quizIcon;
    } else if (ItemType === 'Task' || ItemType === 'GoalTask' || ItemType === 'AdminTask' || ItemType === 'Action Item') {
      iconName = Images.actIconclasses.taskIcon;
    } else if (ItemType === 'GoalTaskObserver' || ItemType === 'GoalObserver') {
      iconName = Images.actIconclasses.ratingStarIcon;
    } else if (ItemType === 'Quick Feedback') {
      if (learningPathData.CreatedByEmpId !== learningPathData.AssignToEmpId) {
        iconName = Images.actIconclasses.provideQuickFeedbackIcon;
      } else {
        iconName = Images.actIconclasses.requestQuickFeedbackIcon;
      }
    } else if (ItemType === 'Feedback Request' && learningPathData.IsSolicited) {
      iconName = Images.actIconclasses.solicitFeedbackIcon;
    } else if (ItemType === 'Feedback Request' && !learningPathData.IsSolicited) {
      iconName = Images.actIconclasses.requestQuickFeedbackIcon;
    } else if (ItemType === 'Assessment' || ItemType === 'Competency Assessment') {
      iconName = Images.actIconclasses.assessmentIcon;
    } else if (ItemType === 'Survey') {
      iconName = Images.actIconclasses.surveyIcon;
    } else if (ItemType === 'Folder') {
      iconName = Images.actIconclasses.folderIcon;
    } else if (ItemType === 'Certify') {
      iconName = Images.actIconclasses.certifyIcon;
    } else if (ItemType === 'SolicitMultiRaterSurvey') {
      iconName = Images.actIconclasses.solicitFeedbackIcon;
    }
    return iconName;
  }


  getItemType(learningPathData) {
    let itemType = (learningPathData.SourceType === 'Training') ? learningPathData.SourceType : learningPathData.ItemType;
    if (learningPathData.ItemType === 'CDRReports') {
      if (this.userDetails.UserDetails.MemberOrgID === MemberOrganization.Viacom) {
        itemType = 'Check-In';
      } else {
        itemType = 'Coaching Conversation';
      }
    } else if (learningPathData.ItemType === 'CDPPlan') {
      itemType = 'Plans';
    } else if (learningPathData.ItemType === 'GoalTaskObserver' || learningPathData.ItemType === 'GoalObserver') {
      itemType = 'Feedback Request';
    } else if (learningPathData.ItemType === 'Feedback Request') {
      itemType = 'Feedback';
    }
    return itemType;
  }

  showCompleteStatus(learningPathData: any) {
    const ItemType = learningPathData.ItemType;
    const status = learningPathData.Status;
    if (ItemType === 'CDRReports') {
      if (learningPathData.IsCompleted) {
        return true;
      } else {
        return false;
      }
    } else if (ItemType === 'GoalTaskObserver' || ItemType === 'GoalObserver') {
      if (status === ActBaseFeedbackStatus.Done) {
        return true;
      } else {
        return false;
      }
    } else if (learningPathData.SourceType === 'Training') {
      if (learningPathData.IsCompleted) {
        return true;
      } else {
        return false;
      }
    }
  }

  isRequiredToShowAttachmentIcon(learningPathData: any) {
    const ItemType = learningPathData.ItemType;
    if (ItemType === 'CDPPlan' || ItemType === 'Plans' || ItemType === 'Reviews' || ItemType === 'Coaching') {
      // if (learningPathData.Status === 'Draft') {
      return true;
      // }
    } else if (ItemType === 'CDRReports') {
      if (learningPathData.IsCompleted || learningPathData.Status === 'Awaiting Acknowledgement') {
        if (!learningPathData.HasAttachment) {
          return false;
        } else {
          return true;
        }
      } else {
        return true;
      }
    }
  }

  onClicked(e: any) {
    if (e.target.className === 'fas fa-paperclip attachment' || e.target.className === 'fas fa-trash-alt') {
      return;
    }
    if (this.isSingleClick) {
      return;
    }
    this.isSingleClick = true;
    let ItemType = this.learningPathData.ItemType;
    if (ItemType === 'Other' || ItemType === 'eLearning' ||
      ItemType === 'Quiz' || ItemType === 'Document' || ItemType === 'Video' ||
      ItemType === 'Link' || ItemType === 'Flip-Chart') {
      ItemType = 'Training';
    }
    switch (ItemType) {
      case 'Training':
        this.openTrainingDetails();
        break;
      case 'CDRReports':
      case 'CDPPlan':
      case 'Plans':
        this.openReport();
        break;
      case 'Quick Feedback':
      case 'Feedback Request':
        this.openQuickFeedbackDetails();
        break;
      // case 'SolicitMultiRaterSurvey':
      //   this.openPulseSurvey(this.learningPathData.AssessmentId, false);
      //   break;
      case 'SolicitMultiRaterSurvey':
      case 'Assessment':
      case 'Survey':
        if (this.isFolderItemAllowed(this.learningPathData.AssessmentId)) {
          const comment = this.learningPathData.Comment;
          if (comment && comment === 'PulseSurvey') {
            this.openPulseSurvey(this.learningPathData.AssessmentId, true);
          } else {
            this.openPulseSurvey(this.learningPathData.AssessmentId, false);
            // this.openSurveyAssessment();
          }
        }
        break;
      case 'Certify':
        this.openPulseSurvey(this.learningPathData.ItemId, false);
        break;
      /*
      case 'Assessment':
      case 'Certify':
        this.openSurveyAssessment();
        break;
      */
      case 'GoalTaskObserver':
        this.openTaskObserverTaskRating();
        break;
      case 'GoalObserver':
        this.openGoalObserverGoalRating();
        break;
      case 'Folder':
        this.openFolderDetails();
        break;
      case 'Competency Assessment':
        this.openCompetencyAssessment();
        break;
      case 'Action Item':
        this.openNovoActionItem();
        break;
      default:
        break;
    }

    setTimeout(() => {
      this.isSingleClick = false;
    }, 300);

  }

  openCompetencyAssessment() {
    // window.addEventListener('message', this.handleIframeResponse.bind(this));
    const request = {} as SurveyAssessmentUrlRequest;
    request.CompetencyId = this.learningPathData.ItemId;
    request.Source = 'icf6';
    request.EmpId = this.userDetails.UserDetails.EmpId;
    request.MemberOrgId = this.userDetails.UserDetails.MemberOrgID;
    request.AssesssmentType = this.learningPathData.AssesssmentType;
    request.RedirectTo = 'dashboard';
    request.Culture = this.localizationService.getICF6CultreFromLocalStorage().CultureCode;
    request.ICF5IFramePageToOpen = 'manage';
    const competencyAssessmentUrl = this.surveyAssessmentUrlBuilderService.openCompetencyAssessment(request);
    const queryParam = encodeURI(competencyAssessmentUrl);
    this.sharedDataService.setData(competencyAssessmentUrl);
    this.sharedDataService.setRedirectionValue(this.getRedirectionValueFromIframe());
    this.router.navigate(['/iCoachFirst/report/dynamicreport', this.learningPathData.ItemName], { queryParams: { encodedUrl: queryParam } });
    return false;
  }

  openSurveyAssessment() {
    // window.addEventListener('message', this.handleIframeResponse.bind(this));
    const request = {} as SurveyAssessmentUrlRequest;
    request.CandAssId = this.learningPathData.ItemId;
    request.MemberOrgId = this.userDetails.UserDetails.MemberOrgID;
    request.RedirectTo = 'dashboard';
    if (this.learningPathData.FolderId) {
      // The below API is to check whether any priority item other than selected item is pending or not.
      // If item to associated to any folder then only need to check enforcement
      this.learnService.checkFolderEnforcement(this.learningPathData.ItemId, this.learningPathData.FolderId, 'survey')
        .subscribe(enforceCheck => {
          if (enforceCheck.IsOrderEnforced && enforceCheck.Message !== '') {
            this.toast.prepareParameterizedMessage('error', ['LearningDashboard_EnforePreReqMsg', enforceCheck.Message]);
            return;
          } else {
            let reportUrl = '';
            if (this.learningPathData.Status === 'Complete') {
              reportUrl = this.surveyAssessmentUrlBuilderService.openSurveyAssessment(request);
            } else {
              reportUrl = this.surveyAssessmentUrlBuilderService.openSurveyAssessmentForNonCompleted(request);
            }
            const queryParam = encodeURI(reportUrl);
            this.sharedDataService.setData(reportUrl);
            this.sharedDataService.setRedirectionValue(this.getRedirectionValueFromIframe());
            this.router.navigate(['/iCoachFirst/report/dynamicreport', this.learningPathData.ItemName],
              { queryParams: { encodedUrl: queryParam } });
            return false;
          }
        });
    } else {
      let reportUrl = '';
      if (this.learningPathData.Status === 'Complete') {
        reportUrl = this.surveyAssessmentUrlBuilderService.openSurveyAssessment(request);
      } else {
        reportUrl = this.surveyAssessmentUrlBuilderService.openSurveyAssessmentForNonCompleted(request);
      }
      const queryParam = encodeURI(reportUrl);
      this.sharedDataService.setData(reportUrl);
      this.sharedDataService.setRedirectionValue(this.getRedirectionValueFromIframe());
      this.router.navigate(['/iCoachFirst/report/dynamicreport', this.learningPathData.ItemName],
        { queryParams: { encodedUrl: queryParam } });
    }
    return false;
  }

  openReport() {
    // window.addEventListener('message', this.handleIframeResponse.bind(this));
    const reportUrl = this.dynamicUrlBuilderService.draftedReportUrl(this.createUrlRequest(this.learningPathData));
    const queryParam = encodeURI(reportUrl);
    this.sharedDataService.setData(reportUrl);
    this.sharedDataService.setRedirectionValue(this.getRedirectionValueFromIframe());
    this.router.navigate(['/iCoachFirst/report/dynamicreport', this.learningPathData.ItemName], { queryParams: { encodedUrl: queryParam } });
  }

  createUrlRequest(draftReport: IActBaseInterface): DynamicReportUrlRequest {
    const request = {} as DynamicReportUrlRequest;
    request.EmpReportId = draftReport.ItemId;
    request.ReportName = draftReport.ItemName;
    request.ReportId = draftReport.ReportTypeId;
    request.ReportId = 0; // draftReport.ReportTypeId; // Need to get ReportId from API. 0 has been assigned temporarily.
    if (draftReport.AssignToEmpId === this.userDetails.UserDetails.EmpId) {
      request.IsMgr = 'F';
      request.CoachId = draftReport.AssignToEmpId;
    } else {
      request.IsMgr = 'T';
      request.CoachId = draftReport.ManagerId;
    }
    request.CoacheeId = draftReport.AssignToEmpId;
    request.MemberOrgID = this.userDetails.UserDetails.MemberOrgID;
    request.Source = 'icf6';
    if (this.userDetails.IsRepView !== undefined && this.userDetails.IsRepView) {
      request.RedirectTo = 'manage';
    } else {
      request.RedirectTo = 'dashboard';
    }
    request.Culture = this.localizationService.getICF6CultreFromLocalStorage().CultureCode;
    request.PagePath = draftReport.TargetURL;
    request.CoachExternalId = draftReport.CoachExternalId;
    return request;
  }

  openNovoActionItem() {
    const request = {} as NovoActionItems;
    request.ItemId = this.learningPathData.AssessmentId;
    request.ItemName = this.learningPathData.ItemName;
    request.Status = this.learningPathData.Status;
    request.SourceType = this.learningPathData.SourceType;
    request.ItemType = this.learningPathData.ItemType;
    request.CreatedByName = this.learningPathData.CreatedByName;
    request.FromTable = this.learningPathData.FromTable;
    request.NextEmpReportID = this.learningPathData.ManagerId;
    request.MemberOrgID = this.userDetails.UserDetails.MemberOrgID;
    if (request.Status !== '') {
      const dialogConfig = new MatDialogConfig();
      dialogConfig.width = 900 + 'px';
      dialogConfig.disableClose = true;
      dialogConfig.data = request;
      this.dialogRef = this.dialog.open(NovoActionItemComponent, dialogConfig);
      this.dialogRef.afterClosed().subscribe(() => {
        this._eventEmiter.emit({ actionType: 'ReloadActData' });
      });
    } else {
      this.toast.error('ActionItem_Alert');
    }
  }

  openTaskObserver() {
    // window.addEventListener('message', this.handleIframeResponse.bind(this));
    const request = {} as TaskObserverUrlRequest;
    request.LearningId = this.learningPathData.ItemId;
    request.EmpId = this.userDetails.UserDetails.EmpId;
    request.MemberOrgID = this.userDetails.UserDetails.MemberOrgID;
    request.Source = 'icf6';
    request.Culture = 'en';
    request.RedirectTo = 'AllPending';
    const reportUrl = this.taskObserverUrlBuilderService.openTaskObserverUrl(request);
    const dialogConfig = new MatDialogConfig();
    dialogConfig.width = 900 + 'px';
    dialogConfig.disableClose = true;
    dialogConfig.data = { url: reportUrl };
    this.dialogRef = this.dialog.open(IframeNoborderModalComponent, dialogConfig);
    window.addEventListener('closeIframeNoborder', function () {
      const clrBtn: any = window.document.getElementsByClassName('btn-cancel')[0];
      clrBtn.click();
    });
  }

  openGoalObserver() {
    // // window.addEventListener('message', this.handleIframeResponse.bind(this));
    // const request = {} as TaskObserverUrlRequest;
    // request.LearningId = this.learningPathData.ItemId;
    // request.EmpId = this.userDetails.UserDetails.EmpId;
    // request.MemberOrgID = this.userDetails.UserDetails.MemberOrgID;
    // request.Source = 'icf6';
    // request.Culture = 'en';
    // request.RedirectTo = 'AllPending';
    // const reportUrl = this.taskObserverUrlBuilderService.openTaskObserverUrl(request);
    // const dialogConfig = new MatDialogConfig();
    // dialogConfig.width = 900 + 'px';
    // dialogConfig.disableClose = true;
    // dialogConfig.data = { url: reportUrl };
    // this.dialogRef = this.dialog.open(IframeNoborderModalComponent, dialogConfig);
    // window.addEventListener('closeIframeNoborder', function () {
    //   const clrBtn: any = window.document.getElementsByClassName('btn-cancel')[0];
    //   clrBtn.click();
    // });
  }

  openGoalObserverGoalRating() {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.width = 900 + 'px';
    dialogConfig.disableClose = true;
    dialogConfig.data = { dataToPass: this.learningPathData };
    this.dialogRef = this.dialog.open(GoalRatingComponent, dialogConfig);
  }

  openTaskObserverTaskRating() {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.width = 900 + 'px';
    dialogConfig.disableClose = true;
    dialogConfig.data = { dataToPass: this.learningPathData };
    this.dialogRef = this.dialog.open(TaskRatingComponent, dialogConfig);
  }

  openQuickFeedbackDetails() {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.width = 800 + 'px';
    dialogConfig.disableClose = true;
    dialogConfig.data = this.learningPathData;
    this.dialogAct = this.dialog.open(QuickFeedbackDetailsComponent, dialogConfig);
    this.dialogAct.afterClosed().subscribe(() => {
      //this._eventEmiter.emit({ actionType: 'ReloadActData' });
    });
  }

  openTrainingDetails() {
    // window.addEventListener('message', this.handleIframeResponse.bind(this));
    this.trainDetailRequest.Id = this.learningPathData.ItemId;
    this.trainDetailRequest.EmpId = this.userDetails.UserDetails.EmpId;
    this.learnService.getTrainingDetails(this.trainDetailRequest).subscribe(response => {
      const trainingDetail = response.GetTrainingDataForAct;
      if (this.learningPathData.FolderId) {
        // The below API is to check whether any priority item other than selected item is pending or not.
        // If item to associated to any folder then only need to check enforcement
        this.learnService.checkFolderEnforcement(trainingDetail.ContentId, this.learningPathData.FolderId, 'training')
          .subscribe(enforceCheck => {
            if (enforceCheck.IsOrderEnforced && enforceCheck.Message !== '') {
              this.toast.prepareParameterizedMessage('error', ['LearningDashboard_EnforePreReqMsg', enforceCheck.Message]);
              return;
            } else {
              this.handleTrainingDetails(trainingDetail);
            }
          });
      } else {
        this.handleTrainingDetails(trainingDetail);
      }
    });
  }

  handleTrainingDetails(trainingDetail: any) {
    if (!trainingDetail.MarkComplete) {
      this.sharedDataService.setRedirectionValue(this.getRedirectionValueFromIframe());
      this.commonService.reviewTraining(trainingDetail);
      /* if (!this.commonService.isTrainingDueDateExpired(trainingDetail.DueDate)) {
         if (trainingDetail.TypeName === 'Video' || trainingDetail.TypeName === 'Document' || trainingDetail.TypeName.toLowerCase() === 'quiz') {
           this.router.navigate(['/iCoachFirst/learn/reviewTraining', trainingDetail.AssignmentId]);
         } else if (trainingDetail.TypeName === 'eLearning') {
           const traningInvitation = new TrainingInvitationUrlRequest();
           traningInvitation.AssignmentId = trainingDetail.AssignmentId;
           traningInvitation.AssigneeId = trainingDetail.AssigneeId;
           this.learnService.getTrainingInvitationURL(traningInvitation).subscribe(data => {
             const datas = JSON.parse(JSON.stringify(data));
             if (datas.GenerateTrainingInvitationUrlResult.ResultStatusCode === '1040') {
               this.router.navigate(['/iCoachFirst/learn/reviewTraining', trainingDetail.AssignmentId]);
             } else {
               this.toast.error(datas.GenerateTrainingInvitationUrlResult.ErrorMessage);
             }
           });
         } else {
           this.router.navigate(['/iCoachFirst/learn/reviewTraining', trainingDetail.AssignmentId]);
           window.open(trainingDetail.ReviewLink, '_blank');
           window.focus();
         }
       } else {
         this.toast.error('Item Due date has expired');
       } */
    } else {
      this.openPreviewModalPopup(trainingDetail);
    }
  }

  openPreviewModalPopup(trainingDetail: any) {
    var iOS = !!navigator.platform && /iPad|iPhone|iPod/.test(navigator.platform);
    const dialogConfig = new MatDialogConfig();
    dialogConfig.data = trainingDetail;
    if (dialogConfig.data.TypeName === 'Document') {
      // dialogConfig.disableClose = true;
      if (iOS) {
        window.open(trainingDetail.ReviewLink, '_blank');
        window.focus();
      } else {
        dialogConfig.width = LearnModalPopupEnum.PreviewModalWidth + 'px';
        dialogConfig.height = LearnModalPopupEnum.PreviewModalHeight + 'px';
        this.dialog.open(TrainingContentComponent, dialogConfig);
      }
    }
    else if (dialogConfig.data.TypeName === 'Video') {
      dialogConfig.width = LearnModalPopupEnum.PreviewModalWidth + 'px';
      dialogConfig.height = LearnModalPopupEnum.PreviewModalHeight + 'px';
      this.dialog.open(TrainingContentComponent, dialogConfig);
    } else if (trainingDetail.TypeName.toLowerCase() === 'quiz') {
      if (trainingDetail.CandidateAssessmentID !== undefined) {
        const reportUrl = this.staticUrlBuilderService.newAssessmentReportUrl(trainingDetail.CandidateAssessmentID);
        this.sharedDataService.setData(reportUrl);
        this.router.navigate(['/iCoachFirst/report/dynamicreport', 'Quiz'], { queryParams: { encodedUrl: trainingDetail.ContentId } });
      }
    } else if (dialogConfig.data.TypeName === 'Other') {
      window.open('', '_blank');
      window.focus();
    } else if (dialogConfig.data.TypeName === 'eLearning') {
      const request = {} as ScormLaunchUrlRequest;
      request.AssignmentId = trainingDetail.AssignmentId;
      request.MemberOrgId = this.userService.getUserDetails().UserDetails.MemberOrgID;
      this.learnService.geteLearningLaunchUrl(request).subscribe(data => {
        const datas = JSON.parse(JSON.stringify(data));
        if (!datas.ErrorMessage) {
          window.open(datas.LaunchUrl, '_blank');
        } else {
          this.toast.error(datas.ErrorMessage);
        }
      });
    } else {
      window.open(dialogConfig.data.ReviewLink, '_blank');
      window.focus();
    }
  }

  openFolderDetails() {
    this.enableBackButton = true;
    this.router.navigate(['/iCoachFirst/dashboard/folder/', this.learningPathData.ItemId, this.learningPathData.SourceType]);
    // this.router.navigate(['/iCoachFirst/dashboard/goals']);
  }

  openReportAttachment() {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.width = 800 + 'px';
    dialogConfig.disableClose = false;
    dialogConfig.data = this.learningPathData;
    this.dialog.open(ActReportAttachmentComponent, dialogConfig);
  }

  reloadAllPending(_data?: any) {
    this._eventEmiter.emit({ actionType: 'ReloadActData' });
  }

  ngOnDestroy() {
    // window.removeEventListener('message', this.handleIframeResponse, false);
  }

  getStatus(): string {
    let currentStatus = this.learningPathData.Status;
    if (this.learningPathData.SourceType === SourceType.Training) {
      if (!this.learningPathData.IsCompleted && this.commonService.isTrainingDueDateExpired(this.learningPathData.DueDate)) {
        currentStatus = 'Expired';
      }
      else if (this.learningPathData.IsCompleted && currentStatus.toLowerCase() == "approved") {
        currentStatus = "Completed";
      }

    } else if (this.learningPathData.ItemType === ItemTypeEnum.SolicitMultiRaterSurvey || this.learningPathData.ItemType === ItemTypeEnum.Assessment ||
      this.learningPathData.ItemType === ItemTypeEnum.Survey || this.learningPathData.ItemType === ItemTypeEnum.Certify) {
      if (currentStatus !== GoalTaskStatus.Complete && this.commonService.isTrainingDueDateExpired(this.learningPathData.DueDate)) {
        currentStatus = 'Expired';
      }
    }
    return currentStatus;
  }

  getRedirectionValue() {
    if (this.userDetails.IsRepView !== undefined && this.userDetails.IsRepView) {
      return 'manage';
    } else {
      return 'dashboard';
    }
  }

  getRedirectionValueFromIframe(): string {
    const url = window.location.href;
    return url.split(environment.iframeRedirectionHostName)[1];
  }

  openPulseSurvey(candidateAssessmentId: number, isPulseSurvey: boolean = false) {
    const EmpId = this.userService.getUserDetails().UserDetails.EmpId;
    this.surveyService.getPulseSurveyDetails(candidateAssessmentId, isPulseSurvey).subscribe(resp => {
      if (resp.length > 0) {
        resp[0].EmpId = EmpId;
        const dialogConfig = new MatDialogConfig();
        dialogConfig.width = ModalPopupSizeEnum.PulseSurveyModalWidth + 'px';
        dialogConfig.disableClose = true;
        dialogConfig.data = resp[0];
        this.dialog.open(SurveyCreatorComponent, dialogConfig).afterClosed().subscribe((response) => {
          if (response === 'complete' || response === 'Inprogress') {
            this.reloadAllPending();
          }
        });
      } else if (resp.length === 0) {
        this.toast.error('OperationFailedMessage');
      }
    });
    // }
  }

  isFolderItemAllowed(candidateAssessmentId: number): boolean {
    if (this.learningPathData.FolderId > 0) {
      // The below API is to check whether any priority item other than selected item is pending or not.
      // If item to associated to any folder then only need to check enforcement
      this.learnService.checkFolderEnforcement(candidateAssessmentId, this.learningPathData.FolderId, 'survey')
        .subscribe(enforceCheck => {
          if (enforceCheck.IsOrderEnforced && enforceCheck.Message !== '') {
            this.toast.prepareParameterizedMessage('error', ['LearningDashboard_EnforePreReqMsg', enforceCheck.Message]);
            return false;
          } else {
            return true;
          }
        });
    } else {
      return true;
    }
  }

  CheckItemImageExists(imageUrl: string, contentType: string): boolean {
    if (contentType !== null && contentType !== '') {
      contentType = contentType.toLowerCase();
      if (contentType === 'assessment' || contentType === 'survey' || contentType === 'quiz') {
        if (imageUrl === null || imageUrl === '') {
          return false;
        } else if (imageUrl && (imageUrl).indexOf('trainingcatalog_noimage.png') > -1) {
          return false;
        }
      }
    }
    return true;
  }

  CheckDefaultImageOrNoImageInList(imageUrl: string): boolean {
    return (imageUrl).toLowerCase().indexOf('trainingcatalog_noimage.png') > -1;
  }

  ContentTypeImageClass(contentType: string): string {
    if (contentType != null) {
      contentType = contentType.toLowerCase();
      if (contentType === 'assessment') {
        return 'fas fa-clipboard-list';
      } else if (contentType === 'survey') {
        return 'fas fa-poll-h';
      } else if (contentType === 'quiz') {
        return 'fas fa-question-circle';
      } else {
        return 'nodisplay';
      }
    }
    return 'nodisplay';
  }

}
