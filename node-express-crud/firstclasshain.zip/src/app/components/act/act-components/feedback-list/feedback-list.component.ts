import { Component, OnInit, Input, SimpleChanges, OnChanges } from '@angular/core';
import { UserService } from 'src/app/services/user.service';
// import { UserDetails } from 'src/app/models/user-details-result';
import { MatDialogConfig, MatDialog } from '@angular/material';
import { AssignQuickFeedbackComponent } from 'src/app/components/quick-feedback/assign-quick-feedback/assign-quick-feedback.component';
import { UserPermissions } from 'src/app/helpers/enums/common-enums';
import { ActRequest } from 'src/app/models/requests/act-request';
import { ActResponse, Act } from 'src/app/models/response/act-response';
import { PageRequest } from '../../../../models/requests/page-request';
import { environment } from 'src/environments/environment';
import { ActService } from 'src/app/services/act.service';
import { Subscription } from 'rxjs';
import { EventEmiterService } from 'src/app/services/event.emmiter.service';


@Component({
  selector: 'app-feedback-list',
  templateUrl: './feedback-list.component.html',
  styleUrls: ['./feedback-list.component.scss']
})

export class FeedbackListComponent implements OnInit, OnChanges {

  isRequiredToShowAdd = false;
  isProvidedClick = false;
  isReceivedClick = true;
  userInfo: any;
  IsTaskRatingActionAllowed = false;
  IsGoalRatingActionAllowed = false;
  empId: number;
  @Input() feedbackListData: any;
  filteredData: any[] = [];
  UserPermissions = UserPermissions;
  isShowFilterPopup = false;
  sourceType = 'Feedback';
  responseData: Act[];
  callingSource = 'calllingSourceFeedbackRequest';

  selectedObserver: any;
  subscription: Subscription;
  fromDate = '';
  toDate = '';
  statusOpen: any;
  statusClose: any;
  qfKeyword: string;
  feedbackListDataOld: any;
  isSearchApply = false;

  constructor(
    private userService: UserService, private dialog: MatDialog,
    private actService: ActService,
    private eventEmiter: EventEmiterService

  ) { }

  ngOnInit() {

    //this.feedbackListDataOld = JSON.stringify(this.feedbackListData);
    this.userInfo = this.userService.getUserDetails();
    this.IsTaskRatingActionAllowed = this.userInfo.UserDetails.IsTaskRatingActionAllowed;
    this.IsGoalRatingActionAllowed = this.userInfo.UserDetails.IsGoalRatingActionAllowed;
    this.isReceivedClick = true;
    this.setEmpId();
    
    if (this.userInfo.IsRepView !== undefined && this.userInfo.IsRepView &&
      this.userService.isExistPermission(UserPermissions.ProvideFeedback)) {
      this.isRequiredToShowAdd = true;
    }

    this.setData();
    this.subscription = this.eventEmiter.subscribe(observer => {
      if (observer.keyName === 'calllingSourceFeedbackRequest') {
        this.selectedObserver = observer.observerData;
      }
    });

  }

  showFilter() {
    this.isShowFilterPopup = !this.isShowFilterPopup;
  }


  filterQuickFeedback() {
    if (this.fromDate > this.toDate) {
      return false;
    }

    this.feedbackListDataOld = '';
    const userDetails = this.userService.getUserDetails();
    const request = new ActRequest();
    request.EmpId = userDetails.UserDetails.EmpId;
    request.RecordCount = 0;
    request.RowOffSet = 1;
    request.SourceType = this.sourceType;
    request.PageRequest = new PageRequest();
    request.PageRequest.PageNumber = 0;
    request.PageRequest.PageSize = environment.defaultActPageSize;

    request.FilterRequest = {
      Status: this.statusOpen && this.statusClose ? 'Open,Closed' : this.statusOpen ? 'Open' : this.statusClose ? 'Closed' : '',
      UserEmpId: (this.selectedObserver ? this.selectedObserver.EmpID : 0),
      Keyword: this.qfKeyword,
      StartDate: this.fromDate,
      EndDate: this.toDate,
      FilterFor: this.isProvidedClick ? 'Provided' : 'Received'
    }

     /// For Calling Manage API
    if (this.isRequiredToShowAdd) {
        if (userDetails !== undefined && userDetails.CoacheeDetails !== undefined && userDetails.IsRepView) {
        request.RepId = userDetails.CoacheeDetails.UserDetails.EmpId;

        this.actService.getManageAct(request).subscribe((actList: ActResponse) => {

        this.FillResponseData(actList);
        });
      }
    }
   else{
      /// For Calling LearningPath API
    this.actService.getAll(request).subscribe((actList: ActResponse) => {

      this.FillResponseData(actList);

    });
   }

  }

FillResponseData(actList: ActResponse)
{
  this.feedbackListData = actList.ActData;
      if (this.isReceivedClick) {
        this.onReceivedClickWithOutReset();
      } else {
        this.onProvidedClickWithOutReset();
      }
      this.isShowFilterPopup = false;

      if (this.statusClose || this.statusOpen || (this.qfKeyword != '' && this.qfKeyword != undefined)
        || (this.fromDate != '' && this.fromDate !== null)
        || (this.toDate != '' && this.toDate !== null)
        || (this.selectedObserver != null)
      ) {
        this.isSearchApply = true;
      } else {
        this.isSearchApply = false;
      }
}


  ngOnChanges(changes: SimpleChanges) {
    if (changes !== undefined && this.userInfo !== undefined) {
      this.setEmpId();
      this.setData();
    }
  }

  private setData() {

    if (this.isReceivedClick) {
      this.onReceivedClick();
    } else {
      this.onProvidedClick();
    }
  }

  onReceivedClick(isReset = 0) {
    if (isReset === 1) {
      this.resetformData();
    }
    this.isReceivedClick = true;
    this.isProvidedClick = false;
    this.filterQuickFeedback();
  }

  onProvidedClick(isReset = 0) {
    if (isReset === 1) {
      this.resetformData();
    }
    this.isReceivedClick = false;
    this.isProvidedClick = true;
    this.filterQuickFeedback();
  }

  filterListByItemType() {
    this.filteredData = this.filteredData.filter(
      (objActData) => {
        if (objActData.ItemType === 'GoalObserver' && !this.IsGoalRatingActionAllowed) {
          return false;
        } else if (objActData.ItemType === 'GoalTaskObserver' && !this.IsTaskRatingActionAllowed) {
          return false;
        } else {
          return true;
        }
      });
  }

  setEmpId() {
    this.empId = this.userInfo.UserDetails.EmpId;
    if (this.userInfo.IsRepView !== undefined && this.userInfo.IsRepView) {
      this.empId = this.userInfo.CoacheeDetails.UserDetails.EmpId;
    }
    // return empId;
  }

  assignQuickFeedback() {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.width = '600px';
    dialogConfig.disableClose = true;

    dialogConfig.data = {
      ManagerId: this.userInfo.UserDetails.EmpId,
      RepId: this.userInfo.CoacheeDetails.UserDetails.EmpId,
      CommentedBy: this.userInfo.UserDetails.EmpId,
      IsRequestFeedback: false,
      // IsOutOfHierarchy: this.userInfo.CoacheeDetails.UserDetails.IsOutOfHierarchy,
      // IsMangerCanSeeAndPrivateOptionShow: this.userInfo.CoacheeDetails.UserDetails.IsPvtAndMgrCanSeeOptionAvailableAtOrgLevel,
      feedbackUserDetails: this.userInfo.CoacheeDetails.UserDetails,
    };
    this.dialog.open(AssignQuickFeedbackComponent, dialogConfig);
  }

  showToggleBuuton() {

    if (this.userInfo.IsRepView !== undefined && this.userInfo.IsRepView &&
      !this.userService.isExistPermission(UserPermissions.OnlyUserProvidedFeedback)) {
      return false;
    } else {
      return true;
    }
  }

  onProvidedClickWithOutReset() {
    this.isProvidedClick = true;
    this.isReceivedClick = false;
    if (this.userInfo.IsRepView) {
      this.filteredData = this.feedbackListData.filter(
        // In case of manage, only feedback having manager view on should be visible
        objActData => (objActData.AssignToEmpId !== this.empId && !objActData.IsPrivate));
    } else {
      this.filteredData = this.feedbackListData.filter(
        objActData => (objActData.ManagerId === this.empId));
    }
    this.filterListByItemType();
  }

  onReceivedClickWithOutReset() {

    this.isProvidedClick = false;
    this.isReceivedClick = true;

    if (this.userInfo.IsRepView !== undefined && this.userInfo.IsRepView &&
      this.userService.isExistPermission(UserPermissions.OnlyUserProvidedFeedback)) {

      this.filteredData = this.feedbackListData.filter(
        objActData => (objActData.CreatedByEmpId === this.userInfo.UserDetails.EmpId));

    } else {
      if (this.userInfo.IsRepView) {
        // In case of manage, only feedback having manager view on should be visible
        this.filteredData = this.feedbackListData.filter(
          objActData => (objActData.AssignToEmpId === this.empId && !objActData.IsPrivate));
      } else {
        this.filteredData = this.feedbackListData.filter(
          objActData => (objActData.ManagerId !== this.empId));
      }
    }
    this.filterListByItemType();
  }

  resetformData() {

    //this.feedbackListData = JSON.parse(this.feedbackListDataOld);
    this.statusClose = '';
    this.statusOpen = '';
    this.qfKeyword = '';
    this.fromDate = '';
    this.toDate = '';
    this.selectedObserver = null;

    this.eventEmiter.emit({ keyName: 'resetAutoComplete' });
    this.eventEmiter.emit({ keyName: 'resetDate' });
  }

  onClearSearch() {
    if (this.isReceivedClick) {
      this.onReceivedClick(1);
    } else {
      this.onProvidedClick(1);
    }
    this.isSearchApply = false;

  }


}
