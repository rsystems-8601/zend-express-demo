import { Component} from '@angular/core';
import { ActBaseComponent } from '../act-base/act-base.component';


@Component({
  selector: 'app-act-quick-feedback',
  templateUrl: './act-quick-feedback.component.html',
  styleUrls: ['./act-quick-feedback.component.scss']
})
export class ActQuickFeedbackComponent extends ActBaseComponent {

}
