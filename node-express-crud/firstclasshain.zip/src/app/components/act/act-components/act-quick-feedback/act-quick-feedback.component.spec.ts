import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ActQuickFeedbackComponent } from './act-quick-feedback.component';

describe('ActQuickFeedbackComponent', () => {
  let component: ActQuickFeedbackComponent;
  let fixture: ComponentFixture<ActQuickFeedbackComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ActQuickFeedbackComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ActQuickFeedbackComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
