import { Component} from '@angular/core';
import { ActBaseComponent } from '../act-base/act-base.component';


@Component({
  selector: 'app-act-review',
  templateUrl: './act-review.component.html',
  styleUrls: ['./act-review.component.scss']
})
export class ActReviewComponent extends ActBaseComponent {

}
