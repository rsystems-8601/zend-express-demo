import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ActReviewComponent } from './act-review.component';

describe('ActReviewComponent', () => {
  let component: ActReviewComponent;
  let fixture: ComponentFixture<ActReviewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ActReviewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ActReviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
