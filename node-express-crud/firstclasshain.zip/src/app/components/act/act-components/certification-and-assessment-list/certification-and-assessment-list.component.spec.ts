import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CertificationAndAssessmentListComponent } from './certification-and-assessment-list.component';

describe('CertificationAndAssessmentListComponent', () => {
  let component: CertificationAndAssessmentListComponent;
  let fixture: ComponentFixture<CertificationAndAssessmentListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CertificationAndAssessmentListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CertificationAndAssessmentListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
