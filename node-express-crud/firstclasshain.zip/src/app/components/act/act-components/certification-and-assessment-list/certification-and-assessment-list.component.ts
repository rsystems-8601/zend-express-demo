import { Component, OnInit, Input, SimpleChanges, OnChanges } from '@angular/core';
import { UserPermissions, ReportType } from 'src/app/helpers/enums/common-enums';
import { UserService } from 'src/app/services/user.service';
import { MatDialog, MatDialogConfig } from '@angular/material';
import { AssignCoachingReportComponent } from 'src/app/components/my-team/assign-report/assign-coaching-report.component';
import { BaseRequest } from 'src/app/models/requests/base-request';

@Component({
  selector: 'app-certification-and-assessment-list',
  templateUrl: './certification-and-assessment-list.component.html',
  styleUrls: ['./certification-and-assessment-list.component.scss']
})
export class CertificationAndAssessmentListComponent implements OnInit, OnChanges {

  @Input() certificationAndAssessmentListData: any;
  filteredData: any;
  isRequiredToShowAdd = false;
  userInfo: any;
  UserPermissions = UserPermissions;
  ReportType = ReportType;

  constructor(private userService: UserService, private dialog: MatDialog) { }

  ngOnInit() {

    this.userInfo = this.userService.getUserDetails();
    if (this.userInfo.IsRepView !== undefined && this.userInfo.IsRepView && this.userService.isExistPermission(UserPermissions.CanCoach)) {
      this.isRequiredToShowAdd = true;
    }
    this.setData();
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes !== undefined && this.userInfo !== undefined) {
      this.setData();
    }
  }

  private setData() {

    if (this.userInfo.IsRepView !== undefined && this.userInfo.IsRepView &&
      this.userService.isExistPermission(UserPermissions.UserAssignedCertificationsAndAssessmentsOnly)) {

      this.filteredData = this.certificationAndAssessmentListData.filter(
        objActData => (objActData.CreatedByEmpId === this.userInfo.UserDetails.EmpId));

    } else {
      this.filteredData = this.certificationAndAssessmentListData;
    }
  }

  assignCertificationAndAssessments() {

    const dialogConfig = new MatDialogConfig();
    dialogConfig.width = '800px';
    const dataToPass = new BaseRequest();
    dataToPass.RepId = this.userInfo.CoacheeDetails.UserDetails.EmpId;
    dataToPass.IsRepInitiated = false;
    dialogConfig.data = {
      dataToPass: dataToPass, coacheeData: { Name: this.userInfo.CoacheeDetails.UserDetails.Name, EmpId: this.userInfo.CoacheeDetails.UserDetails.EmpId },
      filterType: ReportType.CertificationAssessment
    };
    dialogConfig.disableClose = true;
    this.dialog.open(AssignCoachingReportComponent, dialogConfig);
  }


}
