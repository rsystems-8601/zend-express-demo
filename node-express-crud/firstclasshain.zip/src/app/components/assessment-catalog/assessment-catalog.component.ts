import { Component, OnInit, EventEmitter, Output } from '@angular/core';
import { UserDetails } from 'src/app/models/user-details-result';
import { ApplicationModuleListEnum } from 'src/app/helpers/enums/common-enums';
import { Router } from '@angular/router';
import { CommonService } from 'src/app/services/common.service';

@Component({
  selector: 'app-assessment-catalog',
  templateUrl: './assessment-catalog.component.html',
  styleUrls: ['./assessment-catalog.component.scss']
})
export class AssessmentCatalogComponent implements OnInit {

  userInfo: UserDetails;
  @Output() setLeftContainerVisibility: EventEmitter<number> = new EventEmitter<number>();
  applicationModuleId: number = ApplicationModuleListEnum.None;

  constructor(
    private router: Router,
    private commonService: CommonService
  ) { }

  ngOnInit() { }

  openMainComponentLeftContainer(appModuleId: number = 0) {
    this.setLeftContainerVisibility.emit(appModuleId);
  }

  hidePopUpForMobile(appModuleId: number = 0) {
    const isMobileDevice = this.commonService.detectMobileDevice();

    if (isMobileDevice) {
      this.setLeftContainerVisibility.emit(appModuleId);
    }
  }

  selectedAssess(type: string) {
    this.router.navigate(['/iCoachFirst/assessment/type', type]);
  }

  showAssessReport() {
    this.router.navigate(['/iCoachFirst/assessment/report']);
  }
}

