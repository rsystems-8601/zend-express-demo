import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AssessmentCatalogComponent } from './assessment-catalog.component';

describe('AssessmentCatalogComponent', () => {
  let component: AssessmentCatalogComponent;
  let fixture: ComponentFixture<AssessmentCatalogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssessmentCatalogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssessmentCatalogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
