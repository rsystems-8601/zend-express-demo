import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
// import { SharedDataService } from 'src/app/services/shared-data.service';
import { AssessUrlRequest } from 'src/app/models/requests/url-builder/assess-url-request';
import { AssessUrlBuilderService } from 'src/app/services/assess-url-builder.service';
import { CommonService } from 'src/app/services/common.service';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-assessment-viewer',
  templateUrl: './assessment-viewer.component.html',
  styleUrls: ['./assessment-viewer.component.scss']
})
export class AssessmentViewerComponent implements OnInit, OnDestroy {
  url: string;
  name: string;
  assessUrlRequest = {} as AssessUrlRequest;
  showHeader = false;
  callBackComplete = false;

  constructor(
    // private sharedDataService: SharedDataService,
    private route: ActivatedRoute,
    private assessUrlBuilderService: AssessUrlBuilderService,
    private commonService: CommonService,
    private authService: AuthService
  ) { }

  ngOnInit() {
    window.addEventListener('message', this.handleIframeTask.bind(this), false);
    this.route.params.subscribe(params => {
      if (params.type) {
        this.assessUrlRequest.Type = params.type;
        this.url = this.assessUrlBuilderService.newReportUrl(this.assessUrlRequest);
      } else {
        this.showHeader = true;
        this.url = this.assessUrlBuilderService.getAssessReportUrl(this.assessUrlRequest);
      }
    });
  }

  closePopupOnIframe() {
    this.commonService.closePopupOnIframe();
  }

  handleIframeTask(e) {
    window.removeEventListener('message', () => { });
    // Member variable this.callBackComplete will be false if user refreshes the url
    // and it will be true if user open this same component again and again
    // so added the check using variable
    if (!this.callBackComplete) {
      if (e.data.redirectTo === undefined && e.data.lockAngularScreen === undefined) {
        // the redirectTo will be undefined if user directly refreshes the url
        // added because this func is getting fired first if user refreshes url directly.
        return;
      }
      if (e.data.redirectTo && e.data.redirectTo === 'logout') {
        this.authService.commonLogout();
      }
    }
  }

  ngOnDestroy() {
    this.callBackComplete = true;
    window.removeEventListener('message', () => { });
  }

}
