import { Component, OnInit } from '@angular/core';
import { LearnService } from 'src/app/services/learn.service';
import { AssessmentReportResponse } from 'src/app/models/response/assess-response';

@Component({
  selector: 'app-assessment-reports',
  templateUrl: './assessment-reports.component.html',
  styleUrls: ['./assessment-reports.component.scss']
})
export class AssessmentReportsComponent implements OnInit {

  assessReports: Array<AssessmentReportResponse>;
  constructor(private learnService: LearnService) { }

  ngOnInit() {
    this.getAssessmentReport();
  }

  getAssessmentReport() {
    this.learnService.getAssessmentReport().subscribe(resultData => {
      this.assessReports = JSON.parse(JSON.stringify(resultData));
    },
      () => {

      }
    );
  }

}
