import { Component, OnInit, EventEmitter, Output } from '@angular/core';
import { DashboardReportsService } from 'src/app/services/dashboard-reports.service';
import { DashboardReport } from 'src/app/models/response/dashboard-report-response';
import { SharedDataService } from 'src/app/services/shared-data.service';
import { Router } from '@angular/router';
import { UserService } from 'src/app/services/user.service';
import { UserDetails } from 'src/app/models/user-details-result';
import { DashboardReportUrlBuilderService } from 'src/app/services/dashboard-report-url-builder.service';
import { ApplicationModuleListEnum } from 'src/app/helpers/enums/common-enums';
import { CommonService } from 'src/app/services/common.service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-dashboard-reports-panel',
  templateUrl: './dashboard-reports-panel.component.html',
  styleUrls: ['./dashboard-reports-panel.component.scss']
})
export class DashboardReportsPanelComponent implements OnInit {
  dashboardReportUrl: string;
  dashboardReports: DashboardReport[];
  randomIcons: string[] = ['assignment', 'people', 'cloud_done', 'subject', 'recent_actors', 'description'];
  userInfo: UserDetails;
  @Output() setLeftContainerVisibility: EventEmitter<number> = new EventEmitter<number>();
  applicationModuleId: number = ApplicationModuleListEnum.None;
  _listFilter: string;
  filteredDashboardReports: DashboardReport[];

  constructor(private dashboardReportService: DashboardReportsService,
    private sharedDataService: SharedDataService,
    private router: Router,
    private userService: UserService,
    private dashboardReportUrlBuilderService: DashboardReportUrlBuilderService,
    private commonService: CommonService) { }

  ngOnInit() {
    this.dashboardReportService.getAll().subscribe(response => {
      this.dashboardReports = response;
      this.filteredDashboardReports = this.dashboardReports;
    });
  }

  // for random icon on report boxes
  getRandomIcon(index) {
    try {
      const len = this.randomIcons.length;
      if (index < len) {
        return this.randomIcons[index];
      } else {
        return this.randomIcons[index % len];
      }
    } catch {
      // fallback
      return this.randomIcons[0];
    }
  }

  // put selected report object in shared service to share
  selectedDashboard(report: DashboardReport) {
    this.userInfo = this.userService.getUserDetails().UserDetails;
    report.CoachId = this.userInfo.EmpId;
    report.MemberOrgID = this.userInfo.MemberOrgID;

    // tslint:disable-next-line:max-line-length
    const url = this.dashboardReportUrlBuilderService.newReportUrl(report); // get the iframe request compatible url and update original reporturl in request
    const queryParam = encodeURI(url);
    this.sharedDataService.setData(url);
    this.sharedDataService.setRedirectionValue(this.getRedirectionValueFromIframe());
    if (report.IsV6DashboardReport === true && report.ReportName === 'Review Assignments') {
      this.router.navigate(['/iCoachFirst/admin/review-assignments']);
    } else if (report.IsV6DashboardReport === true) {
      this.router.navigate([report.ReportUrl]);
    } else {
      this.router.navigate(['/iCoachFirst/report/dashboardreport', report.ReportName], { queryParams: { encodedUrl: queryParam } });
    }
  }

  openMainComponentLeftContainer(appModuleId: number = 0) {
    this.setLeftContainerVisibility.emit(appModuleId);
  }

  hidePopUpForMobile(appModuleId: number = 0) {
    const isMobileDevice = this.commonService.detectMobileDevice();

    if (isMobileDevice) {
      this.setLeftContainerVisibility.emit(appModuleId);
    }
  }

  get listFilter(): string {
    return this._listFilter;
  }
  set listFilter(value: string) {
    this._listFilter = value;
    this.filteredDashboardReports = this.listFilter ? this.performFilter(this.listFilter) : this.dashboardReports;
  }
  performFilter(filterBy: string): DashboardReport[] {
    filterBy = filterBy.toLocaleLowerCase();
    return this.dashboardReports.filter((report: DashboardReport) =>
      report.ReportName.toLocaleLowerCase().indexOf(filterBy) !== -1);
  }

  getRedirectionValueFromIframe(): string {
    const url = window.location.href;
    return url.split(environment.iframeRedirectionHostName)[1];
  }

}
