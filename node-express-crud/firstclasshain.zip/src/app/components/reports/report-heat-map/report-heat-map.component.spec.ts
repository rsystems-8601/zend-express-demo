import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReportHeatMapComponent } from './report-heat-map.component';

describe('ReportHeatMapComponent', () => {
  let component: ReportHeatMapComponent;
  let fixture: ComponentFixture<ReportHeatMapComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReportHeatMapComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReportHeatMapComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
