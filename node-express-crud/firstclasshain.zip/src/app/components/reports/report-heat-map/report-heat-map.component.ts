import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-report-heat-map',
  templateUrl: './report-heat-map.component.html',
  styleUrls: ['./report-heat-map.component.scss']
})
export class ReportHeatMapComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
