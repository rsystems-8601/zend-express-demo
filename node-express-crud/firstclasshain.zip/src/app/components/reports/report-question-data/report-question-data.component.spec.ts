import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReportQuestionDataComponent } from './report-question-data.component';

describe('ReportQuestionDataComponent', () => {
  let component: ReportQuestionDataComponent;
  let fixture: ComponentFixture<ReportQuestionDataComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReportQuestionDataComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReportQuestionDataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
