import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-report-question-data',
  templateUrl: './report-question-data.component.html',
  styleUrls: ['./report-question-data.component.scss']
})
export class ReportQuestionDataComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
