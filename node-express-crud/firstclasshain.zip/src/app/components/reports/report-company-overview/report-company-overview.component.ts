import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-report-company-overview',
  templateUrl: './report-company-overview.component.html',
  styleUrls: ['./report-company-overview.component.scss']
})
export class ReportCompanyOverviewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
