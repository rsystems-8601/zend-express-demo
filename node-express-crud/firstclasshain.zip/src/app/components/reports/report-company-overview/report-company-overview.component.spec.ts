import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReportCompanyOverviewComponent } from './report-company-overview.component';

describe('ReportCompanyOverviewComponent', () => {
  let component: ReportCompanyOverviewComponent;
  let fixture: ComponentFixture<ReportCompanyOverviewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReportCompanyOverviewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReportCompanyOverviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
