import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-report-pulse-overview',
  templateUrl: './report-pulse-overview.component.html',
  styleUrls: ['./report-pulse-overview.component.scss']
})
export class ReportPulseOverviewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
