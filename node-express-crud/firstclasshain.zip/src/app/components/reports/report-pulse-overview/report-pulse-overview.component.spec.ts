import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReportPulseOverviewComponent } from './report-pulse-overview.component';

describe('ReportPulseOverviewComponent', () => {
  let component: ReportPulseOverviewComponent;
  let fixture: ComponentFixture<ReportPulseOverviewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReportPulseOverviewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReportPulseOverviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
