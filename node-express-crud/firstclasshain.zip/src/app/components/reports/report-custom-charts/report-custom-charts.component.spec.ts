import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReportCustomChartsComponent } from './report-custom-charts.component';

describe('ReportCustomChartsComponent', () => {
  let component: ReportCustomChartsComponent;
  let fixture: ComponentFixture<ReportCustomChartsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReportCustomChartsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReportCustomChartsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
