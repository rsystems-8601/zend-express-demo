import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-report-custom-charts',
  templateUrl: './report-custom-charts.component.html',
  styleUrls: ['./report-custom-charts.component.scss']
})
export class ReportCustomChartsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
