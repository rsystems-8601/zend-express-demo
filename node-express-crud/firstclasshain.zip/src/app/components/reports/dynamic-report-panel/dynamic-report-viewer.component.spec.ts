import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DynamicReportViewerComponent } from './dynamic-report-viewer.component';

describe('DynamicReportViewerComponent', () => {
  let component: DynamicReportViewerComponent;
  let fixture: ComponentFixture<DynamicReportViewerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DynamicReportViewerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DynamicReportViewerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
