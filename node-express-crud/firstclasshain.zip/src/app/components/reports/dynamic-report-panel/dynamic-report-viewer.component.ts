import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SharedDataService } from 'src/app/services/shared-data.service';
import { CommonService } from 'src/app/services/common.service';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-dynamic-report-viewer',
  templateUrl: './dynamic-report-viewer.component.html',
  styleUrls: ['./dynamic-report-viewer.component.scss']
})
export class DynamicReportViewerComponent implements OnInit, OnDestroy {

  dynamicReportUrl: string;
  coacheeId: number;
  userDetails: any;
  callBackComplete: boolean;
  ToggleGoalButtonAngular = false;
  constructor(private sharedDataService: SharedDataService,
    private route: ActivatedRoute,
    private router: Router,
    private commonService: CommonService,
    private authService: AuthService
  ) { }

  ngOnInit() {
    window.addEventListener('message', this.handleIframeTask.bind(this), false);
    this.callBackComplete = false;
    this.route.params.subscribe(params => {
      if (params.reportname) {
        const reportUrl = this.sharedDataService.getData();
        if (reportUrl !== undefined) {
          this.dynamicReportUrl = reportUrl;
        } else {
          this.route.queryParams.subscribe(param => {
            // Defaults to 0 if no query param provided.
            const encodedUrl = param['encodedUrl'];
            if (encodedUrl !== undefined) {
              this.dynamicReportUrl = decodeURI(encodedUrl);
            } else {
              this.router.navigate(['/iCoachFirst/dashboard']);
            }
          });
        }
      }
    });
  }

  closePopupOnIframe() {
    this.commonService.closePopupOnIframe();
  }

  handleIframeTask(e) {
    window.removeEventListener('message', () => { });
    // Member variable this.callBackComplete will be false if user refreshes the url
    // and it will be true if user open this same component again and again
    // so added the check using variable
    if (!this.callBackComplete) {
      if (e.data.coachingParams !== undefined && e.data.coachingParams === 'coachingconversation') {
        this.commonService.setBubbleValue(false, e.data.selectedRepId);
      }

      if (e.data.redirectTo === undefined && e.data.lockAngularScreen === undefined) {
        this.ToggleGoalButtonAngular = false;
        // the redirectTo will be undefined if user directly refreshes the url
        // added because this func is getting fired first if user refreshes url directly.
        return;
      }

      if (e.data.redirectTo && e.data.redirectTo === 'logout') {
        this.authService.commonLogout();
      }

      if (e.data.redirectTo) {
        this.callBackComplete = true;
        let redirect = this.sharedDataService.getRedirectionValue();

        if (redirect !== undefined) {
          redirect = decodeURIComponent(redirect);
          this.router.navigate([`/${redirect}`]);
        } else {
          // If userdirectly refreshes the url the redirect value will will be undefined.
          this.router.navigate(['/iCoachFirst/dashboard']);
        }
        // this.route.queryParams.subscribe(param => {
        //   const encodedUrl = param['encodedUrl'];
        //   if (encodedUrl !== undefined) {
        //     const redirect = decodeURIComponent(decodeURI(encodedUrl).split('ICF6redirectTo=')[1]);
        //     this.router.navigate([`/${redirect}`]);
        //   } else {
        //     this.router.navigate(['/iCoachFirst/dashboard']);
        //   }
        // });
      } else if (e.data.lockAngularScreen !== undefined) {
        this.ToggleGoalButtonAngular = e.data.lockAngularScreen;
      }


    }
  }

  ngOnDestroy() {
    this.callBackComplete = true;
    window.removeEventListener('message', () => { });
  }
}
