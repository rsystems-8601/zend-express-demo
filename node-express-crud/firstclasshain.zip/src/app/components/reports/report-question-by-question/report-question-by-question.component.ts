import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-report-question-by-question',
  templateUrl: './report-question-by-question.component.html',
  styleUrls: ['./report-question-by-question.component.scss']
})
export class ReportQuestionByQuestionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
