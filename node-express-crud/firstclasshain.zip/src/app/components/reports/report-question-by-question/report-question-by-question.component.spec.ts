import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReportQuestionByQuestionComponent } from './report-question-by-question.component';

describe('ReportQuestionByQuestionComponent', () => {
  let component: ReportQuestionByQuestionComponent;
  let fixture: ComponentFixture<ReportQuestionByQuestionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReportQuestionByQuestionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReportQuestionByQuestionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
