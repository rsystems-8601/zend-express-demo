import { Component, OnInit, OnDestroy } from '@angular/core';
import { SharedDataService } from 'src/app/services/shared-data.service';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonService } from 'src/app/services/common.service';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-dashboard-report-viewer',
  templateUrl: './dashboard-report-viewer.component.html',
  styleUrls: ['./dashboard-report-viewer.component.scss']
})
export class DashboardReportViewerComponent implements OnInit, OnDestroy {

  dashboardReportUrl: string;
  dashboardReportName: string;
  callBackComplete: any;

  constructor(
    private sharedDataService: SharedDataService,
    private route: ActivatedRoute,
    private commonService: CommonService,
    private router: Router,
    private authService: AuthService
  ) { }

  ngOnInit() {
    this.route.params.subscribe(params => {
      if (params.reportname) {
        const reportUrl = this.sharedDataService.getData();
        if (reportUrl !== undefined) {
          this.dashboardReportUrl = reportUrl;
          this.dashboardReportName = params.reportname.trim();
        } else {
          this.route.queryParams.subscribe(param => {
            // Defaults to 0 if no query param provided.
            const encodedUrl = param['encodedUrl'];
            if (encodedUrl !== undefined) {
              this.dashboardReportUrl = decodeURI(encodedUrl);
              this.dashboardReportName = params.reportname.trim();
            } else {
              this.router.navigate(['/iCoachFirst/dashboard']);
            }
           });
        }
      }
    });
  }

  closePopupOnIframe() {
    this.commonService.closePopupOnIframe();
  }

  handleIframeTask(e) {
    window.removeEventListener('message', () => { });
    // Member variable this.callBackComplete will be false if user refreshes the url
    // and it will be true if user open this same component again and again
    // so added the check using variable
    if (!this.callBackComplete) {
      if (e.data.redirectTo === undefined && e.data.lockAngularScreen === undefined) {
        // the redirectTo will be undefined if user directly refreshes the url
        // added because this func is getting fired first if user refreshes url directly.
        return;
      }
      if (e.data.redirectTo && e.data.redirectTo === 'logout') {
        this.authService.commonLogout();
      }

      if (e.data.redirectTo === 'dashboard') {
        this.callBackComplete = true;
        let redirect = this.sharedDataService.getRedirectionValue();
        if (redirect !== undefined) {
          redirect = decodeURIComponent(redirect);
          this.router.navigate([`/${redirect}`]);
        } else {
          // If userdirectly refreshes the url the redirect value will will be undefined.
          this.router.navigate(['/iCoachFirst/dashboard']);
        }
      }
    }
  }

  ngOnDestroy() {
    this.callBackComplete = true;
    window.removeEventListener('message', () => { });
  }
}
