import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-report-trends',
  templateUrl: './report-trends.component.html',
  styleUrls: ['./report-trends.component.scss']
})
export class ReportTrendsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
