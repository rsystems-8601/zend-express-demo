import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReportIndividualPageComponent } from './report-individual-page.component';

describe('ReportIndividualPageComponent', () => {
  let component: ReportIndividualPageComponent;
  let fixture: ComponentFixture<ReportIndividualPageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReportIndividualPageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReportIndividualPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
