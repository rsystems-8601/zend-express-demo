import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-report-individual-page',
  templateUrl: './report-individual-page.component.html',
  styleUrls: ['./report-individual-page.component.scss']
})
export class ReportIndividualPageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
