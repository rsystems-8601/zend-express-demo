import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-report-percentile-charts',
  templateUrl: './report-percentile-charts.component.html',
  styleUrls: ['./report-percentile-charts.component.scss']
})
export class ReportPercentileChartsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
