import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReportPercentileChartsComponent } from './report-percentile-charts.component';

describe('ReportPercentileChartsComponent', () => {
  let component: ReportPercentileChartsComponent;
  let fixture: ComponentFixture<ReportPercentileChartsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReportPercentileChartsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReportPercentileChartsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
