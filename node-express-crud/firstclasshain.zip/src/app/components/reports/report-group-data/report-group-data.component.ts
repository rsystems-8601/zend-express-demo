import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-report-group-data',
  templateUrl: './report-group-data.component.html',
  styleUrls: ['./report-group-data.component.scss']
})
export class ReportGroupDataComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
