import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReportGroupDataComponent } from './report-group-data.component';

describe('ReportGroupDataComponent', () => {
  let component: ReportGroupDataComponent;
  let fixture: ComponentFixture<ReportGroupDataComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReportGroupDataComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReportGroupDataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
