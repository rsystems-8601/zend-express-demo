import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-report-driver-overview',
  templateUrl: './report-driver-overview.component.html',
  styleUrls: ['./report-driver-overview.component.scss']
})
export class ReportDriverOverviewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
