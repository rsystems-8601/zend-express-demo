import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReportDriverOverviewComponent } from './report-driver-overview.component';

describe('ReportDriverOverviewComponent', () => {
  let component: ReportDriverOverviewComponent;
  let fixture: ComponentFixture<ReportDriverOverviewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReportDriverOverviewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReportDriverOverviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
