import { Component, OnDestroy } from '@angular/core';
import { GroupBaseComponent } from '../group-base/group-base.component';
import { ConnectMessageService } from 'src/app/services/connect-message.service';
import { EventEmiterService } from 'src/app/services/event.emmiter.service';
import { MatDialog, MatDialogConfig, MatSlideToggleChange } from '@angular/material';
import { ConfirmationDialogService } from '../../shared/confirmation-dialog/confirmation-dialog.service';
import { ManageGroupMembersRequest } from 'src/app/models/requests/create-group-request';
import { UserService } from 'src/app/services/user.service';
import { ConnectapiService } from 'src/app/services/connectapi.service';
import { IcftoasterService } from 'src/app/services/icftoaster.service';
import { User } from 'src/app/models/response/user-response';
import { IUserProfileUrlRequest } from 'src/app/models/requests/url-builder/user-profile-url-request';
import { LocalizationService } from 'src/app/services/localization.service';
import { UserProfileService } from 'src/app/services/user-profile.service';
import { IframeModalComponent } from '../../shared/iframe-modal/iframe-modal.component';
import { UserPermissions } from 'src/app/helpers/enums/common-enums';
import { Router } from '@angular/router';

@Component({
  selector: 'app-connect-people',
  templateUrl: './connect-people.component.html',
  styleUrls: ['./connect-people.component.scss']
})
export class ConnectPeopleComponent extends GroupBaseComponent implements OnDestroy {

  hasAdminRights = false;
  groupId: number;
  UserPermissions = UserPermissions;
  constructor(connectMessageService: ConnectMessageService,
    _eventEmiter: EventEmiterService,
    private dialog: MatDialog,
    private confirmationDialogService: ConfirmationDialogService,
    private userService: UserService,
    private connectapiService: ConnectapiService,
    private toast: IcftoasterService,
    private localizationService: LocalizationService,
    private profileService: UserProfileService,
    router: Router,
  ) {
    super(connectMessageService, _eventEmiter, router);

    this.checkAdminRights();
    this.subscribeEvents();
  }

  private checkAdminRights() {
    const loginUserId = this.userService.getUserDetails().UserDetails.EmpId;
    this.hasAdminRights = this.connectMessageService.hasAdminRights(loginUserId);
  }
  subscribeEvents() {

    this.subscription = this._eventEmiter.subscribe(newGroupEvent => {

      if (newGroupEvent.actionType === 'newgroupselected') {
        if (this.connectMessageService.selectedGroup !== undefined) {
          this.checkAdminRights();
        }
      }
    });
  }
  peoples() {

    if (this.connectMessageService.selectedGroup !== undefined) {
      this.groupId = this.connectMessageService.selectedGroup.GroupId;
      return this.connectMessageService.selectedGroup.LstMember;
    } else {
      return [];
    }
  }

  onDeleteClick(people) {
    this.confirmationDialogService.confirm('Common_Confirm_MemberDelete',
      'Common_Yes',
      'Common_No').subscribe(value => {

        if (value) {
          this.deleteGroupMember(people);
        }
      });
  }

  private getManageGroupMemberRequest(people: User) {
    const request = new ManageGroupMembersRequest();
    const userDetails = this.userService.getUserDetails().UserDetails;

    request.EmpId = userDetails.EmpId;
    request.GroupId = this.connectMessageService.selectedGroup.GroupId;
    request.GroupMembersJSON = [];

    request.GroupMembersJSON.push({
      MemberId: people.EmpId
    });

    return request;
  }
  private deleteGroupMember(people) {

    const request = this.getManageGroupMemberRequest(people);

    this.connectapiService.RemoveGroupMembers(request).subscribe(response => {

      this.connectMessageService.selectedGroup.LstMember = this.connectMessageService.selectedGroup.LstMember.filter(
        element => element.EmpId !== people.EmpId);

      if (response === true) {
        // this._eventEmiter.emit({ actionType: 'reloadGroups' });

        this.toast.success('Group member removed successfully');
        this.connectMessageService.sendGroupchangesNotificationToMembers(this.connectMessageService.selectedGroup.LstMember);

      } else {
        this.toast.error('Remove member request failed');
      }
    });
  }

  adminToggle(event: MatSlideToggleChange, people: User) {

    const request = this.getManageGroupMemberRequest(people);

    if (event.checked) {

      this.connectapiService.makeGroupAdmin(request).subscribe(response => {

        if (response === true) {
          this.toast.success('Admin rights updated for the user');
          this.connectMessageService.sendGroupchangesNotificationToMembers(this.connectMessageService.selectedGroup.LstMember);
          // this._eventEmiter.emit({ actionType: 'reloadGroups' });

        } else {
          this.toast.error('Request Failed');
        }
      });
    } else {
      this.connectapiService.removeGroupAdmin(request).subscribe(response => {

        if (response === true) {
          this.toast.success('Admin rights updated for the user');
          this.connectMessageService.sendGroupchangesNotificationToMembers(this.connectMessageService.selectedGroup.LstMember);
          // this._eventEmiter.emit({ actionType: 'reloadGroups' });

        } else {
          this.toast.error('Request Failed');
        }
      });
    }
  }

  isOwner(people) {
    if (this.connectMessageService.selectedGroup !== undefined) {
      return people.EmpId === this.connectMessageService.selectedGroup.CreatedById;
    } else {
      return false;
    }
  }

  isRegularMember(people) {
    if (this.connectMessageService.selectedGroup !== undefined) {
      return people.EmpId !== this.connectMessageService.selectedGroup.CreatedById;
    } else {
      return false;
    }
  }

  openProfileMatPop(people) {
    const request = {} as IUserProfileUrlRequest;
    request.EmpId = people.EmpId;
    request.EmpName = people.Name;
    const userDetails = this.userService.getUserDetails().UserDetails;

    request.MemberOrgID = userDetails.MemberOrgID;
    request.Source = 'icf6';
    request.PagePath = 'MyProfile';
    request.Culture = this.localizationService.getICF6CultreFromLocalStorage().CultureCode;
    const dialogConfig = new MatDialogConfig();
    dialogConfig.width = 900 + 'px';
    dialogConfig.disableClose = true;
    request.eid = userDetails.EmployeeId;
    const reportUrl = this.profileService.getUserProfilePageUrl(request);
    dialogConfig.data = { url: reportUrl };
    this.dialog.open(IframeModalComponent, dialogConfig);
  }

  ngOnDestroy() {
    this._eventEmiter.unsubscribe(this.subscription);
  }
}
