import { Component, OnInit, OnDestroy } from '@angular/core';
import { ConnectMessageService } from 'src/app/services/connect-message.service';
import { EventEmiterService } from 'src/app/services/event.emmiter.service';
import { Subscription } from 'rxjs';
import { Router } from '@angular/router';


@Component({
  selector: 'app-group-base',
  templateUrl: './group-base.component.html',
  styleUrls: ['./group-base.component.scss']
})
export class GroupBaseComponent implements OnInit, OnDestroy {

  groupName = '';
  subscription: Subscription;

  constructor(
    protected connectMessageService: ConnectMessageService,
    protected _eventEmiter: EventEmiterService,
    protected router: Router, ) {
    if (this.connectMessageService.selectedGroup !== undefined) {
      this.groupName = this.connectMessageService.selectedGroup.GroupName;
    } else {
      this.router.navigate(['/iCoachFirst/dashboard']); // If browser is refreshed then redirect to dashboard
    }
  }

  ngOnInit() {
    this.subscribeEvents();
  }

  ngOnDestroy() {
    this._eventEmiter.unsubscribe(this.subscription);
  }

  groupUpdated() {
    // 'INFORMATION - Override Method in derived classes if on group update some changes are required.');
  }

  subscribeEvents() {

    this.subscription = this._eventEmiter.subscribe(newGroupEvent => {

      if (newGroupEvent.actionType === 'newgroupselected') {
        if (this.connectMessageService.selectedGroup !== undefined) {
          this.groupName = this.connectMessageService.selectedGroup.GroupName;
        }
        this.groupUpdated();
      } else if (newGroupEvent.actionType === 'updateGroups') {
        if (this.connectMessageService.selectedGroup !== undefined) {
          this.groupName = this.connectMessageService.selectedGroup.GroupName;
        }
        this.groupUpdated();
      }
    });
  }
}
