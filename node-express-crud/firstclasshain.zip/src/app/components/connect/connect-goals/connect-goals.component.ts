// import { Component, OnInit } from '@angular/core';

// @Component({
//   selector: 'app-connect-goals',
//   templateUrl: './connect-goals.component.html',
//   styleUrls: ['./connect-goals.component.scss']
// })
// export class ConnectGoalsComponent implements OnInit {

//   constructor() { }

//   ngOnInit() {
//   }

// }

import { Component, OnInit, OnChanges, SimpleChanges } from '@angular/core';


// Now init modules:
// HighchartsMore(Highcharts);
// HighchartsSolidGauge(Highcharts);


import { GoalRequest } from 'src/app/models/requests/goal-request';
import { Goal } from 'src/app/models/response/goal/goal-response';
import { UserDetails, GoalConfiguration, StatusImage, TypeImage } from 'src/app/models/user-details-result';
import { UserService } from 'src/app/services/user.service';
import { ActivatedRoute } from '@angular/router';
import { GoalResponseResolved } from 'src/app/models/response/goal/goal-response';
import { CreateGoalRequest } from 'src/app/models/requests/create-goal-request';
import { GoalsService } from 'src/app/services/goals.service';
import { IcftoasterService } from 'src/app/services/icftoaster.service';
import { DatePipe } from '@angular/common';
import { MatDialogConfig, MatDialog } from '@angular/material';
import * as Highcharts from 'highcharts';
import { TrackService } from 'src/app/services/track.service';
import { CreateGoalComponent } from 'src/app/components/goals/create-goal/create-goal.component';
import { PieChartRequest, SeriesData } from 'src/app/models/requests/highchart-request';
import { HighchartService } from 'src/app/services/highchart.service';
import { GoalCompletedColorCode, GoalCompletedColorRange, ChartType } from 'src/app/helpers/enums/common-enums';

@Component({
  selector: 'app-connect-goals',
  templateUrl: './connect-goals.component.html',
  styleUrls: ['./connect-goals.component.scss']
})

export class ConnectGoalsComponent implements OnInit, OnChanges {
  highcharts = Highcharts;
  pieChartConfig = {} as PieChartRequest;
  goalType = 'I';
  selectedRepId = 0;
  userInfo: UserDetails;
  goalConfiguration: GoalConfiguration;
  // @Input() goalsListContainer: Goal[];

  goalRequest = new CreateGoalRequest();
  goalsListChart: Goal[];
  weight: [];
  public chart: any;
  imagePath: string;
  errorMesaage: string;

  customLabelText: string;
  enableValue: boolean;
  goalLabelName: string;
  onOffValue: boolean;

  showGoalNameLabel = false;
  showGoalNameType = false;
  showGoalNameAction = false;
  showGoalNameImpact = false;
  showGoalNameWeight = false;
  showGoalNameDueDate = false;

  goalNameType: string;
  goalNameAction: string;
  goalNameImpact: string;
  goalNameWeight: string;
  goalNameDueDate: string;

  searchPanelVisible = false;
  goalStatuses: StatusImage[] = [];
  goalTypes: TypeImage[] = [];
  searchString: string;
  isSearchApply = false;
  filteredData: Goal[];

  slideOptions = {
    items: 4, dots: false, nav: true, responsive: {
      0: {
        items: 1
      },
      600: {
        items: 2
      },
      1000: {
        items: 3
      },
      1300: {
        items: 4
      }
    }
  };

  constructor(private trackService: TrackService,
    private userService: UserService,
    private route: ActivatedRoute, private goalService: GoalsService,
    private toast: IcftoasterService, private datePipe: DatePipe,
    private dialog: MatDialog,
    private highchartService: HighchartService) { }

  ngOnInit() {
    const resolvedGoals: GoalResponseResolved = this.route.snapshot.data['getGoals'];
    this.goalsListChart = resolvedGoals.goalResponse.TrackResult.MyGoals;
    this.filteredData = this.goalsListChart;
    this.setHighchartOptions(this.filteredData);
    this.errorMesaage = resolvedGoals.error;
    this.loadGoalData();
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes !== undefined) {
      this.filteredData = this.goalsListChart;
      this.setHighchartOptions(this.filteredData);
      this.loadGoalData();
    }
  }

  private loadGoalData() {
    this.weight = Array.apply(null, { length: 101 }).map(Number.call, Number);
    this.goalConfiguration = this.userService.getUserDetails().GoalConfiguration;

    for (let i = 0; i < this.goalConfiguration.Labels.length; i++) {
      this.goalLabelName = this.goalConfiguration.Labels[i].GoalLabelName;
      this.customLabelText = this.goalConfiguration.Labels[i].CustomLabelText;
      this.enableValue = this.goalConfiguration.Labels[i].EnableValue;
      this.onOffValue = this.goalConfiguration.Labels[i].OnOffValue;

      switch (this.goalLabelName.toLowerCase()) {
        case 'title':
          this.showGoalNameLabel = this.onOffValue; // Show Goal Title.
          break;
        case 'type':
          this.showGoalNameType = this.onOffValue; // Show Goal Type.
          this.goalNameType = this.enableValue ? this.customLabelText : this.goalLabelName; // Show Custom Label Text.
          break;
        case 'action':
          this.showGoalNameAction = this.onOffValue; // Show Goal Action.
          this.goalNameAction = this.enableValue ? this.customLabelText : this.goalLabelName; // Show Custom Label Text.
          break;
        case 'impact':
          this.showGoalNameImpact = this.onOffValue; // Show Goal Impact.
          this.goalNameImpact = this.enableValue ? this.customLabelText : this.goalLabelName; // Show Custom Label Text.
          break;
        case 'weight':
          this.showGoalNameWeight = this.onOffValue; // Show Goal Weight.
          this.goalNameWeight = this.enableValue ? this.customLabelText : this.goalLabelName; // Show Custom Label Text.
          break;
        case 'due date':
          this.showGoalNameDueDate = this.onOffValue; // Show Goal Due Date.
          this.goalNameDueDate = this.enableValue ? this.customLabelText : this.goalLabelName; // Show Custom Label Text.
          break;
      }
    }

    if (this.goalConfiguration.TypeImages.length > 0) {
      for (let i = 0; i < this.goalConfiguration.TypeImages.length; i++) {
        if (this.goalConfiguration.TypeImages[i].OnOffValue) {
          this.goalTypes.push(this.goalConfiguration.TypeImages[i]);
        }
      }
    }

    if (this.goalConfiguration.StatusImages.length > 0) {
      for (let i = 0; i < this.goalConfiguration.StatusImages.length; i++) {
        if (this.goalConfiguration.StatusImages[i].OnOffValue) {
          this.goalStatuses.push(this.goalConfiguration.StatusImages[i]);
        }
      }
    }

    if (this.goalConfiguration.ImagePreference !== 'Default') {
      // if (this.goalConfiguration.ImagePreference === 'Goal Type') {
      //   for (let i = 0; i < this.goalConfiguration.TypeImages.length; i++) {
      //     if()
      //   }
      // } else if (this.goalConfiguration.ImagePreference === 'Goal Status') {
      //   for (let i = 0; i < this.goalConfiguration.StatusImages.length; i++) {
      //   }
      // } else
      if (this.goalConfiguration.ImagePreference === 'Standard') {
        this.imagePath = this.goalConfiguration.StandardImages[0]['imagePath'];
      }
    }
    // for (let i = 0; i < this.goalsListChart.length; i++) {
    // tslint:disable-next-line:max-line-length
    //   this.initChart(this.buildGauge(), +this.goalsListChart[i].GoalId, +this.goalsListChart[i].GoalPercentageComplete, this.goalsListChart[i].GoalTitle);
    // }
  }

  openCreateGoalPopUp() {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.data = { selectedRepId: this.selectedRepId, goalType: this.goalType };
    dialogConfig.width = '600px';
    dialogConfig.disableClose = true;
    const dialogRef = this.dialog.open(CreateGoalComponent, dialogConfig);

    dialogRef.afterClosed().subscribe(value => {

      if (value === 'success') {

        this.userInfo = this.userService.getUserDetails().UserDetails;
        const request = new GoalRequest();
        request.EmpId = this.userInfo.EmpId;
        request.Type = 'Goal';
        // Adding below StatusFilter in request to load all the Goals (i.e. Completed as well)
        const status = this.userService.getUserDetails().GoalConfiguration.StatusImages;
        const statusFilter = [];
        status.forEach(objStatus => {
          if (objStatus.OnOffValue) {
            statusFilter.push(objStatus.statusTitle);
          }
        });
        request.Statusfilter = statusFilter.join(',');

        this.trackService.getGoals(request).subscribe(
          goals => {
            this.goalsListChart = goals.TrackResult.MyGoals;
            this.filteredData = this.goalsListChart;
            this.setHighchartOptions(this.filteredData);
            this.loadGoalData();
          },
          errors => this.errorMesaage = <any>errors
        );
      }
    });
  }

  statusUpdate(statusObject: any, goalInfo: Goal) {
    this.goalRequest.GoalConfigStatus = statusObject.statusTitle;
    goalInfo.GoalConfigStatus = statusObject.statusTitle;

    this.goalRequest.GoalConfigType = goalInfo.GoalConfigType;
    this.goalRequest.DueDate = goalInfo.CompletionDate;
    this.goalRequest.Weight = goalInfo.GoalWeight;

    this.UpdateGoal(goalInfo);
  }

  weightUpdate(weight: any, goalInfo: Goal) {
    this.goalRequest.Weight = weight;
    goalInfo.GoalWeight = weight;

    this.goalRequest.GoalConfigType = goalInfo.GoalConfigType;
    this.goalRequest.DueDate = goalInfo.CompletionDate;
    this.goalRequest.GoalConfigStatus = goalInfo.GoalConfigStatus;

    this.UpdateGoal(goalInfo);
  }

  typeUpdate(typeObject: any, goalInfo: Goal) {
    this.goalRequest.GoalConfigType = typeObject.typeTitle;
    goalInfo.GoalConfigType = typeObject.typeTitle;

    this.goalRequest.GoalConfigStatus = goalInfo.GoalConfigStatus;
    this.goalRequest.DueDate = goalInfo.CompletionDate;
    this.goalRequest.Weight = goalInfo.GoalWeight;

    this.UpdateGoal(goalInfo);
  }

  dateUpdate(dueDate: any, goalInfo: Goal) {
    if (dueDate.isOpen) {

      this.goalRequest.DueDate = dueDate._bsValue;
      goalInfo.CompletionDate = this.datePipe.transform(dueDate._bsValue, 'MM/dd/yyyy');

      this.goalRequest.GoalConfigType = goalInfo.GoalConfigType;
      this.goalRequest.GoalConfigStatus = goalInfo.GoalConfigStatus;
      this.goalRequest.Weight = goalInfo.GoalWeight;

      this.UpdateGoal(goalInfo);
    }
  }

  UpdateGoal(goalInfo: Goal) {
    this.goalRequest.GoalId = goalInfo.GoalId;
    this.goalRequest.GoalTitle = goalInfo.GoalTitle;
    this.goalRequest.Action = goalInfo.GoalDescription;
    if (goalInfo.Impact == null) {
      this.goalRequest.Impact = '';
    } else {
      this.goalRequest.Impact = goalInfo.Impact;
    }
    this.goalRequest.IsPublished = goalInfo.IsPublished;
    this.goalRequest.GoalType = goalInfo.GoalType;
    this.goalRequest.CreatedBy = this.userService.getUserDetails().UserDetails.EmpId;

    this.goalService.updateGoal(this.goalRequest).subscribe(response => {

      const updateGoalResult = response.SaveNewGoalResult;
      if (updateGoalResult.ResultStatusCode === '1040') {
        this.toast.success('Common_UpdatedSuccessfully', '', () => { });

      } else {

        const errorMessage = updateGoalResult.ErrorMessage;
        this.toast.error(errorMessage);
      }
    });
  }

  showSearchPanel() {
    this.searchPanelVisible = !this.searchPanelVisible;
  }

  onSearchClicked() {

    let searchData: any[] = [];
    let isSelectedStatus = false;
    this.goalStatuses.forEach(objStatus => {
      if (objStatus.IsSelected) {
        isSelectedStatus = true;
        searchData = searchData.concat(this.filterTask(objStatus.statusTitle));
      }
    });

    if (!isSelectedStatus) {
      searchData = searchData.concat(this.filterTask(undefined));
    }

    this.filteredData = searchData;
    this.isSearchApply = true;
    this.searchPanelVisible = false;
  }

  filterTask(status) {

    if (status !== undefined) {

      if (this.searchString !== undefined) {
        const filterData = this.goalsListChart.filter(
          objActData => (objActData.GoalConfigStatus === status
            && objActData.GoalTitle.toLowerCase().includes(this.searchString.toLowerCase())));
        return filterData;
      }
      // tslint:disable-next-line: one-line
      else {
        const filterData = this.goalsListChart.filter(
          objActData => objActData.GoalConfigStatus === status);
        return filterData;
      }
    }
    // tslint:disable-next-line: one-line
    else if (this.searchString.length > 0) {
      const filterData = this.goalsListChart.filter(
        objActData => objActData.GoalTitle.toLowerCase().includes(this.searchString.toLowerCase()));
      return filterData;
    }
  }

  onClearSearch() {
    this.searchString = '';
    this.isSearchApply = false;
    this.searchPanelVisible = false;
    this.filteredData = this.goalsListChart;
    this.resetStatus();
  }

  private resetStatus() {

    this.goalStatuses.forEach(objStatus => {
      objStatus.IsSelected = false;
    });
  }

  setHighchartOptions(goal: Goal[]) {
    if (goal && goal.length > 0) {
      goal.forEach(item => {

        let percentageRemaining = 0;
        let percentageCompleted = 0;
        let colorCode = '';

        if (item.GoalPercentageComplete) {
          percentageCompleted = Math.round(+item.GoalPercentageComplete);
          percentageRemaining = 100 - percentageCompleted;

          if (percentageCompleted <= GoalCompletedColorRange.Low) {
            colorCode = GoalCompletedColorCode.Low;
          } else if (percentageCompleted <= GoalCompletedColorRange.Medium) {
            colorCode = GoalCompletedColorCode.Medium;
          } else if (percentageCompleted > GoalCompletedColorRange.Medium) {
            colorCode = GoalCompletedColorCode.High;
          }
        }
        // Pie chart option setting
        this.pieChartConfig.ChartType = ChartType.Pie;
        this.pieChartConfig.ChartSize = '75';
        this.pieChartConfig.ChartTitle = '<style="font-family:arial; font-size:16px;">' + percentageCompleted + '%</style>';
        this.pieChartConfig.TitleYAxis = 7;
        this.pieChartConfig.TooltipFormatterCallbackFun = this.tooltipFormatter;
        this.pieChartConfig.SeriesName = 'Goal';
        this.pieChartConfig.SeriesInnerSize = '70%';
        this.pieChartConfig.DataLabelsDistance = -40;
        this.pieChartConfig.SeriesData = [];

        // Completed Goal Data
        const serDataCompletedPercentage = {} as SeriesData;
        serDataCompletedPercentage.Name = percentageCompleted;
        serDataCompletedPercentage.YAxis = percentageCompleted;
        serDataCompletedPercentage.EnableDataLabel = false;
        serDataCompletedPercentage.Color = colorCode;
        this.pieChartConfig.SeriesData.push(serDataCompletedPercentage);

        // Remaining Goal Data
        const serDataRemainingPercentage = {} as SeriesData;
        serDataRemainingPercentage.Name = percentageRemaining;
        serDataRemainingPercentage.YAxis = percentageRemaining;
        serDataRemainingPercentage.EnableDataLabel = false;
        serDataRemainingPercentage.Color = GoalCompletedColorCode.None,
          this.pieChartConfig.SeriesData.push(serDataRemainingPercentage);

        item.HighchartOptions = this.highchartService.CreateHighChart(this.pieChartConfig);
      });
    }
  }

  tooltipFormatter(_seriesType: any, _seriesName: any, _yAxis: number, _color: string) {
    if (_color === GoalCompletedColorCode.None) {
      return 'Remaining:' + _yAxis + '%';
    } else {
      return 'Completed:' + _yAxis + '%';
    }


  }

}
