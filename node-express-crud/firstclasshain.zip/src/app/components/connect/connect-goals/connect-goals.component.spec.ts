import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConnectGoalsComponent } from './connect-goals.component';

describe('ConnectGoalsComponent', () => {
  let component: ConnectGoalsComponent;
  let fixture: ComponentFixture<ConnectGoalsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConnectGoalsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConnectGoalsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
