import { Component, OnInit, OnDestroy, Inject } from '@angular/core';
import { UserService } from 'src/app/services/user.service';
import { EventEmiterService } from 'src/app/services/event.emmiter.service';
import { IcftoasterService } from 'src/app/services/icftoaster.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { Subscription } from 'rxjs';
import { UserDetails } from 'src/app/models/user-details-result';
import { CreateGroupRequest } from 'src/app/models/requests/create-group-request';
import { ConnectapiService } from 'src/app/services/connectapi.service';
import { ConnectMessageService } from 'src/app/services/connect-message.service';
import { IGroup } from '../connect-interfaces';
import { UserPermissions } from '../../../helpers/enums/common-enums';

@Component({
  selector: 'app-create-group',
  templateUrl: './create-group.component.html',
  styleUrls: ['./create-group.component.scss']
})

export class CreateGroupComponent implements OnInit, OnDestroy {

  callingSource = 'Task';
  groupMembers = [];
  selectedMember: any;
  submitted = false;
  userDetails: UserDetails;

  form: FormGroup;

  group: IGroup;
  groupId = 0;
  private subscription: Subscription;

  componentTitle: string;
  UserPermissions = UserPermissions;

  constructor(
    private formBuilder: FormBuilder,
    private userService: UserService,
    private _eventEmiter: EventEmiterService,
    private toast: IcftoasterService,
    private connectMessageService: ConnectMessageService,
    private connectapiService: ConnectapiService,
    private dialogRef: MatDialogRef<CreateGroupComponent>,
    @Inject(MAT_DIALOG_DATA) private data
  ) {

    this.userDetails = this.userService.getUserDetails().UserDetails;
    this.groupMembers.push({
      EmpId: this.userDetails.EmpId,
      ProfileImageURL: this.userDetails.ProfileImageName,
      Name: this.userDetails.Name,
      EmailId: this.userDetails.EmailId
    });
  }

  ngOnInit() {

    this.subscribeEvents();
    this.setupFormControls();
    if (this.data !== null) { // Updater Group case
      this.group = this.data.group;
      this.f.GroupName.setValue(this.group.GroupName);
      this.groupMembers = Object.assign([], this.group.LstMember);
      this.groupId = this.group.GroupId;
      this.componentTitle = 'Manage Team';
    } else {
      this.componentTitle = 'Create a New Team';
    }

  }

  ngOnDestroy() {
    this._eventEmiter.unsubscribe(this.subscription);
  }

  private setupFormControls() {
    this.form = this.formBuilder.group({
      GroupName: ['', Validators.required],
    });
  }

  subscribeEvents() {

    this.subscription = this._eventEmiter.subscribe(event => {

      if (event.keyName === 'AddObserver') {
        this.selectedMember = event.observerData;
      }
    });
  }

  onClickAddButton() {

    if (this.selectedMember !== undefined) {

      if (this.isMemberExist()) {
        this.toast.error('GoalStats_Error_EmployeeAlreadAdded', '');
        return;
      }

      this.groupMembers.push({
        EmpId: this.selectedMember.EmpID,
        ProfileImageURL: this.selectedMember.ProfileImageName,
        Name: this.selectedMember.FirstName + ' ' + this.selectedMember.LastName,
        EmailId: this.selectedMember.EmailID
      }
      );
      this.selectedMember = null;
      this._eventEmiter.emit({ keyName: 'resetAutoComplete' });
    }
  }

  removeMember(member) {
    this.groupMembers = this.groupMembers.filter(
      element => element.EmpId !== member.EmpId);
  }

  isMemberExist() {

    const filterData = this.groupMembers.filter(
      element => element.EmpId === this.selectedMember.EmpID);
    if (filterData.length > 0) {
      return true;
    }
    return false;
  }

  // convenience getter for easy access to form fields
  get f() {
    return this.form.controls;
  }

  onSubmit() {
    this.submitted = true;

    if (this.form.invalid) {
      return;
    }

    this.createGroup();

  }

  private createGroup() {
    const groupName = this.f.GroupName.value.trim();

    const groupRequest = new CreateGroupRequest();

    groupRequest.EmpId = this.userDetails.EmpId;
    if (this.group !== undefined) {
      groupRequest.GroupId = this.group.GroupId;
      groupRequest.ChannelName = this.group.ChannelName;

    } else {
      groupRequest.GroupId = 0; // For new group
      // ICF6-936 Adding timestamp to channnel name, so that new channel should always be created for custom groups
      groupRequest.ChannelName = groupName + '-' + this.userDetails.EmailId.trim() + '-group-channel-' + new Date().getTime();
    }
    groupRequest.GroupName = groupName;
    groupRequest.GroupMembersJSON = [];

    if (this.groupMembers.length < 2) {
      this.toast.error('Please add team members.');
      return;
    }
    this.groupMembers.forEach(member => {
      groupRequest.GroupMembersJSON.push({
        MemberId: member.EmpId
      });
    });

    const groups = this.connectMessageService.getAllGroups();
    // const filteredGroups = groups.filter(function (group) { return group.GroupName === groupName && group.GroupId !== this.group.GroupId; });
    if (groups && groups.length > 0) {
      const filteredGroups = groups.filter(group => group.GroupName === groupName && group.GroupId !== this.groupId);
      if (filteredGroups.length > 0) {
        this.toast.error('Connect_Group_Already_Exist');
        return;
      }
    }

    this.connectapiService.createGroup(groupRequest).subscribe(response => {

      if (response.ErrorMessage.length > 0) {
        this.toast.error(response.ErrorMessage);
      } else if (response.GroupId !== undefined) {

        this.connectMessageService.sendGroupchangesNotificationToMembers(this.groupMembers);

        if (this.group === undefined) { // Create Group Case
          /*
          this.toast.success('Team created successfully', '', () => {
            this.dialogRef.close('success');
          });
          */
          this.toast.success('Team created successfully', '');
          this.dialogRef.close('success');
        } else { // update group case
          // this._eventEmiter.emit({ actionType: 'reloadGroups' });

          this.group.GroupName = groupName;
          this.group.LstMember = this.groupMembers;
          this.connectMessageService.setSelectedTeam(this.group);
          /*
          this.toast.success('Team updated successfully', '', () => {
            this.dialogRef.close('success');
          });
          */
          this.toast.success('Team updated successfully', '');
          this.dialogRef.close('success');
        }
      } else {
        this.toast.error('Request failed');
      }
    });
  }

  cancelClick() {
    this.dialogRef.close();
  }
}
