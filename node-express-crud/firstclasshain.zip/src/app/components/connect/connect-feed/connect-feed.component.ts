import { Component, OnInit, EventEmitter, Output, OnDestroy } from '@angular/core';
import { ConnectMessageService } from 'src/app/services/connect-message.service';
import { ConnectapiService } from 'src/app/services/connectapi.service';
import { User } from 'src/app/models/response/user-response';
import { Router } from '@angular/router';
import { EventEmiterService } from 'src/app/services/event.emmiter.service';
import { UserService } from 'src/app/services/user.service';
import { Notification, NotificationResponse, NotificationFilterRequest, NotificationFilter } from 'src/app/models/response/connect-response';
import { NotificationItemType, AssignorType, LoggedinEmpType, ModalPopupSizeEnum } from 'src/app/helpers/enums/common-enums';
import { TranslatePipe } from 'src/app/pipes/translate.pipe';
import { QuickFeedbackDetailsComponent } from 'src/app/components/quick-feedback/quick-feedback-details/quick-feedback-details.component';
import { MatDialog, MatDialogConfig } from '@angular/material';
import { ActService } from 'src/app/services/act.service';
import { ActResponse, Act } from 'src/app/models/response/act-response';
import { PageRequest } from 'src/app/models/requests/page-request';
import { ActRequest } from 'src/app/models/requests/act-request';
import { environment } from 'src/environments/environment';
import { CommonService } from 'src/app/services/common.service';
import { UserDetails } from 'src/app/models/user-details-result';
import { DynamicReportUrlRequest } from 'src/app/models/requests/url-builder/dynamic-report-url-request';
import { LocalizationService } from 'src/app/services/localization.service';
import { DynamicReportUrlBuilderService } from 'src/app/services/dynamic-report-url-builder.service';
import { SharedDataService } from 'src/app/services/shared-data.service';
import { IGroup } from '../connect-interfaces';
import { Subscription } from 'rxjs';
import { IcftoasterService } from 'src/app/services/icftoaster.service';
// import { IActBaseInterface } from 'src/app/models/act-base';

@Component({
  selector: 'app-connect-feed',
  templateUrl: './connect-feed.component.html',
  styleUrls: ['./connect-feed.component.scss']
})
export class ConnectFeedComponent implements OnInit, OnDestroy {

  applicationModuleId: number;
  realTimeChatEnabled = false;
  notificationMessages: Array<Notification>;
  notificationFilterReq = {} as NotificationFilterRequest;
  isShowFilterPopup = false;
  selectedObserver: any;
  calllingSource = 'Notification';
  responseData: Act[];
  feedbackData: any; // IActBaseInterface;
  userInfo: UserDetails;
  reportUrl: string;
  subscription: Subscription;
  @Output() setLeftContainerVisibility: EventEmitter<number> = new EventEmitter<number>();

  constructor(public connectMessageService: ConnectMessageService,
    private connectApiService: ConnectapiService,
    private router: Router,
    private _eventEmiter: EventEmiterService,
    private userService: UserService,
    private pipeTransform: TranslatePipe,
    private dialog: MatDialog,
    private actService: ActService,
    private commonService: CommonService,
    private localizationService: LocalizationService,
    private dynamicUrlBuilderService: DynamicReportUrlBuilderService,
    private sharedDataService: SharedDataService,
    private toast: IcftoasterService) { }

  ngOnInit() {
    this.notificationFilterReq.NotificationFilter = {} as NotificationFilter;
    // TODO this will be changed to latest message feed
    // this.groupIndex = 0;
    // this.messages = [];
    // this.getHistoricalMessages();
    this.notificationFilterReq.IsAPICallFromFilter = false;
    this.getAllNotificationDetails();
    const user = this.userService.getUserDetails();
    this.realTimeChatEnabled = user.RealTimeChatEnabled;
    this.subscription = this._eventEmiter.subscribe(data => {
      if (data.KeyName === 'loadNotifications') {
        this.notificationFilterReq.IsAPICallFromFilter = false;
        this.getAllNotificationDetails();
      }
    });
    this.subscription = this._eventEmiter.subscribe(observer => {
      if (observer.keyName === 'Notification') {
        this.selectedObserver = observer.observerData;
        this.addSearchedEmployeeToFilter();
      }
    });
  }

  ngOnDestroy(): void {
    this._eventEmiter.unsubscribe(this.subscription);
  }

  openMainComponentLeftContainer(appModuleId: number = 0) {
    this.setLeftContainerVisibility.emit(appModuleId);
  }

  getAllNotificationDetails() {
    this.connectApiService.getAllNotificationDetails(this.notificationFilterReq).subscribe((notifications: NotificationResponse) => {
      this.notificationMessages = notifications.Notifications;
      // Assigning one by one property, otherwise it'll override SearchEmpId/DateFrom/DateTo property of 'notificationFilterReq.NotificationFilter' object because api don't returns these properties
      this.notificationFilterReq.NotificationFilter.IsFeedbackSelected = notifications.NotificationFilters.IsFeedbackSelected;
      this.notificationFilterReq.NotificationFilter.IsFinalizedReportSelected = notifications.NotificationFilters.IsFinalizedReportSelected;
      this.notificationFilterReq.NotificationFilter.IsGoalSelected = notifications.NotificationFilters.IsGoalSelected;
      this.notificationFilterReq.NotificationFilter.IsTaskSelected = notifications.NotificationFilters.IsTaskSelected;
      this.notificationFilterReq.NotificationFilter.IsTeamChatSelected = notifications.NotificationFilters.IsTeamChatSelected;
      // this.notificationFilterReq.IsAPICallFromFilter = false;
      this.notificationMessages.forEach(item => {
        if (item.ItemType !== NotificationItemType.ConnectGroup) {
          this.setNotificationLocalizedMsg(this.getNotificationMsgKey(item), item);
        }
        // item.Comments = this.setComments(item);
      });

    });
  }
  getNotificationMsgKey(notificationDetails: Notification) {
    let notificationMsgKey: string;
    const messageId = notificationDetails.ItemType + '_' + notificationDetails.ActionType;
    // Manager to Emp: Message/Notification will be sent to employee only if changes made by real manager
    if (notificationDetails.AssignorType === AssignorType.Manager) {
      switch (messageId) {
        case 'Coaching Report_Finalized': {
          notificationMsgKey = 'Connect_MsgForEmpToMgrFinalizedRportForEmp';
          break;
        }
        case 'Feedback_Provide Quick Feedback': {
          notificationMsgKey = 'Connect_MsgForEmpToMgrProvidesFeedbackToEmp';
          break;
        }
        case 'Goal_Goal Created': {
          notificationMsgKey = 'Connect_MsgForEmpToMgrCreatesGoalForEmp';
          break;
        }
        case 'Goal_Goal Updated': {
          notificationMsgKey = 'Connect_MsgForEmpToMgrUpdatesGoalOfEmp';
          break;
        }
        case 'Task_Task Created': {
          notificationMsgKey = 'Connect_MsgForEmpToMgrCreatesTaskForEmp';
          break;
        }
        case 'Task_Task Updated': {
          notificationMsgKey = 'Connect_MsgForEmpToMgrUpdatesTaskOfEmp';
          break;
        }
        default: {
          notificationMsgKey = '';
          break;
        }
      }
    } else if (notificationDetails.AssignorType === AssignorType.Employee) { // Emp self: Message/Notification will be sent to real manager only if changes made by his/her team member(s)
      switch (messageId) {
        case 'Goal_Goal Created': {
          notificationMsgKey = 'Connect_MsgForMgrToEmpCreatesGoalForHimself';
          break;
        }
        case 'Goal_Goal Updated': {
          notificationMsgKey = 'Connect_MsgForMgrToEmpUpdatesOneOfHisGoals';
          break;
        }
        case 'Task_Task Created': {
          notificationMsgKey = 'Connect_MsgForMgrToEmpCreatesTaskForHimself';
          break;
        }
        case 'Task_Task Updated': {
          notificationMsgKey = 'Connect_MsgForMgrToEmpUpdatesOneOfHisTasks';
          break;
        }
        default: {
          notificationMsgKey = '';
          break;
        }
      }
    } else if (notificationDetails.AssignorType === AssignorType.OutOfHierarchy) { // Third party to Emp: Message/Notification will be sent to employee and it's real manager if changes made by outofhierarchy user
      if (notificationDetails.LoggedinEmpType === LoggedinEmpType.Manager) {
        switch (messageId) {
          case 'Coaching Report_Finalized': {
            notificationMsgKey = 'Connect_MsgForMgrToThirdPartyFinalizesReportForEmp';
            break;
          }
          case 'Feedback_Provide Quick Feedback': {
            notificationMsgKey = 'Connect_MsgForMgrToThirdPartyProvidesFeedbackToEmp';
            break;
          }
          case 'Goal_Goal Created': {
            notificationMsgKey = 'Connect_MsgForMgrToThirdPartyCreatesGoalForEmp';
            break;
          }
          case 'Goal_Goal Updated': {
            notificationMsgKey = 'Connect_MsgForMgrToThirdPartyUpdatesGoalOfEmp';
            break;
          }
          case 'Task_Task Created': {
            notificationMsgKey = 'Connect_MsgForMgrToThirdPartyCreatesTaskForEmp';
            break;
          }
          case 'Task_Task Updated': {
            notificationMsgKey = 'Connect_MsgForMgrToThirdPartyUpdatesTaskOfEmp';
            break;
          }
          default: {
            notificationMsgKey = '';
            break;
          }
        }
      } else if (notificationDetails.LoggedinEmpType === LoggedinEmpType.Employee) {
        switch (messageId) {
          case 'Coaching Report_Finalized': {
            notificationMsgKey = 'Connect_MsgForEmpToThirdPartyFinalizesReportForEmp';
            break;
          }
          case 'Feedback_Provide Quick Feedback': {
            notificationMsgKey = 'Connect_MsgForEmpToThirdPartyProvidesFeedbackToEmp';
            break;
          }
          case 'Goal_Goal Created': {
            notificationMsgKey = 'Connect_MsgForEmpToThirdPartyCreatesGoalForEmp';
            break;
          }
          case 'Goal_Goal Updated': {
            notificationMsgKey = 'Connect_MsgForEmpToThirdPartyUpdatesGoalOfEmp';
            break;
          }
          case 'Task_Task Created': {
            notificationMsgKey = 'Connect_MsgForEmpToThirdPartyCreatesTaskForEmp';
            break;
          }
          case 'Task_Task Updated': {
            notificationMsgKey = 'Connect_MsgForEmpToThirdPartyUpdatesTaskOfEmp';
            break;
          }
          default: {
            notificationMsgKey = '';
            break;
          }
        }
      }
    }
    return notificationMsgKey; // this.getNotificationLocalizedMsg(message, notificationDetails);
  }

  setNotificationLocalizedMsg(notificationMsgKey: string, notificationDetails: Notification) {
    let notificationLocalizedMsg: string;
    if (notificationMsgKey && notificationMsgKey.length > 0) {
      notificationLocalizedMsg = this.pipeTransform.transform(notificationMsgKey);
      // Comments: <<ItemName>>/<<AssigneeName>> placeholder might have ^^ characters so first splitting the message before replacing the value for placeholder in message.
      const notificationLocalizedMsgArr = notificationLocalizedMsg.split('^^');
      if (notificationLocalizedMsgArr.length === 3) {
        notificationDetails.MsgContentsBeforeLink = notificationLocalizedMsgArr[0].replace('<<ItemTitle>>', notificationDetails.ItemTitle).replace('<<AssigneeName>>', notificationDetails.AssigneeName);
        notificationDetails.MsgContentsForLink = notificationLocalizedMsgArr[1].replace('<<ItemTitle>>', notificationDetails.ItemTitle).replace('<<AssigneeName>>', notificationDetails.AssigneeName);
        notificationDetails.MsgContentsAfterLink = notificationLocalizedMsgArr[2].replace('<<ItemTitle>>', notificationDetails.ItemTitle).replace('<<AssigneeName>>', notificationDetails.AssigneeName);
      } else {
        notificationDetails.MsgContentsForLink = notificationLocalizedMsg.replace('<<ItemTitle>>', notificationDetails.ItemTitle).replace('<<AssigneeName>>', notificationDetails.AssigneeName);
      }
    }
  }

  viewAction(connectEventMsg: Notification) {
    if (connectEventMsg.AssignorType === AssignorType.Manager) {                   // If action taken by manager then link to be used by employee
      this.navigateToActPage(connectEventMsg);
    } else if (connectEventMsg.AssignorType === AssignorType.Employee) {           // If action taken by employee then link to be used by manager
      this.navigateToManagePage(connectEventMsg);
    } else if (connectEventMsg.AssignorType === AssignorType.OutOfHierarchy) {     // If action taken by outofhierarchy employee then link to be used by Manager/Employee depend on 'LoggedinEmpType' field
      if (connectEventMsg.LoggedinEmpType === LoggedinEmpType.Manager) {
        this.navigateToManagePage(connectEventMsg);
      } else if (connectEventMsg.LoggedinEmpType === LoggedinEmpType.Employee) {
        this.navigateToActPage(connectEventMsg);
      }
    }
  }

  navigateToActPage(connectEventMsg: Notification) {
    let routeUrl = '';
    if (connectEventMsg.ItemType === NotificationItemType.Goal || connectEventMsg.ItemType === NotificationItemType.Task) {
      if (connectEventMsg.ItemType === NotificationItemType.Goal) {
        routeUrl = '/iCoachFirst/dashboard/editGoal/' + connectEventMsg.ItemId;
      } else if (connectEventMsg.ItemType === NotificationItemType.Task) {
        routeUrl = '/iCoachFirst/dashboard/edit-task/' + connectEventMsg.ItemId;
      }
      this.commonService.setRedirectUrl(routeUrl);
      this.router.navigate([routeUrl]);
      this._eventEmiter.emit({ keyName: 'fromNotificationForAct', ItemType: connectEventMsg.ItemType });
      // this.router.navigate(['/iCoachFirst/dashboard/notifications', connectEventMsg.ItemType, connectEventMsg.ItemId]);
      // this.router.navigate(['/iCoachFirst/dashboard/edit-task', connectEventMsg.ItemId]);
    } else if (connectEventMsg.ItemType === NotificationItemType.Feedback) {
      this.getFeedbackData(connectEventMsg, false);
    } else if (connectEventMsg.ItemType === NotificationItemType.CoachingReport) {
      this.reportUrl = this.dynamicUrlBuilderService.draftedReportUrl(this.createUrlRequest(connectEventMsg));
      const queryParam = encodeURI(this.reportUrl);
      this.sharedDataService.setData(this.reportUrl);
      this.sharedDataService.setRedirectionValue(this.getRedirectionValueFromIframe());
      this.router.navigate(['/iCoachFirst/report/dynamicreport', connectEventMsg.ItemTitle], { queryParams: { encodedUrl: queryParam } });
    }
  }

  navigateToManagePage(connectEventMsg: Notification) {
    let routeUrl = '';
    if (connectEventMsg.ItemType === NotificationItemType.Goal || connectEventMsg.ItemType === NotificationItemType.Task) {
      if (connectEventMsg.ItemType === NotificationItemType.Goal) {
        routeUrl = '/iCoachFirst/manage/manage/' + connectEventMsg.AssigneeEmpId + '/editGoal/' + connectEventMsg.ItemId;
      } else if (connectEventMsg.ItemType === NotificationItemType.Task) {
        routeUrl = '/iCoachFirst/manage/manage/' + connectEventMsg.AssigneeEmpId + '/edit-task/' + connectEventMsg.ItemId;
      }
      this.commonService.setRedirectUrl(routeUrl);
      // this.router.navigate(['/iCoachFirst/dashboard/notifications', connectEventMsg.ItemType, connectEventMsg.ItemId]);
      this.router.navigate([routeUrl]);
      this._eventEmiter.emit({ keyName: 'fromNotificationForManage', ItemType: connectEventMsg.ItemType });
    } else if (connectEventMsg.ItemType === NotificationItemType.Feedback) {
      this.getFeedbackData(connectEventMsg, true);
    } else if (connectEventMsg.ItemType === NotificationItemType.CoachingReport) {
      this.reportUrl = this.dynamicUrlBuilderService.draftedReportUrl(this.createUrlRequest(connectEventMsg));
      const queryParam = encodeURI(this.reportUrl);
      this.sharedDataService.setData(this.reportUrl);
      this.sharedDataService.setRedirectionValue(this.getRedirectionValueFromIframe());
      this.router.navigate(['/iCoachFirst/report/dynamicreport', connectEventMsg.ItemTitle], { queryParams: { encodedUrl: queryParam } });
    }
  }
  getRedirectionValueFromIframe(): string {
    const url = window.location.href;
    return url.split(environment.iframeRedirectionHostName)[1];
  }

  createUrlRequest(reportItem: Notification): DynamicReportUrlRequest {
    const request = {} as DynamicReportUrlRequest;
    this.userInfo = this.userService.getUserDetails().UserDetails;
    request.EmpReportId = reportItem.ItemId;
    if (reportItem.IsDynamic) {
      if (reportItem.IsRepInitiated) {
        request.IsMgr = 'F';
         /*
        request.CoachId = reportItem.AssigneeEmployeeId;
        request.CoacheeId = reportItem.AssignorEmpId;
        request.CoachName = reportItem.AssigneeActualName;
        request.CoacheeName = reportItem.AssignorName;
        */
       request.CoachId = reportItem.AssignorEmpId;
       request.CoacheeId =  reportItem.AssigneeEmpId; // reportItem.AssigneeEmployeeId;
       request.CoachName = reportItem.AssignorName;
       request.CoacheeName = reportItem.AssigneeActualName;
      } else {
        if (reportItem.AssigneeEmpId === this.userInfo.EmpId) {
          request.IsMgr = 'F';
          request.CoachId = reportItem.AssigneeEmpId;
        } else {
          request.IsMgr = 'T';
          request.CoachId = reportItem.AssignorEmpId;
        }
        request.CoacheeId = reportItem.AssigneeEmpId;
        request.CoachName = reportItem.AssignorName;
        request.CoacheeName = reportItem.AssigneeActualName;
      }
    } else {
      request.CoachId = reportItem.AssignorEmployeeId;
    }
    request.ReportName = reportItem.ItemTitle;
    request.ReportId = reportItem.ReportId;
    request.IsRepInitiated = reportItem.IsRepInitiated;
    request.MemberOrgID = this.userInfo.MemberOrgID;
    request.PagePath = '';
    request.Source = 'icf6';
    request.RedirectTo = 'dashboard';
    request.Culture = this.localizationService.getICF6CultreFromLocalStorage().CultureCode;
    return request;
  }


  openQuickFeedbackDetails() {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.width = ModalPopupSizeEnum.QuickFeedbackModalWidth + 'px';
    dialogConfig.disableClose = false;
    dialogConfig.data = this.feedbackData;
    this.dialog.open(QuickFeedbackDetailsComponent, dialogConfig);

  }

  getFeedbackData(connectEventMsg: Notification, IsRepView: boolean) {

    const userDetails = this.userService.getUserDetails();
    const request = new ActRequest();
    request.EmpId = userDetails.UserDetails.EmpId;
    request.RecordCount = 0;
    request.RowOffSet = 1;
    request.SourceType = 'Feedback';
    request.PageRequest = new PageRequest();
    request.PageRequest.PageNumber = 0;
    request.PageRequest.PageSize = environment.defaultActPageSize;

    // For Manage
    if (IsRepView) {
      request.RepId = connectEventMsg.AssigneeEmpId;

      this.actService.getManageAct(request).subscribe((actList: ActResponse) => {
        this.responseData = actList.ActData;
        this.feedbackData = this.responseData.find(x => x.ItemId === connectEventMsg.ItemId);
        this.openQuickFeedbackDetails();
      });
    } else {
      this.actService.getAll(request).subscribe((actList: ActResponse) => {
        this.responseData = actList.ActData;
        this.feedbackData = this.responseData.find(x => x.ItemId === connectEventMsg.ItemId);
        this.openQuickFeedbackDetails();
      });
    }
  }

  openGroupChat(notificationDetails: Notification) {
    const group = {} as IGroup;
    group.ChannelName = notificationDetails.ChannelName;
    group.CreatedById = notificationDetails.GroupCreatedBy;
    group.GroupId = notificationDetails.ItemId;
    group.GroupName = notificationDetails.ItemTitle;
    this.connectMessageService.setSelectedTeam(group);

    this.router.navigate(['/iCoachFirst/connect']);
    this._eventEmiter.emit({ actionType: 'newgroupselected' });
    this._eventEmiter.emit({ actionType: 'messageread' });
  }

  openOneToOneChat(notificationDetails: Notification) {
    if (notificationDetails.ItemType === NotificationItemType.ConnectGroup) {
      const user = {} as User;
      user.EmpId = notificationDetails.AssignorEmpId;
      user.EmailId = notificationDetails.AssignorEmailId;
      user.Name = notificationDetails.AssignorName;
      user.ProfileImageName = notificationDetails.AssignorProfileImageUrl;
      if (this.realTimeChatEnabled) {
        this.connectMessageService.openChat(user);
      }
    }
  }

  setComments(item: Notification): string {
    let finalComments = '';
    if (item.ItemType !== NotificationItemType.ConnectGroup && item.Comments) {
      const commentArr = item.Comments.split('~');
      if (commentArr.length > 0) {
        finalComments = commentArr[0];
      }
    } else {
      finalComments = item.Comments;
    }
    return finalComments;
  }

  filterNotifications() {
    this.notificationFilterReq.IsAPICallFromFilter = true;
    // console.log(this.notificationFilterReq);
    this.getAllNotificationDetails();
    this.showFilter();
  }

  showFilter() {
    this.isShowFilterPopup = !this.isShowFilterPopup;
  }

  addSearchedEmployeeToFilter() {
    if (this.selectedObserver && this.selectedObserver !== undefined) {
      this.notificationFilterReq.NotificationFilter.SearchEmpId = this.selectedObserver.EmpID;
    } else {
      this.toast.error('Login_InvalidUser', '');
    }
  }
}
