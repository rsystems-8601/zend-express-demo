import { User } from 'src/app/models/response/user-response';


export interface IGroup {
  GroupId: number;
  CreatedById: number;
  GroupName: string;
  ChannelName: string;
  LstMember: User[];
  groupType: string;
}
