import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { ApplicationModuleListEnum } from '../../../helpers/enums/common-enums';

@Component({
    selector: 'app-connect-quick-details',
    templateUrl: './connect-quick-details.component.html',
    styleUrls: ['./connect-quick-details.component.scss']
})
export class ConnectQuickDetailsComponent implements OnInit {
    applicationModuleId: number = ApplicationModuleListEnum.None;
    @Output() setLeftContainerVisibility: EventEmitter<number> = new EventEmitter<number>();

    openMainComponentLeftContainer(appModuleId: number = 0) {
        this.setLeftContainerVisibility.emit(appModuleId);
    }
    ngOnInit() {}
}
