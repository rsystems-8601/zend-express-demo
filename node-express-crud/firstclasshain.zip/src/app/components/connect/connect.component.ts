import { Component, OnInit, OnDestroy } from '@angular/core';
// import { User } from 'src/app/models/response/user-response';
import { EventEmiterService } from 'src/app/services/event.emmiter.service';
import { User } from 'src/app/models/response/user-response';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-connect',
  templateUrl: './connect.component.html',
  styleUrls: ['./connect.component.scss']
})

export class ConnectComponent implements OnInit, OnDestroy {

  messagingUsers = [];
  maxOffset: number;

  private subscription: Subscription;

  constructor(
    private _eventEmiter: EventEmiterService,
  ) {
  }

  ngOnInit() {
    this.subscribeEvents();
  }

  ngOnDestroy() {
    this._eventEmiter.unsubscribe(this.subscription);
  }

  subscribeEvents() {

    this.subscription = this._eventEmiter.subscribe(event => {

      if (event.actionType === 'newmessaginguser') {
        this.addUser(event.user);
      } else if (event.actionType === 'removemessaginguser') {
        this.removeUser(event.user);

        if (this.messagingUsers.length === 0) {
          event.closeChatCompCallback();
        }
      }
    });
  }

  private addUser(user: User) {
    const found = this.messagingUsers.some(userparam => userparam.EmpId === user.EmpId);

    if (!found) {
      this.messagingUsers.push(user);
    }
  }

  private removeUser(user: User) {
    this.messagingUsers = this.messagingUsers.filter(userparam => userparam.EmpId !== user.EmpId);
  }

  getOffset(index: number) {

    const chatWindowWidth = 320;
    const maxWidth = window.screen.width - chatWindowWidth;

    let offset = index * chatWindowWidth;

    if ((offset + chatWindowWidth) > maxWidth) {

      if (this.maxOffset !== undefined) {
        offset = this.maxOffset;
      } else {
        offset = this.maxOffset = (index - 1) * chatWindowWidth;
      }
    }

    return offset + 'px';

  }
}
