import { Component, OnInit, Input, ViewChild, ElementRef, AfterViewChecked , AfterViewInit } from '@angular/core';
import { ConnectMessageService } from '../../../services/connect-message.service';
import { User } from 'src/app/models/response/user-response';
import { UserService } from 'src/app/services/user.service';
// import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-chat',
  templateUrl: './chat.component.html',
  styleUrls: ['./chat.component.scss']
})
export class ChatComponent implements OnInit, AfterViewChecked, AfterViewInit {

  // chatInputForm: FormGroup;
  submitted = false;

  messages = [];
  messageText: string;
  loginUser: User;
  isHidden = false;

  @Input() user: User;

  @ViewChild('scrollMe') private scrollContainer: ElementRef;
  @ViewChild('chatinputbox') chatInputBoxElement: ElementRef;

  constructor(
    private userService: UserService,
    public connectMessageService: ConnectMessageService,
    // private formBuilder: FormBuilder
  ) {
    this.loginUser = this.userService.getUserDetails().UserDetails;
  }

  ngOnInit() {

    // this.chatInputForm = this.formBuilder.group({
    //   messageInput: ['', [Validators.required]]
    // });
    this.getMessages();
  }
  ngAfterViewInit() {
    this.chatInputBoxElement.nativeElement.focus();
  }
  // convenience getter for easy access to form fields
  // get f() {
  //   return this.chatInputForm.controls;
  // }

  private getMessages() {
    // listen on channels for new messages send to login user as One to One
    this.messages = this.connectMessageService.subscribeMessages(this.user.EmpId, this.messageCallback.bind(this));
  }

  messageCallback = (message) => {
    this.messages.push(message);
  }

  sendMessage(message: string) {
    message = message.trim();
    if (message.length > 0) {
      this.connectMessageService.sendMessage(message, this.user);
      const messageObject = { msg: message, fromUser: this.loginUser };
      this.messages.push(messageObject);

      this.messageText = '';
    }
  }

  // onSubmit() {
  //   this.submitted = true;

  //   // stop here if form is invalid
  //   if (this.chatInputForm.invalid) {
  //     // this.submitted = false;
  //     return;
  //   }

  //   this.sendMessage(this.messageText);
  //   // this.submitted = false;
  // }

  close() {
    this.connectMessageService.closeChat(this.user);
  }

  hideChat() {
    this.isHidden = !this.isHidden;
  }

  ngAfterViewChecked() {
    if (this.scrollContainer !== undefined) {
      this.scrollContainer.nativeElement.scrollTop = this.scrollContainer.nativeElement.scrollHeight;
    }
  }

  onKeyDown() {
    this.sendMessage(this.messageText);
  }
}
