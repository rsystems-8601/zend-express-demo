import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConnectTaskComponent } from './connect-task.component';

describe('ConnectTaskComponent', () => {
  let component: ConnectTaskComponent;
  let fixture: ComponentFixture<ConnectTaskComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConnectTaskComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConnectTaskComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
