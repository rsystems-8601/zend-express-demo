import { Component, OnInit, OnDestroy } from '@angular/core';
import { TaskStatus } from 'src/app/models/user-details-result';
import { UserPermissions } from 'src/app/helpers/enums/common-enums';
import { EventEmiterService } from 'src/app/services/event.emmiter.service';
import { UserService } from 'src/app/services/user.service';
import { MatDialog, MatDialogConfig } from '@angular/material';
// import { AssignTaskComponent } from '../../tasks/assign-task/assign-task.component';
import { ConnectMessageService } from 'src/app/services/connect-message.service';
import { ConnectapiService } from 'src/app/services/connectapi.service';
// import { Act } from 'src/app/models/response/act-response';
import { Subscription } from 'rxjs';
import { ConnectTeamMembersComponent } from '../connect-team-members/connect-team-members.component';
import { AssignTaskComponent } from '../../tasks/assign-task/assign-task.component';
import { AssignGroupTasRequest } from 'src/app/models/response/connect-settings';

@Component({
  selector: 'app-connect-task',
  templateUrl: './connect-task.component.html',
  styleUrls: ['./connect-task.component.scss']
})
export class ConnectTaskComponent implements OnInit, OnDestroy {

  taskListData: any;
  filteredData = [];
  searchString: string;
  isSearchApply = false;
  searchPanelVisible = false;
  taskStatuses: TaskStatus[];
  UserPermissions = UserPermissions;
  groupId = 0;

  private subscription: Subscription;
  constructor(
    private _eventEmiter: EventEmiterService,
    private userService: UserService,
    private dialog: MatDialog,
    private connectMessageService: ConnectMessageService,
    private connectAPIService: ConnectapiService) {

    this.subscribeEvents();

  }

  ngOnInit() {

    this.taskStatuses = this.userService.getUserDetails().TaskStatuses;
    this.groupId = this.connectMessageService.selectedGroup.GroupId;
    this.getConnectTask();
  }

  ngOnDestroy() {
    this._eventEmiter.unsubscribe(this.subscription);
  }

  subscribeEvents() {

    this.subscription = this._eventEmiter.subscribe(eventData => {

      if ((eventData.actionType === 'ReloadConnectTask') ||
        (eventData.actionType === 'newgroupselected')) {
        this.getConnectTask();
      }
    });
  }

  getConnectTask() {

    this.connectAPIService.getConnectGroupTasks(this.connectMessageService.selectedGroup.GroupId).subscribe((response: any) => {
      this.taskListData = response;
      this.filteredData = response;
    });
  }


  createTask() {

    const userDetails = this.userService.getUserDetails();
    const dialogConfig = new MatDialogConfig();

    dialogConfig.disableClose = true;
    dialogConfig.width = '600px';
    const dialogRefTeam = this.dialog.open(ConnectTeamMembersComponent, dialogConfig);

    // let dialogRef;
    dialogRefTeam.afterClosed().subscribe(data => {

      if (data.Action) {

        const dialogConfigAssignTask = new MatDialogConfig();
        dialogConfigAssignTask.disableClose = true;
        dialogConfigAssignTask.width = '600px';
        dialogConfigAssignTask.data = {
          taskAssignerEmpId: userDetails.UserDetails.EmpId,
          taskAssigneeEmpId: 0,
          groupId: this.groupId,
          selectedTeamMembers: data.SelectedTeamMembers
        };
        const dialogRef = this.dialog.open(AssignTaskComponent, dialogConfigAssignTask);
        dialogRef.afterClosed().subscribe(value => {
          if (value.Type === 'success') {
            if (value.selectedTeamMembers !== undefined && value.selectedTeamMembers.length > 0) {
              this.assignTaskToTeamMember(value.TaskId, value.selectedTeamMembers);
            } else {
              this._eventEmiter.emit({ actionType: 'ReloadConnectTask' });
            }
          }
        });
      }
    });
  }

  assignTaskToTeamMember(taskId, selectedTeamMembers) {
    const userDetails = this.userService.getUserDetails();
    const assignGroupTasRequest = {} as AssignGroupTasRequest;
    assignGroupTasRequest.GroupId = this.groupId;
    assignGroupTasRequest.TaskId = taskId;
    assignGroupTasRequest.EmpId = userDetails.UserDetails.EmpId;
    assignGroupTasRequest.GroupMembersJSON = selectedTeamMembers;

    this.connectAPIService.assignGroupTask(assignGroupTasRequest).subscribe((response: any) => {

      response = response;
      this._eventEmiter.emit({ actionType: 'ReloadConnectTask' });
    });
  }


  showSearchPanel() {
    this.searchPanelVisible = !this.searchPanelVisible;
  }

  filterTask(statusId) {
    let filterData = [];
    if (statusId !== undefined) {

      if (this.searchString !== undefined) {
        filterData = this.taskListData.filter(
          objActData => (objActData.Status === String(statusId)
            && objActData.ItemName.toLowerCase().includes(this.searchString.toLowerCase())));
        return filterData;
      }
      // tslint:disable-next-line: one-line
      else {
        filterData = this.taskListData.filter(
          objActData => objActData.Status === String(statusId));
        return filterData;
      }
    }
    // tslint:disable-next-line: one-line
    else if (this.searchString && this.searchString.length > 0) {
      filterData = this.taskListData.filter(
        objActData => objActData.ItemName.toLowerCase().includes(this.searchString.toLowerCase()));
      return filterData;
    } else {
      return filterData;
    }
  }


  onSearchClicked() {

    let searchData: any[] = [];
    let isSelectedStatus = false;
    this.taskStatuses.forEach(objStatus => {
      if (objStatus.IsSelected) {
        isSelectedStatus = true;
        searchData = searchData.concat(this.filterTask(objStatus.StatusId));
      }
    });

    if (!isSelectedStatus) {
      searchData = searchData.concat(this.filterTask(undefined));
    }

    if (searchData.length > 0) {
      this.filteredData = searchData;
      this.isSearchApply = true;
      this.searchPanelVisible = false;
    } else {
      this.onClearSearch();
    }
  }
  onClearSearch() {
    this.searchString = '';
    this.isSearchApply = false;
    this.searchPanelVisible = false;
    this.filteredData = this.taskListData;
    this.resetStatus();
  }

  private resetStatus() {

    this.taskStatuses.forEach(objStatus => {
      objStatus.IsSelected = false;
    });
  }


}
