import { Component, OnInit, Inject } from '@angular/core';


import { ActService } from 'src/app/services/act.service';
import { UserService } from 'src/app/services/user.service';
import { IcftoasterService } from 'src/app/services/icftoaster.service';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

import { UserDetails } from 'src/app/models/user-details-result';
import { UserAttachmentResponse } from 'src/app/models/response/act-response';
import { CommonEnum } from 'src/app/helpers/enums/common-enums';
import { GroupResourceRequest } from 'src/app/models/requests/connect-request';
import { ConnectMessageService } from 'src/app/services/connect-message.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-resource-form',
  templateUrl: './resource-form.component.html',
  styleUrls: ['./resource-form.component.scss']
})

export class ResourceFormComponent implements OnInit {

  resourceAttachDocRequest = {} as GroupResourceRequest;
  reportRequestParam = { empReportId: '' };
  attachReportDocForm: FormGroup;
  submitted = false;
  selectedFile: any;
  allAttachments: any;
  userDetails: UserDetails;
  userAttachmentList: UserAttachmentResponse[];
  CommonEnum = CommonEnum;
  GroupId: number;

  constructor(private userService: UserService,
    private toast: IcftoasterService,
    private actService: ActService,
    public dialogRef: MatDialogRef<ResourceFormComponent>,
    @Inject(MAT_DIALOG_DATA) public data,
    private formBuilder: FormBuilder,
    protected connectMessageService: ConnectMessageService,
    private router: Router,
  ) { }

  ngOnInit() {

    this.userDetails = this.userService.getUserDetails().UserDetails;

    if (this.connectMessageService.selectedGroup) {
      this.GroupId = this.connectMessageService.selectedGroup.GroupId;
    } else {
      this.toast.error('Please click on any coach tab first.');
      this.router.navigate(['/iCoachFirst/dashboard']);
      return false;
    }

    this.attachReportDocForm = this.formBuilder.group({
      docFileName: ['', Validators.required],
    });

  }

  get f() {
    return this.attachReportDocForm.controls;
  }

  onSubmit() {
    this.submitted = true;
    if (this.attachReportDocForm.invalid) {
      return;
    }

    this.attachDocument();
  }

  attachDocument() {
    const af = this.allAttachments[0];
    const reader = new FileReader();
    reader.onload = (function (cb, parentThis) {
      if (cb) {
        return function () {
          parentThis.resourceAttachDocRequest.GroupId = parentThis.GroupId;
          parentThis.resourceAttachDocRequest.GroupResourceId = 0;
          parentThis.resourceAttachDocRequest.UploadedFileInfo = {
            'FileName': af.name,
            'FileStream': reader.result.toString().split(',')[1]
          };
          parentThis.actService.resourceAttachDocument(parentThis.resourceAttachDocRequest).subscribe((response) => {
            if (response) {
              parentThis.toast.success('Attachment saved successfully.', '');
              parentThis.submitted = false;
              parentThis.cancelClicked();
              parentThis.router.navigate(['/iCoachFirst/connect/resources']);
            }
          });
        };
      }
    })(af, this);
    reader.readAsDataURL(af);
  }

  saveResourceFormData() {
    const resuestData = { 'uploadedfile': this.allAttachments, 'GroupId': this.GroupId };
    this.actService.saveAttachmentFormData(resuestData).subscribe((response) => {
      if (response) {
        if (response) {
          this.toast.success('Attachment saved successfully.', '');
          this.submitted = false;
          this.attachReportDocForm.reset();
        }
      }
    });

  }

  cancelClicked() {
    this.attachReportDocForm.reset();
    this.dialogRef.close();
  }

  isDraft() {
    if (this.data.Status === 'Active' || this.data.Status === 'Pending' || this.data.Status === 'Draft' || true) {
      return true;
    }

  }

  onFileChanged(event: any) {
    this.GroupId = this.connectMessageService.selectedGroup.GroupId;
    this.selectedFile = event.target.files[0];
    if (!this.validateFile(this.selectedFile.name.toLowerCase())) {
      this.toast.error('Document is not in correct format.');
      return false;
    }
    this.attachReportDocForm.get('docFileName').clearValidators();
    this.attachReportDocForm.get('docFileName').updateValueAndValidity();
    this.allAttachments = event.target.files;
  }

  validateFile(name: String) {
    // const allowedExtensions = ['pdf', 'doc', 'docx', 'ppt', 'pptx', 'png', 'jpeg', 'jpg', 'xls', 'xlsx'];
    const notAllowedExtensions = ['exe', 'js'];
    const fileExtension = name.split('.').pop();
    if (this.isInArray(notAllowedExtensions, fileExtension)) {
      return false;
    }
    return true;
  }

  isInArray(array, word) {
    return array.indexOf(word.toLowerCase()) > -1;
  }

}
