import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConnectResourcesComponent } from './connect-resources.component';

describe('ConnectResourcesComponent', () => {
  let component: ConnectResourcesComponent;
  let fixture: ComponentFixture<ConnectResourcesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConnectResourcesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConnectResourcesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
