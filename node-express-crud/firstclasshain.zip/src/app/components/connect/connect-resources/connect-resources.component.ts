import { Component, OnInit, Inject } from '@angular/core';
import { MatDialog, MatDialogConfig, MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { ResourceFormComponent } from 'src/app/components/connect/connect-resources/resource-form/resource-form.component';
import { BaseRequest } from 'src/app/models/requests/base-request';
import { UserService } from 'src/app/services/user.service';
import { UserAttachmentResponse } from 'src/app/models/response/act-response';
import { ActService } from 'src/app/services/act.service';
import { CommonEnum, UserPermissions } from 'src/app/helpers/enums/common-enums';
import { IcftoasterService } from 'src/app/services/icftoaster.service';
import { ConnectMessageService } from 'src/app/services/connect-message.service';
// import { Router } from '@angular/router';
import { GroupResourceListRequest, GroupResourceRequest } from 'src/app/models/requests/connect-request';
import { ConfirmationDialogService } from 'src/app/components/shared/confirmation-dialog/confirmation-dialog.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-connect-resources',
  templateUrl: './connect-resources.component.html',
  styleUrls: ['./connect-resources.component.scss']
})

export class ConnectResourcesComponent implements OnInit {

  userInfo: any;
  reportRequestParam = { empReportId: '' };
  userAttachmentList: UserAttachmentResponse[];
  CommonEnum = CommonEnum;
  GroupId: number;
  dialogRefClose: any;
  canEditTitle = 0;
  canEditTitleId = 0;
  resourceAttachDocRequest = {} as GroupResourceRequest;
  updatedTitle = '';
  UserPermissions = UserPermissions;

  constructor(
    private userService: UserService,
    private dialog: MatDialog,
    private actService: ActService,
    public dialogRef: MatDialogRef<ResourceFormComponent>,
    @Inject(MAT_DIALOG_DATA) public data,
    private toast: IcftoasterService,
    protected connectMessageService: ConnectMessageService,
    // private router: Router,
    private confirmationDialogService: ConfirmationDialogService,
    private route: ActivatedRoute
  ) { }

  ngOnInit() {
    this.userInfo = this.userService.getUserDetails();

    // if (this.connectMessageService.selectedGroup) {
    //   this.GroupId = this.connectMessageService.selectedGroup.GroupId;
    // } else {
    //   // this.toast.error('Please click on any coach tab first2.');
    //   // this.router.navigate(['/iCoachFirst/dashboard']);
    //   // return false;
    // }
    this.route.params.subscribe(_params => {
      if (_params.groupId) {
        this.GroupId = +(_params.groupId);
      } else {
        this.GroupId = this.connectMessageService.selectedGroup.GroupId;
      }
      this.getReportAttachmentList();
    });
  }


  addResource() {

    const dialogConfig = new MatDialogConfig();
    dialogConfig.width = '580px';
    const dataToPass = new BaseRequest();
    dataToPass.RepId = this.userInfo.UserDetails.EmpId;
    dataToPass.IsRepInitiated = false;
    dialogConfig.data = {
      coacheeData: { Name: this.userInfo.UserDetails.Name, EmpId: this.userInfo.UserDetails.EmpId }
    };
    // dialogConfig.disableClose = true;
    this.dialogRefClose = this.dialog.open(ResourceFormComponent, dialogConfig);
    this.dialogRefClose.afterClosed().subscribe(() => {
      this.getReportAttachmentList();
    });

  }

  getReportAttachmentList() {
    if (this.connectMessageService.selectedGroup) {
      if (this.connectMessageService.selectedGroup.GroupId) {
        this.actService.getResourceAttachmentList(this.GroupId).subscribe((response) => {
          if (response) {
            this.userAttachmentList = response.slice().reverse();
          }
        });
      }
    }
  }

  confirmDelete(attachment) {

    // tslint:disable-next-line:max-line-length
    this.confirmationDialogService.confirm('Common_Confirm_Delete',
      'Common_Yes',
      'Common_No').subscribe(value => {
        if (value) {
          this.deleteAttachment(attachment);
        }
      });

  }

  deleteAttachment(attachment: GroupResourceListRequest) {
    this.actService.deleteResourceAttachment(attachment.GroupResourceId).subscribe((response) => {
      if (response) {
        if (response === true) {
          this.toast.success('Attachment deleted successfully.');
          this.getReportAttachmentList();
        } else {
          this.toast.error('Error Occured');
        }
      }
    });
  }

  updateTitle(groupResourceId: number) {
    if (this.updatedTitle !== '') {
      this.resourceAttachDocRequest.GroupResourceId = groupResourceId;
      this.resourceAttachDocRequest.Title = this.updatedTitle;
      this.resourceAttachDocRequest.GroupId = this.GroupId;
      this.actService.resourceAttachDocument(this.resourceAttachDocRequest).subscribe((response) => {
        if (response) {
          this.toast.success('Title updated successfully.', '');
          this.getReportAttachmentList();
          this.enableEdit(0, 0);
        }
      });
    }
  }

  enableEdit(canEditTitle: number, canEditTitleId: number) {
    this.canEditTitle = canEditTitle;
    this.canEditTitleId = canEditTitleId;
    this.updatedTitle = '';
  }

}
