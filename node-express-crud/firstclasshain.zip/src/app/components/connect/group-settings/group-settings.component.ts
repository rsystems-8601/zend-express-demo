import { Component, OnInit, OnDestroy, OnChanges, SimpleChanges } from '@angular/core';
// import * as settingsData from '../../../data/settings.json';
import { ConnectSettings, SaveGroupSettings } from 'src/app/models/response/connect-settings.js';
import { ConnectapiService } from 'src/app/services/connectapi.service.js';
import { IcftoasterService } from 'src/app/services/icftoaster.service';
import { ConnectMessageService } from 'src/app/services/connect-message.service';
// import { GroupBaseComponent } from '../group-base/group-base.component';
import { EventEmiterService } from 'src/app/services/event.emmiter.service';
import { UserService } from 'src/app/services/user.service';
import { Subscription } from 'rxjs';
import { MatDialog, MatDialogConfig } from '@angular/material';
import { CreateGroupComponent } from '../create-group/create-group.component';
import { ConfirmationDialogService } from '../../shared/confirmation-dialog/confirmation-dialog.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-group-settings',
  templateUrl: './group-settings.component.html',
  styleUrls: ['./group-settings.component.scss']
})

export class GroupSettingsComponent implements OnInit, OnDestroy, OnChanges {

  adminSettings: ConnectSettings[] = [];
  nonAdminSettings: ConnectSettings[] = [];
  filteredNonAdminSettings: ConnectSettings[] = [];
  subscription: Subscription;
  hasAdminRights = false;

  constructor(private connectAPIService: ConnectapiService,
    private toast: IcftoasterService,
    private connectMessageService: ConnectMessageService,
    private _eventEmiter: EventEmiterService,
    private userService: UserService,
    private dialog: MatDialog,
    private confirmationDialogService: ConfirmationDialogService,
    private router: Router) {

    this.checkAdminRights();

  }

  ngOnInit() {

    this.subscribeEvents();
    this.setupSettings();
  }

  private checkAdminRights() {
    const loginUserId = this.userService.getUserDetails().UserDetails.EmpId;
    this.hasAdminRights = this.connectMessageService.hasAdminRights(loginUserId);
  }

  addMemberClick() {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.data = {
      group: this.connectMessageService.selectedGroup
    };
    dialogConfig.width = '600px';
    const dialogRef = this.dialog.open(CreateGroupComponent, dialogConfig);
    dialogRef.afterClosed().subscribe(value => {
      if (value === 'success') {
        // TODO Make any changes required after new member addtion.
      }
    });
  }

  onDeleteGroupClick() {
    this.confirmationDialogService.confirm('Common_Confirm_GroupDelete',
      'Common_Yes',
      'Common_No').subscribe(value => {

        if (value) {
          this.deleteConnectGroup(this.connectMessageService.selectedGroup.GroupId);
        }
      });
  }

  private deleteConnectGroup(groupId: number) {

    this.connectAPIService.deleteConnectGroup(groupId).subscribe(response => {

      if (response === true) {
        this.toast.prepareParameterizedMessage('success', ['Common_DeleteSuccessPlaceholder', 'Group'], '');

        // this.toast.success('Group deleted successfully');
        this.router.navigate(['/iCoachFirst/dashboard']);
        this._eventEmiter.emit({ actionType: 'reloadGroups' });

      } else {
        this.toast.error('ShareConnectOption_Error');
      }
    });
  }

  ngOnDestroy() {
    this._eventEmiter.unsubscribe(this.subscription);
  }

  ngOnChanges(changes: SimpleChanges) {

    if (changes !== undefined) {
      this.setupSettings();
    }
  }

  subscribeEvents() {

    this.subscription = this._eventEmiter.subscribe(newGroupEvent => {

      if (newGroupEvent.actionType === 'newgroupSettings') {
        if (this.connectMessageService.selectedGroup !== undefined) {
          this.setupSettings();
        }
      }
    });
  }

  setupSettings() {

    if (this.connectMessageService.teamSettingsResponse !== undefined) {
      this.adminSettings = this.connectMessageService.teamSettingsResponse.AdminGroupSettings;
      this.nonAdminSettings = this.connectMessageService.teamSettingsResponse.RegularGroupSettings;
      // Filtering the below two values for Non-Admin as these values are not valid for non-admin
      this.filteredNonAdminSettings = this.nonAdminSettings.filter(x => !(x.KeyLabel === 'DeletePeople' || x.KeyLabel === 'MakeothersAdmin'));
    } else {
      this.adminSettings = [];
      this.nonAdminSettings = [];
      this.filteredNonAdminSettings = [];
    }
    // // alert(this.connectMessageService.selectedGroup.GroupId);
    // this.connectAPIService.getGroupSettings(this.connectMessageService.selectedGroup.GroupId).
    //   subscribe((response: ConnectSettingsResponse) => {

    //     this.adminSettings = response.AdminGroupSettings;
    //     this.nonAdminSettings = response.RegularGroupSettings;
    //   });
  }

  saveSettings(settingObj: ConnectSettings) {

    settingObj.OnOffValue = !settingObj.OnOffValue;
    const request = {} as SaveGroupSettings;
    request.GroupId = this.connectMessageService.selectedGroup.GroupId;
    request.AdminGroupSettings = this.adminSettings;
    request.RegularGroupSettings = this.nonAdminSettings;
    request.EmpId = this.userService.getUserDetails().UserDetails.EmpId;
    this.connectAPIService.saveGroupSettings(request).
      subscribe((response: any) => {
        if (response === true) {
        } else {
          this.toast.error('Something went wrong. Please try again.');
        }

      });

  }

}
