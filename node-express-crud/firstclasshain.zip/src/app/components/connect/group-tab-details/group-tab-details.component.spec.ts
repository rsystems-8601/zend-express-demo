import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GroupTabDetailsComponent } from './group-tab-details.component';

describe('GroupTabDetailsComponent', () => {
  let component: GroupTabDetailsComponent;
  let fixture: ComponentFixture<GroupTabDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GroupTabDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GroupTabDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
