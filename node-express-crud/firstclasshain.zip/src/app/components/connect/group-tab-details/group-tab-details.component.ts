import { Component } from '@angular/core';
import { ConnectMessageService } from 'src/app/services/connect-message.service';
import { EventEmiterService } from 'src/app/services/event.emmiter.service';
import { GroupBaseComponent } from '../group-base/group-base.component';
import { UserService } from 'src/app/services/user.service';
import { Router } from '@angular/router';
import { UserDetails } from 'src/app/models/user-details-result';
import { RolesService } from 'src/app/services/roles.service';
import { UserPermissions } from '../../../helpers/enums/common-enums';

@Component({
  selector: 'app-group-chat',
  templateUrl: './group-tab-details.component.html',
  styleUrls: ['./group-tab-details.component.scss']
})
export class GroupTabDetailsComponent extends GroupBaseComponent {

  groupId = 0;
  userInfo: UserDetails;
  isEnableConnect: boolean;
  connectTabs: any = [];
  UserPermissions = UserPermissions;

  constructor(
    connectMessageService: ConnectMessageService,
    _eventEmiter: EventEmiterService,
    private userService: UserService,
    router: Router,
    private rolesService: RolesService
  ) {
    super(connectMessageService, _eventEmiter, router);
    this.userInfo = this.userService.getUserDetails().UserDetails;
    this.isEnableConnect = this.rolesService.hasPermission('CNT');
    this.setupTabs();
  }

  private setupTabs() {

    this.loadTabs();

    if (this.connectMessageService.selectedGroup !== undefined) {
      const group = this.connectMessageService.selectedGroup;
      this.groupId = this.connectMessageService.selectedGroup.GroupId;

      // People and Settings tab should never be visible in 3 default teams
      if (group.groupType !== 'myteam' && group.groupType !== 'mycoaches' && group.groupType !== 'managerteam') {
        this.connectTabs.push({
          key: 'people',
          value: 'People',
        });

        // Settings tab should be visble to owner only.
        const loginUserId = this.userService.getUserDetails().UserDetails.EmpId;
        if (group.CreatedById === loginUserId) {
          this.connectTabs.push({
            key: 'settings',
            value: 'Settings',
          });
        }
      }

      // Add Survey(s) tab for only my-team
      if (group.groupType === 'myteam') {
        this.connectTabs.push({
          key: 'surveys',
          value: 'Survey(s)',
        });
      }
    }
  }

  subscribeEvents() {

    this.subscription = this._eventEmiter.subscribe(newGroupEvent => {

      if (newGroupEvent.actionType === 'newgroupSettings') {
        if (this.connectMessageService.selectedGroup !== undefined) {
          this.groupName = this.connectMessageService.selectedGroup.GroupName;
        }
        this.setupTabs();

        if (this.router.url.includes('connect/goals')) {
          this.router.navigate(['/iCoachFirst/connect/goals', this.connectMessageService.selectedGroup.GroupId]);
        }

      } else if (newGroupEvent.actionType === 'updateGroups') {
        if (this.connectMessageService.selectedGroup !== undefined) {
          this.groupName = this.connectMessageService.selectedGroup.GroupName;
        }
      }
    });
  }

  loadTabs() {

    if (this.isEnableConnect) {
      this.connectTabs = [{
        key: 'conversations',
        value: 'Connect',
      }, {
        key: 'resources',
        value: 'Resources',
      }, {
        key: 'goals',
        value: 'Goals',
      }, {
        key: 'tasks',
        value: 'Tasks',
      }];
    } else {
      this.connectTabs = [{
        key: 'resources',
        value: 'Resources',
      }, {
        key: 'goals',
        value: 'Goals',
      }, {
        key: 'tasks',
        value: 'Tasks',
      }];
    }
  }
}
