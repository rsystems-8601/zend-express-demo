import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { ConnectMessageService } from 'src/app/services/connect-message.service';
import { User } from 'src/app/models/response/user-response';
import { AssignGroupTasRequest } from 'src/app/models/response/connect-settings';
import { EventEmiterService } from 'src/app/services/event.emmiter.service';
import { UserService } from 'src/app/services/user.service';
import { ConnectapiService } from 'src/app/services/connectapi.service';
import { IcftoasterService } from 'src/app/services/icftoaster.service';

@Component({
  selector: 'app-connect-team-members',
  templateUrl: './connect-team-members.component.html',
  styleUrls: ['./connect-team-members.component.scss']
})
export class ConnectTeamMembersComponent implements OnInit {

  groupMembers: User[];
  selectedMembers: any[] = [];
  isShowAssignButton = false;
  selectAllBtn = true;

  constructor(public dialogRef: MatDialogRef<ConnectTeamMembersComponent>,
    @Inject(MAT_DIALOG_DATA) public data,
    private connectMessageService: ConnectMessageService,
    private _eventEmiter: EventEmiterService,
    private userService: UserService,
    private connectAPIService: ConnectapiService,
    private toast: IcftoasterService,
  ) {
  }

  ngOnInit() {

    this.groupMembers = this.connectMessageService.getTeamMembers();
    this.groupMembers.forEach(member => {
      member.IsSelected = false;
    });

    if (this.data) {
      this.isShowAssignButton = true;
      const assigneesList = this.data.TaskAssignees;
      this.updateTeamList(assigneesList);
    }
  }

  updateTeamList(assigeesList) {

    this.groupMembers.forEach(member => {
      assigeesList.some(assgineeMember => {
        if (member.EmpId === assgineeMember.EmpId) {
          member.IsSelected = true;
          return true;
        }
      });
    });

  }

  selectAll() {

    this.groupMembers.forEach(member => {
      if (this.selectAllBtn) {
        member.IsSelected = true;
      } else {
        member.IsSelected = false;
      }
    });
  }

  cancelClicked() {

    this.dialogRef.close({ SelectedTeamMembers: [], Action: false });
  }

  nextClicked() {

    this.groupMembers.forEach(member => {
      if (member.IsSelected === true) {
        this.selectedMembers.push({ MemberId: member.EmpId });
      }
    });
    this.dialogRef.close({ SelectedTeamMembers: this.selectedMembers, Action: true });
  }

  assginClicked() {

    this.groupMembers.forEach(member => {
      if (member.IsSelected === true) {
        this.selectedMembers.push({ MemberId: member.EmpId });
      }
    });
    if (this.selectedMembers.length > 0) {
      this.assignTaskToTeamMember(this.data.ItemId, this.selectedMembers);
    } else {
      this.toast.info('Please select atleast one team member.', '');
    }
  }

  assignTaskToTeamMember(taskId, selectedTeamMembers) {
    const userDetails = this.userService.getUserDetails();
    const assignGroupTasRequest = {} as AssignGroupTasRequest;
    assignGroupTasRequest.GroupId = this.connectMessageService.selectedGroup.GroupId;
    assignGroupTasRequest.TaskId = taskId;
    assignGroupTasRequest.EmpId = userDetails.UserDetails.EmpId;
    assignGroupTasRequest.GroupMembersJSON = selectedTeamMembers;

    this.connectAPIService.assignGroupTask(assignGroupTasRequest).subscribe((response: any) => {

      if (response) {

        this.toast.success('Task assigned successfully.', '', () => {

          this._eventEmiter.emit({ actionType: 'ReloadConnectTask' });
          this.dialogRef.close({ SelectedTeamMembers: [], Action: false });

        });
      }
    });
  }

}
