import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConnectTeamMembersComponent } from './connect-team-members.component';

describe('ConnectTeamMembersComponent', () => {
  let component: ConnectTeamMembersComponent;
  let fixture: ComponentFixture<ConnectTeamMembersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConnectTeamMembersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConnectTeamMembersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
