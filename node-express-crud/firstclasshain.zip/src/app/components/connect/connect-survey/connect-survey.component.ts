import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { SolicitMultiRaterFeedbackService } from 'src/app/services/solicit-multi-rater-feedback.service';
import { SurveyList } from 'src/app/models/response/feedback/solicit-multi-rater-feedback';
import { KeyValuePair } from 'src/app/models/key-value-pair';
import { PulseSurveyCycleRequest } from 'src/app/models/requests/survey.request';
import { SurveyService } from 'src/app/services/survey.service';
import { IcftoasterService } from 'src/app/services/icftoaster.service';
import { EventEmiterService } from 'src/app/services/event.emmiter.service';
import { DatePipe } from '@angular/common';
import { MatDialog, MatDialogConfig } from '@angular/material';
import { ModalPopupSizeEnum } from 'src/app/helpers/enums/common-enums';
import { GenericPopupComponent } from '../../shared/generic-popup/generic-popup.component';
import { PagerService } from 'src/app/services/pager-service';
import { FrequencyType } from 'src/app/models/response/survey.response';
import { CommonService } from 'src/app/services/common.service';


@Component({
  selector: 'app-connect-survey',
  templateUrl: './connect-survey.component.html',
  styleUrls: ['./connect-survey.component.scss']
})
export class ConnectSurveyComponent implements OnInit {

  connectSurveyForm: FormGroup;
  minDate = new Date();
  surveyList: SurveyList[] = [];
  intervalList: number[] = [];
  cadenceList: FrequencyType[] = [];
  gridData: PulseSurveyCycleRequest[] = [];
  submitted = false;
  editMode = false;
  resetDate = {
    from: '',
    to: ''
  };
  selectedPulseSurveyId: number;
  // pager object
  pager: any = {};
  // paged items
  pagedItems: any[] = [];
  tblPages: number;
  rowNo: number;
  pagesize: number;
  adminListCount: number;
  allItemsSelected: boolean;
  constructor(
    private fb: FormBuilder,
    private solicitService: SolicitMultiRaterFeedbackService,
    private surveyService: SurveyService,
    private toast: IcftoasterService,
    private eventEmitter: EventEmiterService,
    private datePipe: DatePipe,
    private dialog: MatDialog,
    private pagerService: PagerService,
    private commonService: CommonService
  ) { }

  ngOnInit() {
    this.solicitService.getSurvey().subscribe(resp => {
      this.surveyList = resp;
    });
    this.surveyService.getPeriodicReviewFrequencyType().subscribe(resp => {
      this.cadenceList = resp;
    });
    this.rowNo = 10;
    this.tblPages = 0;
    this.getGridData(0, this.rowNo, true);
    this.intervalList = this.fillRange(1, 364);
    // this.fillCadenceData();
    this.connectSurveyForm = this.fb.group({
      title: ['', Validators.required],
      fromDate: ['', Validators.required],
      toDate: ['', Validators.required],
      survey: ['', Validators.required],
      cadence: ['', Validators.required],
      interval: ['', Validators.required],
      subject: ['', Validators.required],
      body: ['', Validators.required],
      appNotify: [true],
      emailNotify: [true],
      active: [true]
    });

    this.connectSurveyForm.valueChanges.subscribe(_val => {
      this.submitted = false;
    });  
  }
      resetForm() {
    this.connectSurveyForm.patchValue({
      title: '',
      survey: '',
      cadence: '',
      interval: '',
      subject: '',
      body: '',
      appNotify: true,
      emailNotify: true,
      active: true
    });
    this.eventEmitter.emit({ keyName: 'resetDate' });
    this.editMode = false;
    this.disableFields(false);
  }

  getGridData(page: number, size: number, firstLoad: boolean) {
    const request = {
      PageRequest: {
        PageNumber: page,
        PageSize: size,
        SortColumn: '',
        SortDirection: ''
      }
    };
    this.surveyService.getPulseSurveyReviewCycle(request).subscribe(resp => {
      this.gridData = resp.Surveys;
      this.adminListCount = resp.TotalSurveyCount;
      if (firstLoad) {
        this.setPagination(page, size);
      } else {
        this.setPagination(page,size);
      }
    });
  }
  onSubmit() {
    this.submitted = true;
    if (this.connectSurveyForm.invalid) {
      return;
    }

    // Check for invalid date-range
    if (this.f.fromDate && this.f.toDate) {
      const fDate = new Date(this.f.fromDate.value).getTime();
      const tDate = new Date(this.f.toDate.value).getTime();
      if (tDate < fDate) {
        this.f.fromDate.setErrors({ 'small': true });
        return;
      }
    }

    // Prepare submit request
    const surveyRequest = {} as PulseSurveyCycleRequest;
    const formValues = this.connectSurveyForm.getRawValue();
    if (!this.editMode) {
      surveyRequest.PulseSurveyReviewCycleId = 0;
    } else {
      surveyRequest.PulseSurveyReviewCycleId = this.selectedPulseSurveyId;
    }
    surveyRequest.PulseReviewTitle = formValues.title;
    surveyRequest.OpenDate = formValues.fromDate;
    surveyRequest.CloseDate = formValues.toDate;
    surveyRequest.SurveyCycleId = formValues.survey;
    surveyRequest.CadenceId = formValues.cadence;
    surveyRequest.ReminderIntervals = formValues.interval;
    surveyRequest.MessageSubject = formValues.subject;
    surveyRequest.MessageBody = formValues.body;
    surveyRequest.InAppNotification = formValues.appNotify;
    surveyRequest.EmailNotification = formValues.emailNotify;
    surveyRequest.IsActive = formValues.active;
    this.surveyService.savePulseSurveyReviewCycle(surveyRequest).subscribe(resp => {
      if (resp.ResponseMessage === 'Success') {
        this.toast.success('Common_UpdateSuccess', '', () => { });
        this.getGridData(0, this.rowNo, true);
        this.resetForm();
      }
    });
  }

  fillRange(start: number, end: number) {
    return Array(end - start + 1).fill(1).map((_item, index) => start + index);
  }

  // fillCadenceData() {
  //   this.cadenceList.push({ Key: '1', Value: 'On Demand' });
  //   this.cadenceList.push({ Key: '2', Value: 'Weekly' });
  //   this.cadenceList.push({ Key: '3', Value: 'Monthly' });
  //   this.cadenceList.push({ Key: '4', Value: 'Quaterly' });
  //   this.cadenceList.push({ Key: '5', Value: 'Annually' });
  //   this.cadenceList.push({ Key: '6', Value: 'Semi-Annually' });
  //   this.cadenceList.push({ Key: '7', Value: 'One-Time' });
  // }

  get f() {
    return this.connectSurveyForm.controls;
  }

  editSurvey(survey: PulseSurveyCycleRequest) {
    this.editMode = true;
    this.connectSurveyForm.patchValue({
      title: survey.PulseReviewTitle,
      survey: survey.SurveyCycleId,
      cadence: survey.CadenceId,
      interval: survey.ReminderIntervals,
      subject: survey.MessageSubject,
      body: survey.MessageBody,
      appNotify: survey.InAppNotification,
      emailNotify: survey.EmailNotification,
      active: survey.IsActive
    });
    this.resetDate.from = this.datePipe.transform(survey.OpenDate, 'MM/dd/yyyy');
    this.resetDate.to = this.datePipe.transform(survey.CloseDate, 'MM/dd/yyyy');
    this.selectedPulseSurveyId = survey.PulseSurveyReviewCycleId;
    this.disableFields(true);

  }

  disableFields(disable: boolean) {
    if (disable) {
      this.f.survey.disable();
      this.f.cadence.disable();
      this.f.interval.disable();
    } else {
      this.f.survey.enable();
      this.f.cadence.enable();
      this.f.interval.enable();
    }
  }

  showSurveyDetails(survey: PulseSurveyCycleRequest) {
    const dataForPopup: KeyValuePair[] = [];
    dataForPopup.push({ Key: 'Subject', Value: survey.MessageSubject });
    dataForPopup.push({ Key: 'Body', Value: survey.MessageBody });
    const dialogConfig = new MatDialogConfig();
    dialogConfig.width = ModalPopupSizeEnum.GenericModalWidth + 'px';
    dialogConfig.disableClose = true;
    dialogConfig.data = dataForPopup;
    this.dialog.open(GenericPopupComponent, dialogConfig);
  }

  setPagination(page: number, size: number) {

    if (page > -1 || page === 0) {
      this.tblPages = page;
    }

    if (size) {
      // this.rowNo = size;
    }

    this.pager = this.pagerService.getAjaxPagerForAssignment(this.adminListCount, this.tblPages, Number(size));
    this.pagedItems = this.gridData.slice(this.pager.startIndex, this.pager.endIndex + 1);
    if (this.pagedItems.length > 0) { this.selectEntity(); }
  }

  setPage(page: number) {
    if (page > -1) {
      this.tblPages = page - 1;
    }

    // if (size) {
    //   // this.rowNo = size;
    // }

    this.getGridData(this.tblPages, this.rowNo, false);
    // this.searchBySelectedTab(this.currentTabIndex);
    this.pager.currentPage = this.tblPages;
    this.setPagination(this.tblPages, this.rowNo);
  }

  selectEntity() {
    for (let i = 0; i < this.pagedItems.length; i++) {
      if (!this.pagedItems[i].isSelected) {
        this.allItemsSelected = false;
        return;
      }
    }
    this.allItemsSelected = true;
  }

  selectAll() {
    for (let i = 0; i < this.pagedItems.length; i++) {
      this.pagedItems[i].isSelected = this.allItemsSelected;
    }
  }

  onChange(event) {
    this.getGridData(this.pager.currentPage, parseInt(event.target.value, 0), false);
    this.rowNo = parseInt(event.target.value, 0);
    this.tblPages = 0;
  }

  createNewSurvey(): void {
    this.commonService.createNewSurvey();
  }
}
