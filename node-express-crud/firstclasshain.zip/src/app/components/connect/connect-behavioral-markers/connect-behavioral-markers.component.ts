import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-connect-behavioral-markers',
  templateUrl: './connect-behavioral-markers.component.html',
  styleUrls: ['./connect-behavioral-markers.component.scss']
})
export class ConnectBehavioralMarkersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
