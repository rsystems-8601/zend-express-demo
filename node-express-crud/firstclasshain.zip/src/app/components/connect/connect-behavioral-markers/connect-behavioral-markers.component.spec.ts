import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConnectBehavioralMarkersComponent } from './connect-behavioral-markers.component';

describe('ConnectBehavioralMarkersComponent', () => {
  let component: ConnectBehavioralMarkersComponent;
  let fixture: ComponentFixture<ConnectBehavioralMarkersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConnectBehavioralMarkersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConnectBehavioralMarkersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
