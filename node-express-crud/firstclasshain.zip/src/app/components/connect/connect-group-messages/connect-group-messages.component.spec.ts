import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConnectGroupMessagesComponent } from './connect-group-messages.component';

describe('ConnectGroupMessagesComponent', () => {
  let component: ConnectGroupMessagesComponent;
  let fixture: ComponentFixture<ConnectGroupMessagesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConnectGroupMessagesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConnectGroupMessagesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
