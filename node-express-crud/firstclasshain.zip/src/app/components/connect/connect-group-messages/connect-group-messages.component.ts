import { Component, OnInit, OnDestroy, ElementRef, ViewChild, AfterViewInit } from '@angular/core';
import { User } from 'src/app/models/response/user-response';
import { Subscription } from 'rxjs';
import { ConnectMessageService } from 'src/app/services/connect-message.service';
import { UserService } from 'src/app/services/user.service';
import { EventEmiterService } from 'src/app/services/event.emmiter.service';
import { ConnectapiService } from 'src/app/services/connectapi.service';
import { CreateGroupRequest } from 'src/app/models/requests/create-group-request';
import { IGroup } from '../connect-interfaces';
import { IcftoasterService } from 'src/app/services/icftoaster.service';
import { ActivatedRoute } from '@angular/router';
import { ChatAttachmentResponse } from 'src/app/models/response/chat-attachment-response';
import { Comment } from 'src/app/models/response/common/comment';
import { ChatEnum, FileTypeEnum } from 'src/app/helpers/enums/common-enums';

@Component({
  selector: 'app-connect-group-messages',
  templateUrl: './connect-group-messages.component.html',
  styleUrls: ['./connect-group-messages.component.scss']
})
export class ConnectGroupMessagesComponent implements OnInit, OnDestroy, AfterViewInit {

  messages = [];
  messageText = '';

  loginUser: User;
  isSendThumbUp = false;
  private subscription: Subscription;
  selectedFile: any;
  allAttachments: any;
  showEmojis = false;
  imagePath = 'assets/images/emoji/';
  messageWithEmoji = '';
  emojiCodeArray = [];
  chatAttachmentArr: Array<ChatAttachmentResponse> = [];
  audio = FileTypeEnum.Audio;
  video = FileTypeEnum.Video;
  image = FileTypeEnum.Image;
  text = FileTypeEnum.Text;

  @ViewChild('scrollMe') private scrollContainer: ElementRef;
  @ViewChild('groupchatinputbox') groupChatInputBoxElement: ElementRef;
  @ViewChild('uploadFile') file: ElementRef;

  constructor(
    public connectMessageService: ConnectMessageService,
    private connectApiService: ConnectapiService,
    private userService: UserService,
    private _eventEmiter: EventEmiterService,
    private toast: IcftoasterService,
    private route: ActivatedRoute,
    private connectapiService: ConnectapiService
  ) {

    this.loginUser = this.userService.getUserDetails().UserDetails;

  }

  ngOnInit() {
    this.route.params.subscribe(_params => {
      this.setControlFocus();
    });
    this.listenChannelsForNewMessages();
    this.subscribeEvents();
  }
  ngAfterViewInit() {
    this.setControlFocus();
  }
  setControlFocus() {
    this.groupChatInputBoxElement.nativeElement.focus();
  }
  ngOnDestroy() {
    this._eventEmiter.unsubscribe(this.subscription);
  }

  subscribeEvents() {

    this.subscription = this._eventEmiter.subscribe(newGroupEvent => {

      if (newGroupEvent.actionType === 'newgroupselected') {
        this.listenChannelsForNewMessages();
      }
    });
  }
  private getHistoricalMessages() {

    this.messages = [];
    const group = this.connectMessageService.selectedGroup;

    this.connectApiService.getGroupComment(group.GroupId).subscribe((comments: Comment[]) => {
      comments.forEach(comment => {

        const fromUser = {
          EmpId: comment.CreatedBy,
          Name: comment.CreatedByName,
          ProfileImageName: comment.ProfileImageURL,
          EmailId: comment.EmailID
        } as User;
        if (comment.Attachments && comment.Attachments.length > 0) {
          comment.Attachments.forEach(attachment => {
            attachment.FileType = this.getFileType(attachment.ResourceType);
          });
        }
        let messageObject = {
          msg: comment.Comment,
          msgType: comment.CommentType,
          fromUser: fromUser,
          date: comment.CreatedDate,
          group: group,
          attachments: comment.Attachments,
          html: ''
        };
        messageObject = this.replaceEmojiPresentInComment(messageObject);
        this.messages.push(messageObject);

      });
    });

  }

  private listenChannelsForNewMessages() {
    // listen on channels for new messages send to login user as One to One
    if (this.connectMessageService.selectedGroup !== undefined) {
      const group = this.connectMessageService.selectedGroup;
      // this.messages = this.connectMessageService.subscribeGroupMessages(group.ChannelName, this.messageCallback.bind(this));
      this.connectMessageService.subscribeGroupMessages(group.ChannelName, this.messageCallback.bind(this));

      this.getHistoricalMessages();

    }
  }

  messageCallback = (message) => {
    message = this.replaceEmojiPresentInComment(message);
    if (message.group.ChannelName === this.connectMessageService.selectedGroup.ChannelName) {
      // this.messages.push(message);
      this.getHistoricalMessages();
    }
  }

  sendThumbUp() {
    this.isSendThumbUp = true;
    this.sendMessage();
    this.isSendThumbUp = false;
  }

  sendMessage(message?: string) {
    // this.messageText = message ? message : this.messageText.trim();
    const msg = message ? message : this.messageText.trim();
    if (msg.length > 0 || this.chatAttachmentArr.length > 0 || this.isSendThumbUp) {
      const group = this.connectMessageService.selectedGroup;
      if (group !== undefined && group.GroupId === 0) {
        // Default groups
        this.createGroup(group);
      } else {
        let commentType = '';
        if (msg.length > 0 && this.chatAttachmentArr.length > 0) {
          commentType = ChatEnum.CommentWithAttachment;
        } else if (msg.length > 0) {
          commentType = ChatEnum.Comments;
        } else if (this.chatAttachmentArr.length > 0) {
          commentType = ChatEnum.Attachment;
        } else if (this.isSendThumbUp) {
          commentType = ChatEnum.ThumbUp;
        }
        const chatAttachmentIds = Array.prototype.map.call(this.chatAttachmentArr, x => x.ChatAttachmentId).toString();
        const selectedGroup = this.connectMessageService.selectedGroup;
        const request = {
          GroupId: selectedGroup.GroupId,
          Comment: msg,
          EmpId: this.loginUser.EmpId,
          FileName: '',
          CommentType: commentType, // 'comment',
          AttachmentIds: chatAttachmentIds,
        };
        // this.connectMessageService.sendMessageToGroup(msg, this.connectMessageService.selectedGroup);
        this.connectapiService.saveGroupComment(request).subscribe(result => {
          if (result) {
            const msgObjectToPubnub = {
              message: msg,
              resourceData: this.chatAttachmentArr
            };
            this.connectMessageService.sendMessageToGroup(msgObjectToPubnub, this.connectMessageService.selectedGroup);
            this.messageText = '';
            this.chatAttachmentArr = [];
            this.messageWithEmoji = '';
            this.emojiCodeArray = [];
          } else {
            // ('saveGroupComment Failed');
          }
        });
      }
    }
  }

  onFileChanged(event: any) {
    this.selectedFile = event.target.files[0];
    if (!this.validateFile(this.selectedFile.name.toLowerCase())) {
      this.toast.error('Document is not in correct format.');
      return false;
    }
    this.allAttachments = event.target.files;
    this.attachDocument();
  }

  validateFile(name: String) {
    // const allowedExtensions = ['pdf', 'doc', 'docx', 'ppt', 'pptx', 'png', 'jpeg', 'jpg', 'xls', 'xlsx'];
    const notAllowedExtensions = ['exe', 'js'];
    const fileExtension = name.split('.').pop();
    if (this.isInArray(notAllowedExtensions, fileExtension)) {
      return false;
    }
    return true;
  }

  isInArray(array, word) {
    return array.indexOf(word.toLowerCase()) > -1;
  }

  attachDocument() {
    const af = this.allAttachments[0];
    const resourceType = af['type'];
    const reader = new FileReader();
    reader.readAsDataURL(af);
    reader.onload = (function (cb, parentThis) {
      if (cb) {
        return function () {
          const attachDetails = {
            'FileName': af.name,
            'FileStream': reader.result.toString().split(',')[1],
            'ResourceType': resourceType
          };
          parentThis.connectApiService.uploadChatAttachment(attachDetails).subscribe((response: ChatAttachmentResponse) => {
            if (response) {
              response.FileType = parentThis.getFileType(response.ResourceType);
              parentThis.chatAttachmentArr.push(response);
            }
          });
        };
      }
    })(af, this);
  }

  deleteAttachment(attachment: ChatAttachmentResponse) {
    this.chatAttachmentArr = this.chatAttachmentArr.filter(item => item.ChatAttachmentId !== attachment.ChatAttachmentId);
  }
  private createGroup(group: IGroup) {

    const groupRequest = new CreateGroupRequest();
    groupRequest.EmpId = this.loginUser.EmpId;
    groupRequest.GroupId = 0; // For new group
    groupRequest.GroupName = group.GroupName;
    groupRequest.ChannelName = group.ChannelName;
    groupRequest.GroupMembersJSON = [{ MemberId: this.loginUser.EmpId }];
    group.LstMember.forEach(member => {
      groupRequest.GroupMembersJSON.push({
        MemberId: member.EmpId
      });
    });

    this.connectApiService.createGroup(groupRequest).subscribe(response => {

      if (response.ErrorMessage.length > 0) {
        this.toast.error(response.ErrorMessage);
      } else if (response.GroupId !== undefined) {
        this.connectMessageService.selectedGroup.GroupId = response.GroupId;
        if (this.checkForEmojiUnicode(this.messageText)) {
          this.sendMessageWithEmoji();
        } else {
          this.sendMessage();
        }
        // this.sendMessage(this.messageText);
        // emit event to update the groups
        this._eventEmiter.emit({ actionType: 'reloadGroups' });

      } else {
        // Show Error Message
      }
    });
  }

  // tslint:disable-next-line: use-life-cycle-interface
  ngAfterViewChecked() {
    if (this.scrollContainer !== undefined) {
      this.scrollContainer.nativeElement.scrollTop = this.scrollContainer.nativeElement.scrollHeight;
    }
  }

  onKeyDown() {
    if (this.checkForEmojiUnicode(this.messageText)) {
      this.sendMessageWithEmoji();
    } else {
      this.sendMessage();
    }
  }

  selectEmoji(emoji: string) {
    this.showEmojis = false;
    const codePoint = +('0x' + emoji);
    this.emojiCodeArray.push(codePoint);
    this.messageText += String.fromCodePoint(codePoint);
  }

  checkForEmojiUnicode(input: string) {
    const regex = new RegExp(/\u00a9|\u00ae|[\u2000-\u3300]|\ud83c[\ud000-\udfff]|\ud83d[\ud000-\udfff]|\ud83e[\ud000-\udfff]/g);
    let match = null;
    while (match = regex.exec(input)) {
      if (match[0]) {
        return true;
      }
    }

    return false;
  }

  sendMessageWithEmoji() {
    let msg = this.messageText;
    const regex = new RegExp(/\u00a9|\u00ae|[\u2000-\u3300]|\ud83c[\ud000-\udfff]|\ud83d[\ud000-\udfff]|\ud83e[\ud000-\udfff]/g);
    let match = null;
    let i = 0;
    while (match = regex.exec(msg)) {
      if (match[0]) {
        msg = msg.replace(match[0], `{${this.emojiCodeArray[i]}}`);
      }
      i++;
    }
    this.messageWithEmoji = msg;
    this.sendMessage(this.messageWithEmoji);
  }

  replaceEmojiPresentInComment(comment: any): any {
    comment.html = comment.msg.replace(/\{(\d+)\}/g, (match: string, capture: string) => {
      if (match) {
        const path = `${this.imagePath}${Number(capture).toString(16)}.png`;
        return '<img src="' + path + '" alt="" width="24px" height="24px">';
      }
    });

    return comment;
  }

  getFileType(type: string) {
    let fileType = type.split('/')[0];
    if (fileType && fileType.length > 0) {
      fileType = fileType.toLowerCase();
      if (fileType !== this.image && fileType !== this.video && fileType !== this.audio) {
        fileType = this.text;
      }
    }
    return fileType;
  }

  onSendIconClick() {
    if (this.checkForEmojiUnicode(this.messageText)) {
      this.sendMessageWithEmoji();
    } else {
      this.sendMessage();
    }
  }
}
