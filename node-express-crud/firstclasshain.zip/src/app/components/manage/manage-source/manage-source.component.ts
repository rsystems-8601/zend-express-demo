import { Component, OnInit } from '@angular/core';
import { ActSources } from 'src/app/models/response/act-response';
import { UserDetails } from 'src/app/models/user-details-result';
import { Router, ActivatedRoute } from '@angular/router';
import { UserService } from 'src/app/services/user.service';
import { Subscription } from 'rxjs';
import { EventEmiterService } from 'src/app/services/event.emmiter.service';
// import { ActSourceService } from 'src/app/services/act-source.service';
// import * as sourceData from '../../../../assets/mock-data/manage-act-config.json';

@Component({
  selector: 'app-manage-source',
  templateUrl: './manage-source.component.html',
  styleUrls: ['./manage-source.component.scss']
})
export class ManageSourceComponent implements OnInit {

  liveDocumentSize = document.body.clientWidth;
  numberToDisplayItems: any;
  activeLinkIndex = 0;
  inititalSources: ActSources[] = [];
  otherSources: ActSources[] = [];
  dataSources: ActSources[];

  userInfo: UserDetails;
  isVisiblePlusButton: boolean;
  coacheeId: number;
  subscription: Subscription;

  constructor(
    private router: Router,
    private userService: UserService,
    private route: ActivatedRoute,
    private _eventEmiter: EventEmiterService
  ) {

    this.userInfo = this.userService.getUserDetails().UserDetails;
    this.isVisiblePlusButton = true;

    if (this.liveDocumentSize < 1024) {
      this.numberToDisplayItems = Math.round((this.liveDocumentSize - 230) / 140); // 5;
    } else {
      this.numberToDisplayItems = Math.round((this.liveDocumentSize - 530) / 140); // 5;
    }


  }

  onResize() {
    this.liveDocumentSize = document.body.clientWidth;
    if (this.liveDocumentSize < 1024) {
      this.numberToDisplayItems = Math.round((this.liveDocumentSize - 230) / 140); // 5;
    } else {
      this.numberToDisplayItems = Math.round((this.liveDocumentSize - 530) / 140); // 5;
    }
    // As we are resizing the page, user should not be navigated to first if if index number is not found.
    this.getSourcesData(false);
  }
  ngOnInit() {
    this.route.params.subscribe(params => {
      if (params.coacheeId) {
        this.coacheeId = params.coacheeId;
        // Here true is passed because this is called on application load or refresh, hence redirection to first tab is allowed.
        this.getSourcesData(true);
      }
    });

    this.subscription = this._eventEmiter.subscribe(data => {
      if (data.keyName === 'fromNotificationForManage') {
        this.selectSpecificTab(data);
      }
    });
  }

  updateActiveLinkIndex(selectedSource) {

    if (this.inititalSources.find(x => x === selectedSource)) {
      this.activeLinkIndex = this.inititalSources.findIndex(x => x === selectedSource);
    }
  }

  getSourcesData(redirect: boolean) {

    // this.actSourceService.getManageSources((actList: any) => {
    const sources = JSON.parse(localStorage.getItem('manageActSources'));
    this.dataSources = sources.Sources;
    this.inititalSources = this.deepClone(sources.Sources);
    this.otherSources = this.deepClone(sources.Sources);

    if (this.inititalSources.length > this.numberToDisplayItems) {
      this.inititalSources.splice(this.numberToDisplayItems, this.inititalSources.length);
    }

    if (this.otherSources.length > 0) {
      this.otherSources.splice(0, this.numberToDisplayItems);
    }

    const newUrl = decodeURI(this.router.url);
    const pathUrl = newUrl.split('/');
    const currentPath = pathUrl[pathUrl.length - 1];

    let indexNumber = -1;
    if (newUrl.includes('edit-task')) {
      indexNumber = this.inititalSources.findIndex(x => 'tasks' === x.Key.toLowerCase());
      // this.router.navigate(['/iCoachFirst/manage/manage', this.coacheeId]);
      // this.activeLinkIndex = 0;
    } else if (newUrl.includes('editGoal')) {
      indexNumber = this.inititalSources.findIndex(x => 'goals' === x.Key.toLowerCase());
    } else if (newUrl.includes('folder')) {
      indexNumber = this.inititalSources.findIndex(x => currentPath.toLowerCase() === x.Key.toLowerCase());
      if (indexNumber === -1) {
        indexNumber = this.otherSources.findIndex(x => currentPath.toLowerCase() === x.Key.toLowerCase());
        if (indexNumber > -1) {
          this.otherSourceClicked(this.otherSources[indexNumber]);
          return true;
        }
      }
    } else {
      indexNumber = this.inititalSources.findIndex(x => currentPath.toLowerCase() === x.Key.toLowerCase());
      if (indexNumber === -1) {
        // To check if user has requested for sources(this.otherSources) other than visible sources(this.initialSources)
        indexNumber = this.otherSources.findIndex(x => currentPath.toLowerCase() === x.Key.toLowerCase());
        if (indexNumber > -1) {
          this.otherSourceClicked(this.otherSources[indexNumber]);
          return true;
        }
      }
    }

    // below check is for cluster Competencies if user directly refreshes url for on competencies page
    // They work on Id basis and not on Keys.
    if (indexNumber === -1) {
      indexNumber = this.inititalSources.findIndex(x => x.Id ? currentPath === x.Id.toString() : false);
      if (indexNumber > -1) {
        this.activeLinkIndex = indexNumber;
      } else {
        indexNumber = this.otherSources.findIndex(x => x.Id ? currentPath === x.Id.toString() : false);
        if (indexNumber > -1) {
          this.otherSourceClicked(this.otherSources[indexNumber]);
          return true;
        }
      }
    }

    if (redirect) {
      if (indexNumber === -1 && newUrl !== `/iCoachFirst/manage/manage/${this.coacheeId}`) {
        this.router.navigate(['/iCoachFirst/manage/manage', this.coacheeId]);
        this.activeLinkIndex = 0;
      } else {
        this.activeLinkIndex = indexNumber === -1 ? 0 : indexNumber;
      }
    }
  }


  deepClone(oldArray: Object[]) {
    const newArray: any = [];
    oldArray.forEach((item) => {
      newArray.push(Object.assign({}, item));
    });

    return newArray;
  }

  otherSourceClicked(selectedSource) {

    if (this.otherSources !== undefined) {

      if (this.otherSources.find(x => x === selectedSource)) {
        this.otherSources.splice(this.otherSources.findIndex(x => x === selectedSource),
          0,
          this.inititalSources[this.numberToDisplayItems - 1]);
      }

      this.inititalSources.splice(this.numberToDisplayItems - 1, 1);
      this.inititalSources.push(selectedSource);

      if (this.otherSources.find(x => x === selectedSource)) {
        this.otherSources.splice(this.otherSources.findIndex(x => x === selectedSource), 1);
      }

      this.activeLinkIndex = this.numberToDisplayItems - 1;
    }

  }

  selectSpecificTab(data: any) {
    let indexNumber = -1;
    if (data.ItemType === 'Task') {
      indexNumber = this.inititalSources.findIndex(x => 'tasks' === x.Key.toLowerCase());
    } else if (data.ItemType === 'Goal') {
      indexNumber = this.inititalSources.findIndex(x => 'goals' === x.Key.toLowerCase());
    }

    if (indexNumber === -1) {
      this.router.navigate(['/iCoachFirst/manage/manage', this.coacheeId]);
      this.activeLinkIndex = 0;
    } else {
      this.activeLinkIndex = indexNumber;
    }
  }

}
