import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManageSourceComponent } from './manage-source.component';

describe('ManageSourceComponent', () => {
  let component: ManageSourceComponent;
  let fixture: ComponentFixture<ManageSourceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManageSourceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManageSourceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
