import { Component, OnInit } from '@angular/core';
import { HighchartService } from 'src/app/services/highchart.service';
import { ColumnChartRequest } from 'src/app/models/requests/highchart-request';
import { ChartType } from 'src/app/helpers/enums/common-enums';
import * as Highcharts from 'highcharts';
import { EngagementLevelResponseResolved } from 'src/app/models/response/act-response';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-engagement-level',
  templateUrl: './engagement-level.component.html',
  styleUrls: ['./engagement-level.component.scss']
})
export class EngagementLevelComponent implements OnInit {

  highcharts = Highcharts;
  columnChartConfig = {} as ColumnChartRequest;
  HighchartOptions: any;

  constructor(private highchartService: HighchartService,
    private route: ActivatedRoute, ) { }

  ngOnInit() {


    const resolveEngagementLevel: EngagementLevelResponseResolved = this.route.snapshot.data['getEngagementLevel'];
    const responseData = resolveEngagementLevel.engagementLevelResponse;


    this.columnChartConfig.ChartTitle = '';
    this.columnChartConfig.ChartType = ChartType.Column;
    this.columnChartConfig.Height = '50%';
    this.columnChartConfig.CategoryData = [];
    this.columnChartConfig.SeriesData = [];

    responseData.forEach(engagementLevel => {
      this.columnChartConfig.CategoryData.push(engagementLevel.BarTitle);
      this.columnChartConfig.SeriesData.push(Number(engagementLevel.AverageRating));
    });
    this.HighchartOptions = this.highchartService.CreateHighChart(this.columnChartConfig);
  }

}
