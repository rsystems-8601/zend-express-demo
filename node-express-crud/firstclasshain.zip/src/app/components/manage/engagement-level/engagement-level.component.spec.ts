import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EngagementLevelComponent } from './engagement-level.component';

describe('EngagementLevelComponent', () => {
  let component: EngagementLevelComponent;
  let fixture: ComponentFixture<EngagementLevelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EngagementLevelComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EngagementLevelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
