import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SharedDataService } from 'src/app/services/shared-data.service';
import { CommonService } from 'src/app/services/common.service';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-manage-viewer',
  templateUrl: './manage-viewer.component.html',
  styleUrls: ['./manage-viewer.component.scss']
})
export class ManageViewerComponent implements OnInit, OnDestroy {

  manageUrl: string;
  callBackComplete = false;
  constructor(private sharedDataService: SharedDataService,
    private route: ActivatedRoute,
    private commonService: CommonService,
    private authService: AuthService,
    private router: Router
  ) { }

  ngOnInit() {
    this.route.params.subscribe(params => {
      if (params.coacheeId) {
        this.manageUrl = this.sharedDataService.getData();
      }
    });
  }

  closePopupOnIframe() {
    this.commonService.closePopupOnIframe();
  }

  handleIframeTask(e) {
    window.removeEventListener('message', () => { });
    // Member variable this.callBackComplete will be false if user refreshes the url
    // and it will be true if user open this same component again and again
    // so added the check using variable
    if (!this.callBackComplete) {
      if (e.data.redirectTo === undefined && e.data.lockAngularScreen === undefined) {
        // the redirectTo will be undefined if user directly refreshes the url
        // added because this func is getting fired first if user refreshes url directly.
        return;
      }
      if (e.data.redirectTo && e.data.redirectTo === 'logout') {
        this.authService.commonLogout();
      }

      if (e.data.redirectTo === 'dashboard') {
        this.callBackComplete = true;
        let redirect = this.sharedDataService.getRedirectionValue();
        if (redirect !== undefined) {
          redirect = decodeURIComponent(redirect);
          this.router.navigate([`/${redirect}`]);
        } else {
          // If userdirectly refreshes the url the redirect value will will be undefined.
          this.router.navigate(['/iCoachFirst/dashboard']);
        }
      }
    }
  }

  ngOnDestroy() {
    this.callBackComplete = true;
    window.removeEventListener('message', () => { });
  }

}
