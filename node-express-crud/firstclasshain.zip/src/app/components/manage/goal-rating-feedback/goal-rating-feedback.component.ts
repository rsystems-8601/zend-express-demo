import { Component, OnInit } from '@angular/core';
import { ActService } from 'src/app/services/act.service';
import { UserService } from 'src/app/services/user.service';
import { HighchartService } from 'src/app/services/highchart.service';
import { ColumnChartRequest } from 'src/app/models/requests/highchart-request';
import * as Highcharts from 'highcharts';
import { ChartType } from 'src/app/helpers/enums/common-enums';

@Component({
  selector: 'app-goal-rating-feedback',
  templateUrl: './goal-rating-feedback.component.html',
  styleUrls: ['./goal-rating-feedback.component.scss']
})
export class GoalRatingFeedbackComponent implements OnInit {

  responseDataRatings: any;
  EmpId: number;
  highcharts = Highcharts;
  columnChartConfig = {} as ColumnChartRequest;
  HighchartOptions: any;

  responseData: any;

  arraySection = [];
  sectionKey = [];
  sectionKRAId = [];
  isManageView = false;
  repId: number;
  user: any;

  constructor(private actService: ActService,
    private userService: UserService,
    private highchartService: HighchartService) {
    this.user = this.userService.getUserDetails();
    if (this.user !== undefined && this.user.CoacheeDetails !== undefined && this.user.IsRepView) {
      this.isManageView = true;
      this.repId = this.user.CoacheeDetails.UserDetails.EmpId;
    } else {
      this.isManageView = false;
    }

  }

  ngOnInit() {

    if (this.user.UserDetails.EmpId) {
      this.EmpId = this.isManageView ? this.repId : this.user.UserDetails.EmpId;
    }

    this.actService.getGoalRatingFeedback(this.EmpId).subscribe((actList: any) => {

      if (actList !== undefined) {
        this.responseData = actList;
        /* --  Horizontal points  chart start -- */
        if (this.responseData.GoalRatings !== undefined) {
          this.responseData.GoalRatings.forEach(item => {
            const ratingValue = parseInt(item.Rating, 10);
            if (this.sectionKey.indexOf(item.KRATitle) >= 0
              && this.sectionKRAId[this.sectionKey.indexOf(item.KRATitle)] === item.KRAId
            ) {
              if (ratingValue === 5) { this.arraySection[this.sectionKey.indexOf(item.KRATitle)][2] = item.TotalRatings; }
              if (ratingValue === 4) { this.arraySection[this.sectionKey.indexOf(item.KRATitle)][3] = item.TotalRatings; }
              if (ratingValue === 3) { this.arraySection[this.sectionKey.indexOf(item.KRATitle)][4] = item.TotalRatings; }
              if (ratingValue === 2) { this.arraySection[this.sectionKey.indexOf(item.KRATitle)][5] = item.TotalRatings; }
              if (ratingValue === 1) { this.arraySection[this.sectionKey.indexOf(item.KRATitle)][6] = item.TotalRatings; }
              if (item.TotalRatings) {
                if (parseInt(this.arraySection[this.sectionKey.indexOf(item.KRATitle)][1], 10) < parseInt(item.TotalRatings, 10)) {
                  this.arraySection[this.sectionKey.indexOf(item.KRATitle)][1] = item.TotalRatings;
                }
              }
            } else {
              this.sectionKey.push(item.KRATitle);
              this.sectionKRAId.push(item.KRAId);
              this.arraySection.push([
                item.KRATitle,
                item.TotalRatings,
                (ratingValue === 5 ? item.TotalRatings : 0),
                (ratingValue === 4 ? item.TotalRatings : 0),
                (ratingValue === 3 ? item.TotalRatings : 0),
                (ratingValue === 2 ? item.TotalRatings : 0),
                (ratingValue === 1 ? item.TotalRatings : 0)
              ]
              );
            }

          });


          this.responseDataRatings = this.arraySection;
        }


        /* --  Horizontal points  chart finished -- */
        /* --  Vertival feedback chart start  --  */

        if (typeof this.responseData.GoalFeedbacks !== 'undefined') {

          this.columnChartConfig.ChartTitle = '';
          this.columnChartConfig.ChartType = ChartType.Column;
          this.columnChartConfig.Height = '50%';
          this.columnChartConfig.CategoryData = [];
          this.columnChartConfig.SeriesData = [];

          this.responseData.GoalFeedbacks.forEach(feedbackLevel => {
            this.columnChartConfig.CategoryData.push(feedbackLevel.BarTitle);
            this.columnChartConfig.SeriesData.push(Number(feedbackLevel.AverageRating));
          });
          this.HighchartOptions = this.highchartService.CreateHighChart(this.columnChartConfig);

        }


        /* --  Vertival feedback chart finished  --  */


      }
    });





  }
}
