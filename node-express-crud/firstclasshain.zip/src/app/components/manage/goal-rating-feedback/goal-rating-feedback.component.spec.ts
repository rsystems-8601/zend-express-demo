import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GoalRatingFeedbackComponent } from './goal-rating-feedback.component';

describe('GoalRatingFeedbackComponent', () => {
  let component: GoalRatingFeedbackComponent;
  let fixture: ComponentFixture<GoalRatingFeedbackComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GoalRatingFeedbackComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GoalRatingFeedbackComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
