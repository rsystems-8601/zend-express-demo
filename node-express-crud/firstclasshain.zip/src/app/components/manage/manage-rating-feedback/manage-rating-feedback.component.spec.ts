import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManageRatingFeedbackComponent } from './manage-rating-feedback.component';

describe('ManageRatingFeedbackComponent', () => {
  let component: ManageRatingFeedbackComponent;
  let fixture: ComponentFixture<ManageRatingFeedbackComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManageRatingFeedbackComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManageRatingFeedbackComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
