import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PerformanceJournalComponent } from './performance-journal.component';

describe('PerformanceJournalComponent', () => {
  let component: PerformanceJournalComponent;
  let fixture: ComponentFixture<PerformanceJournalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PerformanceJournalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PerformanceJournalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
