import { Component, OnInit, Input } from '@angular/core';
import { PerformanceJournal } from 'src/app/models/response/act-response';
import { ConfirmationDialogService } from '../../shared/confirmation-dialog/confirmation-dialog.service';
import { IcftoasterService } from 'src/app/services/icftoaster.service';
import { UserService } from 'src/app/services/user.service';
import { EventEmiterService } from 'src/app/services/event.emmiter.service';
import { MyNotesService } from 'src/app/services/my-notes.service';

@Component({
  selector: 'app-performance-journal',
  templateUrl: './performance-journal.component.html',
  styleUrls: ['./performance-journal.component.scss']
})
export class PerformanceJournalComponent implements OnInit {

  @Input() performanceJournalData: PerformanceJournal;

  constructor(private confirmationDialogService: ConfirmationDialogService,
    private toast: IcftoasterService,
    private userService: UserService,
    private _eventEmiter: EventEmiterService,
    private myNotesService: MyNotesService) { }
  ngOnInit() {

  }

  deletePerformanceJournal() {
    this.confirmationDialogService.confirm('Common_Confirm_Delete',
      'Common_Yes',
      'Common_No').subscribe(value => {

        if (value) {
          this.deleteData();
        }
      });
  }

  deleteData() {

    const userInfo = this.userService.getUserDetails();
    const deletePerformanceJournal = {
      deletedBy: userInfo.UserDetails.EmpId,
      deletedTableId: this.performanceJournalData.Id,
      needToDeleteFor: 'PerformanceJournal'
    };

    this.myNotesService.deletePerformanceJournal(deletePerformanceJournal).subscribe(response => {

      const result = response.DeleteDataForSpecificWorkResult;
      if (result.ResultStatusCode === '1040') {

        this._eventEmiter.emit({ actionType: 'GetPerformanceJournal' });
        this.toast.success('Record deleted successfully.', '', () => {

        });
      } else {
        this.toast.error(result.ErrorMessage);
      }
    });
  }


}
