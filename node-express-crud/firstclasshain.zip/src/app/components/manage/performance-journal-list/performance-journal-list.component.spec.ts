import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PerformanceJournalListComponent } from './performance-journal-list.component';

describe('PerformanceJournalListComponent', () => {
  let component: PerformanceJournalListComponent;
  let fixture: ComponentFixture<PerformanceJournalListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PerformanceJournalListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PerformanceJournalListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
