import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActService } from 'src/app/services/act.service';
import {
  PerformanceJournal, PerformanceJournalResponseResolved,
  DownloadPerformanceJournalExcelResponse
} from 'src/app/models/response/act-response';
import { ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { IcftoasterService } from 'src/app/services/icftoaster.service';
import { UserService } from 'src/app/services/user.service';
import { MyNotesService } from 'src/app/services/my-notes.service';
import { SaveEditorRequest, Editor } from 'src/app/models/requests/my-notes-request';
import { Guid } from 'guid-typescript';
import { Review_Journal } from 'src/app/helpers/enums/common-enums';
import { Subscription } from 'rxjs';
import { EventEmiterService } from 'src/app/services/event.emmiter.service';

@Component({
  selector: 'app-performance-journal-list',
  templateUrl: './performance-journal-list.component.html',
  styleUrls: ['./performance-journal-list.component.scss']
})
export class PerformanceJournalListComponent implements OnInit, OnDestroy {

  responseData: PerformanceJournal[];
  filteredData: PerformanceJournal[];
  isVisibleAddButton: boolean;
  isVisibleSearchPanel: boolean;
  isVisibleSearchPopup: boolean;

  performanceJournalForm: FormGroup;
  searchForm: FormGroup;
  submitted = false;
  performanceJournalEntry: string;
  SubmittedFromDate: Date;
  SubmittedToDate: Date;
  minDate: Date;
  subscription: Subscription;
  toMinDate: Date;

  constructor(

    private actService: ActService,
    private route: ActivatedRoute,
    private formBuilder: FormBuilder,
    private toast: IcftoasterService,
    private userService: UserService,
    private myNotesService: MyNotesService,
    private _eventEmiter: EventEmiterService) {

    this.isVisibleAddButton = true;
    this.isVisibleSearchPanel = false;
    this.isVisibleSearchPopup = false;

    this.minDate = new Date();
    this.toMinDate = new Date();

  }

  ngOnInit() {
    this.subscription = this._eventEmiter.subscribe(data => {

      if (data.actionType === 'GetPerformanceJournal') {
        const userInfo = this.userService.getUserDetails();
        this.reloadData(userInfo.CoacheeDetails.UserDetails.EmpId, false, false);
      }
    });

    this.getPerformanceJournalData();

    this.performanceJournalForm = this.formBuilder.group({
      performanceJournalComment: ['', Validators.required],
    });

    this.searchForm = this.formBuilder.group({
      SubmittedFrom: ['', Validators.required],
      SubmittedTo: ['', Validators.required],
    });

  }

  ngOnDestroy() {
    this._eventEmiter.unsubscribe(this.subscription);
  }

  getPerformanceJournalData() {
    const userInfo = this.userService.getUserDetails();
    const resolvePerformanceJournal: PerformanceJournalResponseResolved = this.route.snapshot.data['getPerformanceJournal'];
    this.responseData = resolvePerformanceJournal.performanceJournalResponse.filter(t => t.ManagerId === userInfo.UserDetails.EmpId);
    this.filteredData = resolvePerformanceJournal.performanceJournalResponse.filter(t => t.ManagerId === userInfo.UserDetails.EmpId);
  }

  reloadData(repId, isForSearch, isForDownload) {

    let request = { RepId: repId, PageRequest: null };
    if (isForSearch) {
      request = {
        RepId: repId,
        PageRequest: { FromDate: this.SubmittedFromDate, ToDate: this.SubmittedToDate }
      };
    }

    if (isForDownload) {

      this.actService.downloadPerformanceJournal(request).
        subscribe((response: DownloadPerformanceJournalExcelResponse) => {
          if (response.IsSuccess) {
            window.open(response.Data, 'blank');

          } else {
            this.toast.error('Something went wrong. Please try again.');
          }
        });


    } else {
      this.actService.getPerformanceJournal(request).
        subscribe((response: PerformanceJournal[]) => {
          const userInfo = this.userService.getUserDetails();
          this.responseData = response.filter(t => t.ManagerId === userInfo.UserDetails.EmpId);
          this.filteredData = response.filter(t => t.ManagerId === userInfo.UserDetails.EmpId);
        });
    }
  }


  get f() {
    return this.performanceJournalForm.controls;
  }

  get sf() {
    return this.searchForm.controls;
  }

  onSubmit() {

    this.submitted = true;
    if (this.performanceJournalEntry.trim() === '') {
      this.performanceJournalEntry = '';
      this.performanceJournalForm.get('performanceJournalComment').setErrors({'required': true});
      return;
    }
    if (this.performanceJournalForm.invalid) {
      return;
    }
    this.assignPerformanceJournal();
  }

  assignPerformanceJournal() {
    const request = {} as SaveEditorRequest;
    const editor = {} as Editor;
    request.Editors = [];
    const userInfo = this.userService.getUserDetails();
    editor.CKEditorId = 'editor-tfGUID-' + Guid.create().toString();
    editor.CKEditorContent = this.performanceJournalEntry;
    editor.ReviewType = Review_Journal.REVIEW_LEFTPANEL_JOURNAL.toString();
    request.CreatedBy = userInfo.UserDetails.EmpId;
    request.MemberOrgId = userInfo.UserDetails.MemberOrgID;
    request.RepId = userInfo.CoacheeDetails.UserDetails.EmpId;
    request.LoggedInEmpId = userInfo.UserDetails.EmpId;
    request.IsNonEditorData = true;
    request.Editors.push(editor);

    this.myNotesService.savePerformanceJournal(request).subscribe(data => {
      if (data === true) {
        this.toast.success('Common_UpdateSuccess');
        this.performanceJournalEntry = undefined;
        this.submitted = false;
        this.isVisibleSearchPanel = false;
        this.isVisibleAddButton = true;
        this.reloadData(userInfo.CoacheeDetails.UserDetails.EmpId, false, false);
      } else {
        this.toast.error('Something went wrong. Please try again.');
      }
    });
  }

  addButtonClicked() {
    this.submitted = false;
    this.isVisibleAddButton = false;
  }

  cancelButtonClicked() {
    this.isVisibleAddButton = true;
    this.submitted = false;
    this.performanceJournalEntry = '';
  }

  openSearchPopup() {
    this.isVisibleSearchPopup = !this.isVisibleSearchPopup;
  }

  showSearchPanel() {

    this.SubmittedFromDate = null;
    this.SubmittedToDate = null;
    this.submitted = false;
    this.isVisibleSearchPanel = true;
    this.isVisibleSearchPopup = false;
  }

  downloadXls() {

    this.submitted = false;
    this.isVisibleSearchPopup = false;

    const userInfo = this.userService.getUserDetails();

    this.reloadData(userInfo.CoacheeDetails.UserDetails.EmpId,
      ((this.SubmittedFromDate !== null || this.SubmittedFromDate !== undefined) &&
        (this.SubmittedToDate !== null || this.SubmittedToDate !== undefined)) ? true : false,
      true);
  }

  resetSearchPanel() {
    this.SubmittedFromDate = null;
    this.SubmittedToDate = null;
    this.isVisibleAddButton = true;
    this.isVisibleSearchPanel = false;
    const userInfo = this.userService.getUserDetails();
    this.reloadData(userInfo.CoacheeDetails.UserDetails.EmpId, false, false);
  }

  onSearchSubmit() {

    this.submitted = true;
    if (this.searchForm.invalid) {
      return;
    }
    this.searchPerformanceJournal();
  }

  submittedFromDateChanged(pop: any) {
    if (pop.isOpen) {

      setTimeout(() => {
        this.toMinDate = new Date(pop._bsValue);
        if (this.validDate() === false) {
          this.SubmittedFromDate = null;
          this.toMinDate = null;
        }

      }, 300);
    }
  }

  submittedToDateChanged(pop: any) {
    if (pop.isOpen) {
      setTimeout(() => {
        if (this.validDate() === false) {
          this.SubmittedToDate = null;
        }
      }, 300);
    }
  }

  validFromDate() {
    return true;
  }

  validDate() {

    if (this.SubmittedFromDate !== undefined && (this.SubmittedToDate === undefined || this.SubmittedToDate === null)) {
      return true;

    } else if ((this.SubmittedFromDate === undefined || this.SubmittedFromDate === null) && this.SubmittedToDate !== undefined) {
      return true;

    } else if (this.SubmittedFromDate !== null && this.SubmittedToDate !== null) {

      if (this.SubmittedToDate < this.SubmittedFromDate) {
        return false;
      }
    }
    return true;
  }

  searchPerformanceJournal() {
    const userInfo = this.userService.getUserDetails();
    this.reloadData(userInfo.CoacheeDetails.UserDetails.EmpId, true, false);
  }

}
