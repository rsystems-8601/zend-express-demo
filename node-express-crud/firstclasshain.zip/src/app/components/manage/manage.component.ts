import { ActivatedRoute } from '@angular/router';
import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { UserService } from 'src/app/services/user.service';
import { UserProfileService } from '../../services/user-profile.service';
import { UserDetails } from 'src/app/models/user-details-result';
import { IMyTeamResponse } from '../../models/response/imyteam-response';
import { User } from '../../models/response/user-response';
import { MatDialog, MatDialogConfig } from '@angular/material';
import { ApplicationModuleListEnum } from '../../helpers/enums/common-enums';
import { AssignQuickFeedbackComponent } from '../quick-feedback/assign-quick-feedback/assign-quick-feedback.component';
import { IUserProfileUrlRequest } from 'src/app/models/requests/url-builder/user-profile-url-request';
import { IframeModalComponent } from '../shared/iframe-modal/iframe-modal.component';
import { LocalizationService } from 'src/app/services/localization.service';
import { IGroup } from '../connect/connect-interfaces';
import { ConnectMessageService } from 'src/app/services/connect-message.service';
import { ICoachingReportResponse } from 'src/app/models/response/icoaching-report-response';
import { UserPermissions } from 'src/app/helpers/enums/common-enums';
import { RolesService } from 'src/app/services/roles.service';
import { SharedDataService } from 'src/app/services/shared-data.service';
import { ConfirmationDialogService } from '../shared/confirmation-dialog/confirmation-dialog.service';
import { EventEmiterService } from 'src/app/services/event.emmiter.service';
import { CommonService } from 'src/app/services/common.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-manage',
  templateUrl: './manage.component.html',
  styleUrls: ['./manage.component.scss']
})

export class ManageComponent implements OnInit {
  coacheeName: string;
  coacheeProfilePicUrl: string;
  designation: string;
  myTeamList: IMyTeamResponse[] = [];
  teamList: User[] = [];
  coachesList: User[] = [];
  peersList: User[] = [];
  userInfo: UserDetails;
  coacheeData: User;
  coacheeId = 0;
  isFlyoutOpen = false;
  applicationModuleId: number = ApplicationModuleListEnum.None;
  selectedTeamMember: User;
  manageUrl: string;
  activeItemName = '';
  hasPermissionToAddAdditionalMgr = false;
  coachingReportList: ICoachingReportResponse[] = [];
  reportUrl: string;
  @Output() setLeftContainerVisibility: EventEmitter<number> = new EventEmitter<number>();
  teamGroups: IGroup[] = [];
  selectedGroupIndex: number;
  UserPermissions = UserPermissions;
  flyoutMenuItem: any;
  isVideoEnable = false;
  coacheeEmail: string;
  IsSelectedUserOnline = false;
  onlineUsers = [];
  onlineUsersCollection: Subscription;
  customVideoClass: string;

  constructor(
    private userService: UserService,
    private route: ActivatedRoute,
    private localizationService: LocalizationService,
    private dialog: MatDialog, private profileService: UserProfileService,
    private connectMessageService: ConnectMessageService,
    private roleService: RolesService,
    private sharedDataService: SharedDataService,
    private confirmationDialogService: ConfirmationDialogService,
    private _eventEmiter: EventEmiterService,
    private commonService: CommonService
  ) {

  }

  ngOnInit() {
    this.route.params.subscribe(params => {
      if (params.coacheeId) {
        const userDetails = this.userService.getUserDetails();
        if (userDetails.CoacheeDetails) {
          this.coacheeName = userDetails.CoacheeDetails.UserDetails.Name;
          this.coacheeProfilePicUrl = userDetails.CoacheeDetails.UserDetails.ProfileImageName;
          this.designation = userDetails.CoacheeDetails.UserDetails.Designation;
          this.coacheeData = userDetails.CoacheeDetails.UserDetails;
          this.coacheeId = this.coacheeData.EmpId;
          this.coacheeEmail = this.coacheeData.EmailId;

          this.flyoutMenuItem = this.roleService.getFlyoutMenuItem('Video Chat');
          if (this.flyoutMenuItem.OnOffValue) {
            this.isVideoEnable = true;
          }

          this.onlineUsersCollection = this.sharedDataService.getOnlineUsersCollection().subscribe(response => {
            if (response !== undefined && response.length > 0) {
              this.onlineUsers = response;
              const userOnline = this.onlineUsers.find(obj => obj === this.coacheeData.EmailId.trim());
              if (userOnline !== undefined) {
                this.IsSelectedUserOnline = true;
                this.customClass(true);
              } else {
                this.IsSelectedUserOnline = false;
                this.customClass(false);
              }
            } else {
              this.customClass(false);
            }
          });

        }
      }
    });

  }

  /*
    subscribeEvents() {
      this.teamGroups = this.connectMessageService.getAllGroups();
      for (const setgroup of this.teamGroups) {
        const arrGroup = (setgroup.LstMember);
        if (this.my_coaches_short_cut) {
          break;
        }
        for (const team of arrGroup) {
          if (team.EmpId === this.coacheeId) {
            if ((setgroup.GroupName) === 'My Coaches') {
              this.my_coaches_short_cut = true;
              break;
            } else {
              this.my_coaches_short_cut = false;
            }
          } else {
            this.my_coaches_short_cut = false;
          }
        }
      }
    }
  */

  //  Clone method so make changes both side \iCoachFirst\src\app\components\my-team\my-team.component.ts :: OpenAssignQuickFeedback
  shortCutOpenAssignQuickFeedback() {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.width = '600px';
    dialogConfig.disableClose = true;

    const userDetails = this.userService.getUserDetails().UserDetails;
    dialogConfig.data = {
      ManagerId: userDetails.EmpId,
      RepId: this.coacheeId,
      CommentedBy: userDetails.EmpId,
      IsRequestFeedback: false,
      // IsOutOfHierarchy: false,
      feedbackUserDetails: this.coacheeData,
      feedbackPopUpTitle: 'LeftPanel_MyTeam_QuickFeedback',
    };
    this.dialog.open(AssignQuickFeedbackComponent, dialogConfig);
  }


  //  Clone method so make changes both side \iCoachFirst\src\app\components\my-team\my-team.component.ts :: openChat
  shortCutOpenChat(origin) {
    this.connectMessageService.openChat(this.coacheeData);

    if (origin === 'coach') {
      // this.coachPopover.hide();
    } else if (origin === 'peers') {
      // this.peersPopover.hide();
    } else if (origin === 'custom') {
      // this.customGroupPopover.hide();
    } else {
      // this.teamPopover.hide();
    }
  }

  //  Clone method so make changes both side \iCoachFirst\src\app\components\my-team\my-team.component.ts :: OpenMyProfileMatPop
  shortCutOpenMyProfileMatPop() {
    const request = {} as IUserProfileUrlRequest;
    request.EmpId = this.coacheeId;
    request.EmpName = this.coacheeData.Name;
    request.MemberOrgID = this.coacheeData.MemberOrgID;
    request.Source = 'icf6';
    request.PagePath = 'MyProfile';
    request.Culture = this.localizationService.getICF6CultreFromLocalStorage().CultureCode;
    const dialogConfig = new MatDialogConfig();
    dialogConfig.width = 900 + 'px';
    dialogConfig.disableClose = true;
    request.eid = this.coacheeData.EmpId; // this.coacheeData.EmployeeId;
    const reportUrl = this.profileService.getUserProfilePageUrl(request);
    dialogConfig.data = { url: reportUrl };
    this.dialog.open(IframeModalComponent, dialogConfig);
    return false;
  }

  //  Clone method so make changes both side \iCoachFirst\src\app\components\my-team\my-team.component.ts :: RequestQuickFeedback
  shortCutRequestQuickFeedback() {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.width = '600px';
    dialogConfig.disableClose = true;

    const userDetails = this.userService.getUserDetails().UserDetails;
    dialogConfig.data = {
      ManagerId: this.coacheeId,
      RepId: userDetails.EmpId,
      CommentedBy: userDetails.EmpId,
      IsRequestFeedback: true,
      // IsOutOfHierarchy: (this.coacheeId === userDetails.ManagerId) ? false : true,
      feedbackUserDetails: this.coacheeData,
      feedbackPopUpTitle: 'LeftPanel_MyTeam_RequestQuickFeedback'
    };
    this.dialog.open(AssignQuickFeedbackComponent, dialogConfig);
  }

  startVideoChat(itemName: string) {
    const teammember = this.coacheeData;
    this.flyoutMenuItem = this.roleService.getFlyoutMenuItem(itemName);
    if (this.flyoutMenuItem.OnOffValue && this.IsSelectedUserOnline) {
      const retreiveDetails = this.sharedDataService.getVideoSessionDetails();
      if (retreiveDetails === undefined) { // new chat start request
        const confirmBoxText = this.commonService.prepareParameterizedConfim(['Request_for_VideoChat', teammember.Name]);
        this.confirmationDialogService.confirm(confirmBoxText, 'Common_Yes', 'Common_No').subscribe(value => {
          if (value) {
            this.openVideoChat();
          }
        });
      } else { // add request to the already going chat
        const confirmBoxText = this.commonService.prepareParameterizedConfim(['AdditionalRequest_for_VideoChat', teammember.Name]);
        this.confirmationDialogService.confirm(confirmBoxText, 'Common_Yes', 'Common_No').subscribe(value => {
          if (value) {
            this.openVideoChat();
            this.connectMessageService.sendMessageToUser(this.sharedDataService.getVideoSessionDetails(), this.selectedTeamMember.EmailId.trim());
          }
        });
      }
    }
  }

  openVideoChat() {
    this._eventEmiter.emit({ actionType: 'openVideoChatPanel' });
    this.sharedDataService.setVideoChatUsersCollection(this.coacheeData.EmailId.trim());
    // // this opens video chat in the main window
    // this.router.navigate(['/iCoachFirst/learn/videochat']);
    // this.commonService.closeleftMenuForiPad();
    // this.closePopover(popoverType);
    // this.openVideoChatComponentLeftContainer(ApplicationModuleListEnum.None);
  }

  customClass(userStatus: boolean) {
    if (userStatus) {
      this.customVideoClass = 'fas icon_edit fa-video';
    } else {
      this.customVideoClass = 'fas icon_edit fa-video opacity12';
    }
  }
}
