import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { MatDialog, MatDialogConfig, MatTabChangeEvent } from '@angular/material';
import { LearnSelfAssignComponent } from '../../../components/learn/modal-popup/self-assign/learn-self-assign.component';
import { LearnAssignComponent } from '../../../components/learn/modal-popup/assign/learn-assign.component';
import { LearnReviewComponent } from '../../../components/learn/modal-popup/review/learn-review.component';
import { ReviewPopupRequest } from '../../../models/requests/learn/learn-self-assign-request';
import { LearnService } from '../../../services/learn.service';
import {
  AssignedToMe, FeaturedTrainings, Categories, Competencies, RecentlyAdded,
  HighestRated, AssignedByMe
} from '../../../models/response/learn/learn-response';
import { LearnModalPopupEnum } from '../../../helpers/enums/learn-enums';
import {
  SearchFilter, CategorySearchFilter, TrainingTypeSearchFilter,
  CompetencySearchFilter
} from '../../../models/response/learn/learn-search-filter-response';
import { SearchParam } from '../../../models/requests/learn/learn-search-parameter-request';
import { EventEmiterService } from 'src/app/services/event.emmiter.service';
import { Subscription } from 'rxjs';
import { CommonService } from 'src/app/services/common.service';
import { TrainingContentComponent } from '../modal-popup/training-content/training-content.component';
import { UserDetails } from 'src/app/models/user-details-result';
import { UserService } from 'src/app/services/user.service';
import { environment } from 'src/environments/environment';
import { AssignTrainingService } from 'src/app/services/assign-training.service';

@Component({
  selector: 'app-training-catalog',
  templateUrl: './training-catalog.component.html',
  styleUrls: ['./training-catalog.component.scss']
})

export class TrainingCatalogComponent implements OnInit, OnDestroy {

  isShowCategoryBackButton = false;
  isShowCompetencyBackButton = false;
  isShowAdvanceSearch = false;
  reviewPopupRequest: ReviewPopupRequest = new ReviewPopupRequest();
  featuredTrainingList: Array<FeaturedTrainings> = [];
  assignedToMeList: Array<AssignedToMe> = [];
  categoryList: Array<Categories> = [];
  competencyList: Array<Competencies> = [];
  recentlyAddedList: Array<RecentlyAdded> = [];
  highestRatedList: Array<HighestRated> = [];
  assignedByMeList: Array<AssignedByMe> = [];
  learnListBycategory: Categories;
  learnListByCompetency: Competencies;
  activeSlideIndex = 0;
  // Search/filter
  learnSearchFilter: SearchFilter = new SearchFilter();
  categoryFilteredList: Array<number> = new Array<number>();
  competencyFilteredList: Array<number> = new Array<number>();
  typeFilteredList: Array<number> = new Array<number>();
  learnSearchParam: SearchParam = new SearchParam();
  private subscription: Subscription;
  filterAction = 'Category';
  clickFileterClass = '';
  groupRecord = [];

  categoryLoop = [];
  categoryLoop2 = [];
  categoryLoopIndex = [];
  categoryLoopIndex2 = [];
  categoryLoopContentId = [];

  typeNameLoop = [];
  typeNameLoopIndex = [];
  typeNameLoop2 = [];
  typeNameLoopIndex2 = [];
  typeNameLoopContentId = [];

  trainingNameLoop = [];
  shortedTrainingNameLoop = [];
  trainingNameLoopIndex = [];
  trainingNameLoopContentId = [];

  loopOfGroupRecord = [];
  loopOfGroupRecord1 = [];
  loopOfGroupRecord2 = [];
  loopOfGroupRecord3 = [];

  loopOfGroupRecordCategory = [];
  loopOfGroupRecordCategory3 = [];
  loopOfGroupRecordCategory4 = [];

  loopOfGroupRecordType = [];
  loopOfGroupRecordType3 = [];
  loopOfGroupRecordType4 = [];
  enterSearchText = '';
  enterAdvanceSearchText = '';
  userInfo: UserDetails;
  domain = `${environment.domainName}`;

  constructor(private learnService: LearnService,
    private dialog: MatDialog,
    private router: Router,
    // private toast: IcftoasterService,
    private _eventEmiter: EventEmiterService,
    private commonService: CommonService,
    private userService: UserService,
    private assignTrainingService: AssignTrainingService,
  ) { }

  ngOnInit() {
    this.getLearnData();
    this.getLearnSearchFilter();
    this.subscription = this._eventEmiter.subscribe(data => {
      if (data.actionType === 'UpdateAssignToMe' || data.actionType === 'AssignTraining') {
        this.getLearnSearchData();
      }
    });
    this.userInfo = this.userService.getUserDetails().UserDetails;
  }

  // #region Get Learn Data
  // To get learn data without filter
  getLearnData() {

    this.featuredTrainingList = [];
    this.assignedToMeList = [];
    this.categoryList = [];
    this.competencyList = [];
    this.recentlyAddedList = [];
    this.highestRatedList = [];
    this.assignedByMeList = [];

    this.learnService.getLearnData().subscribe(resultData => {
      const learnData = JSON.parse(JSON.stringify(resultData));
      this.featuredTrainingList = learnData.FeaturedTrainings;
      this.assignedToMeList = learnData.AssignedToMe;
      this.categoryList = learnData.Categories;
      this.competencyList = learnData.Competencies;
      this.recentlyAddedList = learnData.RecentlyAdded;
      this.highestRatedList = learnData.HighestRated;
      this.assignedByMeList = learnData.AssignedByMe;
      this.getFilteredData(learnData);
    },
      () => {
        // default condition;
      }
    );
  }


  getFilteredData(learnData: any) {

    this.loopOfGroupRecord = [];
    this.loopOfGroupRecord1 = [];
    this.loopOfGroupRecord2 = [];
    this.loopOfGroupRecord3 = [];

    this.loopOfGroupRecordCategory = [];
    this.loopOfGroupRecordCategory3 = [];
    this.loopOfGroupRecordCategory4 = [];


    this.loopOfGroupRecordType = [];
    this.loopOfGroupRecordType3 = [];
    this.loopOfGroupRecordType4 = [];

    this.groupRecord = [];
    this.categoryLoop = [];
    this.categoryLoopIndex = [];
    this.categoryLoopContentId = [];

    this.typeNameLoop = [];
    this.typeNameLoopIndex = [];
    this.typeNameLoopContentId = [];

    this.trainingNameLoop = [];
    this.shortedTrainingNameLoop = [];
    this.trainingNameLoopIndex = [];
    this.trainingNameLoopContentId = [];


    if (learnData.FeaturedTrainings) {
      this.groupRecord = this.groupRecord.concat(learnData.FeaturedTrainings);

    }
    if (learnData.AssignedToMe) {
      this.groupRecord = this.groupRecord.concat(learnData.AssignedToMe);
    }
    if (learnData.Competencies) {

      this.groupRecord = this.groupRecord.concat(learnData.Competencies);
    }
    if (learnData.RecentlyAdded) {

      this.groupRecord = this.groupRecord.concat(learnData.RecentlyAdded);
    }
    if (learnData.HighestRated) {

      this.groupRecord = this.groupRecord.concat(learnData.HighestRated);
    }
    if (learnData.AssignedByMe) {

      this.groupRecord = this.groupRecord.concat(learnData.AssignedByMe);
    }

    this.groupRecord.forEach(objStatus => {
      if (objStatus.TrainingName !== undefined && objStatus.TrainingName !== '' && objStatus.TrainingName !== null && objStatus.TrainingName) {
        if (this.loopOfGroupRecord.indexOf(objStatus.TrainingName) === -1) {
          this.loopOfGroupRecord.push(objStatus.TrainingName);
          this.loopOfGroupRecord1.push(objStatus);
          this.loopOfGroupRecord2.push(objStatus.TrainingName);
        }
      }

      if (objStatus.CategoryName !== undefined && objStatus.CategoryName !== '' && objStatus.CategoryName !== null && objStatus.CategoryName) {
        if (this.loopOfGroupRecordCategory.indexOf(objStatus.CategoryName) === -1) {
          this.loopOfGroupRecordCategory.push(objStatus.CategoryName);
        }
      }

      if (objStatus.TypeName !== undefined && objStatus.TypeName !== '' && objStatus.TypeName !== null && objStatus.TypeName) {
        if (this.loopOfGroupRecordType.indexOf(objStatus.TypeName) === -1) {
          this.loopOfGroupRecordType.push(objStatus.TypeName);
        }
      }
    });

    this.loopOfGroupRecord.sort(function (a: any, b: any) {
      if (a.toLowerCase() < b.toLowerCase()) { return -1; }
      if (a.toLowerCase() > b.toLowerCase()) { return 1; }
      return 0;
    });

    this.loopOfGroupRecordCategory.sort(function (a: any, b: any) {
      if (a.toLowerCase() < b.toLowerCase()) { return -1; }
      if (a.toLowerCase() > b.toLowerCase()) { return 1; }
      return 0;
    });

    this.loopOfGroupRecordType.sort(function (a: any, b: any) {
      if (a.toLowerCase() < b.toLowerCase()) { return -1; }
      if (a.toLowerCase() > b.toLowerCase()) { return 1; }
      return 0;
    });

    this.loopOfGroupRecord.forEach(TrainingName => {
      if (TrainingName !== undefined && TrainingName !== '' && TrainingName !== null && TrainingName) {
        const oldCli = this.loopOfGroupRecord2.indexOf(TrainingName);
        this.loopOfGroupRecord3.push(this.loopOfGroupRecord1[oldCli]);
      }
    });

    this.loopOfGroupRecord3.forEach(objStatus => {
      if (this.loopOfGroupRecordCategory.indexOf(objStatus.CategoryName) !== -1) {
        const oldCli = this.loopOfGroupRecordCategory.indexOf(objStatus.CategoryName);
        if (!this.loopOfGroupRecordCategory3[oldCli]) {
          this.loopOfGroupRecordCategory3[oldCli] = [];
        }
        this.loopOfGroupRecordCategory3[oldCli].push(objStatus);
      }
      if (this.loopOfGroupRecordType.indexOf(objStatus.TypeName) !== -1) {
        const oldCli = this.loopOfGroupRecordType.indexOf(objStatus.TypeName);
        if (!this.loopOfGroupRecordType3[oldCli]) {
          this.loopOfGroupRecordType3[oldCli] = [];
        }
        this.loopOfGroupRecordType3[oldCli].push(objStatus);
      }
    });
  }

  arraySwap(arra: any) {
    if (arra.length > 2) {
      const a = arra[0];
      const b = arra[arra.length - 1];
      arra[arra.length - 1] = a;
      arra[0] = b;
    }
    return arra;
  }

  // To get learn data with filter(s)
  getLearnSearchData(enterSearchText = '') {
    this.learnSearchParam.CategoryIds = this.categoryFilteredList.join();
    this.learnSearchParam.CompetencyIds = this.competencyFilteredList.join();
    this.learnSearchParam.TypeIds = this.typeFilteredList.join();
    this.toggleAdvanceSearch(false);
    if (enterSearchText === 'filter') {
      this.learnSearchParam.Title = this.enterSearchText;
      this.enterAdvanceSearchText = '';
    }
    if (enterSearchText === 'search') {
      this.learnSearchParam.Title = this.enterAdvanceSearchText;
      this.enterSearchText = '';
    }

    this.featuredTrainingList = [];
    this.assignedToMeList = [];
    this.categoryList = [];
    this.competencyList = [];
    this.recentlyAddedList = [];
    this.highestRatedList = [];
    this.assignedByMeList = [];

    this.learnService.getLearnSearchData(this.learnSearchParam).subscribe(resultData => {
      const learnData = JSON.parse(JSON.stringify(resultData)).TrainingSearchDataResult;
      this.featuredTrainingList = learnData.FeaturedTrainings;
      this.assignedToMeList = learnData.AssignedToMe;
      this.categoryList = learnData.Categories;
      this.competencyList = learnData.Competencies;
      this.recentlyAddedList = learnData.RecentlyAdded;
      this.highestRatedList = learnData.HighestRated;
      this.assignedByMeList = learnData.AssignedByMe;
      this.getFilteredData(learnData);
    },
      () => {
        // default condition;
      }
    );
  }

  // #endregion
  getArray(averageRating: number, isShowFilledStar: boolean): any[] {
    return this.commonService.getStarRatingArray(averageRating, isShowFilledStar);
  }

  getEmptyListMessage() {
    return 'No_DataAvailable';
  }

  // #region Recently Added Tab: Modal Popup Call
  openPreviewModal4RecentlyAdded(contentId: number) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.data = this.recentlyAddedList.find(x => x.ContentId === contentId);
    if (dialogConfig.data.TypeName === 'Video' || dialogConfig.data.TypeName === 'Document') {
      this.openPreviewModal(dialogConfig);
    } else {
      window.open(dialogConfig.data.ReviewLink, '_blank');
      window.focus();
    }
  }

  openAssignModalPopup4RecentlyAdded(contentId: number) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.data = this.recentlyAddedList.find(x => x.ContentId === contentId);
    this.openAssignModal(dialogConfig);
  }

  openSelfAssignModal4RecentlyAdded(contentId: number) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.data = this.recentlyAddedList.find(x => x.ContentId === contentId);
    this.openSelfAssignModal(dialogConfig);
  }

  //#endregion
  // #region Highest Rated Tab: Modal Popup Call
  openPreviewModal4HighestRated(contentId: number) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.data = this.highestRatedList.find(x => x.ContentId === contentId);
    if (dialogConfig.data.TypeName === 'Video' || dialogConfig.data.TypeName === 'Document') {
      this.openPreviewModal(dialogConfig);
    } else {
      window.open(dialogConfig.data.ReviewLink, '_blank');
      window.focus();
    }
  }

  openAssignModal4HighestRated(contentId: number) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.data = this.highestRatedList.find(x => x.ContentId === contentId);
    this.openAssignModal(dialogConfig);
  }

  openSelfAssignModal4HighestRated(contentId: number) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.data = this.highestRatedList.find(x => x.ContentId === contentId);
    this.openSelfAssignModal(dialogConfig);
  }

  //#endregion
  // #region Assigned By Me Tab: Modal Popup Call
  openPreviewModal4AssignedByMe(contentId: number) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.data = this.assignedByMeList.find(x => x.ContentId === contentId);
    if (dialogConfig.data.TypeName === 'Video' || dialogConfig.data.TypeName === 'Document') {
      this.openPreviewModal(dialogConfig);
    } else {
      window.open(dialogConfig.data.ReviewLink, '_blank');
      window.focus();
    }
  }

  openAssignModal4AssignedByMe(contentId: number) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.data = this.assignedByMeList.find(x => x.ContentId === contentId);
    this.openAssignModal(dialogConfig);
  }

  openSelfAssignModal4AssignedByMe(contentId: number) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.data = this.assignedByMeList.find(x => x.ContentId === contentId);
    this.openSelfAssignModal(dialogConfig);
  }

  // #endregion
  // #region Banner Section: Modal Popup Call
  openPreviewModal4Banner(contentId: number) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.data = this.featuredTrainingList.find(x => x.ContentId === contentId);
    if (dialogConfig.data.TypeName === 'Video' || dialogConfig.data.TypeName === 'Document') {
      this.openPreviewModal(dialogConfig);
    } else {
      window.open(dialogConfig.data.ReviewLink, '_blank');
      window.focus();
    }
  }

  openAssignModal4Banner(contentId: number) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.data = this.featuredTrainingList.find(x => x.ContentId === contentId);
    this.openAssignModal(dialogConfig);
  }

  openSelfAssignModal4Banner(contentId: number) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.data = this.featuredTrainingList.find(x => x.ContentId === contentId);
    this.openSelfAssignModal(dialogConfig);
  }

  // #endregion
  // #region Learn by category Tab: Modal Popup Call
  openPreviewModal4LearnByCategory(contentId: number) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.data = this.learnListBycategory.ListTrainingDataResult.find(x => x.ContentId === contentId);
    if (dialogConfig.data.TypeName === 'Video' || dialogConfig.data.TypeName === 'Document') {
      this.openPreviewModal(dialogConfig);
    } else {
      window.open(dialogConfig.data.ReviewLink, '_blank');
      window.focus();
    }
  }

  openAssignModal4LearnByCategory(contentId: number) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.data = this.learnListBycategory.ListTrainingDataResult.find(x => x.ContentId === contentId);
    this.openAssignModal(dialogConfig);
  }

  openSelfAssignModal4LearnByCategory(contentId: number) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.data = this.learnListBycategory.ListTrainingDataResult.find(x => x.ContentId === contentId);
    this.openSelfAssignModal(dialogConfig);
  }

  // #endregion
  // #region Learn by Competency Tab: Modal Popup Call
  openPreviewModal4LearnByCompetency(contentId: number) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.data = this.learnListByCompetency.ListTrainingDataResult.find(x => x.ContentId === contentId);
    this.openPreviewModal(dialogConfig);
  }

  openAssignModal4LearnByCompetency(contentId: number) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.data = this.learnListByCompetency.ListTrainingDataResult.find(x => x.ContentId === contentId);
    this.openAssignModal(dialogConfig);
  }

  openSelfAssignModal4LearnByCompetency() {
    const dialogConfig = new MatDialogConfig();
    this.openSelfAssignModal(dialogConfig);
  }

  // #endregion
  // #region Assigned To Me Tab: Modal Popup Call
  openReviewModal4AssignedToMe(assignmentId: number) {
    const trainingDetail = this.assignedToMeList.find(x => x.AssignmentId === assignmentId);
    this.commonService.reviewTraining(trainingDetail);
    /*
    let dateValid = false;
    const currentDate = new Date();
    currentDate.setHours(0, 0, 0, 0);
    // const validDate = new Date(trainingDetail.DueDate);
    if (trainingDetail.DueDate !== '') {
      const validDate = new Date(trainingDetail.DueDate);
      if (validDate >= currentDate) {
        dateValid = true;
      }
    } else {
      dateValid = true;
    }

    if (dateValid) {
      if (trainingDetail.TypeName === 'Video' || trainingDetail.TypeName === 'Document' || trainingDetail.TypeName.toLowerCase() === 'quiz') {
        this.router.navigate(['/iCoachFirst/learn/reviewTraining', assignmentId]);
      } else if (trainingDetail.TypeName === 'eLearning') {
        const traningInvitation = new TrainingInvitationUrlRequest();
        traningInvitation.AssignmentId = trainingDetail.AssignmentId;
        traningInvitation.AssigneeId = trainingDetail.AssigneeId;
        traningInvitation.Source = 'ICF6';
        this.learnService.getTrainingInvitationURL(traningInvitation).subscribe(data => {
          const datas = JSON.parse(JSON.stringify(data));
          if (datas.GenerateTrainingInvitationUrlResult.ResultStatusCode === '1040') {
            this.router.navigate(['/iCoachFirst/learn/reviewTraining', assignmentId]);
          } else {
            this.toast.error(datas.GenerateTrainingInvitationUrlResult.ErrorMessage);
          }
        });
      } else {
        this.router.navigate(['/iCoachFirst/learn/reviewTraining', assignmentId]);
        window.open(trainingDetail.ReviewLink, '_blank');
        window.focus();
      }
    } else {
      this.toast.error('Item due date has expired');
    }
    */
    // const dialogConfig = new MatDialogConfig();
    // dialogConfig.data = this.assignedToMeList.find(x => x.ContentId === contentId);
    // this.openReviewModal(dialogConfig);
  }

  // #endregion

  // #region Core Modal Popup Call
  openAssignModal(dialogConfig: MatDialogConfig) {
    dialogConfig.width = LearnModalPopupEnum.AssignModalWidth + 'px';
    dialogConfig.disableClose = true;
    this.dialog.open(LearnAssignComponent, dialogConfig);
  }

  openSelfAssignModal(dialogConfig: MatDialogConfig) {
    dialogConfig.width = LearnModalPopupEnum.SelfAssignModalWidth + 'px';
    dialogConfig.disableClose = true;
    this.dialog.open(LearnSelfAssignComponent, dialogConfig);
  }

  openPreviewModal(dialogConfig: MatDialogConfig) {
    dialogConfig.width = LearnModalPopupEnum.PreviewModalWidth + 'px';
    dialogConfig.height = LearnModalPopupEnum.PreviewModalHeight + 'px';
    // dialogConfig.disableClose = true;
    const dialogRef = this.dialog.open(TrainingContentComponent, dialogConfig);
    dialogRef.afterClosed().subscribe(responseData => {
      if (responseData !== undefined) {
        this.getLearnSearchData();
      }
    });
  }

  openReviewModal(dialogConfig: MatDialogConfig) {
    dialogConfig.width = LearnModalPopupEnum.ReviewModalWidth + 'px';
    dialogConfig.disableClose = true;
    const dialogRef = this.dialog.open(LearnReviewComponent, dialogConfig);
    dialogRef.afterClosed().subscribe(() => {
      this.getLearnSearchData();
      /*                                 Apply condition here
      if (responseData.Refresh) {
          this.getLearnData();
      }
      */
    });
  }

  // #endregion
  getLearnListByCategory(categoryId: number, isShowCategoryBackButton: boolean) {
    this.learnListBycategory = this.categoryList.find(x => x.CategoryId === categoryId);
    this.showLearnByCategory(isShowCategoryBackButton);
  }

  showLearnByCategory(isShowCategoryBackButton: boolean) {
    this.isShowCategoryBackButton = isShowCategoryBackButton;
  }

  getLearnListByCompetency(competencyDimensionId: number, isShowCompetencyBackButton: boolean) {
    this.learnListByCompetency = this.competencyList.find(x => x.CompetencyDimensionId === competencyDimensionId);
    this.showLearnByCompetency(isShowCompetencyBackButton);
  }

  showLearnByCompetency(isShowCompetencyBackButton: boolean) {
    this.isShowCompetencyBackButton = isShowCompetencyBackButton;
  }

  onTabChanged = (_tabChangeEvent: MatTabChangeEvent): void => {
    this.showLearnByCategory(false);
    this.showLearnByCompetency(false);
  }
  // #region LEARN SEARCH FUNCTIONALITY

  getLearnSearchFilter() {
    this.learnService.getLearnSearchFilter().subscribe(resultData => {
      this.learnSearchFilter = JSON.parse(JSON.stringify(resultData));
    },
      () => {
      }
    );
  }

  setFilteredCategory(categorySearchFilter: CategorySearchFilter) {
    if (categorySearchFilter.Selected) {
      this.categoryFilteredList.push(categorySearchFilter.CatID);
    } else {
      const index: number = this.categoryFilteredList.indexOf(categorySearchFilter.CatID);
      if (index !== -1) {
        this.categoryFilteredList.splice(index, 1);
      }
    }
  }

  setFilteredCompetency(competencySearchFilter: CompetencySearchFilter) {
    if (competencySearchFilter.Selected) {
      this.competencyFilteredList.push(competencySearchFilter.CD_ID);
    } else {
      const index: number = this.competencyFilteredList.indexOf(competencySearchFilter.CD_ID);
      if (index !== -1) {
        this.competencyFilteredList.splice(index, 1);
      }
    }
  }

  setFilteredType(typeSearchFilter: TrainingTypeSearchFilter) {
    if (typeSearchFilter.Selected) {
      this.typeFilteredList.push(typeSearchFilter.TypeID);
    } else {
      const index: number = this.typeFilteredList.indexOf(typeSearchFilter.TypeID);
      if (index !== -1) {
        this.typeFilteredList.splice(index, 1);
      }
    }
  }

  resetLearnSearch() {
    this.categoryFilteredList = new Array<number>();
    this.competencyFilteredList = new Array<number>();
    this.typeFilteredList = new Array<number>();
    this.learnSearchParam = new SearchParam();
    // Reset selected Category
    if (this.learnSearchFilter.Categories) {
      this.learnSearchFilter.Categories.forEach(category => {
        category.Selected = false;
      });
    }
    // Reset selected Competency
    if (this.learnSearchFilter.Competencies) {
      this.learnSearchFilter.Competencies.forEach(competency => {
        competency.Selected = false;
      });
    }
    // Reset selected Type
    if (this.learnSearchFilter.TrainingTypes) {
      this.learnSearchFilter.TrainingTypes.forEach(type => {
        type.Selected = false;
      });
    }
    // Get all learn data
    this.getLearnData();
  }

  toggleAdvanceSearch(isShowAdvanceSearch: boolean) {
    this.isShowAdvanceSearch = isShowAdvanceSearch;
  }
  //#endregion

  ngOnDestroy() {
    this._eventEmiter.unsubscribe(this.subscription);
  }

  clickFileter(key: any) {
    this.filterAction = key;
    this.clickFileterClass = '';
  }

  setclickFileterClass() {

    if (this.clickFileterClass === '') {
      this.clickFileterClass = 'show';
    } else {
      this.clickFileterClass = '';
    }
  }

  goToLearnOverview() {
    this.router.navigate(['/iCoachFirst/learn']);

  }


  commonAssign(content: any) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.data = content;
    this.openAssignModal(dialogConfig);
  }

  commonSelfAssign(content: any) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.data = content;
    this.openSelfAssignModal(dialogConfig);
  }

  commonPreview(content: any) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.data = content;
    this.reviewCountIncrease(content.ContentId);
    this.learnService.saveHistoryOfVisitors(this.commonService, this.userInfo.EmpId, 'Training Catalog', content.ContentId, content.TrainingName).subscribe(resultData => {
      if (resultData) { // no log
      }
    });
    if (dialogConfig.data.TypeName === 'Video' || dialogConfig.data.TypeName === 'Document') {
      this.openPreviewModal(dialogConfig);
    } else {
      if (dialogConfig.data.TypeName === 'eLearning') {
        dialogConfig.data.ReviewLink = dialogConfig.data.ReviewLink.replace('https://DomainName', this.domain);
      }
      window.open(dialogConfig.data.ReviewLink, '_blank');
      window.focus();
    }
  }

  // openReviewPopup(content: any) {
  //   const dialogConfig = new MatDialogConfig();
  //   dialogConfig.data = content;
  //   dialogConfig.width = ReviewPopupEnum.ReviewModalWidth + 'px';
  //   dialogConfig.disableClose = true;
  //   const dialogRef = this.dialog.open(ReviewPopupComponent, dialogConfig);
  //   dialogRef.afterClosed().subscribe(() => {
  //     this.getLearnSearchData();
  //     /*                                 Apply condition here
  //     if (responseData.Refresh) {
  //         this.getLearnData();
  //     }
  //     */
  //   });
  // }

  reviewCountIncrease(ContentId: number) {
    this.reviewPopupRequest.ContentId = ContentId;
    this.reviewPopupRequest.LoggedInEmpId = this.userInfo.EmployeeId;
    this.reviewPopupRequest.CandidateAssessmentId = 0;
    this.assignTrainingService.reviewTrainingContent(this.reviewPopupRequest).subscribe(resultData => {
      const result = JSON.parse(JSON.stringify(resultData));
      if (result) {
        // (result)
      }
    },
    );
  }

}
