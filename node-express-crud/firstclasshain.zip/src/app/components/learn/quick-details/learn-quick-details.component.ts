
import { Component, OnInit, Output, EventEmitter, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { MatDialog, MatDialogConfig } from '@angular/material';
import { AssignedToMe, FeaturedTrainings } from '../../../models/response/learn/learn-response';
import { LearnAssignComponent } from '../../../components/learn/modal-popup/assign/learn-assign.component';
import { LearnSelfAssignComponent } from '../../../components/learn/modal-popup/self-assign/learn-self-assign.component';
import { ApplicationModuleListEnum } from '../../../helpers/enums/common-enums';
import { LearnService } from 'src/app/services/learn.service';
import { LearnModalPopupEnum } from 'src/app/helpers/enums/learn-enums';
import { TrainingContentComponent } from '../modal-popup/training-content/training-content.component';
import { EventEmiterService } from 'src/app/services/event.emmiter.service';
import { Subscription } from 'rxjs';
import { SharedDataService } from 'src/app/services/shared-data.service';
import { environment } from 'src/environments/environment';
import { CommonService } from 'src/app/services/common.service';
import { RolesService } from 'src/app/services/roles.service';
import { UserDetails } from 'src/app/models/user-details-result';
import { UserService } from 'src/app/services/user.service';
import { ReviewPopupRequest } from 'src/app/models/requests/learn/learn-self-assign-request';
import { AssignTrainingService } from 'src/app/services/assign-training.service';

@Component({
    selector: 'app-learn-quick-details',
    styleUrls: ['./../learn.component.scss'],
    templateUrl: './learn-quick-details.component.html'
})

export class LearnQuickDetailsComponent implements OnInit, OnDestroy {
    featuredTrainingList: Array<FeaturedTrainings> = [];
    assignedToMeList: Array<AssignedToMe> = [];
    applicationModuleId: number = ApplicationModuleListEnum.None;
    domain = `${environment.domainName}`;
    isExpand = false;
    isSelfAssign = false;
    isAssign = false;
    @Output() setLeftContainerVisibility: EventEmitter<number> = new EventEmitter<number>();
    private subscription: Subscription;
    userInfo: UserDetails;
    reviewPopupRequest: ReviewPopupRequest = new ReviewPopupRequest();

    constructor(private learnService: LearnService, private dialog: MatDialog, private router: Router, private sharedDataService: SharedDataService,
        private _eventEmiter: EventEmiterService, // private toast: IcftoasterService,
        private commonService: CommonService, private roleService: RolesService,
        private userService: UserService,
        private assignTrainingService: AssignTrainingService,
    ) {
        this.subscription = this._eventEmiter.subscribe(data => {
            if (data.actionType === 'UpdateAssignToMe' || data.actionType === 'AssignTraining') {
                this.getLearnData();
            }
        });
    }

    ngOnInit() {
        this.getLearnData();
        if (this.roleService.hasPermission('Expand')) {
            this.isExpand = true;
        } else { this.isExpand = false; }

        if (this.roleService.hasPermission('Assign')) {
            this.isAssign = true;
        } else { this.isAssign = false; }

        if (this.roleService.hasPermission('SelfAssign')) {
            this.isSelfAssign = true;
        } else { this.isSelfAssign = false; }
        this.userInfo = this.userService.getUserDetails().UserDetails;
    }

    ngOnDestroy() {
        this._eventEmiter.unsubscribe(this.subscription);
    }

    openLearnOverviewPage() {
        // Hide the main component left container
        this.onSetLeftContainerVisibility(this.applicationModuleId);
        this.router.navigate(['/iCoachFirst/learn']);
    }

    onSetLeftContainerVisibility(appModuleId: number = 0) {
        this.setLeftContainerVisibility.emit(appModuleId);
    }

    hidePopUpForMobile(appModuleId: number = 0) {
        const isMobileDevice = this.commonService.detectMobileDevice();

        if (isMobileDevice) {
            this.setLeftContainerVisibility.emit(appModuleId);
        }
    }

    getLearnData() {
        this.learnService.getLearnData().subscribe(resultData => {
            const learnData = JSON.parse(JSON.stringify(resultData));
            this.featuredTrainingList = learnData.FeaturedTrainings;
            if (learnData.AssignedToMe) {
                this.assignedToMeList = learnData.AssignedToMe.filter(this.getUnexpiredAssignedToMeList.bind(this));
            }
        },
            () => {
                // default condition;

            }
        );
    }

    getUnexpiredAssignedToMeList(assignedToMe: AssignedToMe) {
        return !this.commonService.isTrainingDueDateExpired(assignedToMe.DueDate);
    }

    getArray(averageRating: number, isShowFilledStar: boolean): any[] {
        return this.commonService.getStarRatingArray(averageRating, isShowFilledStar);
    }
    openPreviewModalPopup(contentId: number) {
        const dialogConfig = new MatDialogConfig();
        dialogConfig.data = this.featuredTrainingList.find(x => x.ContentId === contentId);
        this.learnService.saveHistoryOfVisitors(this.commonService, this.userInfo.EmpId, 'Featured Left Panel',
            dialogConfig.data.ContentId, dialogConfig.data.TrainingName).subscribe(resultData => {
                if (resultData) { // no log 
                }
            });
        this.reviewCountIncrease(contentId);
        if (dialogConfig.data.TypeName === 'Video' || dialogConfig.data.TypeName === 'Document') {
            dialogConfig.width = LearnModalPopupEnum.PreviewModalWidth + 'px';
            dialogConfig.height = LearnModalPopupEnum.PreviewModalHeight + 'px';
            // dialogConfig.disableClose = true;
            this.sharedDataService.setAssignedData('false');
            const dialogRef = this.dialog.open(TrainingContentComponent, dialogConfig);
            dialogRef.afterClosed().subscribe(responseData => {
                if (responseData.Refresh) {
                    this.getLearnData();
                }
            });
        } else {
            if (dialogConfig.data.TypeName === 'eLearning') {
                dialogConfig.data.ReviewLink = dialogConfig.data.ReviewLink.replace('https://DomainName', this.domain);
            }
            window.open(dialogConfig.data.ReviewLink, '_blank');
            window.focus();
        }
    }

    openAssignModalPopup(contentId: number) {

        const dialogConfig = new MatDialogConfig();
        dialogConfig.data = this.featuredTrainingList.find(x => x.ContentId === contentId);
        dialogConfig.width = LearnModalPopupEnum.AssignModalWidth + 'px';
        dialogConfig.disableClose = true;
        this.dialog.open(LearnAssignComponent, dialogConfig);

    }

    openSelfAssignModalPopup(contentId: number) {
        const dialogConfig = new MatDialogConfig();
        dialogConfig.data = this.featuredTrainingList.find(x => x.ContentId === contentId);
        dialogConfig.width = LearnModalPopupEnum.SelfAssignModalWidth + 'px';
        dialogConfig.disableClose = true;
        this.dialog.open(LearnSelfAssignComponent, dialogConfig);
    }

    openReviewModalPopup(assignmentId: number) {
        const trainingDetail = this.assignedToMeList.find(x => x.AssignmentId === assignmentId);
        // let dateValid = false;
        // const currentDate = new Date();
        // currentDate.setHours(0, 0, 0, 0);
        // // const validDate =  new Date(Date.parse(trainingDetail.DueDate));
        // if (trainingDetail.DueDate !== '') {
        //     /*
        //      const dueDate = trainingDetail.DueDate.split('-');
        //      const newDate = dueDate[2] + '-' + dueDate[0] + '-' + dueDate[1];
        //      const validDate = new Date(newDate);
        //     */
        //     const validDate = new Date(trainingDetail.DueDate);
        //     if (validDate >= currentDate) {
        //         dateValid = true;
        //     }
        // } else {
        //     dateValid = true;
        // }

        this.learnService.saveHistoryOfVisitors(this.commonService, this.userInfo.EmpId, 'Assigned To Me Left Panel',
            trainingDetail.ContentId, trainingDetail.TrainingName).subscribe(resultData => {
                if (resultData) { // no log 
                }
            });
        this.commonService.reviewTraining(trainingDetail);
        this.reviewCountIncrease(trainingDetail.ContentId);
        /*
        if (!this.commonService.isTrainingDueDateExpired(trainingDetail.DueDate)) {
            if (trainingDetail.TypeName === 'Video' || trainingDetail.TypeName === 'Document' || trainingDetail.TypeName.toLowerCase() === 'quiz') {
                this.router.navigate(['/iCoachFirst/learn/reviewTraining', assignmentId]);
            } else if (trainingDetail.TypeName === 'eLearning') {
                const request = {} as ScormLaunchUrlRequest;
                request.AssignmentId = assignmentId;
                request.MemberOrgId = this.userService.getUserDetails().UserDetails.MemberOrgID;
                this.learnService.geteLearningLaunchUrl(request).subscribe(data => {
                    const datas = JSON.parse(JSON.stringify(data));
                    if (!datas.ErrorMessage) {
                        this.router.navigate(['/iCoachFirst/learn/reviewTraining', assignmentId]);
                    } else {
                        this.toast.error(datas.ErrorMessage);
                    }
                });
            } else {
                this.router.navigate(['/iCoachFirst/learn/reviewTraining', assignmentId]);
                window.open(trainingDetail.ReviewLink, '_blank');
                window.focus();
            }
        } else {
            this.toast.error('Item due date has expired');
        }

*/
        // const dialogConfig = new MatDialogConfig();
        // dialogConfig.data = this.assignedToMeList.find(x => x.ContentId === contentId);
        // dialogConfig.width = LearnModalPopupEnum.ReviewModalWidth + 'px';
        // dialogConfig.disableClose = true;
        // const dialogRef = this.dialog.open(LearnReviewComponent, dialogConfig);
        // dialogRef.afterClosed().subscribe(responseData => {
        //     this.getLearnData();
        //     /*                                 Apply condition here
        //     if (responseData.Refresh) {
        //         this.getLearnData();
        //     }
        //     */
        // });
    }

    reviewCountIncrease(ContentId: number) {
        this.reviewPopupRequest.ContentId = ContentId;
        this.reviewPopupRequest.LoggedInEmpId = this.userInfo.EmployeeId;
        this.reviewPopupRequest.CandidateAssessmentId = 0;
        this.assignTrainingService.reviewTrainingContent(this.reviewPopupRequest).subscribe(resultData => {
            const result = JSON.parse(JSON.stringify(resultData));
            if (result) {
                // (result)
            }
        },
        );
    }

}


