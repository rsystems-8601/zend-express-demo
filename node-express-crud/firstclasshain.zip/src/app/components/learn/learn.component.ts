import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { MatDialog, MatDialogConfig, MatTabChangeEvent } from '@angular/material';
import { LearnSelfAssignComponent } from '../../components/learn/modal-popup/self-assign/learn-self-assign.component';
import { LearnAssignComponent } from '../../components/learn/modal-popup/assign/learn-assign.component';
import { LearnReviewComponent } from '../../components/learn/modal-popup/review/learn-review.component';
import { LearnService } from '../../services/learn.service';
import {
    AssignedToMe, FeaturedTrainings, Categories, Competencies, RecentlyAdded,
    HighestRated, AssignedByMe
} from '../../models/response/learn/learn-response';
import { LearnModalPopupEnum } from '../../helpers/enums/learn-enums';
import {
    SearchFilter, CategorySearchFilter, TrainingTypeSearchFilter,
    CompetencySearchFilter,
    LearnFilterList
} from '../../models/response/learn/learn-search-filter-response';
import { SearchParam } from '../../models/requests/learn/learn-search-parameter-request';
import { TrainingContentComponent } from './modal-popup/training-content/training-content.component';
// import { IcftoasterService } from 'src/app/services/icftoaster.service';
// import { TrainingInvitationUrlRequest } from 'src/app/models/requests/learn/training-invitation-url-request';
import { EventEmiterService } from 'src/app/services/event.emmiter.service';
import { Subscription } from 'rxjs';
import { CommonService } from 'src/app/services/common.service';
// import { TrainingCatalogComponent } from './training-catalog/training-catalog.component';
import { environment } from 'src/environments/environment';
// import { EventEmiterTypeEnum } from 'src/app/helpers/enums/common-enums';
import { UserDetails } from 'src/app/models/user-details-result';
import { SaveTraingItemVisitHistory, ReviewPopupRequest } from 'src/app/models/requests/learn/learn-self-assign-request';
import { UserService } from 'src/app/services/user.service';
import { SharedDataService } from 'src/app/services/shared-data.service';
import { AssignTrainingService } from 'src/app/services/assign-training.service';

@Component({
    selector: 'app-learn',
    styleUrls: ['./learn.component.scss'],
    templateUrl: './learn.component.html'
})

export class LearnComponent implements OnInit, OnDestroy {
    isShowCategoryBackButton = false;
    isShowCompetencyBackButton = false;
    isShowAdvanceSearch = false;
    _listFilter: string;
    learnFilteredData: LearnFilterList;
    featuredTrainingList: Array<FeaturedTrainings> = [];
    assignedToMeList: Array<AssignedToMe> = [];
    categoryList: Array<Categories> = [];
    competencyList: Array<Competencies> = [];
    recentlyAddedList: Array<RecentlyAdded> = [];
    highestRatedList: Array<HighestRated> = [];
    assignedByMeList: Array<AssignedByMe> = [];
    learnListBycategory: Categories;
    learnListByCompetency: Competencies;
    activeSlideIndex = 0;
    // Search/filter
    learnSearchFilter: SearchFilter = new SearchFilter();
    categoryFilteredList: Array<number> = new Array<number>();
    competencyFilteredList: Array<number> = new Array<number>();
    typeFilteredList: Array<number> = new Array<number>();
    learnSearchParam: SearchParam = new SearchParam();
    private subscription: Subscription;
    domain = `${environment.domainName}`;
    trainingHistoryRequest: SaveTraingItemVisitHistory = new SaveTraingItemVisitHistory();
    userInfo: UserDetails;
    advancedSearchTitle = '';
    reviewPopupRequest: ReviewPopupRequest = new ReviewPopupRequest();

    constructor(private learnService: LearnService,
        private dialog: MatDialog,
        private router: Router,
        // private toast: IcftoasterService,
        private _eventEmiter: EventEmiterService,
        private commonService: CommonService,
        private userService: UserService, private sharedDataService: SharedDataService,
        private assignTrainingService: AssignTrainingService,
    ) { }

    ngOnInit() {
        this.activeSlideIndex = 0;
        // this.getLearnData();
        this.getLearnSearchData();
        this.getLearnSearchFilter();
        // this.subscription = this._eventEmiter.subscribe(data => {
        //     if (data.actionType === 'UpdateAssignToMe' || data.actionType === 'AssignTraining' || EventEmiterTypeEnum.AssignTrainingToTeamMember) {
        //         this.getLearnSearchData();
        //     }
        //     // Commenting this out, as it is giving error in IE
        //     // if (data.actionType === EventEmiterTypeEnum.ModuleOpened) {
        //     //     window.dispatchEvent(new Event('resize'));
        //     // } else if (data.actionType === EventEmiterTypeEnum.ModuleClosed) {
        //     //     window.dispatchEvent(new Event('resize'));
        //     // }
        // });
        this.userInfo = this.userService.getUserDetails().UserDetails;
    }

    refreshAllList() {
        this.assignedToMeList = [];
        this.categoryList = [];
        this.competencyList = [];
        this.recentlyAddedList = [];
        this.highestRatedList = [];
        this.assignedByMeList = [];
        this.featuredTrainingList = [];
        // this.learnFilteredData = null;
    }

    // #region Get Learn Data
    // To get learn data without filter
    getLearnData() {
        this.learnService.getLearnData().subscribe(resultData => {
            const learnData = JSON.parse(JSON.stringify(resultData));
            this.learnFilteredData = learnData;
            this.featuredTrainingList = learnData.FeaturedTrainings;

            if (learnData.AssignedToMe) {
                this.assignedToMeList = learnData.AssignedToMe.filter(this.getUnexpiredAssignedToMeList.bind(this));
                this.assignedToMeList = this.listSort(this.assignedToMeList, 'TrainingName');
            }
            this.categoryList = learnData.Categories;
            this.competencyList = learnData.Competencies;
            this.recentlyAddedList = learnData.RecentlyAdded;
            this.highestRatedList = learnData.HighestRated;
            this.assignedByMeList = learnData.AssignedByMe;

            this.featuredTrainingList = this.listSort(this.featuredTrainingList, 'TrainingName');
            this.categoryList = this.listSort(this.categoryList, 'CategoryName');
            this.competencyList = this.listSort(this.competencyList, 'CompetencyDimension');
            this.recentlyAddedList = this.listSort(this.recentlyAddedList, 'TrainingName');
            this.highestRatedList = this.listSort(this.highestRatedList, 'AverageRating');
            this.assignedByMeList = this.listSort(this.assignedByMeList, 'TrainingName');
        },
            () => {
                // default condition;
            }
        );
    }

    // To get learn data with filter(s)
    getLearnSearchData() {
        this.refreshAllList();
        this.listFilter = '';
        this.learnSearchParam.Title = this.advancedSearchTitle;
        this.learnSearchParam.CategoryIds = this.categoryFilteredList.join();
        this.learnSearchParam.CompetencyIds = this.competencyFilteredList.join();
        this.learnSearchParam.TypeIds = this.typeFilteredList.join();
        this.toggleAdvanceSearch(false);
        if (!this.learnSearchParam.CategoryIds && !this.learnSearchParam.CompetencyIds &&
            this.learnSearchParam.Title === '' && !this.learnSearchParam.TypeIds) {
            this.getLearnData();
        } else {
            this.learnService.getLearnSearchData(this.learnSearchParam).subscribe(resultData => {
                const learnData = JSON.parse(JSON.stringify(resultData)).TrainingSearchDataResult;
                this.learnFilteredData = learnData;
                this.featuredTrainingList = learnData.FeaturedTrainings;
                if (learnData.AssignedToMe) {
                    this.assignedToMeList = learnData.AssignedToMe.filter(this.getUnexpiredAssignedToMeList.bind(this));
                    this.assignedToMeList = this.listSort(this.assignedToMeList, 'TrainingName');
                }
                this.categoryList = learnData.Categories;
                this.competencyList = learnData.Competencies;
                this.recentlyAddedList = learnData.RecentlyAdded;
                this.highestRatedList = learnData.HighestRated;
                this.assignedByMeList = learnData.AssignedByMe;

                this.featuredTrainingList = this.listSort(this.featuredTrainingList, 'TrainingName');
                this.categoryList = this.listSort(this.categoryList, 'CategoryName');
                this.competencyList = this.listSort(this.competencyList, 'CompetencyDimension');
                this.recentlyAddedList = this.listSort(this.recentlyAddedList, 'TrainingName');
                this.highestRatedList = this.listSort(this.highestRatedList, 'AverageRating');
                this.assignedByMeList = this.listSort(this.assignedByMeList, 'TrainingName');
            },
                () => {
                    // default condition;
                }
            );
        }
    }

    listSort(objParent, typo) {
        const listMain = [];
        const listMain2 = [];
        const listMainObj = [];
        const listReturn = [];
        if (objParent) {
            if (typo === 'CategoryName') {
                objParent.forEach(objChild => {
                    if (listMain.indexOf(objChild.CategoryName) === -1) {
                        listMain.push(objChild.CategoryName);
                        listMain2.push(objChild.CategoryName);
                        listMainObj.push(objChild);
                    }
                    if (objParent.AssignmentId === undefined) {
                        this.sharedDataService.setAssignedData('false');
                    }
                });
            }
            if (typo === 'TrainingName') {
                objParent.forEach(objChild => {
                    if (listMain.indexOf(objChild.TrainingName) === -1) {
                        listMain.push(objChild.TrainingName);
                        listMain2.push(objChild.TrainingName);
                        listMainObj.push(objChild);
                    }
                    if (objParent.AssignmentId === undefined) {
                        this.sharedDataService.setAssignedData('false');
                    }
                });
            }
            if (typo === 'CompetencyDimension') {
                objParent.forEach(objChild => {
                    if (listMain.indexOf(objChild.CompetencyDimension) === -1) {
                        listMain.push(objChild.CompetencyDimension);
                        listMain2.push(objChild.CompetencyDimension);
                        listMainObj.push(objChild);
                    }
                    if (objParent.AssignmentId === undefined) {
                        this.sharedDataService.setAssignedData('false');
                    }
                });
            }

            listMain.sort(function (a: any, b: any) {
                if (a.toLowerCase() < b.toLowerCase()) { return -1; }
                if (a.toLowerCase() > b.toLowerCase()) { return 1; }
                return 0;
            });

            listMain.forEach(sortName => {
                const oldcli = listMain2.indexOf(sortName);
                listReturn.push(listMainObj[oldcli]);
            });

            if (typo === 'AverageRating') {
                objParent.forEach(objChild => {
                    listMain.push(objChild.AverageRating);
                    listMain2.push(objChild.AverageRating);
                    listMainObj.push(objChild);
                    if (objParent.AssignmentId === undefined) {
                        this.sharedDataService.setAssignedData('false');
                    }
                });
                listMain.sort(function (a: any, b: any) {
                    if (a < b) { return 1; }
                    if (a > b) { return -1; }
                    return 0;
                });
                listMain.forEach(sortName => {
                    const oldcli = listMain2.indexOf(sortName);
                    listMain2[oldcli] = '';
                    listReturn.push(listMainObj[oldcli]);
                });
            }
        }

        return listReturn;
    }

    get listFilter(): string {
        return this._listFilter;
    }

    set listFilter(value: string) {
        this._listFilter = value;
        this.reloadFilterData();
    }

    reloadFilterData() {
        if (!this.learnFilteredData) { return true; }

        if (this.learnFilteredData.AssignedByMe) {
            this.assignedByMeList = this.learnFilteredData.AssignedByMe.filter(
                objReport => objReport.TrainingName.toLowerCase().includes(this.listFilter.toLowerCase()));
        }
        if (this.assignedByMeList && this.assignedByMeList.length === 0) {
            this.assignedByMeList = null;
        }

        if (this.learnFilteredData.AssignedToMe) {
            this.assignedToMeList = this.learnFilteredData.AssignedToMe.filter(this.getUnexpiredAssignedToMeList.bind(this));
            this.assignedToMeList = this.assignedToMeList.filter(
                objReport => objReport.TrainingName.toLowerCase().includes(this.listFilter.toLowerCase()));
        }
        if (this.assignedToMeList && this.assignedToMeList.length === 0) {
            this.assignedToMeList = null;
        }

        if (this.learnFilteredData.Categories) {
            this.categoryList = this.learnFilteredData.Categories.filter(
                objReport => objReport.CategoryName.toLowerCase().includes(this.listFilter.toLowerCase()));
        }
        if (this.categoryList && this.categoryList.length === 0) {
            this.categoryList = null;
        }

        if (this.learnFilteredData.FeaturedTrainings) {
            this.featuredTrainingList = this.learnFilteredData.FeaturedTrainings.filter(
                objReport => objReport.TrainingName.toLowerCase().includes(this.listFilter.toLowerCase()));
        }
        if (this.featuredTrainingList && this.featuredTrainingList.length === 0) {
            this.featuredTrainingList = null;
        }

        if (this.learnFilteredData.Competencies) {
            this.competencyList = this.learnFilteredData.Competencies.filter(
                objReport => objReport.CompetencyDimension.toLowerCase().includes(this.listFilter.toLowerCase()));
        }
        if (this.competencyList && this.competencyList.length === 0) {
            this.competencyList = null;
        }

        if (this.learnFilteredData.RecentlyAdded) {
            this.recentlyAddedList = this.learnFilteredData.RecentlyAdded.filter(
                objReport => objReport.TrainingName.toLowerCase().includes(this.listFilter.toLowerCase()));
        }
        if (this.recentlyAddedList && this.recentlyAddedList.length === 0) {
            this.recentlyAddedList = null;
        }

        if (this.learnFilteredData.HighestRated) {
            this.highestRatedList = this.learnFilteredData.HighestRated.filter(
                objReport => objReport.TrainingName.toLowerCase().includes(this.listFilter.toLowerCase()));
        }
        if (this.highestRatedList && this.highestRatedList.length === 0) {
            this.highestRatedList = null;
        }
    }

    // #endregion

    getUnexpiredAssignedToMeList(assignedToMe: AssignedToMe) {
        return !this.commonService.isTrainingDueDateExpired(assignedToMe.DueDate);
    }

    getArray(averageRating: number, isShowFilledStar: boolean): any[] {
        return this.commonService.getStarRatingArray(averageRating, isShowFilledStar);
    }

    getEmptyListMessage() {
        return 'No_DataAvailable';
    }

    // #region Recently Added Tab: Modal Popup Call
    openPreviewModal4RecentlyAdded(contentId: number) {

        const dialogConfig = new MatDialogConfig();
        dialogConfig.data = this.recentlyAddedList.find(x => x.ContentId === contentId);
        this.learnService.saveHistoryOfVisitors(this.commonService, this.userInfo.EmpId, 'Recently Added',
            dialogConfig.data.ContentId, dialogConfig.data.TrainingName).subscribe(resultData => {
                if (resultData) { // no log 
                }
            });
        this.reviewCountIncrease(contentId);
        if (dialogConfig.data.TypeName === 'Video' || dialogConfig.data.TypeName === 'Document') {
            this.openPreviewModal(dialogConfig);
        } else {
            if (dialogConfig.data.TypeName === 'eLearning') {
                dialogConfig.data.ReviewLink = dialogConfig.data.ReviewLink.replace('https://DomainName', this.domain);
            }
            window.open(dialogConfig.data.ReviewLink, '_blank');
            window.focus();
        }
    }

    openAssignModalPopup4RecentlyAdded(contentId: number) {

        const dialogConfig = new MatDialogConfig();
        dialogConfig.data = this.recentlyAddedList.find(x => x.ContentId === contentId);
        this.openAssignModal(dialogConfig);

    }

    openSelfAssignModal4RecentlyAdded(contentId: number) {
        const dialogConfig = new MatDialogConfig();
        dialogConfig.data = this.recentlyAddedList.find(x => x.ContentId === contentId);
        this.openSelfAssignModal(dialogConfig);
    }

    //#endregion
    // #region Highest Rated Tab: Modal Popup Call
    openPreviewModal4HighestRated(contentId: number) {
        const dialogConfig = new MatDialogConfig();
        dialogConfig.data = this.highestRatedList.find(x => x.ContentId === contentId);
        this.learnService.saveHistoryOfVisitors(this.commonService, this.userInfo.EmpId, 'Highest Rated',
            dialogConfig.data.ContentId, dialogConfig.data.TrainingName).subscribe(resultData => {
                if (resultData) { // no log 
                }
            });
        this.reviewCountIncrease(contentId);
        if (dialogConfig.data.TypeName === 'Video' || dialogConfig.data.TypeName === 'Document') {
            this.openPreviewModal(dialogConfig);
        } else {
            if (dialogConfig.data.TypeName === 'eLearning') {
                dialogConfig.data.ReviewLink = dialogConfig.data.ReviewLink.replace('https://DomainName', this.domain);
            }
            window.open(dialogConfig.data.ReviewLink, '_blank');
            window.focus();
        }
    }

    openAssignModal4HighestRated(contentId: number) {

        const dialogConfig = new MatDialogConfig();
        dialogConfig.data = this.highestRatedList.find(x => x.ContentId === contentId);
        this.openAssignModal(dialogConfig);
    }

    openSelfAssignModal4HighestRated(contentId: number) {
        const dialogConfig = new MatDialogConfig();
        dialogConfig.data = this.highestRatedList.find(x => x.ContentId === contentId);
        this.openSelfAssignModal(dialogConfig);
    }

    //#endregion

    // #region Assigned By Me Tab: Modal Popup Call
    openPreviewModal4AssignedByMe(contentId: number) {
        const dialogConfig = new MatDialogConfig();
        dialogConfig.data = this.assignedByMeList.find(x => x.ContentId === contentId);
        this.learnService.saveHistoryOfVisitors(this.commonService, this.userInfo.EmpId, 'Assigned By Me',
            dialogConfig.data.ContentId, dialogConfig.data.TrainingName).subscribe(resultData => {
                if (resultData) { // no log 
                }
            });
        this.reviewCountIncrease(contentId);
        if (dialogConfig.data.TypeName === 'Video' || dialogConfig.data.TypeName === 'Document') {
            this.openPreviewModal(dialogConfig);
        } else {
            if (dialogConfig.data.TypeName === 'eLearning') {
                dialogConfig.data.ReviewLink = dialogConfig.data.ReviewLink.replace('https://DomainName', this.domain);
            }
            window.open(dialogConfig.data.ReviewLink, '_blank');
            window.focus();
        }
    }

    openAssignModal4AssignedByMe(contentId: number) {

        const dialogConfig = new MatDialogConfig();
        dialogConfig.data = this.assignedByMeList.find(x => x.ContentId === contentId);
        this.openAssignModal(dialogConfig);

    }

    openSelfAssignModal4AssignedByMe(contentId: number) {
        const dialogConfig = new MatDialogConfig();
        dialogConfig.data = this.assignedByMeList.find(x => x.ContentId === contentId);
        this.openSelfAssignModal(dialogConfig);
    }

    // #endregion

    // #region Banner Section: Modal Popup Call
    openPreviewModal4Banner(contentId: number) {
        const dialogConfig = new MatDialogConfig();
        dialogConfig.data = this.featuredTrainingList.find(x => x.ContentId === contentId);
        this.learnService.saveHistoryOfVisitors(this.commonService, this.userInfo.EmpId, 'Banner',
            dialogConfig.data.ContentId, dialogConfig.data.TrainingName).subscribe(resultData => {
                if (resultData) { // no log 
                }
            });
        this.reviewCountIncrease(contentId);
        if (dialogConfig.data.TypeName === 'Video' || dialogConfig.data.TypeName === 'Document') {
            this.openPreviewModal(dialogConfig);
        } else {
            if (dialogConfig.data.TypeName === 'eLearning') {
                dialogConfig.data.ReviewLink = dialogConfig.data.ReviewLink.replace('https://DomainName', this.domain);
            }
            window.open(dialogConfig.data.ReviewLink, '_blank');
            window.focus();
        }
    }

    openAssignModal4Banner(contentId: number) {
        const dialogConfig = new MatDialogConfig();
        dialogConfig.data = this.featuredTrainingList.find(x => x.ContentId === contentId);
        this.openAssignModal(dialogConfig);
    }

    openSelfAssignModal4Banner(contentId: number) {
        const dialogConfig = new MatDialogConfig();
        dialogConfig.data = this.featuredTrainingList.find(x => x.ContentId === contentId);
        this.openSelfAssignModal(dialogConfig);
    }

    // #endregion
    // #region Learn by category Tab: Modal Popup Call
    openPreviewModal4LearnByCategory(contentId: number) {
        const dialogConfig = new MatDialogConfig();
        dialogConfig.data = this.learnListBycategory.ListTrainingDataResult.find(x => x.ContentId === contentId);
        this.learnService.saveHistoryOfVisitors(this.commonService, this.userInfo.EmpId, 'Learn By Category',
            dialogConfig.data.ContentId, dialogConfig.data.TrainingName).subscribe(resultData => {
                if (resultData) { // no log 
                }
            });
        this.reviewCountIncrease(contentId);
        if (dialogConfig.data.TypeName === 'Video' || dialogConfig.data.TypeName === 'Document') {
            this.openPreviewModal(dialogConfig);
        } else {
            if (dialogConfig.data.TypeName === 'eLearning') {
                dialogConfig.data.ReviewLink = dialogConfig.data.ReviewLink.replace('https://DomainName', this.domain);
            }
            window.open(dialogConfig.data.ReviewLink, '_blank');
            window.focus();
        }
    }

    openAssignModal4LearnByCategory(contentId: number) {
        const dialogConfig = new MatDialogConfig();
        dialogConfig.data = this.learnListBycategory.ListTrainingDataResult.find(x => x.ContentId === contentId);
        this.openAssignModal(dialogConfig);
    }

    openSelfAssignModal4LearnByCategory(contentId: number) {
        const dialogConfig = new MatDialogConfig();
        dialogConfig.data = this.learnListBycategory.ListTrainingDataResult.find(x => x.ContentId === contentId);
        this.openSelfAssignModal(dialogConfig);
    }

    // #endregion
    // #region Learn by Competency Tab: Modal Popup Call
    openPreviewModal4LearnByCompetency(contentId: number) {
        const dialogConfig = new MatDialogConfig();
        dialogConfig.data = this.learnListByCompetency.ListTrainingDataResult.find(x => x.ContentId === contentId);
        this.learnService.saveHistoryOfVisitors(this.commonService, this.userInfo.EmpId, 'Learn By Competency',
            dialogConfig.data.ContentId, dialogConfig.data.TrainingName).subscribe(resultData => {
                if (resultData) { // no log 
                }
            });
        this.reviewCountIncrease(contentId);
        if (dialogConfig.data.TypeName === 'Video' || dialogConfig.data.TypeName === 'Document') {
            this.openPreviewModal(dialogConfig);
        } else {
            if (dialogConfig.data.TypeName === 'eLearning') {
                dialogConfig.data.ReviewLink = dialogConfig.data.ReviewLink.replace('https://DomainName', this.domain);
            }
            window.open(dialogConfig.data.ReviewLink, '_blank');
            window.focus();
        }
    }

    openAssignModal4LearnByCompetency(contentId: number) {
        const dialogConfig = new MatDialogConfig();
        dialogConfig.data = this.learnListByCompetency.ListTrainingDataResult.find(x => x.ContentId === contentId);
        this.openAssignModal(dialogConfig);
    }

    openSelfAssignModal4LearnByCompetency(contentId: number) {
        const dialogConfig = new MatDialogConfig();
        dialogConfig.data = this.learnListByCompetency.ListTrainingDataResult.find(x => x.ContentId === contentId);
        this.openSelfAssignModal(dialogConfig);
    }

    // #endregion
    // #region Assigned To Me Tab: Modal Popup Call
    openReviewModal4AssignedToMe(assignmentId: number) {
        this.assignedToMeList = this.assignedToMeList.filter(this.getUnexpiredAssignedToMeList.bind(this));
        const trainingDetail = this.assignedToMeList.find(x => x.AssignmentId === assignmentId);
        this.learnService.saveHistoryOfVisitors(this.commonService, this.userInfo.EmpId, 'Assigned To Me',
            trainingDetail.ContentId, trainingDetail.TrainingName).subscribe(resultData => {
                if (resultData) { // no log 
                }
            });
        this.reviewCountIncrease(trainingDetail.ContentId);
        // let dateValid = false;
        // const currentDate = new Date();
        // currentDate.setHours(0, 0, 0, 0);
        // // const validDate = new Date(trainingDetail.DueDate);
        // if (trainingDetail.DueDate !== '') {
        //     const validDate = new Date(trainingDetail.DueDate);
        //     if (validDate >= currentDate) {
        //         dateValid = true;
        //     }
        // } else {
        //     dateValid = true;
        // }
        this.commonService.reviewTraining(trainingDetail);
        /*
        if (!this.commonService.isTrainingDueDateExpired(trainingDetail.DueDate)) {
            if (trainingDetail.TypeName === 'Video' || trainingDetail.TypeName === 'Document' || trainingDetail.TypeName.toLowerCase() === 'quiz') {
                this.router.navigate(['/iCoachFirst/learn/reviewTraining', assignmentId]);
            } else if (trainingDetail.TypeName === 'eLearning') {
                const traningInvitation = new TrainingInvitationUrlRequest();
                traningInvitation.AssignmentId = trainingDetail.AssignmentId;
                traningInvitation.AssigneeId = trainingDetail.AssigneeId;
                traningInvitation.Source = 'ICF6';
                this.learnService.getTrainingInvitationURL(traningInvitation).subscribe(data => {
                    const datas = JSON.parse(JSON.stringify(data));
                    if (datas.GenerateTrainingInvitationUrlResult.ResultStatusCode === '1040') {
                        this.router.navigate(['/iCoachFirst/learn/reviewTraining', assignmentId]);
                    } else {
                        this.toast.error(datas.GenerateTrainingInvitationUrlResult.ErrorMessage);
                    }
                });
            } else {
                this.router.navigate(['/iCoachFirst/learn/reviewTraining', assignmentId]);
                window.open(trainingDetail.ReviewLink, '_blank');
                window.focus();
            }
        } else {
            this.toast.error('Item due date has expired');
        }
        */
        // const dialogConfig = new MatDialogConfig();
        // dialogConfig.data = this.assignedToMeList.find(x => x.ContentId === contentId);
        // this.openReviewModal(dialogConfig);
    }

    // #endregion
    // #region Core Modal Popup Call
    openAssignModal(dialogConfig: MatDialogConfig) {
        dialogConfig.width = LearnModalPopupEnum.AssignModalWidth + 'px';
        dialogConfig.disableClose = true;
        this.dialog.open(LearnAssignComponent, dialogConfig);
    }

    openSelfAssignModal(dialogConfig: MatDialogConfig) {
        dialogConfig.width = LearnModalPopupEnum.SelfAssignModalWidth + 'px';
        dialogConfig.disableClose = true;
        this.dialog.open(LearnSelfAssignComponent, dialogConfig);
    }

    openPreviewModal(dialogConfig: MatDialogConfig) {
        dialogConfig.width = LearnModalPopupEnum.PreviewModalWidth + 'px';
        dialogConfig.height = LearnModalPopupEnum.PreviewModalHeight + 'px';
        // dialogConfig.disableClose = true;
        const dialogRef = this.dialog.open(TrainingContentComponent, dialogConfig);
        dialogRef.afterClosed().subscribe(_responseData => {
            // if (responseData.Refresh) {
            //     this.getLearnSearchData();
            // }
            this.getLearnSearchData();
        });
    }

    openReviewModal(dialogConfig: MatDialogConfig) {
        dialogConfig.width = LearnModalPopupEnum.ReviewModalWidth + 'px';
        dialogConfig.disableClose = true;
        const dialogRef = this.dialog.open(LearnReviewComponent, dialogConfig);
        dialogRef.afterClosed().subscribe(() => {
            this.getLearnSearchData();
            /*                                 Apply condition here
            if (responseData.Refresh) {
                this.getLearnData();
            }
            */
        });
    }

    getLearnListByCategory(categoryId: number, isShowCategoryBackButton: boolean) {
        this.learnListBycategory = this.categoryList.find(x => x.CategoryId === categoryId);
        if (this.learnListBycategory.ListTrainingDataResult !== undefined) {
            this.learnListBycategory.ListTrainingDataResult = this.listSort(this.learnListBycategory.ListTrainingDataResult, 'TrainingName');
        }
        this.showLearnByCategory(isShowCategoryBackButton);
    }

    showLearnByCategory(isShowCategoryBackButton: boolean) {
        this.isShowCategoryBackButton = isShowCategoryBackButton;
    }

    getLearnListByCompetency(competencyDimensionId: number, isShowCompetencyBackButton: boolean) {
        this.learnListByCompetency = this.competencyList.find(x => x.CompetencyDimensionId === competencyDimensionId);
        if (this.learnListByCompetency.ListTrainingDataResult !== undefined) {
            this.learnListByCompetency.ListTrainingDataResult = this.listSort(this.learnListByCompetency.ListTrainingDataResult, 'TrainingName');
        }
        this.showLearnByCompetency(isShowCompetencyBackButton);
    }

    showLearnByCompetency(isShowCompetencyBackButton: boolean) {
        this.isShowCompetencyBackButton = isShowCompetencyBackButton;
    }

    onTabChanged = (_tabChangeEvent: MatTabChangeEvent): void => {
        this.showLearnByCategory(false);
        this.showLearnByCompetency(false);
    }

    // #region LEARN SEARCH FUNCTIONALITY
    getLearnSearchFilter() {
        this.learnService.getLearnSearchFilter().subscribe(resultData => {
            this.learnSearchFilter = JSON.parse(JSON.stringify(resultData));
        },
            () => {
            }
        );
    }

    setFilteredCategory(categorySearchFilter: CategorySearchFilter) {
        if (categorySearchFilter.Selected) {
            this.categoryFilteredList.push(categorySearchFilter.CatID);
        } else {
            const index: number = this.categoryFilteredList.indexOf(categorySearchFilter.CatID);
            if (index !== -1) {
                this.categoryFilteredList.splice(index, 1);
            }
        }
    }

    setFilteredCompetency(competencySearchFilter: CompetencySearchFilter) {
        if (competencySearchFilter.Selected) {
            this.competencyFilteredList.push(competencySearchFilter.CD_ID);
        } else {
            const index: number = this.competencyFilteredList.indexOf(competencySearchFilter.CD_ID);
            if (index !== -1) {
                this.competencyFilteredList.splice(index, 1);
            }
        }
    }

    setFilteredType(typeSearchFilter: TrainingTypeSearchFilter) {
        if (typeSearchFilter.Selected) {
            this.typeFilteredList.push(typeSearchFilter.TypeID);
        } else {
            const index: number = this.typeFilteredList.indexOf(typeSearchFilter.TypeID);
            if (index !== -1) {
                this.typeFilteredList.splice(index, 1);
            }
        }
    }

    resetLearnSearch() {
        this.advancedSearchTitle = '';
        this.listFilter = '';
        this.categoryFilteredList = new Array<number>();
        this.competencyFilteredList = new Array<number>();
        this.typeFilteredList = new Array<number>();
        this.learnSearchParam = new SearchParam();
        // Reset selected Category
        if (this.learnSearchFilter.Categories) {
            this.learnSearchFilter.Categories.forEach(category => {
                category.Selected = false;
            });
        }
        // Reset selected Competency
        if (this.learnSearchFilter.Competencies) {
            this.learnSearchFilter.Competencies.forEach(competency => {
                competency.Selected = false;
            });
        }
        // Reset selected Type
        if (this.learnSearchFilter.TrainingTypes) {
            this.learnSearchFilter.TrainingTypes.forEach(type => {
                type.Selected = false;
            });
        }
        // Get all learn data
        this.getLearnData();
    }

    toggleAdvanceSearch(isShowAdvanceSearch: boolean) {
        this.isShowAdvanceSearch = isShowAdvanceSearch;
    }
    //#endregion

    ngOnDestroy() {
        this._eventEmiter.unsubscribe(this.subscription);
    }

    showTrainingCatalog() {
        this.router.navigate(['/iCoachFirst/learn/trainingcatalog']);
        // const dialogConfig = new MatDialogConfig();
        // dialogConfig.data = {};
        // dialogConfig.width = LearnModalPopupEnum.PreviewModalWidth + 'px';
        // dialogConfig.height = LearnModalPopupEnum.PreviewModalHeight + 'px';
        // // dialogConfig.disableClose = true;
        // const dialogRef = this.dialog.open(TrainingCatalogComponent, dialogConfig);
        // dialogRef.afterClosed().subscribe(responseData => {
        //     if (responseData.Refresh) {
        //         this.getLearnSearchData();
        //     }
        // });
    }

    reviewCountIncrease(ContentId: number) {
        this.reviewPopupRequest.ContentId = ContentId;
        this.reviewPopupRequest.LoggedInEmpId = this.userInfo.EmployeeId;
        this.reviewPopupRequest.CandidateAssessmentId = 0;
        this.assignTrainingService.reviewTrainingContent(this.reviewPopupRequest).subscribe(resultData => {
            const result = JSON.parse(JSON.stringify(resultData));
            if (result) {
                // (result)
            }
        },
        );
    }

    OnLeftAndRightArrowClicked(clkOnType: string): number {
        if (clkOnType === "right" && this.activeSlideIndex < this.featuredTrainingList.length - 1) {
            this.activeSlideIndex = this.activeSlideIndex + 1;
        }

        if (clkOnType === "left" && this.activeSlideIndex > 0) {
            this.activeSlideIndex = this.activeSlideIndex - 1;
        }
        return this.activeSlideIndex;
    }

    CurrentIndexBannerItem(): FeaturedTrainings {
        let item = {} as FeaturedTrainings;
        if (this.activeSlideIndex >= 0 && this.activeSlideIndex < this.featuredTrainingList.length) {
            item = this.featuredTrainingList[this.activeSlideIndex];
        }
        return item;
    }
}
