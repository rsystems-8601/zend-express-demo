import { Component, OnInit, Inject, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';

// Custom
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { LearnService } from 'src/app/services/learn.service';
import { Assignment, AssignmentRequest } from 'src/app/models/requests/learn/learn-request';
import { IcftoasterService } from 'src/app/services/icftoaster.service';
import { FeaturedTrainings } from 'src/app/models/response/learn/learn-response';

@Component({
    selector: 'app-select-all',
    styleUrls: ['./../learn-assign.scss'],
    templateUrl: './select-all.component.html'
})
export class LearnSelectAllComponent implements OnInit {

    isFormSubmitted = false;
    assignment: Assignment = new Assignment();
    // Left Panel Assign Training START
    training: FeaturedTrainings;
    CoacheeId: number;
    IsAssignedFromLeftPanel = false;
    assignmentRequest: AssignmentRequest = new AssignmentRequest();
    // Left Panel Assign Training END
    @ViewChild('selectAllForm') selectAllForm: NgForm;
    todyDate: Date = new Date();
    constructor(public dialogRef: MatDialogRef<LearnSelectAllComponent>, @Inject(MAT_DIALOG_DATA) public data: any,
    private learnService: LearnService, private toast: IcftoasterService) { }

    ngOnInit() {
        if (this.data) {
            this.training = this.data.training;
            this.CoacheeId = this.data.coacheeId;
            this.IsAssignedFromLeftPanel = this.data.isAssignedFromLeftPanel;
        }
    }

    close() {
        this.dialogRef.close();
    }

    saveSelectAll() {
        if (!this.selectAllForm.valid) {
            this.isFormSubmitted = true;
            return;
        }
        // If condition for Training Assignment from Left Panel
        if (this.training != null && this.IsAssignedFromLeftPanel) {
            const assignmentReq: Assignment = new Assignment();
            assignmentReq.ContentId = this.training.ContentId;
            assignmentReq.EmpId = this.CoacheeId;
            assignmentReq.ReviewByDate = this.assignment.ReviewByDate;
            assignmentReq.MgrComment = this.assignment.MgrComment;
            this.assignmentRequest.Assignments.push(assignmentReq);
            this.learnService.saveTrainingAssignments(this.assignmentRequest).subscribe(responseData => {
                const apiRespone = JSON.parse(JSON.stringify(responseData));
                if (apiRespone.ResultStatusCode === 'success') {
                    this.toast.success('Common_AddedSuccessfully', '');
                    this.close();
                } else {
                    this.toast.error(apiRespone.ErrorMessage, '');
                }

            },
                // error => {
                //     this.toast.error('API not working' + error, '');
                // }
            );
        } else {
            this.dialogRef.close(this.assignment);
        }
    }

}
