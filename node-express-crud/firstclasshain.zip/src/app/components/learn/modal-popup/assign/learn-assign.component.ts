import { Component, OnInit, Inject, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';

// Custom
import { MatDialogRef, MAT_DIALOG_DATA, MatDialogConfig, MatDialog } from '@angular/material';
import { AssignResponse, AssigneeDetail } from '../../../../models/response/learn/learn-assign-response';
import { LearnService } from 'src/app/services/learn.service';
import { LearnModalPopupEnum } from 'src/app/helpers/enums/learn-enums';
import { EventEmiterTypeEnum } from 'src/app/helpers/enums/common-enums';
import { LearnSelectAllComponent } from '../../../../components/learn/modal-popup/assign/select-all/select-all.component';
import { Assignment, AssignmentRequest } from 'src/app/models/requests/learn/learn-request';
import { LearnBaseResponse } from 'src/app/models/response/learn/learn-response';
import { IcftoasterService } from 'src/app/services/icftoaster.service';
import { LearnHistoryDataResponse } from 'src/app/models/response/learn/learn-history-data-response';
import { EventEmiterService } from 'src/app/services/event.emmiter.service';

@Component({
    selector: 'app-assign',
    styleUrls: ['./learn-assign.scss'],
    templateUrl: './learn-assign.component.html'
})
export class LearnAssignComponent implements OnInit {

    isFormSubmitted = false;
    isShowHistory = false;
    todyDate: Date = new Date();

    learnDetails: LearnBaseResponse;
    // Request
    assignment: Assignment = new Assignment();
    assignmentRequest: AssignmentRequest = new AssignmentRequest();
    // Response
    assignToList: AssignResponse = new AssignResponse();
    historyDataList: Array<LearnHistoryDataResponse> = [];    

    @ViewChild('assignToForm') assignToForm: NgForm;

    constructor(public dialogRef: MatDialogRef<LearnAssignComponent>,
        @Inject(MAT_DIALOG_DATA) public data: any,
        private learnService: LearnService,
        private dialog: MatDialog,
        private toast: IcftoasterService,
        private _eventEmiter: EventEmiterService,
       ) {

    }

    ngOnInit() {
        this.learnDetails = this.data;
        this.getTrainingAssignees();
        this.getLearnHistoryData();
    }

    close() {
        this.dialogRef.close();
    }

    SaveAssignTo() {
        // Validate form
        if (!this.assignToForm.valid) {
            this.isFormSubmitted = true;
            return;
        }
        // Formating data for API input request
        if (this.assignToList.Assignees) {
            this.assignToList.Assignees.forEach(item => {

                if (item.Selected) {
                    let assignmentReq: Assignment = new Assignment();
                    assignmentReq = this.getAssigneeDetail(item);
                    this.assignmentRequest.Assignments.push(assignmentReq);
                }

                if (item.Reportees) {
                    item.Reportees.forEach(reportee => {
                        if (reportee.Selected) {
                            let assignmentReq: Assignment = new Assignment();
                            assignmentReq = this.getAssigneeDetail(reportee);
                            this.assignmentRequest.Assignments.push(assignmentReq);
                        }
                    });
                }
            });
        }
        // At least one assignee must be selected.
        if (this.assignmentRequest.Assignments.length === 0) {
            this.toast.error('TrainAssign_OneRow', '');
            return;
        }

        this.learnService.saveTrainingAssignments(this.assignmentRequest).subscribe(responseData => {
            const apiResponse = JSON.parse(JSON.stringify(responseData));
            if (apiResponse.ResultStatusCode.toLowerCase() === 'success') {
                // this. getLearnHistoryData();
                this.assignToForm.form.reset();
                this.isFormSubmitted = false;
                this._eventEmiter.emit({ actionType: EventEmiterTypeEnum.AssignTrainingToTeamMember });
                this.toast.success('Common_UpdateSuccess', '');
                this.close();
            } else {
                this.toast.error(apiResponse.ErrorMessage, '');
            }

        },
            // error => {
            //     this.toast.error('API not working' + error, '');
            // }
        );
    }

    selectAll() {
        const dialogConfig = new MatDialogConfig();
        dialogConfig.width = LearnModalPopupEnum.SelectAllModalWidth + 'px';
        const dialogRef = this.dialog.open(LearnSelectAllComponent, dialogConfig);
        dialogRef.afterClosed().subscribe(selectAllResp => {
            // Assign common due date and message to all
            if (selectAllResp) {
                this.assignment = selectAllResp;
                if (this.assignToList.Assignees) {
                    this.assignToList.Assignees.forEach(item => {
                        item.Selected = true;
                        item.DueDate = this.assignment.ReviewByDate;
                        item.Comment = this.assignment.MgrComment;
                    });
                }
            }
        });

    }

    toggleShowHistory() {
        this.isShowHistory = !this.isShowHistory;
    }

    getTrainingAssignees() {
        this.learnService.getTrainingAssignees().subscribe(resultData => {
            this.assignToList = JSON.parse(JSON.stringify(resultData));
            if (this.assignToList.Assignees) {
                this.assignToList.Assignees.forEach(item => {
                    item.Selected = false;
                    item.Expended = false;
                    if (item.Reportees) {
                        item.Reportees.forEach(reportee => {
                            reportee.Selected = false;
                            reportee.Expended = false;
                        });
                    }
                });
            }
        },
            // error => {
            //     this.toast.error('API not working' + error, '');
            // }
        );
    }
    getLearnHistoryData() {
        this.learnService.getLearnHistory(this.learnDetails.ContentId, false, false).subscribe(resultData => {
            this.historyDataList = JSON.parse(JSON.stringify(resultData));
        },
            // error => {
            //     this.toast.error('API not working' + error, '');
            // }
        );
    }
    private getAssigneeDetail(assigneeDetail: AssigneeDetail): Assignment {
        const assignmentReq: Assignment = new Assignment();
        assignmentReq.ContentId = this.learnDetails.ContentId;
        assignmentReq.EmpId = assigneeDetail.EmpId;
        assignmentReq.ReviewByDate = assigneeDetail.DueDate;
        assignmentReq.MgrComment = assigneeDetail.Comment;
        return assignmentReq;
    }

}
