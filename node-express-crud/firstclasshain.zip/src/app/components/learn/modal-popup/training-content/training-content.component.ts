import { Component, OnInit, Inject, Input, OnDestroy } from '@angular/core';
import { LearnBaseResponse } from 'src/app/models/response/learn/learn-response';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { SafeResourceUrl, DomSanitizer } from '@angular/platform-browser';
import { ModalResponse } from 'src/app/models/response/common/modal-popup-response';
import { ActivatedRoute, Router } from '@angular/router';
import { LearnService } from 'src/app/services/learn.service';
import { ScormLaunchUrlRequest } from 'src/app/models/requests/learn/scorm-launch-url-request';
import { QuizUrlRequest } from 'src/app/models/requests/url-builder/quiz-url-request';
import { QuizUrlBuilderService } from 'src/app/services/quiz-url-builder.service';
import { UserService } from 'src/app/services/user.service';
import { IcftoasterService } from 'src/app/services/icftoaster.service';
import { SharedDataService } from 'src/app/services/shared-data.service';
import { environment } from 'src/environments/environment';
import { CommonService } from 'src/app/services/common.service';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-training-content',
  templateUrl: './training-content.component.html',
  styleUrls: ['./training-content.component.scss']
})
export class TrainingContentComponent implements OnInit, OnDestroy {

  @Input() trainingContent: LearnBaseResponse;
  modalResponse: ModalResponse = new ModalResponse();
  ShowVideo = false;
  @Input() ContentId = {} as any;
  ShowPDF = false;
  ShowLink = false;
  ShowScorm = false;
  showQuiz = false;
  pdfSource: SafeResourceUrl;
  scormSource: SafeResourceUrl;
  pdfSourceObject: SafeResourceUrl;
  trainingDetails: LearnBaseResponse;
  url: string;
  quizUrlRequest = {} as QuizUrlRequest;
  callBackComplete: boolean;
  userDetails: any;
  coacheeId: number;
  isSelfAssign = false;

  constructor(public dialogRef: MatDialogRef<TrainingContentComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private sanitizer: DomSanitizer,
    private route: ActivatedRoute,
    private learnService: LearnService,
    private quizUrlBuilderService: QuizUrlBuilderService,
    private userService: UserService,
    private toast: IcftoasterService,
    private sharedDataService: SharedDataService,
    private router: Router,
    private commonService: CommonService,
    private authService: AuthService
  ) { }

  ngOnInit() {
    window.addEventListener('message', this.handleIframeResponse.bind(this));
    this.callBackComplete = false;
    this.dialogRef.disableClose = true;
    if (this.sharedDataService.getAssignedData() !== undefined) {     
      if (this.sharedDataService.getAssignedData() === 'true') {
        this.isSelfAssign = true;
      } else if (this.sharedDataService.getAssignedData() === 'false') {
        this.isSelfAssign = false;
      }
    }
    this.route.params.subscribe(params => {
      this.ShowVideo = false;
      this.ShowPDF = false;
      this.ShowScorm = false;
      this.ShowLink = false;
      this.showQuiz = false;
      this.scormSource = undefined;
      if (this.data.TypeName !== undefined) {
        this.trainingDetails = this.data;

        this.BindTraining();
      } else {
        this.learnService.getLearnData().subscribe(resultData => {
          const learnData = JSON.parse(JSON.stringify(resultData));
          this.trainingDetails = learnData.AssignedToMe.find(x => x.AssignmentId === +params.id);

          this.BindTraining();
        });
      }
    });
  }

  BindTraining() {
    if (this.trainingDetails.TypeName.toLowerCase() === 'video') {
      this.ShowVideo = true;
    } else if (this.trainingDetails.TypeName.toLowerCase() === 'document') {
      this.ShowPDF = true;
      var iOS = !!navigator.platform && /iPad|iPhone|iPod/.test(navigator.platform);
      if (iOS) {
      } else {
        this.pdfSource = this.sanitizer.bypassSecurityTrustResourceUrl(this.trainingDetails.ReviewLink);
        // tslint:disable-next-line:max-line-length
        this.pdfSourceObject = this.sanitizer.bypassSecurityTrustResourceUrl('https://docs.google.com/viewer?url=' + this.trainingDetails.ReviewLink + '&embedded=true');
      }
    } else if (this.trainingDetails.TypeName.toLowerCase() === 'elearning') {
      this.ShowScorm = true;
      // Generate scorm url
      // ICF6-590 New API for generating Url for eLearning category
      const request = {} as ScormLaunchUrlRequest;
      request.AssignmentId = this.trainingDetails.AssignmentId;
      request.MemberOrgId = this.userService.getUserDetails().UserDetails.MemberOrgID;
      this.learnService.geteLearningLaunchUrl(request).subscribe(data => {
        const datas = JSON.parse(JSON.stringify(data));
        if (!datas.ErrorMessage) {
          this.scormSource = this.sanitizer.bypassSecurityTrustResourceUrl(datas.LaunchUrl);
        } else {
          this.toast.error(datas.ErrorMessage);
        }
      });
    } else if (this.trainingDetails.TypeName.toLowerCase() === 'quiz') {
      const redirectTo = this.sharedDataService.getRedirectionValue();
      this.showQuiz = true;
      this.quizUrlRequest.CandidateAssessmentId = this.ContentId.CandidateAssessmentId;
      this.quizUrlRequest.RedirectTo = redirectTo; // Need to identify source
      this.url = this.quizUrlBuilderService.newReportUrl(this.quizUrlRequest);
    } else {
      this.ShowLink = true;
    }
  }

  close() {
    this.dialogRef.close();
  }

  handleIframeResponse(e) {
    window.removeEventListener('message', () => { });
    if (!this.callBackComplete) {
      this.callBackComplete = true;
      if (e.origin !== `${environment.domainName}`) {
        return false;
      }
      if (e.data.redirectTo === 'dashboard') {
        this.router.navigate(['/iCoachFirst/dashboard']);

      } else if (e.data.redirectTo === 'manage') {
        this.userDetails = this.userService.getUserDetails();
        if (this.userDetails.CoacheeDetails !== undefined) {
          this.coacheeId = this.userDetails.CoacheeDetails.UserDetails.EmpId;
          this.router.navigate(['/iCoachFirst/manage/manage', this.coacheeId]);

        } else {
          this.router.navigate(['/iCoachFirst/dashboard']);

        }
      } else if (e.data.redirectTo && e.data.redirectTo === 'logout') {
        this.authService.commonLogout();
      } else {
        history.back();
      }
    }
  }

  // completeRequest(_data: any) {

  // }

  ngOnDestroy() {
    this.callBackComplete = true;
    window.removeEventListener('message', () => { });
  }

  closePopupOnIframe() {
    this.commonService.closePopupOnIframe();
  }

  showPopupOnIframe() {
    this.dialogRef.disableClose = true;
  }

  cancelClicked() {
    this.dialogRef.close();
  }
}
