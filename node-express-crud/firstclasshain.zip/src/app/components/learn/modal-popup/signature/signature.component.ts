import { Component, OnInit, Input } from '@angular/core';
import { LearnBaseResponse, ElecSignatureSettingResponse } from 'src/app/models/response/learn/learn-response';
import { DatePipe } from '@angular/common';
import { UserService } from 'src/app/services/user.service';
import { LearnService } from 'src/app/services/learn.service';
import html2canvas from 'html2canvas';
import { MarkCompleteRequest } from 'src/app/models/requests/learn/learn-request';
import { IcftoasterService } from 'src/app/services/icftoaster.service';
import { MatDialogRef } from '@angular/material';
import { FormGroup, FormBuilder } from '@angular/forms';

@Component({
    selector: 'app-signature',
    templateUrl: './signature.component.html',
    styleUrls: ['./signature.component.scss']
})
export class SignatureComponent implements OnInit {

    @Input() learnDetails: LearnBaseResponse;
    dateOfCompletion: string;
    loggedInUserName: string;
    todyDate: Date = new Date();
    eSignatureSettingResponse: ElecSignatureSettingResponse;
    eSignatureStyles: {};
    markCompleteRequest: MarkCompleteRequest = new MarkCompleteRequest();
    signature: FormGroup;
    submitted: false;
    showElectronicSignature: false;

    constructor(private datePipe: DatePipe,
        private userService: UserService,
        private learnService: LearnService,
        private toast: IcftoasterService,
        private dialogRef: MatDialogRef<SignatureComponent>,
        private formBuilder: FormBuilder) { }

    ngOnInit() {
        this.signature = this.formBuilder.group({
            selfComments: [''],
            userName: [''],
            learnTitle: [''],
            dateOfCompletion: [''],
            assignedDate: [''],
            electronicSignatureComments: ['']
        });

        this.dateOfCompletion = this.datePipe.transform(this.todyDate, 'MM-dd-yyyy');
        this.loggedInUserName = this.userService.getUserDetails().UserDetails.Name;
        this.learnService.getOrgLevelSetting4MarkComplete().subscribe(responseData => {
            this.eSignatureSettingResponse = JSON.parse(JSON.stringify(responseData));
            this.eSignatureStyles = {
                'font-size': this.eSignatureSettingResponse.TextSize + 'px',
                'font-family': this.eSignatureSettingResponse.TextFont,
            };
        });
    }

    // convenience getter for easy access to form fields
    get f() {
        return this.signature.controls;
    }

    saveMarkCompleteWithSignature() {
        html2canvas(document.querySelector('#divElectronicSignature')).then(canvas => {
            canvas.style.position = 'absolute';
            const imagedata = canvas.toDataURL();
            this.markCompleteRequest.AssignmentId = this.learnDetails.ContentId;
            this.markCompleteRequest.Image = imagedata.replace(/^data:image\/(png|jpg);base64,/, '');
            this.markCompleteRequest.FileName = 'filename' + '_' + this.learnDetails.ContentId + '_' + this.todyDate.getTime() + '.png';
            this.markCompleteRequest.FileExtension = 'png';
            this.markCompleteRequest.TypeId = this.learnDetails.TypeId;

            this.learnService.saveMarkComplete(this.markCompleteRequest).subscribe(resultData => {
                if (resultData) {
                    this.toast.success('Record saved successfully', '');
                    this.close();
                } else {
                    this.toast.error('Unable to save, please try again.', '');
                }
            },
                // error => {
                //     this.toast.error('API not working' + error, '');
                // }
            );
        });
    }

    close() {
        this.dialogRef.close();
    }

    OnSubmit() { }
}
