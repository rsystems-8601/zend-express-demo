import { Component, OnInit, Inject, ViewChild, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NgForm } from '@angular/forms';

// Custom

import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { LearnBaseResponse, ElecSignatureSettingResponse, AssignedToMe } from '../../../../models/response/learn/learn-response';
import { StarRatingEnum, TypeEnum } from '../../../../helpers/enums/common-enums';
import { StarRatingRequest, MarkCompleteRequest, LearnMarkCompleteRequest } from 'src/app/models/requests/learn/learn-request';
import { LearnService } from 'src/app/services/learn.service';
import { UserService } from 'src/app/services/user.service';
import { IcftoasterService } from 'src/app/services/icftoaster.service';
import html2canvas from 'html2canvas';
import { DatePipe } from '@angular/common';
import { User } from '../../../../models/response/user-response';
import { EventEmiterService } from 'src/app/services/event.emmiter.service';
import { CommonService } from 'src/app/services/common.service';
import { SharedDataService } from 'src/app/services/shared-data.service';
import { AuthService } from 'src/app/services/auth.service';


@Component({
    selector: 'app-learn-review',
    templateUrl: './learn-review.component.html',
    styleUrls: ['./learn-review.component.scss']
})
export class LearnReviewComponent implements OnInit, OnDestroy {
    isFormSubmitted = false;
    contenttId: number;
    linkTypeId: number = TypeEnum.Link;
    eLearningTypeId: number = TypeEnum.eLearning;
    showElectronicSignature = false;
    starRatingRequest: StarRatingRequest = new StarRatingRequest();
    learnDetails = {} as LearnBaseResponse;
    markCompleteRequest: MarkCompleteRequest = new MarkCompleteRequest();
    learnMarkCompleteRequest: LearnMarkCompleteRequest = new LearnMarkCompleteRequest(); // for without signature
    maxRating: number = StarRatingEnum.MaxRating;
    isReadonly = false;
    todyDate: Date = new Date();
    dateOfCompletion: string;
    eSignatureSettingResponse: ElecSignatureSettingResponse = new ElecSignatureSettingResponse();
    // eSignatureFontSize: number = 56; // Default
    // eSignatureFontFamily: string = 'Gigi'; // Default, use emun
    eSignatureStyles: {};
    markCompleteWrapperStyles: {};
    userDetails: User;
    assignedToMeList: AssignedToMe[];
    assignmentId: number;
    ShowTrainingDetails = false;
    ignoreModelForBackHistory = ['report/dynamicreport'];

    @ViewChild('markCompleteForm') markCompleteForm: NgForm;
    callBackComplete = false;

    constructor(
        public dialogRef: MatDialogRef<LearnReviewComponent>,
        @Inject(MAT_DIALOG_DATA) public data: any,
        private learnService: LearnService,
        private toast: IcftoasterService,
        private userService: UserService,
        private datePipe: DatePipe,
        private route: ActivatedRoute,
        private router: Router,
        private _eventEmiter: EventEmiterService,
        private commonService: CommonService,
        private sharedDataService: SharedDataService,
        private authService: AuthService
    ) { }

    ngOnInit() {
        window.addEventListener('message', this.handleIframeTask.bind(this), false);
        this.route.params.subscribe(params => {
            if (+params.id) {
                this.assignmentId = +params.id;
                this.getLearnData();
            }
        });
        this.contenttId = this.route.snapshot.data['ContentId'];
    }

    f() {
        return this.markCompleteForm.controls;
    }
    reset() {
        this.assignmentId = 0;
        this.learnDetails = null;
    }

    getLearnData() {
        this.learnService.getLearnData().subscribe(resultData => {
            const learnData = JSON.parse(JSON.stringify(resultData));
            this.learnDetails = learnData.AssignedToMe.find(x => x.AssignmentId === this.assignmentId);
            this.starRatingRequest.Rating = this.learnDetails.RatingProvidedByUser;
            this.dateOfCompletion = this.datePipe.transform(this.todyDate, 'MM-dd-yyyy');
            this.userDetails = this.userService.getUserDetails().UserDetails;
            this.learnService.getOrgLevelSetting4MarkComplete().subscribe(responseData => {
                this.eSignatureSettingResponse = JSON.parse(JSON.stringify(responseData));
                this.eSignatureStyles = {
                    'font-size': this.eSignatureSettingResponse.TextSize + 'px',
                    'font-family': this.eSignatureSettingResponse.TextFont,
                };
                if (!this.eSignatureSettingResponse.IsEnabled) {
                    this.markCompleteWrapperStyles = {
                        'height': '350px',
                    };
                } else {
                    this.markCompleteWrapperStyles = {};
                }

            });
        },
            // error => this.toast.error('API not working' + error, '');
        );
    }

    close() {
        this.dialogRef.close();
    }

    showTrainingDetails() {
        this.ShowTrainingDetails = !this.ShowTrainingDetails;
    }

    saveStarRating() {
        this.starRatingRequest.AssignmentId = this.learnDetails.AssignmentId;
        this.learnService.saveStarRating(this.starRatingRequest).subscribe(resultData => {

            const apiRespone = JSON.parse(JSON.stringify(resultData));
            if (apiRespone.ResultStatusCode === 'success') {
                this.toast.success('Common_UpdateSuccess', '');
            } else {
                this.toast.error('Unable to save, please try again.', '');
            }
        },
            () => {
                // this.toast.error('API not working'  , '');
            }
        );

    }
    saveMarkComplete() {
        // Close the training details to stop the overlap with signature overlay.
        if (this.ShowTrainingDetails) {
            this.showTrainingDetails();
        }
        this.showElectronicSignature = true;
        /*
        if (this.eSignatureSettingResponse.IsEnabled) {
            this.showElectronicSignature = true;

            // Close the training details to stop the overlap with signature overlay.
            if (this.ShowTrainingDetails) {
                this.showTrainingDetails();
            }
        } else {
            this.saveMarkCompleteWithoutSignature();
        }
        */
    }

    saveMarkCompleteWithoutSignature() {
        this.learnMarkCompleteRequest.AssignmentId = this.learnDetails.AssignmentId;
        this.learnMarkCompleteRequest.IsMarkComplete = true;
        this.learnService.saveMarkCompleteWithoutSignature(this.learnMarkCompleteRequest).subscribe(responseData => {
            const respone = JSON.parse(JSON.stringify(responseData));
            if (respone.ResultStatusCode === 'success') {
                this.toast.success('ActTraining_Popup', '');
                this._eventEmiter.emit({ actionType: 'UpdateAssignToMe' });
                this.router.navigate(['/iCoachFirst/dashboard']);
                // history.back();
            } else {
                this.toast.error('Unable to mark complete.', '');
            }
        });
    }

    saveMarkCompleteWithSignature() {
        if (!this.markCompleteForm.valid) {
            this.isFormSubmitted = true;
            return;
        }
        html2canvas(document.querySelector('#divElectronicSignature')).then(canvas => {
            canvas.style.position = 'absolute';
            const imagedata = canvas.toDataURL();
            this.markCompleteRequest.AssignmentId = this.learnDetails.AssignmentId;
            this.markCompleteRequest.Image = imagedata.replace(/^data:image\/(png|jpg);base64,/, '');
            this.markCompleteRequest.FileName = this.userDetails.EmpId + '_' +
                this.learnDetails.ContentId + '_' + this.todyDate.getTime() + '.png';
            this.markCompleteRequest.FileExtension = 'png';
            this.markCompleteRequest.TypeId = this.learnDetails.TypeId;

            this.learnService.saveMarkComplete(this.markCompleteRequest).subscribe(resultData => {
                if (resultData) {
                    this.toast.success('ActTraining_Popup', '');
                    this._eventEmiter.emit({ actionType: 'UpdateAssignToMe' });
                    this.showElectronicSignature = false;
                    // history.back();
                    this.router.navigate(['/iCoachFirst/dashboard']);
                } else {
                    this.toast.error('Unable to mark complete.', '');
                }
            },
                () => {
                    // this.toast.error('API not working' + error, '');
                }
            );
        });
    }

    onClickBack() {
        for (let i = 0; i < this.ignoreModelForBackHistory.length; i++) {
            const index = location.href.indexOf(this.ignoreModelForBackHistory[i]);
            if (index > 0) {
                return false;
            }
        }
        history.back();
    }

    closePopupOnIframe() {
        this.commonService.closePopupOnIframe();
    }

    handleIframeTask(e) {
        window.removeEventListener('message', () => { });
        // Member variable this.callBackComplete will be false if user refreshes the url
        // and it will be true if user open this same component again and again
        // so added the check using variable
        if (!this.callBackComplete) {
            if (e.data.redirectTo === undefined && e.data.lockAngularScreen === undefined) {
                // the redirectTo will be undefined if user directly refreshes the url
                // added because this func is getting fired first if user refreshes url directly.
                return;
            }
            if (e.data.redirectTo && e.data.redirectTo === 'logout') {
                this.authService.commonLogout();
            }

            if (e.data.redirectTo === 'dashboard') {
                this.callBackComplete = true;
                let redirect = this.sharedDataService.getRedirectionValue();
                if (redirect !== undefined) {
                    redirect = decodeURIComponent(redirect);
                    this.router.navigate([`/${redirect}`]);
                } else {
                    // If userdirectly refreshes the url the redirect value will will be undefined.
                    this.router.navigate(['/iCoachFirst/dashboard']);
                }
            }
        }
    }

    ngOnDestroy() {
        this.callBackComplete = true;
        window.removeEventListener('message', () => { });
      }

}
