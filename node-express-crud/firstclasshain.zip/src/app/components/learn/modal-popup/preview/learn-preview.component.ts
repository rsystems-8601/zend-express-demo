import { Component, OnInit, Inject } from '@angular/core';
// Custom
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { LearnBaseResponse } from '../../../../models/response/learn/learn-response';
import { LearnService } from 'src/app/services/learn.service';
import { StarRatingRequest } from '../../../../models/requests/learn/learn-request';
import { IcftoasterService } from 'src/app/services/icftoaster.service';
import { StarRatingEnum } from '../../../../helpers/enums/common-enums';
import { ModalResponse } from '../../../../models/response/common/modal-popup-response';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';

@Component({
    selector: 'app-learn-preview',
    templateUrl: './learn-preview.component.html'
})
export class LearnPreviewComponent implements OnInit {

    starRatingRequest: StarRatingRequest = new StarRatingRequest();
    learnDetails: LearnBaseResponse;
    maxRating: number = StarRatingEnum.MaxRating;
    isReadonly = false;
    modalResponse: ModalResponse = new ModalResponse();
    ShowTrainingContent = false;
    ShowVideo = false;
    ShowPDF = false;
    pdfSource: SafeResourceUrl;
    constructor(public dialogRef: MatDialogRef<LearnPreviewComponent>,
        @Inject(MAT_DIALOG_DATA) public data: any,
        private learnService: LearnService,
        private toast: IcftoasterService,
        private sanitizer: DomSanitizer
    ) { }

    ngOnInit() {
        this.learnDetails = this.data;
        this.starRatingRequest.Rating = this.learnDetails.RatingProvidedByUser;

        if (this.learnDetails.TypeName === 'Video') {
            this.ShowVideo = true;
        } else if (this.learnDetails.TypeName === 'Document') {
            this.ShowPDF = true;
            this.pdfSource = this.sanitizer.bypassSecurityTrustResourceUrl(this.learnDetails.ReviewLink);
        }
    }

    close() {
        this.dialogRef.close(this.modalResponse);
    }

    saveStarRating() {
        this.starRatingRequest.ContentId = this.learnDetails.ContentId;
        this.learnService.saveStarRating(this.starRatingRequest).subscribe(responseData => {
            const apiRespone = JSON.parse(JSON.stringify(responseData));
            if (apiRespone.ResultStatusCode === 'success') {
                this.toast.success('Common_UpdateSuccess', '');
                this.modalResponse.Refresh = true; // To refresh parant component
            } else {
                this.toast.error('Unable to save, please try again.', '');
            }
        },
            () => {
                // this.toast.error('API not working'  , '');
            }
        );

    }

    saveMarkComplete() {
        if (this.learnDetails.TypeName === 'Video' || this.learnDetails.TypeName === 'Document') {
            this.ShowTrainingContent = !this.ShowTrainingContent;
        } else {
            window.open(this.learnDetails.ReviewLink, '_blank');
            window.focus();
        }
    }
}
