import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mark-complete',
  templateUrl: './mark-complete.component.html',
  styleUrls: ['./mark-complete.component.scss']
})
export class MarkCompleteComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
