import { Component, OnInit, Inject, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
// Custom

import { LearnHistoryDataResponse } from '../../../../models/response/learn/learn-history-data-response';
import { LearnBaseResponse } from '../../../../models/response/learn/learn-response';
import { LearnService } from 'src/app/services/learn.service';
import { LearnSelfAssignRequest } from '../../../../models/requests/learn/learn-self-assign-request';
import { IcftoasterService } from 'src/app/services/icftoaster.service';
import { EventEmiterService } from 'src/app/services/event.emmiter.service';
import { UserService } from 'src/app/services/user.service';
import { UserDetails } from 'src/app/models/user-details-result';

@Component({
    selector: 'app-self-assign-preview',
    styleUrls: ['./../assign/learn-assign.scss'],
    templateUrl: './learn-self-assign.component.html'
})
export class LearnSelfAssignComponent implements OnInit {
    learnDetails: LearnBaseResponse;
    learnHistoryDataResponseList: Array<LearnHistoryDataResponse> = [];
    selfAssignRequest: LearnSelfAssignRequest = new LearnSelfAssignRequest();
    userInfo: UserDetails;


    @ViewChild('selfAssignForm') selfAssignForm: NgForm;
    isFormSubmitted = false;

    todyDate: Date = new Date();

    constructor(public dialogRef: MatDialogRef<LearnSelfAssignComponent>,
        @Inject(MAT_DIALOG_DATA) public data: any,
        private learnService: LearnService,
        private toast: IcftoasterService,
        private _eventEmiter: EventEmiterService,
        private userService: UserService
    ) { }

    ngOnInit() {
        this.learnDetails = this.data;
        this.userInfo = this.userService.getUserDetails().UserDetails;
        this.getLearnHistoryData();
    }

    close() {
        this.dialogRef.close();
    }

    getLearnHistoryData() {
        this.learnService.getLearnHistory(this.learnDetails.ContentId, false, true).subscribe(resultData => {
            this.learnHistoryDataResponseList = JSON.parse(JSON.stringify(resultData));
        },
            // error => {
            //      this.toast.error('API not working' + error, '');
            // }
        );
    }

    saveSelfAssign() {
        if (!this.selfAssignForm.valid) {
            this.isFormSubmitted = true;
            return;
        }

        this.selfAssignRequest.CourseId = this.learnDetails.CourseId;
        this.selfAssignRequest.ContentId = this.learnDetails.ContentId;
        this.selfAssignRequest.LearnerEmailId = this.userInfo.EmailId;
        this.selfAssignRequest.LearnerFirstName = this.userInfo.Name;
        this.selfAssignRequest.LearnerLastName = this.userInfo.Name;
        this.learnService.saveSelfAssignRequest(this.selfAssignRequest).subscribe(resultData => {
            const apiRespone = JSON.parse(JSON.stringify(resultData));
            if (apiRespone.IsSuccess) {
                this.selfAssignForm.form.reset();
                this.isFormSubmitted = false;
                this.toast.success('Common_UpdateSuccess', '');
                this._eventEmiter.emit({ actionType: 'AssignTraining' });
                this.close();
                // this.getLearnHistoryData();
            } else {
                this.toast.error('Unable to save, please try again.', '');
            }
        },
            // error => {
            //     // this.toast.error('API not working' + error, '');
            // }
        );
    }

}
