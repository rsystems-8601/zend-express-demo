import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { IcftoasterService } from 'src/app/services/icftoaster.service';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.scss']
})
export class ResetPasswordComponent implements OnInit {

  resetPasswordForm: FormGroup;
  submitted = false;
  patternError = '';
  emailId = '';
  constructor(private formBuilder: FormBuilder, private toast: IcftoasterService,
    private router: Router, private authService: AuthService,
    private userService: UserService) { }

  ngOnInit() {
    this.emailId = this.router.url.split('=')[1];
    this.resetPasswordForm = this.formBuilder.group({
      oldPassword: ['', Validators.required],
      newPassword: ['', [Validators.required, Validators.minLength(8), Validators.maxLength(16)]],
      cnfmPassword: ['', Validators.required]
    });

    this.resetPasswordForm.valueChanges.subscribe(() => {
      this.submitted = false;
    });
  }

  onSubmit() {
    this.submitted = true;
    if (this.validation()) {
      this.toast.error('Incorrect record');
    }
  }

  get f() {
    return this.resetPasswordForm.controls;
  }

  validation() {
    this.submitted = true;
    const oldPassword = this.f.oldPassword;
    const newPassword = this.f.newPassword;
    const cnfmPassword = this.f.cnfmPassword;


    if (oldPassword.value === '') {
      oldPassword.errors.required = true;
      return false;
    }
    if (newPassword.value === '') {
      newPassword.errors.required = true;
      return false;
    }
    if (cnfmPassword.value === '') {
      cnfmPassword.errors.required = true;
      return false;
    }
    if (newPassword.value !== cnfmPassword.value) {
      cnfmPassword.setErrors({ 'matching': true });
      return false;
    }
    if (newPassword.errors && newPassword.errors.minlength) {
      return false;
    }
    if (newPassword.errors && newPassword.errors.maxlength) {
      return false;
    }

    const msg = this.validateCharacters(newPassword.value);
    if (msg === 'passed') {
      // If all requiremnets are met, the check for OTP by hitting reset service
      this.authService.resetPassword(this.emailId, newPassword.value, oldPassword.value).subscribe(data => {
        if (data.ResultStatusCode === 'OTP password is incorrect') {
          this.toast.error('ResetPassword_IncorrectOldPassword');
        } else if (data.ResultStatusCode === 'Password updated successfully') {
          this.toast.success('ResetPassword_PasswordChangedSuccessfully');
          // Password Reset is successful, login the user
          this.login();
        }
      });
    } else {
      newPassword.setErrors({ 'pattern': true });
      this.patternError = msg;
    }
  }

  login() {
    const email = this.emailId;
    const password = this.f.newPassword.value;

    this.authService.login(email, password).subscribe(response => {
      if (response.IsAuthSucess && !response.IsOTPRequired) {
        // token received success
        this.userService.fetchUserDetails(userInfo => {
          if (userInfo.IsAuthSuccess === 'True') {
            this.router.navigate(['/iCoachFirst/dashboard']);
          } else {
            this.toast.error(userInfo.LoginError);
          }
        });
      } else {
        this.toast.error(response.ErrorMessage);
      }
    });
  }

  validateCharacters(pwd: string): string {
    let upper = false, lower = false, numeric = false;
    const upperCasePattern = new RegExp('^[A-Z]$');
    const lowerCasePattern = new RegExp('^[a-z]$');
    const numericPattern = new RegExp('^[0-9]$');

    for (let i = 0; i < pwd.length; i++) {
      const char = pwd.charAt(i);
      if (!upper) {
        if (upperCasePattern.test(char)) {
          upper = true;
        }
      }
      if (!lower) {
        if (lowerCasePattern.test(char)) {
          lower = true;
        }
      }
      if (!numeric) {
        if (numericPattern.test(char)) {
          numeric = true;
        }
      }

      if (upper && lower && numeric) {
        return 'passed';
      }
    }
    if (!upper) {
      return 'New password should contain atleast one upper case character.';
    }
    if (!lower) {
      return 'New password should contain atleast one lower case character.';
    }
    if (!numeric) {
      return 'New password should contain atleast one numeric';
    }
  }
}
