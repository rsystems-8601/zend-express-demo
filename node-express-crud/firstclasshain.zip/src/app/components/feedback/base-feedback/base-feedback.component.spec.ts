import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BaseFeedbackComponent } from './base-feedback.component';

describe('BaseFeedbackComponent', () => {
  let component: BaseFeedbackComponent;
  let fixture: ComponentFixture<BaseFeedbackComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BaseFeedbackComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BaseFeedbackComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
