import { Component, OnInit, Input } from '@angular/core';
import { IGoalTaskChatDetailsResultDecoded } from 'src/app/models/response/itask-goal-chat-response';
// import { FormGroup, FormBuilder, Validators } from '@angular/forms';


@Component({
  selector: 'app-base-feedback',
  templateUrl: './base-feedback.component.html',
  styleUrls: ['./base-feedback.component.scss']
})
export class BaseFeedbackComponent implements OnInit {

  @Input() feedbackData: IGoalTaskChatDetailsResultDecoded[];
  @Input() EmpId: number;

  constructor() {

  }

  ngOnInit() {

  }

}
