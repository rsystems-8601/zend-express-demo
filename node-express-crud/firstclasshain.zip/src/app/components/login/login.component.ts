import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import { AuthService } from '../../services/auth.service';
import { UserService } from '../../services/user.service';
import { IcftoasterService } from '../../services/icftoaster.service';
import { LanguageSelectionComponent } from '../../components/user-settings/language-selection/language-selection.component';
import { MatDialog, MatDialogConfig } from '@angular/material';
import { LocalizationService } from 'src/app/services/localization.service';
import { TalentCulture } from '../../models/response/talentCulture';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  showPassword = false;
  loginForm: FormGroup;
  submitted = false;
  imagePath = 'assets/images/flag/';
  selectedLocale: TalentCulture;
  showv6Page = false;

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private authService: AuthService,
    private userService: UserService,
    private toast: IcftoasterService,
    private dialog: MatDialog,
    private localizationService: LocalizationService,
    private route: ActivatedRoute
  ) {
    if (window.location.href.indexOf('localhost') !== -1) {
      this.showv6Page = true;
    }
   }

  ngOnInit() {

    // Redirecting to v5 Login Page
    if (this.route.snapshot.data['locale']) {
      this.loginForm = this.formBuilder.group({
        email: ['', [Validators.required, Validators.email]],
        password: ['', Validators.required]
      });
      const icf6Culture: TalentCulture = this.localizationService.getICF6CultreFromLocalStorage();
      if (icf6Culture) {
        this.selectedLocale = icf6Culture;
      }
    }

  }

  // convenience getter for easy access to form fields
  get f() {
    return this.loginForm.controls;
  }

  onSubmit() {
    this.submitted = true;

    if (this.f.email.valid) {
      if (this.showPassword === false) {
        this.checkSSOStatus();
        return;
      }
    } else {
      this.showPassword = false;
    }
    // stop here if form is invalid
    if (this.loginForm.invalid) {
      return;
    }

    this.login();

  }

  checkSSOStatus() {
    const email = this.f.email.value;
    this.authService.isSSOEnabled(email).subscribe(response => {
      if (response) {
        // SSO User
        this.toast.info('SSO Enabled. TODO');
      } else {
        // iCoachFirst User
        this.showPassword = true;
        this.submitted = false;
        /**
         * ICF6-337, Changes done for Mozilla for focussing in pasword field
         * Using timeout, because field is hidden, Working as waiting time to
         * render the field
         */
        setTimeout(function () {
          if (document.getElementsByName('icf6_password')[0]) {
            document.getElementsByName('icf6_password')[0].focus();
          }
        }.bind(this), 1000);
      }
    });
  }

  login() {
    const email = this.f.email.value;
    const password = this.f.password.value;

    this.authService.login(email, password).subscribe(response => {
      if (response.IsAuthSucess && !response.IsOTPRequired) {
        // token received success
        this.userService.fetchUserDetails(userInfo => {
          if (userInfo.IsAuthSuccess === 'True') {
            this.router.navigate(['/iCoachFirst/dashboard']);
          } else {
            this.toast.error(userInfo.LoginError);
          }
        });
      } else if (response.IsAuthSucess && response.IsOTPRequired) {
        // If both the params are true, the user has requested to reset the password.
        this.router.navigate(['/resetpassword'], { queryParams: { emailId: email }, skipLocationChange: true });
      } else {
        this.toast.error(response.ErrorMessage);
      }
    });
  }

  openDialog() {
    let culturalData: TalentCulture[] = null;
    this.localizationService.getCultureSupportDetails().subscribe(data => {
      culturalData = data;
      const dialogConfig = new MatDialogConfig();
      dialogConfig.width = '700px';
      dialogConfig.disableClose = true;
      const modalRef = this.dialog.open(LanguageSelectionComponent, dialogConfig);
      modalRef.componentInstance.data = culturalData;
    });
  }
}
