import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PulseSurveyEmailComponent } from './pulse-survey-email.component';

describe('PulseSurveyEmailComponent', () => {
  let component: PulseSurveyEmailComponent;
  let fixture: ComponentFixture<PulseSurveyEmailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PulseSurveyEmailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PulseSurveyEmailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
