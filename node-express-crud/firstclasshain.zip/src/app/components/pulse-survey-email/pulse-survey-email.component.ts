import { Component, OnInit } from '@angular/core';
import { SurveyService } from 'src/app/services/survey.service';
import { ActivatedRoute } from '@angular/router';
import {
  PulseSurveyReviewRemindMeLaterRequest, PulseSurveyReviewRemindMeLaterResponse,
  PulseSurveyReviewDetailResponse
} from 'src/app/models/response/survey.response';

@Component({
  selector: 'app-pulse-survey-email',
  templateUrl: './pulse-survey-email.component.html',
  styleUrls: ['./pulse-survey-email.component.scss']
})
export class PulseSurveyEmailComponent implements OnInit {

  displayMessage: boolean;
  message: string;
  surveyDetails: PulseSurveyReviewDetailResponse;
  getSurvey: boolean;
  msgType: string;
  constructor(
    private surveyService: SurveyService,
    private route: ActivatedRoute
  ) { }

  ngOnInit() {
    this.displayMessage = false;
    this.getSurvey = false;
    const request: any = {
      EmpId: Number(this.route.snapshot.url[1].path),
      CandidateAssessmentId: Number(this.route.snapshot.url[2].path)
    };

    if (Number(this.route.snapshot.url[3].path) === 1) {
      // User has clicked on Remind me later from email
      const remindMeLaterRequest = {} as PulseSurveyReviewRemindMeLaterRequest;
      remindMeLaterRequest.CandidateAssessmentId = request.CandidateAssessmentId;
      remindMeLaterRequest.EmpId = request.EmpId;
      this.surveyService.updateEmailPulseSurveyReviewRemindMeLater(remindMeLaterRequest).subscribe((resp: PulseSurveyReviewRemindMeLaterResponse) => {
        if (resp && resp.Status) {
          // Please display the successful completion msg;
          this.displayMessage = true;
          this.message = 'Survey_Remind_Later';
          this.msgType = 'success';
        } else if (resp && resp.ResponseCode === 'ERR_01') {
          this.displayMessage = true;
          this.message = 'Invalid candidate assessment Id';
          this.msgType = 'error';
        } else if (resp && resp.ResponseCode === 'ERR_02') {
          this.displayMessage = true;
          this.message = 'Remind me later is not allowed';
          this.msgType = 'error';
        } else if (resp && resp.ResponseCode === 'ERR_03' && resp.ResponseMessage.toLowerCase() === 'complete') {
          this.displayMessage = true;
          this.message = 'Survey_Already_Complete';
          this.msgType = 'success';
        } else {
          this.displayMessage = true;
          this.message = 'OperationFailedMessage';
          this.msgType = 'error';
        }
      });
    } else {
      // User has started the survey from email
      this.surveyService.getEmailPulseSurveyDetails(request).subscribe(resp => {
        if (resp.length > 0) {
          resp[0].EmpId = request.EmpId;
          this.surveyDetails = resp[0];
          this.getSurvey = true;
        } else if (resp.length === 0) {
          this.displayMessage = true;
          this.message = 'Survey_Already_Complete';
          this.msgType = 'success';
        }
      });
    }
  }

  closeSurvey(e: any): void {
    this.getSurvey = false;
    this.displayMessage = true;
    this.message = e;
  }

}
