import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

import { SurveyService } from 'src/app/services/survey.service';
import {
  PollSummaryRequest, PollRespondentsRequest, PollSummaryResponse, Respondent, AnswerOptions,
  QuestionDetails, IdNamePair, RespondentCategoryReports
} from 'src/app/models/response/poll/poll-response';
import { HighchartService } from 'src/app/services/highchart.service';
import * as Highcharts from 'highcharts';
import { BarChartRequest, DonutPieChartRequest, WordCloudChartRequest } from 'src/app/models/requests/highchart-request';
import { ChartType } from 'src/app/helpers/enums/common-enums';
import * as $ from 'jquery';
import { SharedDataService } from 'src/app/services/shared-data.service';
import wordCloud from 'highcharts/modules/wordcloud.js';
wordCloud(Highcharts);

@Component({
  selector: 'app-poll-report',
  templateUrl: './poll-report.component.html',
  styleUrls: ['./poll-report.component.scss']
})
export class PollReportComponent implements OnInit, OnDestroy {
  overallCurrentAnswerTypeId: number;
  respCatCurrentAnswerTypeId: number;
  selectedPollId: number;
  selectedPollType: string;
  highcharts = Highcharts;
  respondents: Respondent[] = [];
  barHighChartOptions: any;
  showBarChart = false;
  showPieChart = false;
  selectedResondentType: string;
  completePerc: string;
  overallSummaryQuestions: QuestionDetails[] = [];
  overallSummaryQuestionIdx = 0;
  currentSummaryQuestion = {} as QuestionDetails;

  pieChartColors = ['#2e90cf', '#004500', '#efad4d', '#69c09f', '#6DBD02', '#DEAC68', '#BE504F'];
  selectedTabIndex = 0;
  QUESTION_TYPE = {
    'SLIDER': 3,
    'RADIOBUTTONIMAGE': 7,
    'CHECKBOXIMAGE': 8,
    'TEXTBOX': 9
  };

  respondentCategoryQuestionIdx = 0;
  currentRespondentQuestion = {} as QuestionDetails;
  respondentCategoryResponse: QuestionDetails[] = [];
  // {
  //   'Question': QuestionDetails,
  //   'Catgories': [{
  //     'Id': string,
  //     'Name': string,
  //     'Total': number,
  //     'Responded': number
  //   }],
  //   'ChartData': {
  //     'Managers': [{
  //       'OptionRespondentCount': number,
  //       'Percentage': number,
  //       'Answer': string
  //     },{
  //       'OptionRespondentCount': number,
  //       'Percentage': number,
  //       'Answer': string
  //     }],
  //     'Senior Lead': [{
  //       'OptionRespondentCount': number,
  //       'Percentage': number,
  //       'Answer': string
  //     },{
  //       'OptionRespondentCount': number,
  //       'Percentage': number,
  //       'Answer': string
  //     }]
  //   }
  // }


  copyRespondentCategoryResponse: string;
  availableCategories = [];

  showFilters = false;
  filters: string[] = [];
  title: string;

  constructor(
    private route: ActivatedRoute,
    private surveyService: SurveyService,
    private highChartService: HighchartService,
    private sharedDataService: SharedDataService,
    private router: Router
  ) { }

  ngOnInit() {
    this.route.params.subscribe(param => {
      this.selectedPollId = param.id;
      this.selectedPollType = param.type;
      const name = this.sharedDataService.getData();
      if (name) {
        this.title = name.Report_Name;
        this.getPollSummaryReport();
      } else {
        this.router.navigate(['iCoachFirst/dashboard']);
      }

    });

  }

  reset() {
    this.showBarChart = false;
    this.showPieChart = false;
    this.overallSummaryQuestions = [];
    this.overallSummaryQuestionIdx = 0;
    this.currentSummaryQuestion = {} as QuestionDetails;
    this.respondentCategoryQuestionIdx = 0;
    this.currentRespondentQuestion = {} as QuestionDetails;
    this.selectedTabIndex = 0;
  }

  getPollSummaryReport(): void {
    this.reset();
    const req = {} as PollSummaryRequest;
    req.InstanceId = this.selectedPollId;
    req.PollType = this.selectedPollType;
    this.surveyService.getPollReportSummary(req).subscribe(resp => {
      if (resp && resp.TotalRespondents > 0) {
        this.createBarChartRequest(resp);
        this.getCompletePerc(resp.TotalRespondents, resp.CompleteCount);
        this.selectedResondentType = 'Act_Status_Completed';
        this.getPollRespondents('complete');
        this.getOverallSummaryReport();
      }
    });
  }

  createBarChartRequest(data: PollSummaryResponse): void {
    const barChartConfig = {} as BarChartRequest;
    barChartConfig.ChartType = ChartType.Bar;
    barChartConfig.ChartTitle = '';
    barChartConfig.ChartSubTitle = '';
    barChartConfig.ChartYAxisText = '';
    barChartConfig.Height = 200;
    barChartConfig.Width = 1200;
    barChartConfig.CategoryData = ['Completed', 'In Progress', 'Not Yet Started'];
    barChartConfig.SeriesData = [];
    barChartConfig.BarColor = ['#6DBDA2', '#DEAC68', '#BE504F'];
    barChartConfig.SeriesData.push(data.CompleteCount);
    barChartConfig.SeriesData.push(data.InProgressCount);
    barChartConfig.SeriesData.push(data.NotYetStartedCount);
    this.barHighChartOptions = this.highChartService.CreateHighChart(barChartConfig);
  }

  ngOnDestroy() {
    $('.highcharts-xaxis-labels text').off('click');
  }

  getPollRespondents(type: string): void {
    if (type === 'Completed') {
      type = 'complete';
    }
    const req = {} as PollRespondentsRequest;
    req.InstanceId = this.selectedPollId;
    req.PollType = this.selectedPollType;
    req.Status = type.toLowerCase();
    this.surveyService.getPollRespondents(req).subscribe(resp => {
      if (resp) {
        this.respondents = resp.Respondents;
        this.showBarChart = true;
        $(() => {
          $('.highcharts-xaxis-labels text').on('click', (e) => {
            this.getResponseTypeValue(e.target.innerHTML);
            this.getPollRespondents(e.target.innerHTML);
          });
        });
      }
    });
  }

  getResponseTypeValue(type: string) {
    if (type === 'Completed') {
      this.selectedResondentType = 'Act_Status_Completed';
    } else if (type === 'In Progress') {
      this.selectedResondentType = 'Act_Bubble_InProgress';
    } else if (type === 'Not Yet Started') {
      this.selectedResondentType = 'Act_Bubble_NotYetStarted';
    }
  }

  getDate(date: string) {
    if (date) {
      return date.split(' ')[0];
    } else {
      return '';
    }
  }

  getCompletePerc(total: number, completed: number): void {
    this.completePerc = ((completed / total) * 100).toFixed(2);
  }

  getOverallSummaryReport(): void {
    const request = {} as PollSummaryRequest;
    request.InstanceId = this.selectedPollId;
    request.PollType = this.selectedPollType;

    this.surveyService.getPollReportByQuestion(request).subscribe(resp => {
      if (resp) {
        this.overallSummaryQuestions = resp.Questions;
        if (resp.Questions.length > 0) {
          this.currentSummaryQuestion = resp.Questions[0];
          this.overallCurrentAnswerTypeId = this.currentSummaryQuestion.AnswerTypeId;
          this.overallSummaryQuestionIdx = 0;
          if (this.overallCurrentAnswerTypeId === this.QUESTION_TYPE.TEXTBOX) {
            this.currentSummaryQuestion.highChartOptions = this.createWordCloudChart(this.currentSummaryQuestion.AnswerOptions);
          } else {
            this.currentSummaryQuestion.highChartOptions = this.createDonutPieRequest(this.currentSummaryQuestion.AnswerOptions, { 'width': 370 });
          }
          // this.currentSummaryQuestion.highChartOptions = this.createDonutPieRequest(this.currentSummaryQuestion.AnswerOptions, { 'width': 370 });

          if (request.PollType === 'SolicitedFeedback') {
            this.getRespondentCategoryReport();
          } else {
            this.showPieChart = true;
          }
        }
      }
    });
  }

  previousClicked(): void {
    if (this.selectedTabIndex === 0) {
      if (this.overallSummaryQuestionIdx > 0) {
        --this.overallSummaryQuestionIdx;
        this.currentSummaryQuestion = this.overallSummaryQuestions[this.overallSummaryQuestionIdx];
        this.overallCurrentAnswerTypeId = this.currentSummaryQuestion.AnswerTypeId;
        if (this.overallCurrentAnswerTypeId === this.QUESTION_TYPE.TEXTBOX) {
          this.currentSummaryQuestion.highChartOptions = this.createWordCloudChart(this.currentSummaryQuestion.AnswerOptions);
        } else {
          this.currentSummaryQuestion.highChartOptions = this.createDonutPieRequest(this.currentSummaryQuestion.AnswerOptions, { 'width': 370 });
        }
      }
    } else {
      if (this.respondentCategoryQuestionIdx > 0) {
        --this.respondentCategoryQuestionIdx;
        this.currentRespondentQuestion = this.respondentCategoryResponse[this.respondentCategoryQuestionIdx];
        this.respCatCurrentAnswerTypeId = this.currentRespondentQuestion.AnswerTypeId;
        this.currentRespondentQuestion.CategoryChartOptions = [];
        Object.entries(this.currentRespondentQuestion.ChartData).forEach(([_key, value], index) => {
          if (this.respCatCurrentAnswerTypeId === this.QUESTION_TYPE.TEXTBOX) {
            this.currentRespondentQuestion.CategoryChartOptions[index] = this.createWordCloudChart(value);
          } else {
            this.currentRespondentQuestion.CategoryChartOptions[index] = this.createDonutPieRequest(value, { 'width': 300 });
          }
          // this.currentRespondentQuestion.CategoryChartOptions[index] = this.createDonutPieRequest(value, { 'width': 300 });
        });

      }
    }
  }

  nextClicked(): void {
    if (this.selectedTabIndex === 0) {
      if (this.overallSummaryQuestionIdx < this.overallSummaryQuestions.length - 1) {
        ++this.overallSummaryQuestionIdx;
        this.currentSummaryQuestion = this.overallSummaryQuestions[this.overallSummaryQuestionIdx];
        this.overallCurrentAnswerTypeId = this.currentSummaryQuestion.AnswerTypeId;
        if (this.overallCurrentAnswerTypeId === this.QUESTION_TYPE.TEXTBOX) {
          this.currentSummaryQuestion.highChartOptions = this.createWordCloudChart(this.currentSummaryQuestion.AnswerOptions);
        } else {
          this.currentSummaryQuestion.highChartOptions = this.createDonutPieRequest(this.currentSummaryQuestion.AnswerOptions, { 'width': 370 });
        }
      }
    } else {
      if (this.respondentCategoryQuestionIdx < this.respondentCategoryResponse.length - 1) {
        ++this.respondentCategoryQuestionIdx;
        this.currentRespondentQuestion = this.respondentCategoryResponse[this.respondentCategoryQuestionIdx];
        this.respCatCurrentAnswerTypeId = this.currentRespondentQuestion.AnswerTypeId;
        this.currentRespondentQuestion.CategoryChartOptions = [];
        Object.entries(this.currentRespondentQuestion.ChartData).forEach(([_key, value], index) => {
          if (this.respCatCurrentAnswerTypeId === this.QUESTION_TYPE.TEXTBOX) {
            this.currentRespondentQuestion.CategoryChartOptions[index] = this.createWordCloudChart(value);
          } else {
            this.currentRespondentQuestion.CategoryChartOptions[index] = this.createDonutPieRequest(value, { 'width': 300 });
          }
        });
      }
    }
  }

  createDonutPieRequest(list: any, config: any): any {
    const chartConfig = {} as DonutPieChartRequest;
    chartConfig.ChartType = ChartType.DonutPie;
    chartConfig.ChartTitle = '';
    chartConfig.Height = 270;
    chartConfig.Width = config.width;
    chartConfig.Size = '90%';
    chartConfig.SeriesInnerSize = '40%';
    chartConfig.SeriesData = [];
    chartConfig.DataLabelConfig = {
      style: {
        fontSize: '20px',
        fontWeight: 'bold',
        color: '#fff',
        stroke: '#fff'
      },
      distance: -30
    };
    chartConfig.IsMouseTrackingEnabled = false;
    chartConfig.FormatterFn = function () {
      // display only if larger than 1
      return this.y > 1 ? this.y : null;
    };

    list.forEach((option: AnswerOptions, idx: number) => {
      chartConfig.SeriesData.push({
        Name: option.Answer,
        YAxis: Number(option.Percentage),
        Color: option.AnswerId === -1 ? '#FF0000' : this.pieChartColors[idx],
        EnableDataLabel: true
      });
    });
    return this.highChartService.CreateHighChart(chartConfig);

  }

  createWordCloudChart(list: any) {
    let texts: string;
    if (list) {
      list.forEach((option: AnswerOptions, _idx: number) => {
        if (option.AnswerId === 0) {
          texts = option.Answer;
        }
      });
    }
      const chartConfig = {} as WordCloudChartRequest;
      chartConfig.ChartType = ChartType.WordCloud;
      chartConfig.Texts = texts;
      return this.highChartService.CreateHighChart(chartConfig);
  }

  getRespondentCategoryReport(): void {
    const request = {} as PollSummaryRequest;
    request.InstanceId = this.selectedPollId;
    request.PollType = this.selectedPollType;
    this.surveyService.getPollReportByRespondentCategory(request).subscribe(resp => {
      if (resp.Reports.length > 0) {
        this.prepareRespondentCategoryData(resp.Reports);
      }
    });
  }

  prepareRespondentCategoryData(reports: RespondentCategoryReports[]): void {
    this.respondentCategoryResponse = [];
    const categories: IdNamePair[] = [];
    this.respondentCategoryResponse = reports[0].Questions;
    reports.forEach(element => {
      categories.push({
        Id: element.RespondentCategoryId,
        Name: element.RespondentCategoryName,
        Total: element.TotalRespondentCount,
        Responded: 0
      });
    });
    this.respondentCategoryResponse.forEach(question => {
      question.Categories = JSON.parse(JSON.stringify(categories));
      question.ChartData = {};
      categories.forEach((element) => {
        question.ChartData[element.Name] = [];
      });
    });
    this.availableCategories = categories;

    this.prepareRespondentCategoryChartData(reports);
  }

  prepareRespondentCategoryChartData(reports: RespondentCategoryReports[]): void {
    reports.forEach((category) => {
      category.Questions.forEach((question, q) => {
        const categoryChartData = [];
        question.AnswerOptions.forEach(answer => {
          const obj = {
            'OptionRespondentCount': answer.OptionRespondentCount,
            'Percentage': answer.Percentage,
            'Answer': answer.Answer,
            'AnswerId': answer.AnswerId
          };
          categoryChartData.push(obj);
        });

        // Insert in the Chat Data
        this.respondentCategoryResponse[q].ChartData[category.RespondentCategoryName] = categoryChartData;
        this.respondentCategoryResponse[q].Categories.forEach(cat => {
          if (cat.Name === category.RespondentCategoryName) {
            cat.Responded = question.ActualRespondentCount;
          }
        });
      });
    });

    this.copyRespondentCategoryResponse = JSON.stringify(this.respondentCategoryResponse);
    // Display the chart
    this.currentRespondentQuestion = this.respondentCategoryResponse[0];
    this.respCatCurrentAnswerTypeId = this.currentRespondentQuestion.AnswerTypeId;
    this.respondentCategoryQuestionIdx = 0;
    this.currentRespondentQuestion.CategoryChartOptions = [];
    Object.entries(this.currentRespondentQuestion.ChartData).forEach(([_key, value], index) => {
      if (this.respCatCurrentAnswerTypeId === this.QUESTION_TYPE.TEXTBOX) {
        this.currentRespondentQuestion.CategoryChartOptions[index] = this.createWordCloudChart(value);
      } else {
        this.currentRespondentQuestion.CategoryChartOptions[index] = this.createDonutPieRequest(value, { 'width': 300 });
      }
      this.currentRespondentQuestion.CategoryChartOptions[index] = this.createDonutPieRequest(value, { 'width': 300 });
    });
    this.showPieChart = true;
  }

  tabChange(e: any): void {
    this.selectedTabIndex = e.index;
  }

  onCheckBoxChange(category: IdNamePair, checkbox: any, event: any): void {
    event.preventDefault();
    event.stopPropagation();
    let exists = -1;
    exists = this.filters.findIndex(x => x === category.Name);
    if (exists === -1 && !checkbox.checked) {
      this.filters.push(category.Name);
    } else if (exists !== -1 && checkbox.checked) {
      this.filters = this.filters.filter(x => x !== category.Name);
    }
  }

  clearFilters(): void {
    this.filters = [];
    this.applyFilters(false);
    this.showFilters = false;
  }

  applyFilters(apply: boolean): void {
    this.respondentCategoryResponse = JSON.parse(this.copyRespondentCategoryResponse);

    if (apply) {
      this.respondentCategoryResponse.forEach(question => {
        question.ChartData = this.filterObject(question.ChartData);
        question.Categories = question.Categories.filter(x => this.filters.includes(x.Name));
      });
    }

    this.currentRespondentQuestion = this.respondentCategoryResponse[this.respondentCategoryQuestionIdx];
    this.respCatCurrentAnswerTypeId = this.currentRespondentQuestion.AnswerTypeId;
    this.currentRespondentQuestion.CategoryChartOptions = [];
    Object.entries(this.currentRespondentQuestion.ChartData).forEach(([_key, value], index) => {
      if (this.respCatCurrentAnswerTypeId === this.QUESTION_TYPE.TEXTBOX) {
        this.currentRespondentQuestion.CategoryChartOptions[index] = this.createWordCloudChart(value);
      } else {
        this.currentRespondentQuestion.CategoryChartOptions[index] = this.createDonutPieRequest(value, { 'width': 300 });
      }
      // this.currentRespondentQuestion.CategoryChartOptions[index] = this.createDonutPieRequest(value, { 'width': 300 });
    });
    this.showFilters = false;
  }

  filterObject(data: {}): {} {
    const result = {};
    for (const key in data) {
      if (this.filters.indexOf(key) > -1) {
        result[key] = data[key];
      }
    }
    return result;
  }

  getBackgroundColor(question: QuestionDetails, i: number, option: AnswerOptions) {
    if (question.AnswerTypeId === this.QUESTION_TYPE.SLIDER) {
      if (question.ScrollbarAnsOptionType === 'ImageUrl') {
        if (!option.ImageUrl) {
          return { 'background-color': '#FF0000' };
        }
      } else {
        if (!option.ColorCode) {
          return { 'background-color': '#FF0000' };
        }
      }
    } else if (option.Answer === 'Not Responded') {
      return { 'background-color': '#FF0000' };
    }


    return { 'background-color': this.pieChartColors[i] };
  }
}
