import { Component, OnInit, Output, EventEmitter } from '@angular/core';

import { ApplicationModuleListEnum } from 'src/app/helpers/enums/common-enums';
import { CommonService } from 'src/app/services/common.service';
import { SurveyService } from 'src/app/services/survey.service';
import { Poll, PollRequest } from 'src/app/models/response/poll/poll-response';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { SharedDataService } from 'src/app/services/shared-data.service';

@Component({
  selector: 'app-poll-list',
  templateUrl: './poll-list.component.html',
  styleUrls: ['./poll-list.component.scss']
})
export class PollListComponent implements OnInit {

  applicationModuleId: number = ApplicationModuleListEnum.None;
  @Output() setLeftContainerVisibility: EventEmitter<number> = new EventEmitter<number>();
  pollList: Poll[] = [];
  filteredPollList: Poll[] = [];
  _listFilter: string;
  showFilters = false;
  filterForm: FormGroup;
  errorMsg = false;
  selectedPollId = 0;

  constructor(
    private commonService: CommonService,
    private surveyService: SurveyService,
    private fb: FormBuilder,
    private router: Router,
    private sharedDataService: SharedDataService
  ) { }

  ngOnInit() {
    this.filterForm = this.fb.group({
      DateFrom: [''],
      DateTo: [''],
      IsSolicitedFeedback: [false],
      IsPulseSurvey: [false]
    });

    this.applyFilters(false);
  }

  openMainComponentLeftContainer(appModuleId: number = 0) {
    this.setLeftContainerVisibility.emit(appModuleId);
  }

  hidePopUpForMobile(appModuleId: number = 0) {
    const isMobileDevice = this.commonService.detectMobileDevice();

    if (isMobileDevice) {
      this.setLeftContainerVisibility.emit(appModuleId);
    }
  }

  get listFilter(): string {
    return this._listFilter;
  }
  set listFilter(value: string) {
    this._listFilter = value;
    this.filteredPollList = this.listFilter ? this.performSearchFilter(this.listFilter) : this.pollList;
  }
  performSearchFilter(filterBy: string): Poll[] {
    filterBy = filterBy.toLocaleLowerCase();
    return this.pollList.filter((poll: Poll) => {
      if (poll.PollType === 'PulseSurvey' && poll.SurveyName.toLocaleLowerCase().indexOf(filterBy) !== -1) {
        return true;
      } else if (poll.PollType === 'SolicitedFeedback' && poll.SolicitedForEmpName.toLocaleLowerCase().indexOf(filterBy) !== -1) {
        return true;
      } else {
        return false;
      }
    });
  }

  getDate(date: string) {
    if (date) {
      return date.split(' ')[0];
    } else {
      return '';
    }
  }

  applyFilters(apply: boolean) {
    this.errorMsg = false;
    const pollRequest = {} as PollRequest;
    pollRequest.Filters = this.filterForm.value;
    if (!pollRequest.Filters.DateFrom) {
      pollRequest.Filters.DateFrom = '';
    }
    if (!pollRequest.Filters.DateTo) {
      pollRequest.Filters.DateTo = '';
    }

    if (apply) {
      if ((pollRequest.Filters.DateFrom && !pollRequest.Filters.DateTo) || (!pollRequest.Filters.DateFrom && pollRequest.Filters.DateTo)) {
        this.errorMsg = true;
        return;
      } else if (new Date(pollRequest.Filters.DateFrom).getTime() > new Date(pollRequest.Filters.DateTo).getTime()) {
        this.errorMsg = true;
        return;
      }
    }
    pollRequest.IsApplyFilter = apply;
    this.getPolls(pollRequest);
    this.showFilters = false;
  }

  get f() {
    return this.filterForm.controls;
  }

  getPolls(request: PollRequest): void {
    this.surveyService.getPolls(request).subscribe(resp => {
      if (resp.Polls && resp.Polls.length > 0) {
        this.pollList = resp.Polls;
        this.filteredPollList = this.pollList;
      } else {
        this.pollList = [];
        this.filteredPollList = [];
      }
    });
  }

  clearFilters(): void {
    this.filterForm.setValue({
      DateFrom: '',
      DateTo: '',
      IsPulseSurvey: false,
      IsSolicitedFeedback: false
    });
    this.showFilters = false;
    this.applyFilters(false);
  }

  openPollReportSummary(poll: Poll): void {
    if (poll.InstanceId) {
      this.selectedPollId = poll.InstanceId;
      if (poll.PollType.toLowerCase() === 'solicitedfeedback') {
        this.sharedDataService.setData({ 'Report_Name': poll.SolicitedForEmpName });
      } else {
        this.sharedDataService.setData({ 'Report_Name': poll.SurveyName });
      }
      this.router.navigate(['iCoachFirst/poll/report', poll.InstanceId, poll.PollType]);
    }
  }

  getSelectedClass(poll: Poll): string {
    if (poll.InstanceId === this.selectedPollId) {
      return 'selected';
    }
  }

}
