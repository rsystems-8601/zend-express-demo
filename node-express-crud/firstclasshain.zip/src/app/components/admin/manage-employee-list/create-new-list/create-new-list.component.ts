import { Component, OnInit, Inject} from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { UserService } from 'src/app/services/user.service';
import { AdminService } from 'src/app/services/admin.service';
import { AddNewListRequest } from 'src/app/models/requests/add-newlist-request';
import { IcftoasterService } from 'src/app/services/icftoaster.service';

@Component({
  selector: 'app-create-new-list',
  templateUrl: './create-new-list.component.html',
  styleUrls: ['./create-new-list.component.scss']
})
export class CreateNewListComponent implements OnInit {
  NewListForm: FormGroup;
  newListPublic: string;
  newlistName: string;
  listResponse: string;
  empID: number;
  submitted: boolean;
  addnewListRequest = {} as AddNewListRequest;
  constructor(public dialogRef: MatDialogRef<CreateNewListComponent>, @Inject(MAT_DIALOG_DATA) public data: any,
  private formBuilder: FormBuilder, private adminService: AdminService, private userService: UserService, private toast: IcftoasterService) { }
  ngOnInit() {
    this.setupFormControls();
  }
   setupFormControls() {
    this.NewListForm = this.formBuilder.group({
      txtNewListName: ['', Validators.required],
      ddlListPublic: [''],
      tblGrid: ['']
    });
    this.newListPublic = 'true';
  }
  close() {
    this.dialogRef.close('Close');
  }
  // used to save new list
  saveListToDB() {
    this.submitted = true;
    if (this.NewListForm.invalid) {
      return;
    }
    const userDetails = this.userService.getUserDetails().UserDetails;
    this.addnewListRequest.MemberOrgId = userDetails.MemberOrgID;
    this.empID = userDetails.EmployeeId;
    this.addnewListRequest.EmployeeID = userDetails.EmployeeId;
    this.addnewListRequest.OwnerID = userDetails.EmployeeId;
    this.addnewListRequest.ResourceType = 'Employee';
    if ( this.newlistName !== undefined) {
      this.addnewListRequest.ListName = this.newlistName ;
    }
    if (this.newListPublic !== undefined) {
      this.addnewListRequest.IsPublic = Boolean(this.newListPublic);
    }
    this.addnewListRequest.XmlEmpData = [] ;
    this.adminService.addToNewList(this.addnewListRequest).subscribe((response: any) => {
    this.listResponse = response;
    if (this.listResponse.length > 0) {
        this.toast.error('This list already exists');
      } else {
        this.toast.success('List added successfully');
      }
      this.dialogRef.close(this.newlistName);
  }); }
   // convenience getter for easy access to form fields
   get f() {
    return this.NewListForm.controls;
  }
}
