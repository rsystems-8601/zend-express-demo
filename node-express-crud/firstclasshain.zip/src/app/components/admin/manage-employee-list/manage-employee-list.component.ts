import { Component, OnInit } from '@angular/core';
import { ManageEmployeeRequest } from 'src/app/models/requests/manage-employee-request';
import { ManageEmployeeResponse } from 'src/app/models/response/admin/manage-employee-response';
import { EmployeeRosterRequest } from '../../../models/requests/employee-roaster-request';
import { UserService } from 'src/app/services/user.service';
import { AdminService } from '../../../services/admin.service';
import { PagerService } from '../../../services/pager-service';
import { IcftoasterService } from 'src/app/services/icftoaster.service';
import { DeleteCandidateListRequest } from 'src/app/models/requests/delete-candidate-list-request';
import { CreateNewListComponent } from 'src/app/components/admin/manage-employee-list/create-new-list/create-new-list.component';
import { MatDialog , MatDialogConfig} from '@angular/material';
import { Router } from '@angular/router';


@Component({
  selector: 'app-manage-employee-list',
  templateUrl: './manage-employee-list.component.html',
  styleUrls: ['./manage-employee-list.component.scss']
})
export class ManageEmployeeListComponent implements OnInit {
  manageEmpRequest = {} as ManageEmployeeRequest;
  empRosterRequest = new EmployeeRosterRequest();
  deleteRequest = {} as DeleteCandidateListRequest;
  manageEmpReponse: ManageEmployeeResponse;
  employeeID: number;
  memberOrgId: number;
  empListReponse: ManageEmployeeResponse;
  candidateListID: string;
  empList: [];
  rowNo: number;
  pagesize: number;
  tblPages: number;
  // pager object
  pager: any = {};
  // paged items
  pagedItems: any[];
  cancelPopUp: any;
  passData: any[];
  recentlyAddedList: Array<any> = [];
  allItemsSelected: boolean;
  masterSelected: boolean;
  checkboxAddedList: Array<any> = [];
  candidateListId: number;
  ddlListId: any = 0;
  ddlSelectedList: Array<any> = [];
  empListName: string;

  constructor(private empAdminService: AdminService, private userService: UserService,
    private pagerService: PagerService , private toast: IcftoasterService, private dialog: MatDialog,private router: Router,) {
    this.masterSelected = false;
    this.allItemsSelected = false;
    this.fetchListddl();
    this.pagedItems = [];
    this.empListName = 'Select';
   }

  ngOnInit() {
    this.empListName = 'Select';
    localStorage.removeItem('ResourceId');
}
fetchListddl(emplist?: string) {
    this.ddlSelectedList = [];
    const userDetails = this.userService.getUserDetails().UserDetails;
    this.memberOrgId = userDetails.MemberOrgID;
    this.manageEmpRequest.EmployeeID = userDetails.EmployeeId;
    this.manageEmpRequest.MemberOrgId = this.memberOrgId;
    this.manageEmpRequest.ResourceType = 'Employee';
    this.empAdminService.getEmpLists(this.manageEmpRequest).subscribe((manageEmpReponse: ManageEmployeeResponse) => {
    this.empListReponse = manageEmpReponse;
    this.ddlSelectedList.push(this.empListReponse);
    if (emplist !== undefined) {
      const emList = 'Employee_' + emplist;
      const val = this.ddlSelectedList[0].filter(x => x.ListName === emList);
      this.empListName = String(val[0].CandidateListID);
    } else {
      this.empListName = 'Select';
    }
  });
}

listSelection(event) {
  this.empRosterRequest.MemberOrgID = this.memberOrgId;
  this.empRosterRequest.Name = '';
    this.empRosterRequest.ReportToEmpID = 0;
  this.empRosterRequest.Keyword = '';
  this.empRosterRequest.EmploymentStatusID = 0;
  this.empRosterRequest.DottedLineTo = 0;
  this.empRosterRequest.DesignationId = 0;
    // display the complete list data.
     if (event.target.value !== 'Select' && event.target.value !== undefined ) {
      this.empRosterRequest.CandidateListID = Number(event.target.value);
      this.empRosterRequest.dataforexcel = false;
      this.empAdminService.getManageResourceDetails(this.empRosterRequest).subscribe((res) => {
      const resSTR = <any>res;
      this.empList = (JSON.parse(resSTR).Table);
      this.setPage(1);
});
    } else if (event.target.value === undefined) {
      // this.empRosterRequest.CandidateListID = Number(event.target.value);
      this.empRosterRequest.dataforexcel = false;
      this.empAdminService.getManageResourceDetails(this.empRosterRequest).subscribe((res) => {
      const resSTR = <any>res;
      this.empList = (JSON.parse(resSTR).Table);
      this.setPage(1);
});
    } else {
       this.empRosterRequest.CandidateListID = 0;
       this.empList = [];
       this.setPage(1);
    }
}
// get all the employee data
getAllEmployeeData() {
  this.empRosterRequest.MemberOrgID = this.memberOrgId;
  this.empRosterRequest.Name = '';
    this.empRosterRequest.ReportToEmpID = 0;
  this.empRosterRequest.Keyword = '';
  this.empRosterRequest.EmploymentStatusID = 0;
  this.empRosterRequest.DottedLineTo = 0;
  this.empRosterRequest.DesignationId = 0;
  this.empRosterRequest.dataforexcel = false;
  this.empRosterRequest.CandidateListID = 0 ;
    // display the complete list data.
      this.empAdminService.getManageResourceDetails(this.empRosterRequest).subscribe((res) => {
      const resSTR = <any>res;
      this.empList = (JSON.parse(resSTR).Table);
      this.setPage(1);
});
}
setPage(page: number) {
  if (page < 1) {
    // || page > this.pager.totalPages
    return;
  }
  // get pager object from service
  this.tblPages = page;
  this.pager = this.pagerService.getPager(this.empList.length, page);
  // get current page of items
  this.pagedItems = this.empList.slice(this.pager.startIndex, this.pager.endIndex + 1);
 if (this.pagedItems.length > 0) {this.selectEntity(); }
}
selectEntity() {
  // If any entity is not checked, then uncheck the "allItemsSelected" checkbox
  for (let i = 0; i < this.pagedItems.length; i++) {
    if (!this.pagedItems[i].isSelected) {
      this.allItemsSelected = false;
      return;
  }
}
  // If not the check the "allItemsSelected" checkbox
  this.allItemsSelected = true;
}
// This executes when checkbox in table header is checked
selectAll() {
  // Loop through all the entities and set their isChecked property
  for (let i = 0; i < this.pagedItems.length; i++) {
    this.pagedItems[i].isSelected = this.allItemsSelected;
  }
}
onChange(event) {
  this.pager = this.pagerService.getPager(this.empList.length, this.tblPages, parseInt(event.target.value, 0));
  // get current page of items
  this.pagedItems = this.empList.slice(this.pager.startIndex, this.pager.endIndex + 1);
  if (this.pagedItems.length > 0) {
  this.selectEntity();
  this.selectAll();
  }

}
// Remove the list
deleteList() {
  if (Number(this.empListName) > 0 && this.empListName !== 'Select') {
    this.candidateListId = Number(this.empListName);
    this.empAdminService.deleteSelectedList(this.candidateListId).subscribe(response => {
      if (response === '1') {
         // history.back();
         this.fetchListddl();
         this.empList = [];
         this.empRosterRequest.CandidateListID = 0;
         this.setPage(1);
        this.toast.success('List removed successfully', '', () => {
        });
      } else {
        this.toast.error('List cannot be removed due to Referential Integrity');
        this.fetchListddl();
        this.empList = [];
        this.empRosterRequest.CandidateListID = 0;
        this.setPage(1);
      }
    });
  } else {
    this.toast.error('Please select any list item from Select List to remove');
    return ;
  }
}
// remove candidates from the List.
deleteFromList() {
  this.checkboxAddedList = [];
  if (this.pagedItems !== undefined) {
    for (let i = 0; i < this.pagedItems.length; i++) {
      if (this.pagedItems[i].isSelected && this.pagedItems[i].isSelected !== undefined ) {
        this.checkboxAddedList.push(String(this.pagedItems[i].EmpID));
    }
  }
  }
if ( this.checkboxAddedList.length <= 0) {
  this.toast.error('Please select at least one row to remove from a grid'); return;
} else {
  this.deleteRequest.XmlEmpData = this.checkboxAddedList;
 }
 if (this.empRosterRequest.CandidateListID !== undefined) {
  this.deleteRequest.CandidateListID = this.empRosterRequest.CandidateListID;
 }
this.deleteRequest.ResourceType = 'Employee';
this.empAdminService.deleteCandidateFromList(this.deleteRequest).subscribe((res) => {
  if (res) {
    this.toast.success('Record removed successfully');
    this.listSelection(event) ;
  }
});
}
// pop up logic create new List
openCreateNewListPopup() {
  const dialogConfig = new MatDialogConfig();
  dialogConfig.data =  this.recentlyAddedList;
  dialogConfig.width = '600px';
  dialogConfig.disableClose = true;
  const dialogRef = this.dialog.open(CreateNewListComponent, dialogConfig);
  dialogRef.afterClosed().subscribe(value => {
   if (value !== 'Close') {
    this.fetchListddl(String(value));
    this.empList = [];
    this.empRosterRequest.CandidateListID = 0;
    this.setPage(1);
   } else if (value === 'Close') {
     // nothing
   }
  });
}
goToEmployeeDetails(id: number) {
  localStorage.setItem('ResourceId', id.toString());
  this.router.navigate(['/iCoachFirst/admin/add-resource']);
}
}
