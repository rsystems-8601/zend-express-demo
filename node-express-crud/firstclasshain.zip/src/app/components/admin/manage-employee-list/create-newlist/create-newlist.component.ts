import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-newlist',
  templateUrl: './create-newlist.component.html',
  styleUrls: ['./create-newlist.component.scss']
})
export class CreateNewlistComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
