import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { EventEmiterService } from 'src/app/services/event.emmiter.service';
import { UserService } from 'src/app/services/user.service';
import { UserDetails } from 'src/app/models/user-details-result';
import { CreateCustomFieldRequest, CreateResourceRequest } from 'src/app/models/requests/create-custom-field-request';
import { Subscription } from 'rxjs';
import { AdminService } from 'src/app/services/admin.service';
import { FormGroup, FormBuilder, Validators, FormArray } from '@angular/forms';
import { IcftoasterService } from 'src/app/services/icftoaster.service';
import { MatDialogRef } from '@angular/material';
import { CreateGroupComponent } from '../../connect/create-group/create-group.component';
import { AddRosterResponse } from 'src/app/models/response/admin/add-roster-response';
import { DatePipe } from '@angular/common';
import { EmployeeAdditionalManagerService } from 'src/app/services/employee-additional-manager.service';
import { AdditionalManagerRequest } from 'src/app/models/requests/additional-manager-request';

@Component({
  selector: 'app-add-resource',
  templateUrl: './add-resource.component.html',
  styleUrls: ['./add-resource.component.scss']
})

export class AddResourceComponent implements OnInit {

  emailId: string;
  SourcingChannel: number;
  resourceType: string;
  hireDate: string;
  step = 0;
  appraisalDate: string;
  dob: string;
  sourceChannelId = 0;
  empId: number;
  resourceId: number;
  panelOpenState: boolean;
  resourceEntryForm: FormGroup;
  submitted = false;
  selectedObserver: any;
  customRequest = {} as CreateResourceRequest;
  subscription: Subscription;
  userInfo: UserDetails;
  selectedDeptId: number;
  isValidEmail: boolean;
  responseData: CreateCustomFieldRequest[];
  employeeStatusList: any[];
  designationList: any[];
  maritalStatusList: any[];
  projectList: any[];
  departmentList: any[];
  sourcingChannelList: any[];
  regionList: any[];
  districtList: any[];
  calllingSourceReportTo = 'ReportTo';
  calllingSourceDottedLineTo = 'DottedLineTo';
  calllingOriginalChannelTo = 'OriginalChannelPartner';
  items: FormArray;
  emptyForm: CreateCustomFieldRequest;
  isEdit: boolean;
  successMessage: string;
  additionalManagerList: Array<AdditionalManagerRequest>;
  existingAddManagerCount = 0;

  constructor(private adminService: AdminService,
    private router: Router, private datepipe: DatePipe,
    private formBuilder: FormBuilder,
    private toast: IcftoasterService,
    private _eventEmiter: EventEmiterService,
    private dialogRef: MatDialogRef<CreateGroupComponent>,
    private userService: UserService,
    private empAdditionalManagerService: EmployeeAdditionalManagerService) {
    this.subscription = this._eventEmiter.subscribe(data => {

      if (data.keyName === 'ReportTo') {
        this.selectedObserver = data;
        if (this.selectedObserver.observerData) {
          this.customRequest.ReportTo = 0;
          this.customRequest.ReportTo = this.selectedObserver.observerData.EmpID;
        } else {
          this.customRequest.ReportTo = 0;
        }
        this.selectedObserver = null;
      } else if (data.keyName === 'DottedLineTo') {
        this.selectedObserver = data;
        if (this.selectedObserver.observerData) {
          this.customRequest.DottedLineTo = 0;
          this.customRequest.DottedLineTo = this.selectedObserver.observerData.EmpID;
        } else {
          this.customRequest.DottedLineTo = 0;
        }
        this.selectedObserver = null;
      } else if (data.keyName === 'OriginalChannelPartner') {
        this.selectedObserver = data;
        if (this.selectedObserver.observerData) {
          this.customRequest.OriginalChannelPartnerID = 0;
          this.customRequest.OriginalChannelPartnerID = this.selectedObserver.observerData.EmpID;
        } else {
          this.customRequest.OriginalChannelPartnerID = 0;
        }
        this.selectedObserver = null;
      }
    });
  }

  ngOnInit() {
    this.emptyForm = {
      RowId: 0, ColACustomFieldId: 0, ColACustomFieldName: '', ColACandCustValueID: 0, ColADefaultValue: '0', ColAFieldType: 0, ColAIsMandatory: false,
      ColBCustomFieldId: 0, ColBCustomFieldName: '', ColBCandCustValueID: 0, ColBDefaultValue: '0', ColBFieldType: 0, ColBIsMandatory: false, ColADate: null, ColBDate: null, ColANo: '', ColBNo: '', ColBYes: '', ColAYes: ''
    };
    this.isEdit = false;
    this.hireDate = '';
    this.appraisalDate = '';
    this.dob = '';
    this.userInfo = this.userService.getUserDetails().UserDetails;
    this.buildForm();
    this.adminService.getSourcingChannelList(this.userInfo.EmpId, this.userInfo.MemberOrgID).subscribe(resultData => {
      this.sourcingChannelList = JSON.parse(JSON.stringify(resultData));
    });
    this.resourceType = 'Add New Resource';
    this.resourceId = Number(localStorage.getItem('ResourceId'));
    this.empId = this.userInfo.EmpId;
    if (this.resourceId > 0) {
      this.getResourceDetail(this.resourceId, this.userInfo.MemberOrgID);
      this.resourceType = 'Edit Resource';
      this.empId = this.resourceId;
      this.isEdit = true;
    }
    this.bindDropDownlists();
    this.setCustomFields(this.empId);
    this.additionalManagerList = [];
    this.getEmpAdditionalManager(this.empId);
  }
  isValidEmailId(value) {
    this.isValidEmail = false;
    const EMAIL_REGEXP = /^[a-z0-9!#$%&'*+\/=?^_`{|}~.-]+@[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)*$/i;
    if (value !== '' && (value.length <= 5 || !EMAIL_REGEXP.test(value))) {
      this.isValidEmail = true;
      this.resourceEntryForm.get('EmailId').setValidators([Validators.email]);
      this.resourceEntryForm.get('EmailId').updateValueAndValidity();
      return false;
    }
    this.resourceEntryForm.get('EmailId').clearValidators();
    this.resourceEntryForm.get('EmailId').updateValueAndValidity();
  }

  setStep(index: number) {
    this.step = index;
  }

  nextStep() {
    this.step++;
  }

  prevStep() {
    this.step--;
  }

  getResourceDetail(resourceId, MemberOrgID) {
    this.adminService.getResourceDetails(resourceId, MemberOrgID)
      .subscribe((data: any) => {
        window.document.getElementsByClassName('mat-input-element')[1].setAttribute('value', data.ReportToEmpName);
        this.customRequest.ReportTo = data.ReportTo;
        window.document.getElementsByClassName('mat-input-element')[2].setAttribute('value', data.DottedLineToEmpName);
        this.customRequest.DottedLineTo = data.DottedLineTo;
        window.document.getElementsByClassName('mat-input-element')[3].setAttribute('value', data.OriginalChannelPartner);
        this.customRequest.OriginalChannelPartnerID = data.OriginalChannelPartnerID;
        this.customRequest.CandidateID = resourceId;
        this.customRequest.MemberOrgID = MemberOrgID;
        this.resourceEntryForm.patchValue({
          CandidateID: resourceId,
          EmpCode: data.EmpCode,
          FirstName: data.FirstName,
          LastName: data.LastName,
          EmailId: data.EmailID.trim(),
          EmploymentStatus: data.EmploymentStatusID === 0 ? '' : data.EmploymentStatusID,
          Designation: data.DesignationID === 0 ? '' : data.DesignationID,
          HireDate: data.HireDate,
          ReportTo: data.ReportTo,
          DottedLineTo: data.DottedLineTo,
          MiddleInitial: data.MiddleInitial,
          PreferredName: data.PreferredName,
          DOB: data.DOB,
          Race: data.Race,
          Veteran: data.Veteran,
          StreetAddress1: data.StreetAddress1,
          City: data.City,
          Country: data.Country,
          HomePhone: data.HomePhone,
          CellPhone: data.CellPhone,
          WebAddress: data.WebAddress,
          WillingToTravel: parseInt(data.WillingToTravel, 0),
          AppraisalDate: data.AppraisalDate,
          Department: data.Department,
          Gender: parseInt(data.Gender, 0),
          MaritalStatus: data.MaritalStatusID,
          SocialSecurityNumber: data.SocialSecurityNumber.trim(),
          LegalStatus: data.LegalStatus,
          Disability: parseInt(data.Disability, 0),
          StreetAddress2: data.StreetAddress2,
          State: data.State,
          PostalCode: data.PostalCode,
          OfficePhone: data.OfficePhone,
          Fax: data.PreferredPhone,
          EligibleToWork: parseInt(data.EligibleToWork, 0),
          WillingToRelocate: parseInt(data.WillingToRelocate, 0),
          OriginalChannelPartner: data.OriginalChannelPartnerID,
          Project: data.ProjectID,
          Region: data.Region,
          District: data.District,
          Territory: data.Territory,
          BioDetails: data.BioDetails === '<br>' ? '' : data.BioDetails
        }), this.emailId = data.EmailID, this.onDepartChange(data.Department), this.onRegionChange(data.Region), this.hireDate = this.datepipe.transform(data.HireDate, 'MM/dd/yyyy'),
          setTimeout(() => {
            this.SourcingChannel = this.getSourceChannelId(data.SourcingChannel);
          }, 2000),
          this.appraisalDate = this.datepipe.transform(data.AppraisalDate, 'MM/dd/yyyy'), this.dob = this.datepipe.transform(data.DOB, 'MM/dd/yyyy');
      });
    this.resourceEntryForm.controls['EmploymentStatus'].setValidators([Validators.required]);
    this.resourceEntryForm.controls['Designation'].setValidators([Validators.required]);
  }

  onChangeReportTo(value) {
    if (value === '') {
      this.customRequest.ReportTo = 0;
    }

  }
  onChangeDottedLineTo(value) {
    if (value === '') {
      this.customRequest.DottedLineTo = 0;
    }

  }
  onChangeOriginalChannelPartnerID(value) {
    if (value === '') {
      this.customRequest.OriginalChannelPartnerID = 0;
    }

  }

  setCustomFields(empId) {
    this.adminService.getCustomFieldRosterData(this.userInfo.MemberOrgID, empId).subscribe(data => {
      if (data !== undefined && data !== '') {
        this.responseData = JSON.parse(data);
        this.items = this.resourceEntryForm.get('items') as FormArray;
        this.items.removeAt(0);
        for (const ele of this.responseData) {
          this.items.push(this.createItem(ele));
        }
      }
    });
  }

  getSourceChannelId(sourceChannel: string) {
    if (this.sourcingChannelList !== undefined) {
      this.sourceChannelId = this.sourcingChannelList.filter(x => x.SourcingChannel === sourceChannel)[0].SourcingChannelID;
      return this.sourceChannelId;
    }
  }

  bindDropDownlists() {
    this.adminService.getEmployeeStatusList(this.userInfo.MemberOrgID).subscribe(resultData => {
      const statusList = JSON.parse(JSON.stringify(resultData));
      this.employeeStatusList = statusList;
    });
    this.adminService.getDesignationList(this.userInfo.MemberOrgID).subscribe(resultData => {
      this.designationList = JSON.parse(JSON.stringify(resultData));
    });
    this.adminService.getMaritalStatusList(this.userInfo.MemberOrgID).subscribe(resultData => {
      this.maritalStatusList = JSON.parse(JSON.stringify(resultData));
    });
    this.adminService.getProjectList(this.userInfo.MemberOrgID).subscribe(resultData => {
      this.projectList = JSON.parse(JSON.stringify(resultData));
    });
    this.adminService.getDepartmentList(this.userInfo.MemberOrgID).subscribe(resultData => {
      this.departmentList = JSON.parse(JSON.stringify(resultData));
    });
  }
  buildForm() {
    this.resourceEntryForm = this.formBuilder.group({
      EmployeeId: 0,
      CandidateID: 0,
      EmpCode: [''],
      FirstName: ['', [Validators.required]],
      LastName: ['', [Validators.required]],
      EmailId: ['', ''],
      EmploymentStatus: ['', [Validators.required]],
      Designation: ['', [Validators.required]],
      HireDate: ['', Validators.required],
      ReportTo: [''],
      DottedLineTo: [''],
      MiddleInitial: [''],
      PreferredName: [''],
      DOB: [''],
      Race: [''],
      Veteran: [''],
      StreetAddress1: [''],
      City: [''],
      Country: [''],
      HomePhone: [''],
      CellPhone: [''],
      WebAddress: [''],
      WillingToTravel: [''],
      SourcingChannel: ['3'],
      AppraisalDate: [''],
      Department: [''],
      District: [''],
      Gender: [0],
      MaritalStatus: [''],
      SocialSecurityNumber: [''],
      LegalStatus: [''],
      Disability: [''],
      StreetAddress2: [''],
      State: [''],
      PostalCode: [''],
      OfficePhone: [''],
      Fax: [''],
      EligibleToWork: [''],
      WillingToRelocate: [''],
      OriginalChannelPartner: [''],
      Project: [''],
      Region: [''],
      Territory: [''],
      BioDetails: [''],
      items: this.formBuilder.array([this.createItem(this.emptyForm)])
    }
    );

    setTimeout(function () {
      window.document.getElementsByClassName('mat-input-element')[3].setAttribute('value', this.userInfo.Name);
      this.customRequest.OriginalChannelPartnerID = this.userInfo.EmployeeId;
    }.bind(this), 3000);
  }

  createItem(form: any): any {
    return this.formBuilder.group({
      RowId: form.RowId,
      ColACustomFieldId: form.ColACustomFieldId,
      ColACustomFieldName: form.ColACustomFieldName,
      ColACandCustValueID: form.ColACandCustValueID,
      ColADefaultValue: form.ColADefaultValue,
      ColAFieldType: form.ColAFieldType,
      ColAIsMandatory: form.ColAIsMandatory,
      ColBCustomFieldId: form.ColBCustomFieldId,
      ColBCustomFieldName: form.ColBCustomFieldName,
      ColBCandCustValueID: form.ColBCandCustValueID,
      ColBDefaultValue: form.ColBDefaultValue,
      ColBFieldType: form.ColBFieldType,
      ColBIsMandatory: form.ColBIsMandatory,
      ColADate: form.ColADate,
      ColBDate: form.ColBDate,
      ColAYes: form.ColAYes,
      ColBYes: form.ColBYes,
      ColANo: form.ColANo,
      ColBNo: form.ColBNo
    });
  }
  // convenience getter for easy access to form fields
  get f() { return this.resourceEntryForm.controls; }

  onDepartChange(departmentValue) {
    this.adminService.getRegionList(departmentValue, this.userInfo.MemberOrgID).subscribe(resultData => {
      this.regionList = JSON.parse(JSON.stringify(resultData));
      this.districtList = [];
    });
  }

  onRegionChange(regionValue) {
    this.districtList = [];
    this.adminService.getDistrictList(regionValue, this.userInfo.MemberOrgID).subscribe(resultData => {
      this.districtList = JSON.parse(JSON.stringify(resultData));
    });
  }

  onSubmit(ResourceEntryForm) {
    this.submitted = true;
    this.customRequest.CustomData = ResourceEntryForm.items;
    const SSN_REGEXP = /^(\d{3})-?\d{2}-?\d{4}$/;
    if (ResourceEntryForm.SocialSecurityNumber.trim() !== '' && (ResourceEntryForm.SocialSecurityNumber.trim().length < 9 || !SSN_REGEXP.test(ResourceEntryForm.SocialSecurityNumber.trim()))) {
      this.toast.error('Invalid SSN. Must be 9 digits or in the form NNN-NN-NNNN', 'Error Message');
      return;
    }
    if ( this.customRequest.DottedLineTo && this.customRequest.ReportTo) {
       if (this.customRequest.DottedLineTo === this.customRequest.ReportTo) {
      this.toast.error('"Dotted Line To" and "Report To" can not be the same person', 'Error Message');
      return;
    }}
    // stop here if form is invalid
    if (this.resourceEntryForm.invalid) {
      return;
    }
    if (this.customRequest.OriginalChannelPartnerID === 0) {
      this.customRequest.OriginalChannelPartnerID = this.userInfo.EmployeeId;
    }
    this.customRequest.MemberOrgID = this.userInfo.MemberOrgID;
    this.customRequest.EmpCode = ResourceEntryForm.EmpCode;
    this.customRequest.FirstName = ResourceEntryForm.FirstName;
    this.customRequest.LastName = ResourceEntryForm.LastName;
    this.customRequest.EmailId = ResourceEntryForm.EmailId === undefined ? this.emailId : ResourceEntryForm.EmailId.trim();
    this.customRequest.EmploymentStatus = ResourceEntryForm.EmploymentStatus;
    this.customRequest.Designation = ResourceEntryForm.Designation === '' ? 0 : ResourceEntryForm.Designation;
    this.customRequest.HireDate = ResourceEntryForm.HireDate == null ? '' : ResourceEntryForm.HireDate;
    this.customRequest.MiddleInitial = ResourceEntryForm.MiddleInitial;
    this.customRequest.PreferredName = ResourceEntryForm.PreferredName;
    this.customRequest.DOB = ResourceEntryForm.DOB == null ? '' : ResourceEntryForm.DOB;
    this.customRequest.Race = ResourceEntryForm.Race;
    this.customRequest.Veteran = ResourceEntryForm.Veteran === '' ? 0 : ResourceEntryForm.Veteran;
    this.customRequest.HomePhone = ResourceEntryForm.HomePhone;
    this.customRequest.StreetAddress1 = ResourceEntryForm.StreetAddress1;
    this.customRequest.City = ResourceEntryForm.City;
    this.customRequest.Country = ResourceEntryForm.Country;
    this.customRequest.CellPhone = ResourceEntryForm.CellPhone;
    this.customRequest.WebAddress = ResourceEntryForm.WebAddress;
    this.customRequest.WillingToTravel = ResourceEntryForm.WillingToTravel;
    if (isNaN(ResourceEntryForm.SourcingChannel)) {
      this.customRequest.SourcingChannelID = this.getSourceChannelId(ResourceEntryForm.SourcingChannel);
    } else {
      this.customRequest.SourcingChannelID = ResourceEntryForm.SourcingChannel;
    }
    this.customRequest.AppraisalDate = ResourceEntryForm.AppraisalDate == null ? '' : ResourceEntryForm.AppraisalDate;
    this.customRequest.Department = ResourceEntryForm.Department === '' ? 0 : parseInt(ResourceEntryForm.Department, 0);
    this.customRequest.District = ResourceEntryForm.District === '' ? 0 : ResourceEntryForm.District;
    this.customRequest.Gender = ResourceEntryForm.Gender === 0 ? 'Male' : 'Female';
    this.customRequest.MaritalStatus = ResourceEntryForm.MaritalStatus === '' ? 0 : ResourceEntryForm.MaritalStatus;
    this.customRequest.SocialSecurityNumber = ResourceEntryForm.SocialSecurityNumber.trim();
    this.customRequest.LegalStatus = ResourceEntryForm.LegalStatus === null ? '' : ResourceEntryForm.LegalStatus;
    this.customRequest.Disability = ResourceEntryForm.Disability;
    this.customRequest.StreetAddress2 = ResourceEntryForm.StreetAddress2;
    this.customRequest.State = ResourceEntryForm.State;
    this.customRequest.PostalCode = ResourceEntryForm.PostalCode === null ? '' : ResourceEntryForm.PostalCode;
    this.customRequest.OfficePhone = ResourceEntryForm.OfficePhone;
    this.customRequest.Fax = ResourceEntryForm.Fax === null ? '' : ResourceEntryForm.Fax;
    this.customRequest.EligibleToWork = ResourceEntryForm.EligibleToWork;
    this.customRequest.WillingToRelocate = ResourceEntryForm.WillingToRelocate;
    if (!isNaN(ResourceEntryForm.Project)) {
      this.customRequest.Project = ResourceEntryForm.Project === '' ? 0 : ResourceEntryForm.Project;
    } else {
      this.customRequest.Project = '0';
    }
    this.customRequest.Region = ResourceEntryForm.Region === '' ? 0 : ResourceEntryForm.Region;
    this.customRequest.Territory = ResourceEntryForm.Territory;
    this.customRequest.BioDetails = ResourceEntryForm.BioDetails;
    this.customRequest.UpdatedBy = this.userInfo.EmpId;
    this.customRequest.IsEdit = this.isEdit;

    this.adminService.createResource(this.customRequest)
      .subscribe(
        (response: AddRosterResponse) => {
          if (response.Status) {
            if (this.isEdit) {
              this.successMessage = 'Employee updated successfully';
            } else {
              this.successMessage = 'Employee Added successfully';
            }
            this.toast.success(this.successMessage, '', () => {
              this.resourceEntryForm.reset();
              this.router.navigate(['/iCoachFirst/admin/employee-roster']);
              this.dialogRef.close('success');
            });
          } else {
            this.toast.error(response.ResponseMessage, 'Error Message');
          }
          this.submitted = false;
        });

  }

  cancle_click() {
    this.router.navigate(['/iCoachFirst/admin/employee-roster']);
  }

  getControls() {
    return (<FormArray>this.resourceEntryForm.get('items')).controls;
  }
    getEmpAdditionalManager(empid: Number) {
    this.empAdditionalManagerService.GetEmployeeAdditionalManagerByEmpId(empid).subscribe(response => {
      const addManagers = JSON.parse(JSON.stringify(response));
      if (addManagers && addManagers.length > 0) {
        this.existingAddManagerCount = addManagers.length;
        addManagers.forEach(addManager => {
          const addManagerDetails = {} as AdditionalManagerRequest;
          addManagerDetails.ManagerId = addManager.ManagerId;
          addManagerDetails.FirstName = addManager.FirstName;
          addManagerDetails.LastName = addManager.LastName;
          addManagerDetails.EmailId = addManager.EmailId;
          addManagerDetails.ProfilePicUrl = addManager.ProfileImageName;
          if (addManager.StatusId === 80) {
            addManagerDetails.Name = (addManager.FirstName + ' ' + addManager.LastName) + ' ' + '(Invited)'  ;
          } else {
            addManagerDetails.Name = addManager.FirstName + ' ' + addManager.LastName;
          }
          addManagerDetails.StatusId = addManager.StatusId;
          this.additionalManagerList.push(addManagerDetails);
        });
      }
    });
  }
}
