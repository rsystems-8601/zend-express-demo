import { Component, OnInit, Inject} from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { UserService } from '../../../services/user.service';
import { AdminService } from '../../../services/admin.service';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { AvailableEmployeelistRequest } from 'src/app/models/requests/available-employeelist-request';
import { AvailableEmployeeListResponse } from 'src/app/models/response/admin/available-employeelist-response';
// import { ManageEmployeeResponse } from 'src/app/models/response/admin/manage-employee-response';
import { AddCandidateListRequest } from 'src/app/models/requests/add-candidatelist-request';
import { IcftoasterService } from 'src/app/services/icftoaster.service';


@Component({
  selector: 'app-search-employee',
  templateUrl: './search-employee.component.html',
  styleUrls: ['./search-employee.component.scss']
})
export class SearchEmployeeComponent implements OnInit {
  searchEmpForm: FormGroup;
  availEmpRequest = {} as AvailableEmployeelistRequest;
  availEmpResponse: AvailableEmployeeListResponse;
  empListCollection: AvailableEmployeeListResponse;
  manageemployeeResponse: any[];
  listName: string;
  owner: string;
  puborPri: string;
  Selected: number;
  listEmpIds: Array<string> = new Array<string>();
  searchFilteredList: Array<number> = new Array<number>();
  addCandiateList = {} as AddCandidateListRequest;
  constructor(
    private formBuilder: FormBuilder,
    private adminService: AdminService,
    private userService: UserService,
    private toast: IcftoasterService,
    public dialogRef: MatDialogRef<SearchEmployeeComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) { }

  ngOnInit() {
    this.puborPri = '-1';
    this.manageemployeeResponse = this.data;
    this.setupFormControls();
    this.getEmployeeLists();
  }
  private setupFormControls() {
    this.searchEmpForm = this.formBuilder.group({
      txtListName: ['', Validators.required],
      ddlVisibility: [''],
      tblGrid: ['']
    });
  }
  getEmployeeLists() {
    const userDetails = this.userService.getUserDetails().UserDetails;
    this.availEmpRequest.MemberOrgId = userDetails.MemberOrgID;
    this.availEmpRequest.ListName = '';
    this.availEmpRequest.PuborPri = '-1';
    this.availEmpRequest.Owner = '';
    this.adminService.getAvailableLists(this.availEmpRequest).subscribe((availEmpReponse: AvailableEmployeeListResponse) => {
    this.empListCollection = availEmpReponse;
  });
}
searchListGo() {
  const userDetails = this.userService.getUserDetails().UserDetails;
    this.availEmpRequest.MemberOrgId = userDetails.MemberOrgID;
    this.availEmpRequest.ListName = this.listName;
    this.availEmpRequest.PuborPri = this.puborPri;
    this.availEmpRequest.Owner = '';
    this.adminService.getAvailableLists(this.availEmpRequest).subscribe((availEmpReponse: AvailableEmployeeListResponse) => {
    this.empListCollection = availEmpReponse;
  });
}

setFilteredList(typeSelectedList: AvailableEmployeeListResponse) {
  if (typeSelectedList.CandidateListID) {
    this.searchFilteredList = [];
    this.searchFilteredList.push(typeSelectedList.CandidateListID);
   }
}
searchListFinish() {
  const userDetails = this.userService.getUserDetails().UserDetails;
    const EmployeeID = userDetails.EmployeeId;

  if (this.searchFilteredList.length > 0) {
    const candidateListID = this.searchFilteredList[0];
    this.addCandiateList.CandidateListID = candidateListID;
  } else if (this.searchFilteredList.length <= 0) {
    {
    // validation of check boxes
    this.toast.error('Please select any list item from Select List');
    this.addCandiateList.CandidateListID = 0;
    return ;
  }
  }
  if (this.manageemployeeResponse.length > 0) {
    this.listEmpIds = [];
    for (let i = 0; i < this.manageemployeeResponse.length; i++) {
      this.listEmpIds.push(String(this.manageemployeeResponse[i].EmpID));
    }
    this.addCandiateList.XmlEmpData = this.listEmpIds;
  }
  this.addCandiateList.ResourceType = 'Employee';
  this.addCandiateList.loggedInEmpID = EmployeeID;
  this.adminService.addCandidateToList(this.addCandiateList).subscribe((res) => {
    const errMessage = res;
    if (errMessage.length === 0) {
      this.toast.success('Resources added successfully');
    } else {this.toast.error('These resources are already exist in this list:' + errMessage);
  }
    this.dialogRef.close();
});
}
// cancel button
Cancel() {
  this.dialogRef.close('close');
}
}
