import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { ConnectapiService } from 'src/app/services/connectapi.service';
import { ManageEmployeeResponse } from 'src/app/models/response/admin/manage-employee-response';
import { AdminService } from 'src/app/services/admin.service';
import { UserService } from 'src/app/services/user.service';
import { ManageEmployeeRequest, UpdateEmployeeRequest } from 'src/app/models/requests/manage-employee-request';
import { AddNewListRequest } from 'src/app/models/requests/add-newlist-request';
import { IcftoasterService } from 'src/app/services/icftoaster.service';
import * as $ from 'jquery';
import { ExcelService } from 'src/app/services/excel-service';
import { LoaderService } from 'src/app/services/loader.service';

@Component({
  selector: 'app-update-employee-lists',
  templateUrl: './update-employee-lists.component.html',
  styleUrls: ['./update-employee-lists.component.scss']
})

export class UpdateEmployeeListsComponent implements OnInit {

  selectedFile: any;
  docFileNameerrors = false;
  allAttachments: any;
  arrayBuffer: any;
  empListReponse: ManageEmployeeResponse;
  memberOrgId: number;
  manageEmpRequest = {} as ManageEmployeeRequest;
  updateEmployeeRequest = {} as UpdateEmployeeRequest;
  newListPublic: string;
  addnewListRequest = {} as AddNewListRequest;
  listResponse: string;
  newlistName: string;
  selectedUpdatelistName = '';
  showList = [];
  responseMessage = '';

  @ViewChild('fileList') el2: ElementRef;

  constructor(
    private connectApiService: ConnectapiService,
    private empAdminService: AdminService,
    private userService: UserService,
    private adminService: AdminService,
    private toast: IcftoasterService,
    public excelService: ExcelService,
    private loaderService: LoaderService,
  ) { }

  ngOnInit() {
    this.newListPublic = 'true';
    const userDetails = this.userService.getUserDetails().UserDetails;
    this.memberOrgId = userDetails.MemberOrgID;
    this.manageEmpRequest.EmployeeID = userDetails.EmployeeId;
    this.manageEmpRequest.MemberOrgId = this.memberOrgId;
    this.manageEmpRequest.ResourceType = 'Employee';
    this.loademployeeList();
  }

  onFileChanged(event: any) {
    this.selectedFile = event.target.files[0];
    if (this.selectedFile !== undefined) {
      this.docFileNameerrors = this.validateFile(this.selectedFile.name.toLowerCase());
      if (this.docFileNameerrors) {
        this.toast.error('Please upload a valid document');
        return false;
      }
      this.loaderService.show();
      this.allAttachments = event.target.files;
      this.excelService.readXlsFile(event).subscribe((response) => {
        if (response) {
          this.showList = response;
          this.loaderService.hide();
        }
      });
    }
  }

  validateFile(name: String) {
    const allowedExtensions = ['xls', 'xlsx'];
    const fileExtension = name.split('.').pop();
    if (this.isInArray(allowedExtensions, fileExtension)) {
      return false;
    }
    return true;
  }

  isInArray(array, word) {
    return array.indexOf(word.toLowerCase()) > -1;
  }

  attachDocument() {
    const af = this.allAttachments[0];
    const resourceType = af['type'];
    const reader = new FileReader();
    reader.readAsDataURL(af);
    reader.onload = (function (cb, parentThis) {
      if (cb) {
        return function () {
          const attachDetails = {
            'FileName': af.name,
            'FileStream': reader.result.toString().split(',')[1],
            'ResourceType': resourceType
          };
          parentThis.connectApiService.uploadChatAttachment(attachDetails).subscribe((response) => {
            if (response) {
              //
            }
          });
        };
      }
    })(af, this);
  }

  saveListToDB() {
    if ($.trim(this.newlistName) === '') {
      this.toast.error('Please enter valid list name');
      return;
    }

    const userDetails = this.userService.getUserDetails().UserDetails;
    this.addnewListRequest.MemberOrgId = userDetails.MemberOrgID;
    this.addnewListRequest.EmployeeID = userDetails.EmployeeId;
    this.addnewListRequest.OwnerID = userDetails.EmployeeId;
    this.addnewListRequest.ResourceType = 'Employee';
    if (this.newlistName !== undefined) {
      this.addnewListRequest.ListName = this.newlistName;
    }

    if (this.newListPublic === 'true') {
      this.addnewListRequest.IsPublic = true;
    } else {
      this.addnewListRequest.IsPublic = false;
    }

    this.addnewListRequest.XmlEmpData = [];
    this.adminService.addToNewList(this.addnewListRequest).subscribe((response: any) => {
      this.listResponse = response;
      if (this.listResponse.length > 0) {
        this.toast.error('This list already exists');
      } else {
        this.toast.success('List added successfully');
        this.resetUpdateForm();
        this.loademployeeList();
      }
    });
  }

  loademployeeList() {
    this.empAdminService.getEmpLists(this.manageEmpRequest).subscribe((manageEmpReponse: ManageEmployeeResponse) => {
      this.empListReponse = manageEmpReponse;
    });
  }

  resetUpdateForm() {
    this.showList = [];
    this.newlistName = '';
    this.selectedUpdatelistName = '';
    this.el2.nativeElement.value = '';
  }

  saveToDatabse() {
    event.preventDefault();
    event.stopPropagation();
    if (this.selectedUpdatelistName === '' || this.selectedUpdatelistName === undefined) {
      this.toast.error('Please select any employee list first');
      this.el2.nativeElement.value = '';
      return true;
    }

    const setRequestEmail = [];
    this.showList.forEach(item => {
      setRequestEmail.push({ EmailId: item.Email_Address });

    });
    this.updateEmployeeRequest.EmpListId = this.selectedUpdatelistName;
    this.updateEmployeeRequest.EmailJson = setRequestEmail;

    this.empAdminService.updtaeEmpLists(this.updateEmployeeRequest).subscribe((updateEmpReponse: any) => {
      this.excelService.exportAsExcelFile(updateEmpReponse, 'savedEmploeeListStatus');
      // updateEmpReponse.forEach((item, index) => {
      //   this.responseMessage += index + ' ' + ' -' + (item.IsError === 'Yes' ? 'Already Exist' : 'Saved') + '\n';
      // });
      this.toast.success('Please review update response in downloaded XLS Sheet');
      this.resetUpdateForm();
    });
  }

  downloadSampleTemplate() {
    const updateEmpReponse = [{ Email_Address: '' }];
    this.excelService.exportAsExcelFile(updateEmpReponse, 'templateEmploeeList');
  }

}
