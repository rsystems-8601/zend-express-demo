import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateEmployeeListsComponent } from './update-employee-lists.component';

describe('UpdateEmployeeListsComponent', () => {
  let component: UpdateEmployeeListsComponent;
  let fixture: ComponentFixture<UpdateEmployeeListsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdateEmployeeListsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateEmployeeListsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
