import { Component, OnInit, Inject } from '@angular/core';
import { UserService } from 'src/app/services/user.service';
import { IcftoasterService } from 'src/app/services/icftoaster.service';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { FormGroup, FormBuilder /*, Validators */ } from '@angular/forms';
import { UserDetails } from 'src/app/models/user-details-result';
import { UserAttachmentResponse } from 'src/app/models/response/act-response';
import { CommonEnum } from 'src/app/helpers/enums/common-enums';
import { GroupResourceRequest } from 'src/app/models/requests/connect-request';
import { ConnectMessageService } from 'src/app/services/connect-message.service';
import { AdminService } from '../../../../services/admin.service';

@Component({
  selector: 'app-review-assignment-form',
  templateUrl: './review-assignment-form.component.html',
  styleUrls: ['./review-assignment-form.component.scss']
})

export class ReviewAssignmentFormComponent implements OnInit {

  resourceAttachDocRequest = {} as GroupResourceRequest;
  reportRequestParam = { empReportId: '' };
  getReviewAssignmentForm: FormGroup;
  submitted = false;
  selectedFile: any;
  allAttachments: any;
  userDetails: UserDetails;
  userAttachmentList: UserAttachmentResponse[];
  CommonEnum = CommonEnum;
  formDueDate: any;
  readOnlyElementDate = true;
  readOnlyElementManager = true;
  readOnlyElementEmployee = true;

  constructor(private userService: UserService,
    private toast: IcftoasterService,
    public dialogRef: MatDialogRef<ReviewAssignmentFormComponent>,
    @Inject(MAT_DIALOG_DATA) public data,
    private formBuilder: FormBuilder,
    protected connectMessageService: ConnectMessageService,
    private empAdminService: AdminService,
  ) { }

  ngOnInit() {
    this.userDetails = this.userService.getUserDetails().UserDetails;

    this.getReviewAssignmentForm = this.formBuilder.group({
      //  managerComments: ['', Validators.required],
      //  employeeComments: ['', Validators.required],
      managerComments: [''],
      employeeComments: [''],
    });

    if (this.data.commentsData.data.Completed === 'No') {
      this.readOnlyElementDate = false;
      this.readOnlyElementManager = false;
    }

    if (this.data.commentsData.data.AssignmentCatalog === 'Assessment' || this.data.commentsData.data.AssignmentCatalog === 'Survey') {
      this.readOnlyElementManager = true;
    }

    if (this.data.commentsData.data.Completed === 'Yes') {
      this.readOnlyElementDate = true;
      this.readOnlyElementManager = true;
    }

  }

  get f() {
    return this.getReviewAssignmentForm.controls;
  }

  onSubmit() {
    this.submitted = true;
    if (this.getReviewAssignmentForm.invalid || !this.formDueDate) {
      return;
    }

    this.saveReviewAssignmentFormData();
  }

  saveReviewAssignmentFormData() {
    const resuestData = {
      'assignmentId': this.data.commentsData.data.AssignmentId,
      'reviewId': this.data.commentsData.data.ReviewId,
      'dueDate': this.formDueDate,
      'ManagerComments': this.getReviewAssignmentForm.value.managerComments,
      'EmployeeComments': this.getReviewAssignmentForm.value.employeeComments,
      'flag': this.data.commentsData.data.Type
    };

    this.empAdminService.updateAssignedDueDate(resuestData).subscribe((response) => {
      if (response) {
        if (response) {
          this.toast.success('Assignment comments added successfully', '');
          this.submitted = false;
          this.cancelClicked('save');
        }
      }
    });
  }

  cancelClicked(action: string) {
    this.formDueDate = '';
    this.getReviewAssignmentForm.reset();
    this.dialogRef.close(action);
  }

}
