import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReviewAssignmentFormComponent } from './review-assignment-form.component';

describe('ReviewAssignmentFormComponent', () => {
  let component: ReviewAssignmentFormComponent;
  let fixture: ComponentFixture<ReviewAssignmentFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReviewAssignmentFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReviewAssignmentFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
