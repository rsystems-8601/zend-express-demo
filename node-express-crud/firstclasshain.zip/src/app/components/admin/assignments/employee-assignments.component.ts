import { Component, OnInit, OnDestroy } from '@angular/core';
import { EmployeeAssignmentRequest } from '../../../models/requests/employee-assignments-request';
import { AdminService } from '../../../services/admin.service';
import { AdminResponse } from 'src/app/models/response/admin/admin-response';
import { PagerService } from '../../../services/pager-service';
import { ExcelService } from '../../../services/excel-service';
import { UserService } from 'src/app/services/user.service';
import * as _ from 'underscore';
import { EventEmiterService } from '../../../services/event.emmiter.service';
import { Subscription } from 'rxjs';
import { MatDialog, MatDialogConfig, MatTabChangeEvent, MatDialogRef } from '@angular/material';
import { IcftoasterService } from 'src/app/services/icftoaster.service';
import { SearchEmployeeComponent } from 'src/app/components/admin/search-employee/search-employee.component';
import { Router } from '@angular/router';
import { AdminPageRequest } from 'src/app/models/requests/page-request';
import { ReviewAssignmentFormComponent } from 'src/app/components/admin/assignments/review-assignment-form/review-assignment-form.component';
import { BaseRequest } from 'src/app/models/requests/base-request';
import { ConfirmationDialogService } from 'src/app/components/shared/confirmation-dialog/confirmation-dialog.service';

@Component({
  moduleId: module.id,
  selector: 'app-employee-assignments',
  templateUrl: './employee-assignments.component.html',
  styleUrls: ['./employee-assignments.component.scss']
})

export class EmployeeAssignmentsComponent implements OnInit, OnDestroy {
  adminLists: AdminResponse;
  adminList: any[];
  adminListCount: number;
  memberOrgID: number;
  empAssignmentsRequest = {} as EmployeeAssignmentRequest;
  responseAdmin: any[];
  responseStatus: any;
  responseDesignation: any;
  masterSelected: boolean;
  checkedList = [];
  searchKeyword = '';
  searchReportTo = 0;
  searchDottedLineTo = 0;
  searchName = '';
  searchStatus = '';
  searchDesignation = '';
  exportToExcelList: any[];
  rowNo: number;
  pagesize: number;
  tblPages: number;
  calllingSourceAssignment = 'calllingSourceAssignment';
  calllingSourceReportTo = 'All';
  // pager object
  pager: any = {};
  // paged items
  pagedItems: any[];
  model = [];
  allItemsSelected: boolean;
  selectedObserver: any;
  Observers: any;
  passData: any[];
  recentlyAddedList: Array<any> = [];
  private subscription: Subscription;
  empId: number;
  isSelectedSearchByTitle = 0;
  SelectedType = '';
  currentTabIndex: number;
  searchFilterManager = '';
  getAssignedFrom: any;
  getAssignedTo: any;
  userDetails: any;
  dialogRefClose: any;

  constructor(private empAdminService: AdminService, private pagerService: PagerService, private router: Router,
    private excelservice: ExcelService, private userService: UserService, private _eventEmiter: EventEmiterService,
    private dialog: MatDialog, private toast: IcftoasterService,
    public dialogRef: MatDialogRef<ReviewAssignmentFormComponent>,
    private confirmationDialogService: ConfirmationDialogService) {
    this.masterSelected = false;
    this.allItemsSelected = false;
    this.pagedItems = [];
    this.userDetails = this.userService.getUserDetails().UserDetails;
    this.subscription = this._eventEmiter.subscribe(data => {
      if (data.keyName === 'calllingSourceAssignment') {
        this.selectedObserver = data;
        if (this.selectedObserver.observerData) {
          this.empAssignmentsRequest.TeamMemberEmail = this.selectedObserver.observerData.EmailID;
        } else {
          this.empAssignmentsRequest.TeamMemberEmail = 'All';
        }
      }
      this.selectedObserver = null;
    });
  }

  ngOnInit() {
    this.searchStatus = 'Select Status';
    this.searchDesignation = 'Select Designation';

    this.memberOrgID = this.userDetails.MemberOrgID;
    this.rowNo = 10;
    this.tblPages = 0;
    this.empAssignmentsRequest.SearchBy = 'TeamMember';     // also from HTML
    this.empAssignmentsRequest.TeamMemberEmail = 'All';     // also from HTML
    this.empAssignmentsRequest.AssignedFrom = '';
    this.empAssignmentsRequest.AssignedTo = '';


    this.empAssignmentsRequest.AssignmentType = '';
    this.empAssignmentsRequest.MemberOrgId = this.memberOrgID;
    this.empAssignmentsRequest.PageRequest = {} as AdminPageRequest;
    this.empAssignmentsRequest.PageRequest.PageNumber = 0;
    this.empAssignmentsRequest.PageRequest.PageSize = 10;
    this.empAssignmentsRequest.PageRequest.SortColumn = 'DueDate';
    this.empAssignmentsRequest.PageRequest.SortDirection = 'ASC';
    this.empAssignmentsRequest.IsExcelExport = false;
    this.currentTabIndex = 0;
    this.searchBySelectedTab(this.currentTabIndex, true);
  }

  loadTabdata(TabName: string, pageReload = false) {
    this.empAssignmentsRequest.TabName = TabName;
    if (this.SelectedType !== '') {
      this.empAssignmentsRequest.AssignmentType = this.SelectedType;
    }
    this.empAssignmentsRequest.AssignedFrom = this.getAssignedFrom;
    this.empAssignmentsRequest.AssignedTo = this.getAssignedTo;
    if (pageReload) {
      this.empAssignmentsRequest.PageRequest.PageNumber = 0;
    }

    const searchName: any = window.document.getElementsByClassName('mat-form-field-autofill-control')[1];
    if (searchName.value === '') {
      this.empAssignmentsRequest.TeamMemberEmail = 'All';
    }

    this.empAdminService.getManageAssignmentDetails(this.empAssignmentsRequest).subscribe((res) => {
      const resSTR = <any>res;
      this.adminList = resSTR.ReviewSpecificAssignment;
      this.adminListCount = resSTR.TotalCount;
      if (pageReload) {
        this.setPagination(0, this.rowNo);
      }
      localStorage.removeItem('ResourceId');
    });
  }

  changeTolowerCase(valString: any) {
    if (valString !== '' && valString !== false && valString !== undefined && valString !== null && valString) {
      return valString.toLowerCase();
    } else {
      return valString + '';
    }

  }

  setSearchBy(val: number) {
    this.isSelectedSearchByTitle = val;
    if (val === 1) {
      this.empAssignmentsRequest.SearchBy = 'Title';
    } else {
      this.empAssignmentsRequest.SearchBy = 'TeamMember';
    }
  }

  unassignAssignment(assignmentId: number, type: any) {
    const data = { 'assignmentId': assignmentId, 'type': type };
    this.confirmationDialogService.confirm('Common_Confirm_Unassign',
      'Common_Yes',
      'Common_No').subscribe(value => {
        if (value) {
          this.empAdminService.unAssignedContent(data).subscribe((res) => {
            if (res) {
              this.toast.success('Review unassigned successfully.', '');
              this.searchBySelectedTab(this.currentTabIndex);
            }
          });
        }
      });
  }

  unassignAssignmentText(g: any) {
    const dataType = (g.Type.toLowerCase() === 'assessment' || g.Type.toLowerCase() === 'survey') ? 'survey' : 'train';
    if (g.FolderId > 0 && g.Completed === 'No' && (g.Type !== 'Document' || g.Type !== 'Link' || g.Type !== 'eLearning')) {
      return 'Unassign';
    }
    if (g.FolderId === 0 && g.Type !== 'Document' && g.Type !== 'Link' && g.Type !== 'eLearning') {
      if (
        (dataType === 'survey' && g.Status === 'Not Yet Started')
        ||
        (dataType === 'train' && g.Completed === 'No')
      ) {
        return 'Unassign';
      }
    }
    return ' ';
  }

  setPagination(page: number, size: number) {

    if (page > -1 || page === 0) {
      this.tblPages = page;
    }

    if (size) {
      // this.rowNo = size;
    }

    this.pager = this.pagerService.getAjaxPagerForAssignment(this.adminListCount, this.tblPages, Number(size));
    this.pagedItems = this.adminList.slice(this.pager.startIndex, this.pager.endIndex + 1);
    if (this.pagedItems.length > 0) { this.selectEntity(); }
  }

  setPage(page: number, size: number) {
    if (page > -1) {
      this.tblPages = page - 1;
    }

    if (size) {
      // this.rowNo = size;
    }

    this.empAssignmentsRequest.PageRequest.PageNumber = this.tblPages;
    this.searchBySelectedTab(this.currentTabIndex);
    this.pager.currentPage = this.tblPages;
    this.setPagination(this.tblPages, this.rowNo);
  }

  selectEntity() {
    for (let i = 0; i < this.pagedItems.length; i++) {
      if (!this.pagedItems[i].isSelected) {
        this.allItemsSelected = false;
        return;
      }
    }
    this.allItemsSelected = true;
  }

  selectAll() {
    for (let i = 0; i < this.pagedItems.length; i++) {
      this.pagedItems[i].isSelected = this.allItemsSelected;
    }
  }

  generateCurrentToExcel() {
    this.excelservice.exportAsExcelFile(this.adminList, 'TalentFirstData');
  }

  generateToExcel() {
    const cloneData = this.empAssignmentsRequest;
    this.empAssignmentsRequest.PageRequest.PageNumber = 0;
    this.empAssignmentsRequest.PageRequest.PageSize = 1048576;

    this.empAdminService.getManageAssignmentDetails(this.empAssignmentsRequest).subscribe((res) => {
      const resSTR = <any>res;
      this.excelservice.exportAsExcelFile(resSTR.ReviewSpecificAssignment, 'TalentFirstData');
    });
    this.empAssignmentsRequest = cloneData;
  }

  goToEmployeeDetails(id: number) {
    localStorage.setItem('ResourceId', id.toString());

    this.router.navigate(['/iCoachFirst/admin/add-resource']);
  }

  exportToExcel(mode: string) {
    if (mode === 'current') {
      this.generateCurrentToExcel();
    }
    if (mode === 'all') {
      this.generateToExcel();
    }
  }

  onChange(event) {
    this.empAssignmentsRequest.PageRequest.PageSize = event.target.value;
    this.rowNo = event.target.value;
    this.tblPages = 0;
    this.searchBySelectedTab(this.currentTabIndex, true);
  }

  ngOnDestroy() {
    this._eventEmiter.unsubscribe(this.subscription);
  }

  addToList() {
    this.openEmpListModalPopup();
  }

  // pop up logic
  openEmpListModalPopup() {
    const dialogConfig = new MatDialogConfig();
    this.recentlyAddedList = [];
    if (this.adminList !== undefined) {
      for (let i = 0; i < this.adminList.length; i++) {
        if (this.adminList[i].isSelected && this.adminList[i].isSelected !== undefined) {
          this.recentlyAddedList.push(this.adminList[i]);
        }
      }
    }
    if (this.recentlyAddedList.length <= 0) {
      this.toast.error('Please select at least one row to add in a list');
      return;
    }
    dialogConfig.data = this.recentlyAddedList;
    dialogConfig.width = '720px';
    dialogConfig.disableClose = true;
    const dialogRef = this.dialog.open(SearchEmployeeComponent, dialogConfig);
    dialogRef.afterClosed().subscribe(value => {
      if (value === 'close') {
        // Nothing
      } else {
        this.selectEntity();
        this.selectAll();
      }
    });
  }

  onTabChanged = (_tabChangeEvent: MatTabChangeEvent): void => {
    if (_tabChangeEvent) {
      this.searchBySelectedTab(_tabChangeEvent.index, true);
    }
  }

  searchBySelectedTab(index = 0, pageReload = false) {
    this.currentTabIndex = index;
    if (index === 0) {
      this.loadTabdata('Manager', pageReload);
    }
    if (index === 1) {
      this.loadTabdata('Self', pageReload);
    }
    if (index === 2) {
      this.loadTabdata('View', pageReload);
    }
  }

  setAssignmentDate(e: any) {
    this.empAssignmentsRequest.AssignedFrom = e.targetElement.value;
  }

  setAssignedTo(e: any) {
    this.empAssignmentsRequest.AssignedTo = e.targetElement.value;
  }

  actionShowAll() {
    this.actionClearAll();
    this.searchBySelectedTab(this.currentTabIndex);
  }

  actionClearAll() {
    this.empAssignmentsRequest.SearchBy = 'TeamMember';     // also from HTML
    this.empAssignmentsRequest.TeamMemberEmail = 'All';     // also from HTML
    this.empAssignmentsRequest.AssignedFrom = '';
    this.empAssignmentsRequest.AssignedTo = '';
    this.empAssignmentsRequest.AssignmentType = '';
    this.empAssignmentsRequest.PageRequest.PageNumber = 1;
    this.empAssignmentsRequest.PageRequest.PageSize = 10;
    this.getAssignedFrom = '';
    this.getAssignedTo = '';

    const btSearchByTeammember: any = window.document.getElementsByClassName('searchByTeammember')[0];
    btSearchByTeammember.click();

    const searchName2: any = window.document.getElementsByClassName('mat-form-field-autofill-control')[1];
    searchName2.value = '';
    this.searchFilterManager = '';
    this.rowNo = 10;
  }

  actionDoneAll() {
    this.router.navigate(['/iCoachFirst/dashboard']);
  }

  addManagerComments(data: any) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.width = '580px';
    const dataToPass = new BaseRequest();
    dataToPass.RepId = this.userDetails.EmpId;
    dataToPass.IsRepInitiated = false;
    dialogConfig.data = {
      commentsData: { data: data, EmpId: this.userDetails.EmpId }
    };
    // dialogConfig.disableClose = true;
    this.dialogRefClose = this.dialog.open(ReviewAssignmentFormComponent, dialogConfig);
    this.dialogRefClose.afterClosed().subscribe(value => {
      if (value === 'cancel') {
        // Nothing
      } else {
        this.searchBySelectedTab(this.currentTabIndex);
      }
    });
  }
}
