import { Component, OnInit, OnDestroy } from '@angular/core';
import { EmployeeRosterRequest } from '../../../models/requests/employee-roaster-request';
import { AdminService } from '../../../services/admin.service';
import { AdminResponse } from 'src/app/models/response/admin/admin-response';
import { PagerService } from '../../../services/pager-service';
import { ExcelService } from '../../../services/excel-service';
import { UserService } from 'src/app/services/user.service';
import * as _ from 'underscore';
import { EventEmiterService } from '../../../services/event.emmiter.service';
import { Subscription } from 'rxjs';
import { MatDialog, MatDialogConfig } from '@angular/material';
import { IcftoasterService } from 'src/app/services/icftoaster.service';
import { SearchEmployeeComponent } from 'src/app/components/admin/search-employee/search-employee.component';
import { Router } from '@angular/router';

@Component({
  moduleId: module.id,
  selector: 'app-employee-roster',
  templateUrl: './employee-roster.component.html',
  styleUrls: ['./employee-roster.component.scss']
})
export class EmployeeRosterComponent implements OnInit, OnDestroy {
  adminLists: AdminResponse;
  adminList: any[];
  memberOrgID: number;
  statusList: [];
  designationList: [];
  empRosterRequest = new EmployeeRosterRequest();
  responseAdmin: any[];
  responseStatus: any;
  responseDesignation: any;
  masterSelected: boolean;
  checkedList = [];
  searchKeyword = '';
  searchReportTo = 0;
  searchDottedLineTo = 0;
  searchName = '';
  searchStatus = '';
  searchDesignation = '';
  exportToExcelList: any[];
  rowNo: number;
  pagesize: number;
  tblPages: number;
  calllingSourceDottedLineTo = 'DottedLineTo';
  calllingSourceReportTo = 'ReportTo';
  // pager object
  pager: any = {};
  // paged items
  pagedItems: any[];
  model = [];
  allItemsSelected: boolean;
  selectedObserver: any;
  Observers: any;
  passData: any[];
  recentlyAddedList: Array<any> = [];
  private subscription: Subscription;
  empId: number;
  constructor(private empAdminService: AdminService, private pagerService: PagerService, private router: Router,
    private excelservice: ExcelService, private userService: UserService, private _eventEmiter: EventEmiterService,
    private dialog: MatDialog, private toast: IcftoasterService) {
    this.masterSelected = false;
    this.allItemsSelected = false;
    this.pagedItems = [];
    this.subscription = this._eventEmiter.subscribe(data => {

      if (data.keyName === 'ReportTo') {
        this.selectedObserver = data;
        if (this.selectedObserver.observerData) {
          this.empRosterRequest.ReportToEmpID = 0;
          this.empRosterRequest.ReportToEmpID = this.selectedObserver.observerData.EmpID;
        } else {
          this.empRosterRequest.ReportToEmpID = 0;
        }
        this.selectedObserver = null;
      } else if (data.keyName === 'DottedLineTo') {
        this.selectedObserver = data;
        if (this.selectedObserver.observerData) {
          this.empRosterRequest.DottedLineTo = 0;
          this.empRosterRequest.DottedLineTo = this.selectedObserver.observerData.EmpID;
        } else {
          this.empRosterRequest.DottedLineTo = 0;
        }
      }
      this.selectedObserver = null;
    });
  }
  ngOnInit() {
    this.searchStatus = 'Select Status';
    this.searchDesignation = 'Select Designation';
    const userDetails = this.userService.getUserDetails().UserDetails;
    this.memberOrgID = userDetails.MemberOrgID;
    this.empRosterRequest.MemberOrgID = this.memberOrgID;
    this.empRosterRequest.Name = '';
    this.empRosterRequest.ReportToEmpID = 0;
    this.empRosterRequest.Keyword = '';
    this.empRosterRequest.EmploymentStatusID = 0;
    this.empRosterRequest.DottedLineTo = 0;
    this.empRosterRequest.DesignationId = 0;
    this.empRosterRequest.CandidateListID = 0;
    this.empRosterRequest.dataforexcel = false;
    this.empAdminService.getManageResourceDetails(this.empRosterRequest).subscribe((res) => {
      const resSTR = <any>res;
      this.designationList = (JSON.parse(resSTR).Table2);
      this.statusList = (JSON.parse(resSTR).Table1);
      this.adminList = (JSON.parse(resSTR).Table);

      // initialize to page 1
      this.rowNo = 10;
      this.setPage(1, 10);
      // this.generateToExcel();
      localStorage.removeItem('ResourceId');
      // get the employee
    });

  }
  setPage(page: number, size: number) {
    if (page < 1) {
      // || page > this.pager.totalPages
      return;
    }
    // get pager object from service
    size = this.rowNo;
    this.tblPages = page;
    this.pager = this.pagerService.getPager(this.adminList.length, page, Number(size));
    // get current page of items
    this.pagedItems = this.adminList.slice(this.pager.startIndex, this.pager.endIndex + 1);
    if (this.pagedItems.length > 0) { this.selectEntity(); }
  }
  // This executes when entity in table is checked
  selectEntity() {
    // If any entity is not checked, then uncheck the "allItemsSelected" checkbox
    for (let i = 0; i < this.pagedItems.length; i++) {
      if (!this.pagedItems[i].isSelected) {
        this.allItemsSelected = false;
        return;
      }
    }
    // If not the check the "allItemsSelected" checkbox
    this.allItemsSelected = true;
  }
  // This executes when checkbox in table header is checked
  selectAll() {
    // Loop through all the entities and set their isChecked property
    for (let i = 0; i < this.pagedItems.length; i++) {
      this.pagedItems[i].isSelected = this.allItemsSelected;
    }
  }
  generateToExcel() {
    // this.empRosterRequest.MemberOrgID = this.memberOrgID;
    // this.empRosterRequest.Name = '';
    // this.empRosterRequest.ReportToEmpID = 0;
    // this.empRosterRequest.Keyword = '';
    // this.empRosterRequest.EmploymentStatusID = 0;
    // this.empRosterRequest.DottedLineTo = 0;
    // this.empRosterRequest.DesignationId = 0;
    // this.empRosterRequest.CandidateListID = 0;
    // this.empRosterRequest.dataforexcel = true;
    this.empRosterRequest.MemberOrgID = this.memberOrgID;
    this.empRosterRequest.Name = this.searchName;
    // for RportToEmpID
    if (this.empRosterRequest.ReportToEmpID === undefined) {
      this.empRosterRequest.ReportToEmpID = 0;
    }
    // Close ReportToEmpID

    // Start DottedLineTo
    if (this.empRosterRequest.DottedLineTo === undefined) {
      this.empRosterRequest.DottedLineTo = 0;
    }
    // End DottedLineTo
    if (this.searchDesignation !== 'Select Designation') {
      this.empRosterRequest.DesignationId = Number(this.searchDesignation);
    } else {
      this.empRosterRequest.DesignationId = 0;
    }
    if (this.searchStatus !== 'Select Status') {
      this.empRosterRequest.EmploymentStatusID = Number(this.searchStatus);
    } else { this.empRosterRequest.EmploymentStatusID = 0; }

    this.empRosterRequest.Keyword = this.searchKeyword;
    // this.empRosterRequest.DottedLineTo = this.searchDottedLineTo;
    // this.empRosterRequest.ReportToEmpID = this.empRosterRequest.Observers[0].ReportToEmpID;
    this.empRosterRequest.CandidateListID = 0;
    this.empRosterRequest.dataforexcel = true;
    this.empAdminService.getManageResourceDetails(this.empRosterRequest).subscribe((response) => {
      const resSTR = <any>response;

      this.exportToExcelList = (JSON.parse(resSTR).Table);
      if (this.exportToExcelList !== undefined) {
        this.excelservice.exportAsExcelFile(this.exportToExcelList, 'TalentFirstData');
      }
    });
  }
  goToEmployeeDetails(id: number) {
    localStorage.setItem('ResourceId', id.toString());

    this.router.navigate(['/iCoachFirst/admin/add-resource']);
  }

  exportToExcel() {
    this.generateToExcel();
  }

  onChange(event) {
    this.pager = this.pagerService.getPager(this.adminList.length, this.tblPages, parseInt(event.target.value, 0));
    // get current page of items
    this.pagedItems = this.adminList.slice(this.pager.startIndex, this.pager.endIndex + 1);
    if (this.pagedItems.length > 0) {
      this.selectEntity();
      this.selectAll();
    }
  }

  ngOnDestroy() {
    this._eventEmiter.unsubscribe(this.subscription);
    this.empRosterRequest.Observers = null;
  }
  searchGo() {
    this.empRosterRequest.MemberOrgID = this.memberOrgID;
    this.empRosterRequest.Name = this.searchName;
    // for RportToEmpID
    if (this.empRosterRequest.ReportToEmpID === undefined) {
      this.empRosterRequest.ReportToEmpID = 0;
    }
    // Close ReportToEmpID

    // Start DottedLineTo
    if (this.empRosterRequest.DottedLineTo === undefined) {
      this.empRosterRequest.DottedLineTo = 0;
    }
    // End DottedLineTo
    if (this.searchDesignation !== 'Select Designation') {
      this.empRosterRequest.DesignationId = Number(this.searchDesignation);
    } else {
      this.empRosterRequest.DesignationId = 0;
    }
    if (this.searchStatus !== 'Select Status') {
      this.empRosterRequest.EmploymentStatusID = Number(this.searchStatus);
    } else { this.empRosterRequest.EmploymentStatusID = 0; }

    this.empRosterRequest.Keyword = this.searchKeyword;
    // this.empRosterRequest.DottedLineTo = this.searchDottedLineTo;
    // this.empRosterRequest.ReportToEmpID = this.empRosterRequest.Observers[0].ReportToEmpID;
    this.empRosterRequest.CandidateListID = 0;
    this.empRosterRequest.dataforexcel = false;

    this.empAdminService.getManageResourceDetails(this.empRosterRequest).subscribe((response) => {
      const strJson = <any>response;
      this.adminList = (JSON.parse(strJson).Table);
      //this.setPage(this.tblPages, this.rowNo);
      this.setPage(1, 10);

    });
  }

  showAllSearch() {
    this.searchStatus = 'Select Status';
    this.searchDesignation = 'Select Designation';
    const userDetails = this.userService.getUserDetails().UserDetails;
    this.memberOrgID = userDetails.MemberOrgID;
    this.empRosterRequest.MemberOrgID = this.memberOrgID;
    this.empRosterRequest.Name = '';
    this.empRosterRequest.ReportToEmpID = 0;
    this.empRosterRequest.Keyword = '';
    this.empRosterRequest.EmploymentStatusID = 0;
    this.empRosterRequest.DottedLineTo = 0;
    this.empRosterRequest.DesignationId = 0;
    this.empRosterRequest.CandidateListID = 0;
    this.empRosterRequest.dataforexcel = false;
    this.empAdminService.getManageResourceDetails(this.empRosterRequest).subscribe((res) => {
      const resSTR = <any>res;
      this.designationList = (JSON.parse(resSTR).Table2);
      this.statusList = (JSON.parse(resSTR).Table1);
      this.adminList = (JSON.parse(resSTR).Table);
      // initialize to page 1
      this.rowNo = 10;
      this.setPage(1, 10);
      this._eventEmiter.emit({ keyName: 'resetAutoComplete' });
      // this.generateToExcel();
      // get the employee
    });

  }
  addToList() {
    this.openEmpListModalPopup();
  }
  // pop up logic
  openEmpListModalPopup() {
    const dialogConfig = new MatDialogConfig();
    this.recentlyAddedList = [];
    if (this.adminList !== undefined) {
      for (let i = 0; i < this.adminList.length; i++) {
        if (this.adminList[i].isSelected && this.adminList[i].isSelected !== undefined) {
          this.recentlyAddedList.push(this.adminList[i]);
        }
      }
    }
    if (this.recentlyAddedList.length <= 0) {
      // validation of check boxes
      this.toast.error('Please select at least one row to add in a list');
      return;
    }
    dialogConfig.data = this.recentlyAddedList;
    dialogConfig.width = '720px';
    dialogConfig.disableClose = true;
    const dialogRef = this.dialog.open(SearchEmployeeComponent, dialogConfig);
    dialogRef.afterClosed().subscribe(value => {
      if (value === 'close') {
        // Nothing
      } else {
        this.selectEntity();
        this.selectAll();
      }
    });
  }
}



