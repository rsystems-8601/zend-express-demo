import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateEmployeeRosterComponent } from './update-employee-roster.component';

describe('UpdateEmployeeRosterComponent', () => {
  let component: UpdateEmployeeRosterComponent;
  let fixture: ComponentFixture<UpdateEmployeeRosterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdateEmployeeRosterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateEmployeeRosterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
