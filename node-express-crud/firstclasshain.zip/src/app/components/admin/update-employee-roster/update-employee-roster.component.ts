import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
// import { ConnectapiService } from 'src/app/services/connectapi.service';
import { ValidateReponse } from 'src/app/models/response/admin/manage-employee-response';
import { AdminService } from 'src/app/services/admin.service';
import { UserService } from 'src/app/services/user.service';
import { ManageEmployeeRequest, ValidateRosterRequest } from 'src/app/models/requests/manage-employee-request';
import { IcftoasterService } from 'src/app/services/icftoaster.service';
import { ExcelService } from 'src/app/services/excel-service';
import { LoaderService } from 'src/app/services/loader.service';
import { Observable } from 'rxjs';
import { User } from 'src/app/models/response/user-response';

@Component({
  selector: 'app-update-employee-roster',
  templateUrl: './update-employee-roster.component.html',
  styleUrls: ['./update-employee-roster.component.scss']
})

export class UpdateEmployeeRosterComponent implements OnInit {
  selectedFile: any;
  docFileNameerrors = false;
  allAttachments: any;
  memberOrgId: number;
  manageEmpRequest = {} as ManageEmployeeRequest;
  validateRosterRequest = {} as ValidateRosterRequest;
  listResponse: string;
  showList = [];
  showListTop = [];
  showMainList = [];
  responseMessage = '';
  excelColumnsList = [];
  canUpload = true;
  userDetails: User;
  isTableErrorEnable = false;
  isTableXLSEnable = false;
  hasXLSAnyErrors = false;
  errorList = [];
  showListLength: number;
  errorListLength: number;
  mainColumnList: number;
  isErrorButtonEnable = false;
  errorNumberCount = [];
  errorListAfterSaveTodatabase = true;
  showSTDBbutton = true;

  @ViewChild('fileList') el2: ElementRef;

  constructor(
    private empAdminService: AdminService,
    private userService: UserService,
    private toast: IcftoasterService,
    public excelService: ExcelService,
    private loaderService: LoaderService,
  ) { }

  ngOnInit() {
    this.userDetails = this.userService.getUserDetails().UserDetails;
    this.manageEmpRequest.EmployeeID = this.userDetails.EmployeeId;
    this.manageEmpRequest.MemberOrgId = this.userDetails.MemberOrgID;
    this.manageEmpRequest.ResourceType = 'Employee';
  }

  makeingCustomColumnList() {
    if (this.showList && this.showList.length > 0) {
      this.showList.forEach((mainRow) => {
        let tempRowCollection = {};
        let tempRow = '{';
        tempRow += Object.keys(mainRow).slice(0, this.mainColumnList).map(temp => { return ('"' + temp + '"' + ':"' + mainRow[temp] + '"'); });
        tempRow += ',"CustomFields":{}}';
        tempRowCollection = JSON.parse('' + tempRow + '');
        const customList = Object.keys(mainRow).slice(this.mainColumnList).map(key => { return { Key: key, Value: mainRow[key] }; });
        tempRowCollection['CustomFields'] = customList;
        this.showMainList.push(tempRowCollection);
      });
    }
  }

  validateRoster() {

    if (this.excelColumnsList.length < 1) {
      this.toast.error('Please upload a valid document');
      // this.loaderService.hide();
      return false;
    }
    this.errorNumberCount = [];
    this.errorListLength = 0;
    this.hasXLSAnyErrors = false;
    this.makeingCustomColumnList();
    this.validateRosterRequest.EmpId = this.userDetails.EmpId;
    this.validateRosterRequest.EmployeeID = this.userDetails.EmployeeId;
    this.validateRosterRequest.MemberOrgId = this.userDetails.MemberOrgID;
    this.validateRosterRequest.Employees = this.showList;
    this.validateRosterRequest.ExcelColumnsList = this.excelColumnsList;
    this.empAdminService.validateRosterFiles(this.validateRosterRequest).subscribe((validateReponse: ValidateReponse) => {
      if (validateReponse.Errors !== undefined) {
        if (validateReponse.Errors.length > 0) {
          this.errorList = validateReponse.Errors;
          if (this.errorList && this.errorList.length > 0) {
            this.errorList.forEach((mainRow) => {
              this.errorNumberCount.push(mainRow.RowId);
            });
            this.errorNumberCount = this.errorNumberCount.filter((item, i, ar) => ar.indexOf(item) === i);
            this.toast.error('Unable to process some records.');
          }
          this.errorListLength = this.errorList.length;
          this.hasXLSAnyErrors = true;
          // this.enableTableErrors();
          this.isErrorButtonEnable = true;
        } else {
          this.enableTableXLS();
          this.showSTDBbutton = false;
        }
        this.el2.nativeElement.value = '';
      } else {
        this.hasXLSAnyErrors = false;
        this.isErrorButtonEnable = false;
        // this.enableTableXLS();
        this.el2.nativeElement.value = '';
      }
      // this.loaderService.hide();
    }, error => {
      if (error) {
        this.toast.error('Server issue, Please contact server administrator.');
        this.resetUpdateForm();
        // this.loaderService.hide();
      }
    });
  }

  enableTableXLS(reset = 'No') {
    this.loaderService.show();
    if (reset === 'resetall') {
      const timer = setTimeout(() => {
        this.filterList('all').subscribe(resp => {
          if (resp) {
            this.isTableXLSEnable = true;
            this.isTableErrorEnable = false;
            this.loaderService.hide();
            clearTimeout(timer);
          }
        });
      }, 1000);
    } else {
      this.isTableXLSEnable = true;
      this.isTableErrorEnable = false;
      this.loaderService.hide();
    }
    // this.autohide(this.showListLength);

  }



  enableTableErrors() {
    // this.autohide(this.errorListLength);
    this.isTableErrorEnable = true;
    this.isTableXLSEnable = false;
  }

  autohide(len: number) {
    if (len > 1000) {
      this.loaderService.show();
      setTimeout(() => { this.loaderService.hide(); }, len);
    }
  }

  onFileChanged(event: any) {
    this.resetUpdateForm();
    this.loaderService.show();
    event.preventDefault();
    event.stopPropagation();
    this.selectedFile = event.target.files[0];
    if (this.selectedFile !== undefined) {
      this.docFileNameerrors = this.validateFile(this.selectedFile.name.toLowerCase());
      if (this.docFileNameerrors) {
        this.toast.error('Please upload a valid document');
        this.loaderService.hide();
        this.el2.nativeElement.value = '';
        return false;
      }

      this.excelService.readXlsFile(event).subscribe((response) => {
        if (response) {
          this.showListTop = response;
          this.showList = response;
          this.showListLength = this.showList.length;
          this.makingDisplayReesultOfXLS(response);
          if (this.canUpload) {
            this.validateRoster();
            this.loaderService.hide();
          } else {
            this.toast.error('First 11 column should be in sequence and all are mandatory as :: EmailId, FirstName, LastName, ReportToEmailId, ' +
              'DesignationCode,  EmploymentStatus, DottedLineToEmailId, Department, Region, District, Territory');
            this.resetUpdateForm();
            this.loaderService.hide();
          }
        } else {
          this.loaderService.hide();
          this.el2.nativeElement.value = '';
        }
      }, error => {
        if (error) {
          this.toast.error('Server issue, Please contact server administrator.');
          this.resetUpdateForm();
          this.loaderService.hide();
        }
      });
    } else {
      this.loaderService.hide();
      this.el2.nativeElement.value = '';
    }
  }

  makingDisplayReesultOfXLS(uploadedList: any) {
    this.excelColumnsList = [];
    uploadedList.some((row) => {
      if (this.excelColumnsList.length < 1) {
        this.excelColumnsList = Object.keys(row);
        this.validateStartedColumn();
        return;
      }
    });
  }

  validateStartedColumn() {
    this.canUpload = true;
    const mainArr = ['EmailId', 'FirstName', 'LastName', 'ReportToEmailId', 'DesignationCode',
      'EmploymentStatus', 'DottedLineToEmailId', 'Department', 'Region', 'District', 'Territory'];
    this.mainColumnList = mainArr.length;
    const slicedValue = this.excelColumnsList.slice(0, (this.mainColumnList));
    for (let i = 0; i < this.mainColumnList; i++) {
      if (slicedValue[i] !== mainArr[i]) {
        this.canUpload = false;
      }
    }
  }

  validateFile(name: String) {
    const allowedExtensions = ['xls', 'xlsx'];
    const fileExtension = name.split('.').pop();
    if (this.isInArray(allowedExtensions, fileExtension)) {
      return false;
    }
    return true;
  }

  isInArray(array, word) {
    return array.indexOf(word.toLowerCase()) > -1;
  }

  resetUpdateForm(button = '') {
    if (button === 'reset') {
      this.el2.nativeElement.value = '';
    }
    this.showList = [];
    this.showListTop = [];
    this.errorList = [];
    this.showMainList = [];
    this.hasXLSAnyErrors = true;
    this.canUpload = false;
    this.isErrorButtonEnable = false;
    this.errorListAfterSaveTodatabase = true;
    this.isTableXLSEnable = false;
    this.isTableErrorEnable = false;
    this.showSTDBbutton = true;
  }

  saveToDatabse() {
    if (this.hasXLSAnyErrors) {
      this.toast.error('Please remove erros and upload again.');
      return true;
    } else {
      this.saveEmployeeRoster();
    }
  }

  downloadErrors(filename = '') {
    this.loaderService.show();
    const errorListSplitTags = [];
    const errorListArr = this.errorList.filter((_item, i) => {
      if (i > -1) {
        return true;
      }
    });
    if (errorListArr && errorListArr.length > 0) {
      errorListArr.forEach((mainRow, i) => {
        mainRow.RowId = ((mainRow.RowId === '0' || mainRow.RowId === 0) ? (i + 1) : (mainRow.RowId));
        if (mainRow.ErrorDescription && mainRow.ErrorDescription !== '') {
          //  dont remove double Qotes from below two lines 
          mainRow.ErrorDescription = (mainRow.ErrorDescription).replace(/<\/?[^>]+(>|$)/g, '');
          mainRow.ErrorDescription = (mainRow.ErrorDescription).replace('&nbsp;', '');
        }
        errorListSplitTags.push(mainRow);
      }
      );
      this.excelService.exportRoster(errorListSplitTags, ((filename !== '') ? filename : 'errorList'));
    }
    this.loaderService.hide();
  }

  saveEmployeeRoster() {
    if (this.showMainList.length < 0) {
      this.toast.error('Please upload a valid document');
      this.resetUpdateForm();
      return;
    }
    const saveRosterRequest = {} as ValidateRosterRequest;
    saveRosterRequest.EmpId = this.userDetails.EmpId;
    saveRosterRequest.EmployeeID = this.userDetails.EmployeeId;
    saveRosterRequest.MemberOrgId = this.userDetails.MemberOrgID;
    saveRosterRequest.Employees = this.showMainList;

    this.empAdminService.saveEmployeeRoster(saveRosterRequest).subscribe((saveReponse: ValidateReponse) => {
      if (saveReponse !== undefined && saveReponse.Errors.length > 0) {
        let isAllSaved = true;
        saveReponse.Errors.some(element => {
          if (element['IsError'] !== undefined && element['IsError'] === 'Yes') {
            isAllSaved = false;
            return true;
          }
        });
        if (isAllSaved) {
          this.toast.success('Roster successfully saved.');
          this.isErrorButtonEnable = false;
        } else {
          this.toast.error('Some records failed. Please review downloaded XLS file and remove errors.');
        }
        this.errorListAfterSaveTodatabase = false;
        this.errorList = saveReponse.Errors;
        this.errorListLength = this.errorList.length;
        this.hasXLSAnyErrors = true;
        this.enableTableXLS();
        this.downloadErrors(('UpdateEmployeeDetails_' + new Date().getTime()));
      } else {
        this.toast.success('Roster updation failed. Please remove errors.');
        this.resetUpdateForm();
        return;
      }
    }, error => {
      if (error) {
        this.toast.error('Server issue, Please contact server administrator.');
        this.resetUpdateForm();
        return;
      }
    });
  }

  downloadSampleTemplate() {
    const updateEmpReponse = [{
      EmailId: '', FirstName: '', LastName: '', ReportToEmailId: '',
      DesignationCode: '', EmploymentStatus: '', DottedLineToEmailId: '',
      Department: '', Region: '', District: '', Territory: ''
    }];
    this.excelService.exportRoster(updateEmpReponse, 'UpdateEmployeesFormatNewProcess');
  }


  viewSuccessRecords() {
    this.loaderService.show();
    const timer = setTimeout(() => {
      this.filterList('success').subscribe(resp => {
        if (resp) {
          this.isTableXLSEnable = true;
          this.isTableErrorEnable = false;
          this.loaderService.hide();
          clearTimeout(timer);
        }
      });
    }, 1000);

  }

  filterList(type: string): Observable<true> {
    return Observable.create(observer => {
      this.showList = [];
      if (type === 'success') {
        this.showList = this.showListTop.filter((_item, i) => {
          if (this.errorNumberCount.indexOf(i + 1) < 0) {
            return true;
          }
        });
      } else if (type === 'all') {
        this.showList = this.showListTop.filter(() => {
          return true;
        });
      } else if (type === 'failure') {
        this.showList = this.showListTop.filter((_item, i) => {
          if (!(this.errorNumberCount.indexOf(i + 1) < 0)) {
            return true;
          }
        });
      }
      observer.next(true);
      observer.complete();
    });
  }
  downloadSuccessRecords() {
    let downLoadList = [];
    downLoadList = this.showListTop.filter((_item, i) => {
      if (this.errorNumberCount.indexOf(i + 1) < 0) {
        return true;
      }
    });
    this.excelService.exportRoster(downLoadList, 'SuccessfulRosterRecords');
  }

  viewFailedRecords() {
    this.loaderService.show();
    const timer = setTimeout(() => {
      this.filterList('failure').subscribe(resp => {
        if (resp) {
          this.isTableXLSEnable = true;
          this.isTableErrorEnable = false;
          this.loaderService.hide();
          clearTimeout(timer);
        }
      });
    }, 1000);
  }

  downloadFailedRecords() {
    let downLoadList = [];
    downLoadList = this.showListTop.filter((_item, i) => {
      if (!(this.errorNumberCount.indexOf(i + 1) < 0)) {
        return true;
      }
    });
    this.excelService.exportRoster(downLoadList, 'FailedRosterRecords');
  }
}
