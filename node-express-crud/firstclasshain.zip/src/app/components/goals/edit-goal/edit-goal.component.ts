import { Component, OnInit, HostListener, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { GoalResponseResolved, GoalTaskMilestoneResponseResolved } from 'src/app/models/response/goal/goal-response';
import { ActivatedRoute, Router } from '@angular/router';
import { Goal } from 'src/app/models/response/goal/goal-response';
import { UserService } from 'src/app/services/user.service';
import { IcftoasterService } from 'src/app/services/icftoaster.service';
import { CreateGoalRequest } from 'src/app/models/requests/create-goal-request';
import { GoalsService } from 'src/app/services/goals.service';
import { DatePipe } from '@angular/common';
import { GoalTask } from 'src/app/models/response/goal/goal-task-response';
import { Milestone } from 'src/app/models/response/milestone/milestone-response';
import { MatDialogConfig, MatDialog } from '@angular/material';
import { UpdateTaskStatusComponent } from '../update-task-status/update-task-status.component';
import { AssignTaskComponent } from '../../tasks/assign-task/assign-task.component';
import { CreateMilestoneComponent } from '../create-milestone/create-milestone.component';
import { CreateGoalLinkingComponent } from '../create-goal-linking/create-goal-linking.component';
import { MilestoneRequest } from 'src/app/models/requests/milestone-request';
import { TrackService } from 'src/app/services/track.service';
import { GoalRequest } from 'src/app/models/requests/goal-request';
import * as Highcharts from 'highcharts';
import { GoalConfiguration, UserDetails, StatusImage, TypeImage } from 'src/app/models/user-details-result';
import { GoalCompletedColorCode, ChartType, GoalCompletedColorRange, ApplicationModuleListEnum } from 'src/app/helpers/enums/common-enums';
import { PieChartRequest, SeriesData } from 'src/app/models/requests/highchart-request';
import { HighchartService } from 'src/app/services/highchart.service';
import { DeleteGoalLinkingRequest } from 'src/app/models/requests/goal-linking-request';
import { ConfirmationDialogService } from '../../shared/confirmation-dialog/confirmation-dialog.service';
import { SaveGoalTaskCommentRequest } from 'src/app/models/requests/task-request';
import { LocalizationService } from 'src/app/services/localization.service';
import { TaskService } from 'src/app/services/task.service';
import { Subscription } from 'rxjs';
import { EventEmiterService } from 'src/app/services/event.emmiter.service';
import { SharedDataService } from 'src/app/services/shared-data.service';
import { UserPermissions } from 'src/app/helpers/enums/common-enums';

@Component({
  selector: 'app-edit-goal',
  templateUrl: './edit-goal.component.html',
  styleUrls: ['./edit-goal.component.scss']
})
export class EditGoalComponent implements OnInit, OnDestroy {

  highcharts = Highcharts;
  pieChartConfig = {} as PieChartRequest;
  callingSource = 'Goal';
  editGoalForm: FormGroup;
  goalDetails: Goal;
  goalTasks: GoalTask[];
  goalTasksCopy: GoalTask[];
  goalMilestones: Milestone[];
  selectedGoalId: number;
  errorMessageFromGoalResolver: string;
  errorMessageFromGoalTaskMilestoneResolver: string;
  weight: [];
  goalRequest = new CreateGoalRequest();
  goalConfiguration: GoalConfiguration;
  submitted = false;
  goalsListChart: Goal[];

  customLabelText: string;
  enableValue: boolean;
  goalLabelName: string;
  onOffValue: boolean;

  showGoalNameLabel = false;
  showGoalNameType = false;
  showGoalNameAction = false;
  showGoalNameImpact = false;
  showGoalNameWeight = false;
  showGoalNameDueDate = false;
  showGoalNameMilestone = false;
  showGoalNameTask = false;
  showGoalNameFeedback = false;
  showGoalNameGoalLinking = false;
  showSaveAndPublishButton = false;
  goalStatuses: StatusImage[] = [];
  goalTypes: TypeImage[] = [];

  goalNameType: string;
  goalNameAction: string;
  goalNameImpact: string;
  goalNameWeight: string;
  goalNameDueDate: string;
  goalNameMilestone: string;
  goalNameTask: string;
  goalNameFeedback: string;
  goalNameGoalLinking: string;
  saveAndPublishLabel: string;
  userInfo: UserDetails;
  // Task Tab
  dialogRef4TaskSlider: any;
  updatedTaskStatus: string;
  updatedTaskStatusId: number;
  taskDetails: GoalTask;
  isTaskSliderValueChanged = false;
  taskStatuses: any;
  taskStatusChangeDirection: string;
  imagePath: string;
  isManageView = false;
  repId: number;
  IsGoalRatingActionAllowed = false;
  groupId: number;

  goalDetailsCopy: string;
  saveGoalTaskCommentRequestArr: SaveGoalTaskCommentRequest[];
  goalMilestonesCopy: Milestone[];
  initialTasksCopy: GoalTask[];
  public subscription: Subscription;
  selectedObserver: any;
  calllingSource = 'Task';
  userDetailsResult: any;
  UserPermissions = UserPermissions;
  constructor(private route: ActivatedRoute, private userService: UserService,
    private formBuilder: FormBuilder, private toast: IcftoasterService,
    private goalService: GoalsService, private router: Router,
    private datePipe: DatePipe, private dialog: MatDialog, private trackService: TrackService,
    private highchartService: HighchartService,
    private confirmationDialogService: ConfirmationDialogService,
    private localizationService: LocalizationService,
    private taskService: TaskService,
    private sharedDataService: SharedDataService,
    private _eventEmiter: EventEmiterService) {
    const user = this.userService.getUserDetails();
    if (user !== undefined && user.CoacheeDetails !== undefined && user.IsRepView) {
      this.isManageView = true;
      this.repId = user.CoacheeDetails.UserDetails.EmpId;
    } else {
      this.isManageView = false;
    }
  }

  ngOnInit() {

    this.editGoalForm = this.formBuilder.group({
      goleTitle: ['', Validators.required],
      ddlGoalType: [''],
      ddlGoalStatus: [''],
      goalAction: [''],
      goalImpact: [''],
      ddlGoalWeight: [''],
      // ddlTaskStatus: [''],
      goalDueDate: ['', Validators.required],
    });
    this.IsGoalRatingActionAllowed = this.userService.getUserDetails().UserDetails.IsGoalRatingActionAllowed;
    const resolvedGoals: GoalResponseResolved = this.route.snapshot.data['getEditGoal'];
    this.route.params.subscribe(params => { // reset and set based on new parameter this time
      this.selectedGoalId = params['GoalId'];
      this.groupId = params['groupId'];
      this.goalDetails = resolvedGoals.goalResponse.TrackResult.MyGoals.filter(t => t.GoalId === +this.selectedGoalId)[0];
      if (!this.goalDetails) {
        this.router.navigate(['/iCoachFirst/dashboard/goals']);
      }
      this.goalDetailsCopy = JSON.stringify(this.goalDetails);
      this.errorMessageFromGoalResolver = resolvedGoals.error;

      const resolvedGoalTaskMilestone: GoalTaskMilestoneResponseResolved = this.route.snapshot.data['getTaskMilestones'];
      this.goalMilestones = resolvedGoalTaskMilestone.taskMilestone.GoalMilestoneListResult.ListGoalMileStoneEntity;
      this.goalTasks = resolvedGoalTaskMilestone.taskMilestone.GoalMilestoneListResult.ListTask;

      this.goalMilestonesCopy = JSON.parse(JSON.stringify(this.goalMilestones));
      this.BindEditGoal();
      const resolvedLinkedGoals: GoalResponseResolved = this.route.snapshot.data['getLinkedGoals'];
      this.goalsListChart = JSON.parse(JSON.stringify(resolvedLinkedGoals.goalResponse));
      this.setHighchartOptions(this.goalsListChart);

      // Keeping master copy for tasks tab to get the old value of taskstatus in case of task status changed(in dropdown)
      this.goalTasksCopy = JSON.parse(JSON.stringify(this.goalTasks));
      // Keeping this copy so any changes in task should be logged in feedback section
      this.initialTasksCopy = JSON.parse(JSON.stringify(this.goalTasks));
      // this.BindEditGoal();
      this.taskStatuses = this.userService.getUserDetails().TaskStatuses;

      this.subscription = this._eventEmiter.subscribe(observerData => {
        if (observerData.keyName === 'AddObserver') {
          this.selectedObserver = observerData;
        }
      });
      this.userDetailsResult = this.userService.getUserDetails().UserDetails;
      if (this.goalDetails.Coaches.length === 0) {
        this.goalDetails.Coaches = [{
          ObserverEmpId: this.userDetailsResult.EmpId,
          ProfilePicUrl: this.userDetailsResult.ProfileImageName,
          ObserverName: this.userDetailsResult.Name,
        }];
      }
    });
  }
  /*
  setCustomSliderStyles(taskStatus: string) {
    let width = '0%';
    if (taskStatus === GoalTaskStatus.SomeProgress) {
      width = GoalTaskStatusCompletedPercentage.SomeProgress;
    } else if (taskStatus === GoalTaskStatus.InProgress) {
      width = GoalTaskStatusCompletedPercentage.InProgress;
    } else if (taskStatus === GoalTaskStatus.Complete) {
      width = GoalTaskStatusCompletedPercentage.Complete;
    }
    return {
      // CSS property names
      'width': width
    };

  }
  */

  BindEditGoal() {
    this.weight = Array.apply(null, { length: 101 }).map(Number.call, Number);

    this.goalRequest.GoalTitle = this.goalDetails.GoalTitle;
    this.goalRequest.GoalConfigType = this.goalDetails.GoalConfigType;
    this.goalRequest.Action = this.goalDetails.GoalDescription;
    this.goalRequest.Impact = this.goalDetails.Impact;
    this.goalRequest.Weight = this.goalDetails.GoalWeight;
    this.goalRequest.DueDate = this.datePipe.transform(this.goalDetails.CompletionDate, 'MM/dd/yyyy');
    this.goalRequest.GoalConfigStatus = this.goalDetails.GoalConfigStatus;
    this.goalRequest.IsPublished = this.goalDetails.IsPublished;

    this.goalConfiguration = this.userService.getUserDetails().GoalConfiguration;

    for (let i = 0; i < this.goalConfiguration.Labels.length; i++) {
      this.goalLabelName = this.goalConfiguration.Labels[i].GoalLabelName;
      this.customLabelText = this.goalConfiguration.Labels[i].CustomLabelText;
      this.enableValue = this.goalConfiguration.Labels[i].EnableValue;
      this.onOffValue = this.goalConfiguration.Labels[i].OnOffValue;

      switch (this.goalLabelName.toLowerCase()) {
        case 'title':
          this.showGoalNameLabel = this.onOffValue; // Show Goal Title.
          break;
        case 'type':
          this.showGoalNameType = this.onOffValue; // Show Goal Type.
          this.goalNameType = this.enableValue ? this.customLabelText : this.goalLabelName; // Show Custom Label Text.
          break;
        case 'action':
          this.showGoalNameAction = this.onOffValue; // Show Goal Action.
          this.goalNameAction = this.enableValue ? this.customLabelText : this.goalLabelName; // Show Custom Label Text.
          break;
        case 'impact':
          this.showGoalNameImpact = this.onOffValue; // Show Goal Impact.
          this.goalNameImpact = this.enableValue ? this.customLabelText : this.goalLabelName; // Show Custom Label Text.
          break;
        case 'weight':
          this.showGoalNameWeight = this.onOffValue; // Show Goal Weight.
          this.goalNameWeight = this.enableValue ? this.customLabelText : this.goalLabelName; // Show Custom Label Text.
          break;
        case 'due date':
          this.showGoalNameDueDate = this.onOffValue; // Show Goal Due Date.
          this.goalNameDueDate = this.enableValue ? this.customLabelText : this.goalLabelName; // Show Custom Label Text.
          break;
        case 'milestone':
          this.showGoalNameMilestone = this.onOffValue; // Show Goal Due Date.
          this.goalNameMilestone = this.enableValue ? this.customLabelText : this.goalLabelName; // Show Custom Label Text.
          break;
        case 'task':
          this.showGoalNameTask = this.onOffValue; // Show Goal Due Date.
          this.goalNameTask = this.enableValue ? this.customLabelText : this.goalLabelName; // Show Custom Label Text.
          break;
        case 'feedback':
          this.showGoalNameFeedback = this.onOffValue; // Show Goal Due Date.
          this.goalNameFeedback = this.enableValue ? this.customLabelText : this.goalLabelName; // Show Custom Label Text.
          break;
        case 'goal linking':
          this.showGoalNameGoalLinking = this.onOffValue; // Show Goal Due Date.
          this.goalNameGoalLinking = this.enableValue ? this.customLabelText : this.goalLabelName; // Show Custom Label Text.
          break;
        case 'save and publish':
          this.showSaveAndPublishButton = this.onOffValue; // Show save and publish button
          this.saveAndPublishLabel = this.enableValue ? this.customLabelText : this.goalLabelName; // Show Custom Label Text.
          break;
      }
    }

    if (this.goalConfiguration.TypeImages.length > 0) {
      this.goalTypes = [];
      for (let i = 0; i < this.goalConfiguration.TypeImages.length; i++) {
        if (this.goalConfiguration.TypeImages[i].OnOffValue) {
          this.goalTypes.push(this.goalConfiguration.TypeImages[i]);
        }
      }
    }

    if (this.goalConfiguration.StatusImages.length > 0) {
      this.goalStatuses = [];
      for (let i = 0; i < this.goalConfiguration.StatusImages.length; i++) {
        if (this.goalConfiguration.StatusImages[i].OnOffValue) {
          this.goalStatuses.push(this.goalConfiguration.StatusImages[i]);
        }
      }
    }

    if (this.goalConfiguration.ImagePreference !== 'Default') {
      if (this.goalConfiguration.ImagePreference === 'Standard') {
        this.imagePath = this.goalConfiguration.StandardImages[0]['imagePath'];
      }
    }
  }

  @HostListener('document:keyup', ['$event'])
  @HostListener('mouseup')
  hostListener() {
    if (this.isTaskSliderValueChanged) {
      this.isTaskSliderValueChanged = false;
      this.openUpdateTaskModal();
    }
  }

  onTaskSliderInputChanged(event: any, taskDetails: GoalTask) {
    this.taskDetails = taskDetails;
    this.updatedTaskStatus = event.value;
    this.updatedTaskStatusId = event.value;
    this.isTaskSliderValueChanged = true;
    // Calculate task status change direction
    if (event.value > taskDetails.TaskStatus) {
      this.taskStatusChangeDirection = 'U';
    } else {
      this.taskStatusChangeDirection = 'D';
    }

  }

  taskStatusChnaged(event: any, itemId: number, goalId: number) {
    this.taskDetails = {} as GoalTask;
    this.taskDetails.GoalId = goalId;
    this.taskDetails.ItemId = itemId;
    this.taskDetails.StatusOption = 'C';
    this.taskDetails.TaskStatus = this.goalTasksCopy.find(x => x.ItemId === itemId).TaskStatus; // Previous TaskStatus
    this.updatedTaskStatus = event.srcElement.value;
    // Calculate task status change direction
    this.updatedTaskStatusId = this.taskStatuses.find(x => x.Status === event.srcElement.value).StatusId;
    const oldTaskStatusId = this.taskStatuses.find(x => x.Status === this.taskDetails.TaskStatus).StatusId;
    if (this.updatedTaskStatusId < oldTaskStatusId) {
      this.taskStatusChangeDirection = 'U';
    } else {
      this.taskStatusChangeDirection = 'D';
    }
    this.openUpdateTaskModal();
  }

  openUpdateTaskModal() {
    if (this.dialogRef4TaskSlider) {
      this.dialogRef4TaskSlider.close();
    }
    const dialogConfig = new MatDialogConfig();
    dialogConfig.data = {
      updatedtaskstatus: this.updatedTaskStatus,
      details: this.taskDetails,
      updatedtaskstatusid: this.updatedTaskStatusId,
      statuschangedirection: this.taskStatusChangeDirection
    };
    dialogConfig.width = '600px';
    // dialogConfig.height = '200px';
    dialogConfig.disableClose = true;
    this.dialogRef4TaskSlider = this.dialog.open(UpdateTaskStatusComponent, dialogConfig);
    this.dialogRef4TaskSlider.afterClosed().subscribe(() => {
      this.updateGoalMileStoneAfterSuccess();
      // this.goalTasks = JSON.parse(JSON.stringify(this.goalTasks));
    });
  }
  createGoalTask() {

    const userDetails = this.userService.getUserDetails().UserDetails;

    const dialogConfig = new MatDialogConfig();
    // tslint:disable-next-line:max-line-length
    dialogConfig.data = { taskAssigneeEmpId: (this.isManageView ? this.repId : userDetails.EmpId), taskAssignerEmpId: userDetails.EmpId, GoalId: this.selectedGoalId, goalNameTask: this.goalNameTask };
    dialogConfig.width = '600px';
    dialogConfig.disableClose = true;
    const dialogRef = this.dialog.open(AssignTaskComponent, dialogConfig);
    // dialogRef.close();
    dialogRef.afterClosed().subscribe(value => {
      this.updateGoalMileStoneAfterSuccess();
      if (value.Type === 'success') {
        // this.reloadGoalTasksData();
      }
    });
  }

  createGoalMileStone() {

    const userDetails = this.userService.getUserDetails().UserDetails;

    const dialogConfig = new MatDialogConfig();
    // tslint:disable-next-line:max-line-length
    dialogConfig.data = { empId: (this.isManageView ? this.repId : userDetails.EmpId), goalId: this.selectedGoalId, goalNameMilestone: this.goalNameMilestone };
    dialogConfig.width = '600px';
    dialogConfig.disableClose = true;
    const dialogRef = this.dialog.open(CreateMilestoneComponent, dialogConfig);

    dialogRef.afterClosed().subscribe(value => {

      if (value === 'success') {
        this.updateGoalMileStoneAfterSuccess();
      }
    });
  }

  updateGoalMileStone(m: Milestone) {
    const userDetails = this.userService.getUserDetails().UserDetails;

    const dialogConfig = new MatDialogConfig();
    // tslint:disable-next-line:max-line-length
    dialogConfig.data = { empId: (this.isManageView ? this.repId : userDetails.EmpId), milestoneDetails: m, goalId: this.selectedGoalId, goalNameMilestone: this.goalNameMilestone };
    dialogConfig.width = '600px';
    dialogConfig.disableClose = true;
    const dialogRef = this.dialog.open(CreateMilestoneComponent, dialogConfig);

    dialogRef.afterClosed().subscribe(value => {

      if (value === 'success') {
        this.updateGoalMileStoneAfterSuccess();
      }
    });
  }

  updateGoalMileStoneAfterSuccess() {
    this.userInfo = this.userService.getUserDetails().UserDetails;
    const goalRequest = new GoalRequest();
    goalRequest.EmpId = this.isManageView ? this.repId : this.userInfo.EmpId;
    goalRequest.Type = 'Goal';

    // Adding below StatusFilter in request to load all the Goals (i.e. Completed as well)
    const status = this.userService.getUserDetails().GoalConfiguration.StatusImages;
    const statusFilter = [];
    status.forEach(objStatus => {
      if (objStatus.OnOffValue) {
        statusFilter.push(objStatus.statusTitle);
      }
    });
    goalRequest.Statusfilter = statusFilter.join(',');

    this.trackService.getGoals(goalRequest).subscribe(
      goals => {
        this.goalDetails = goals.TrackResult.MyGoals.filter(t => t.GoalId === +this.selectedGoalId)[0];

        const request = new MilestoneRequest();
        request.EmpId = this.isManageView ? this.repId : this.userInfo.EmpId;
        request.GoalId = this.selectedGoalId;

        this.trackService.getMilestones(request).subscribe(
          taskMilestoneresponse => {
            this.goalMilestones = taskMilestoneresponse.GoalMilestoneListResult.ListGoalMileStoneEntity;
            this.goalTasks = taskMilestoneresponse.GoalMilestoneListResult.ListTask;
            // Keeping master copy for tasks tab to get the old value of taskstatus in case of task status changed(in dropdown)
            this.goalTasksCopy = JSON.parse(JSON.stringify(this.goalTasks));
          },
          errors => this.errorMessageFromGoalResolver = <any>errors
        );

        this.trackService.getLinkedGoals(request).subscribe(
          linkedGoalresponse => {
            this.goalsListChart = JSON.parse(JSON.stringify(linkedGoalresponse));
            this.setHighchartOptions(this.goalsListChart);
          },
          errors => this.errorMessageFromGoalResolver = <any>errors
        );

        this.BindEditGoal();
      },
      errors => this.errorMessageFromGoalResolver = <any>errors
    );
  }

  createGoalLinking() {
    const userDetails = this.userService.getUserDetails().UserDetails;

    const dialogConfig = new MatDialogConfig();
    // tslint:disable-next-line:max-line-length
    dialogConfig.data = { empId: (this.isManageView ? this.repId : userDetails.EmpId), goalId: +this.selectedGoalId, goalNameGoalLinking: this.goalNameGoalLinking };
    dialogConfig.width = '600px';
    dialogConfig.disableClose = true;
    const dialogRef = this.dialog.open(CreateGoalLinkingComponent, dialogConfig);
    dialogRef.afterClosed().subscribe(value => {
      if (value === 'success') {
        this.updateGoalMileStoneAfterSuccess();
      }
    });
  }

  // convenience getter for easy access to form fields
  get f() {
    return this.editGoalForm.controls;
  }

  onSubmit(isSaveAndPublish: boolean) {
    this.submitted = true;
    if (this.editGoalForm.invalid) {
      return;
    }
    // Prepare Goal Edit related changes comments
    const initialDetails: Goal = JSON.parse(this.goalDetailsCopy);
    initialDetails.CompletionDate = this.datePipe.transform(initialDetails.CompletionDate, 'MM/dd/yyyy');
    this.saveGoalTaskCommentRequestArr = [];

    // Check for change in Goal title
    if (initialDetails.GoalTitle !== this.goalRequest.GoalTitle) {
      const reqObj = this.getCommonObject();
      const fromVal =
        !initialDetails.GoalTitle ? `Goal Title Changed` : this.goalRequest.GoalTitle ?
          `Goal Title Changed from ${initialDetails.GoalTitle}` : 'Goal Title Removed';

      reqObj.Comment = `TFIGoalStatusChange~${fromVal}~${this.goalRequest.GoalTitle}~T~0`;

      this.saveGoalTaskCommentRequestArr.push(reqObj);
    }

    // Check for change in Goal decription
    if (initialDetails.GoalDescription !== this.goalRequest.Action) {
      const reqObj = this.getCommonObject();
      const fromVal =
        !initialDetails.GoalDescription ? `Goal Description Changed` : this.goalRequest.Action ?
          `Goal Description Changed from ${initialDetails.GoalDescription}` : 'Goal Description Removed';

      reqObj.Comment = `TFIGoalStatusChange~${fromVal}~${this.goalRequest.Action}~T~0`;
      this.saveGoalTaskCommentRequestArr.push(reqObj);
    }

    // Check for change in Goal Impact
    if (initialDetails.Impact !== this.goalRequest.Impact) {
      const reqObj = this.getCommonObject();
      const fromVal =
        !initialDetails.Impact ? `Goal Impact Changed` : this.goalRequest.Impact ?
          `Goal Impact Changed from ${initialDetails.Impact}` : 'Goal Impact Removed';

      reqObj.Comment = `TFIGoalStatusChange~${fromVal}~${this.goalRequest.Impact}~T~0`;
      this.saveGoalTaskCommentRequestArr.push(reqObj);
    }

    // Check for change in Due Date
    if (new Date(initialDetails.CompletionDate).getTime() !== new Date(this.goalRequest.DueDate).getTime()) {
      const reqObj = this.getCommonObject();
      const fromVal = `Date Changed from ${initialDetails.CompletionDate}`;
      reqObj.Comment = `TFIGoalStatusChange~${fromVal}~${this.goalRequest.DueDate}~T~0`;
      this.saveGoalTaskCommentRequestArr.push(reqObj);
    }

    // Check for change in status change
    if (this.goalRequest.GoalConfigStatus !== initialDetails.GoalConfigStatus) {
      const reqObj = this.getCommonObject();
      const fromVal = `Status Changed from ${initialDetails.GoalConfigStatus}`;
      reqObj.Comment = `TFIGoalStatusChange~${fromVal}~${this.goalRequest.GoalConfigStatus}~T~0`;
      this.saveGoalTaskCommentRequestArr.push(reqObj);
    }

    // Check for change in Goal Config Type change
    if (this.goalRequest.GoalConfigType !== initialDetails.GoalConfigType) {
      const reqObj = this.getCommonObject();
      const fromVal = `Type Changed from ${initialDetails.GoalConfigType}`;
      reqObj.Comment = `TFIGoalStatusChange~${fromVal}~${this.goalRequest.GoalConfigType}~T~0`;
      this.saveGoalTaskCommentRequestArr.push(reqObj);
    }

    // Check for change in Weight change
    if (this.goalRequest.Weight !== initialDetails.GoalWeight) {
      const reqObj = this.getCommonObject();
      const fromVal = `Weight Changed from ${initialDetails.GoalWeight}`;
      reqObj.Comment = `TFIGoalStatusChange~${fromVal}~${this.goalRequest.Weight}~T~0`;
      this.saveGoalTaskCommentRequestArr.push(reqObj);
    }

    // check for any change in Goal Milestones List
    this.getUpdatedMilestones();
    // Check for any change in Gaol Tasks
    this.getUpdatedTasks();
    if (this.saveGoalTaskCommentRequestArr.length > 0) {
      this.saveGoalTaskComment(isSaveAndPublish);
    } else {
      this.updateGoal(isSaveAndPublish);
    }
  }

  getUpdatedMilestones() {
    if (this.goalMilestones.length > 0 || this.goalMilestonesCopy.length > 0) {
      const updatedIds = this.goalMilestones.map(function (x) { return x['MileStoneId']; });
      const actualIds = this.goalMilestonesCopy.map(function (x) { return x['MileStoneId']; });

      let addList = [];
      addList = updatedIds.filter(function (obj) { return actualIds.indexOf(obj) === -1; });
      let deleteList = [];
      deleteList = actualIds.filter(function (obj) { return updatedIds.indexOf(obj) === -1; });

      if (addList.length > 0) {
        // New Milestones have been added
        addList.forEach(ele => {
          const milestone = this.goalMilestones.find(x => x.MileStoneId === ele);
          const reqObj = this.getCommonObject();
          const fromVal = `New Milestone ${milestone.Title} added.`;
          reqObj.Comment = `TFIGoalStatusChange~${fromVal}~~T~0`;
          this.saveGoalTaskCommentRequestArr.push(reqObj);
        });

      }

      if (deleteList.length > 0) {
        // Milestones have been deleted
        deleteList.forEach(ele => {
          const milestone = this.goalMilestonesCopy.find(x => x.MileStoneId === ele);
          const reqObj = this.getCommonObject();
          const fromVal = `Milestone ${milestone.Title} deleted.`;
          reqObj.Comment = `TFIGoalStatusChange~${fromVal}~~T~0`;
          this.saveGoalTaskCommentRequestArr.push(reqObj);
        });
      }
    }
  }

  getUpdatedTasks() {
    if (this.goalTasks.length > 0 || this.initialTasksCopy.length > 0) {
      const updatedIds = this.goalTasks.map(function (x) { return x['ItemId']; });
      const actualIds = this.initialTasksCopy.map(function (x) { return x['ItemId']; });

      let addList = [];
      addList = updatedIds.filter(function (obj) { return actualIds.indexOf(obj) === -1; });
      let deleteList = [];
      deleteList = actualIds.filter(function (obj) { return updatedIds.indexOf(obj) === -1; });

      if (addList.length > 0) {
        // New Tasks have been added
        addList.forEach(ele => {
          const task = this.goalTasks.find(x => x.ItemId === ele);
          const reqObj = this.getCommonObject();
          const fromVal = `New Task ${task.ItemName} added.`;
          reqObj.Comment = `TFIGoalStatusChange~${fromVal}~~T~0`;
          this.saveGoalTaskCommentRequestArr.push(reqObj);
        });
      }

      if (deleteList.length > 0) {
        // Tasks have been deleted
        deleteList.forEach(ele => {
          const task = this.initialTasksCopy.find(x => x.ItemId === ele);
          const reqObj = this.getCommonObject();
          const fromVal = `Task ${task.ItemName} deleted.`;
          reqObj.Comment = `TFIGoalStatusChange~${fromVal}~~T~0`;
          this.saveGoalTaskCommentRequestArr.push(reqObj);
        });
      }
    }
  }

  saveGoalTaskComment(isSaveAndPublish: boolean) {
    const saveTaskCommentReq = {
      Comments: this.saveGoalTaskCommentRequestArr,
      EmpId: this.userService.getUserDetails().UserDetails.EmpId,
      UserId: '',
      MemberOrgId: this.userService.getUserDetails().UserDetails.MemberOrgID,
      LoginCulture: this.localizationService.getCutureCode()
    };

    this.taskService.SaveArrayOfGoalTaskComments(saveTaskCommentReq).subscribe(response => {
      if (response.ResultStatusCode === 'success') {
        this.updateGoal(isSaveAndPublish);
      }
    });
  }
  generateObserverXML() {
    let XML = '&lt;ROOT&gt;';
    for (const observer of this.goalDetails.Coaches) {
      XML =
        XML +
        '&lt;Collection EmpId=\'' +
        observer.ObserverEmpId +
        '\' &gt;&lt;/Collection&gt;';
    }
    XML = XML + '&lt;/ROOT&gt;';
    return XML;
  }
  updateGoal(isSaveAndPublish: boolean) {
    // TO DO Service Call

    this.goalRequest.GoalId = this.selectedGoalId;
    this.goalRequest.GoalType = this.goalDetails.GoalType;
    if (isSaveAndPublish) {
      this.goalRequest.IsPublished = true;
    }

    this.goalRequest.CreatedBy = this.userService.getUserDetails().UserDetails.EmpId;
    this.goalRequest.RepId = this.isManageView ? this.repId : this.userService.getUserDetails().UserDetails.EmpId; // this.RepId;
    this.goalRequest.XMLObserverIds = this.generateObserverXML();
    this.goalService.updateGoal(this.goalRequest).subscribe(response => {

      const updateGoalResult = response.SaveNewGoalResult;
      if (updateGoalResult.ResultStatusCode === '1040') {
        // this._eventEmiter.emit({ actionType: 'ReloadGoal' });

        this.toast.success('GoalStats_GoalSavedMessage', '', () => { });
        if (this.isManageView) {
          this.router.navigate(['/iCoachFirst/manage/manage/' + this.repId + '/goals']);
        } else {
          this.router.navigate(['/iCoachFirst/dashboard/goals']);
        }
        // this.cancelClick();

      } else {

        const errorMessage = updateGoalResult.ErrorMessage;
        this.toast.error(errorMessage);
      }
    });
  }

  getCommonObject(): any {
    return {
      CommentedBy: this.userService.getUserDetails().UserDetails.EmpId,
      GoalId: this.selectedGoalId,
      TaskId: 0,
      Category: 'Goal',
      Comment: ''
    };
  }

  DeleteGoalLinking(goalDetails: Goal) {
    const request = new DeleteGoalLinkingRequest();
    request.ParentGoalId = +this.selectedGoalId;
    request.ChildGoalId = goalDetails.GoalId;
    this.confirmationDialogService.confirm('Common_Confirm_Delete',
      'Common_Yes', 'Common_No').subscribe(value => {
        if (value) {
          this.trackService.deleteGoalToGoalLinking(request).subscribe(response => {
            if (response) {
              this.toast.prepareParameterizedMessage('success', ['Common_DeleteSuccessPlaceholder', 'Common_GoalLinking']);
              this.updateGoalMileStoneAfterSuccess();
            }
          });
        }
      });

  }

  cancelClick() {
    // if (this.isManageView) {
    //   this.router.navigate(['/iCoachFirst/manage/manage/' + this.repId + '/goals']);
    // } else {
    //   this.router.navigate(['/iCoachFirst/dashboard/goals']);
    // }

    history.back();

  }

  deleteClick() {
    this.confirmationDialogService.confirm('Common_Confirm_Delete',
      'Common_Yes',
      'Common_No').subscribe(value => {

        if (value) {
          this.deleteGoal();
        }
      });
  }

  deleteGoal() {

    this.goalService.deleteGoal(this.selectedGoalId).subscribe(response => {
      if (response) {
        this.toast.prepareParameterizedMessage('success', ['Common_DeleteSuccessPlaceholder', 'Common_Goal'], '', () => {
          const appModuleId = this.sharedDataService.getSelectedAppModuleId();
          if (appModuleId === ApplicationModuleListEnum.Connect) {
            this._eventEmiter.emit({ KeyName: 'loadNotifications' });
          }
          history.back();
        });
      }
    });
  }

  setHighchartOptions(goal: Goal[]) {
    if (goal && goal.length > 0) {
      goal.forEach(item => {

        let percentageRemaining = 0;
        let percentageCompleted = 0;
        let colorCode = '';

        if (item.GoalPercentageComplete) {
          percentageCompleted = Math.round(+item.GoalPercentageComplete);
          percentageRemaining = 100 - percentageCompleted;

          if (percentageCompleted <= GoalCompletedColorRange.Low) {
            colorCode = GoalCompletedColorCode.Low;
          } else if (percentageCompleted <= GoalCompletedColorRange.Medium) {
            colorCode = GoalCompletedColorCode.Medium;
          } else if (percentageCompleted > GoalCompletedColorRange.Medium) {
            colorCode = GoalCompletedColorCode.High;
          }
        }
        // Pie chart option setting
        this.pieChartConfig.ChartType = ChartType.Pie;
        this.pieChartConfig.ChartSize = '75';
        this.pieChartConfig.ChartTitle = '<style="font-family:arial; font-size:16px;">' + percentageCompleted + '%</style>';
        this.pieChartConfig.TitleYAxis = 7;
        this.pieChartConfig.TooltipFormatterCallbackFun = this.tooltipFormatter;
        this.pieChartConfig.SeriesName = 'Goal';
        this.pieChartConfig.SeriesInnerSize = '70%';
        this.pieChartConfig.DataLabelsDistance = -40;
        this.pieChartConfig.SeriesData = [];

        // Completed Goal Data
        const serDataCompletedPercentage = {} as SeriesData;
        serDataCompletedPercentage.Name = percentageCompleted;
        serDataCompletedPercentage.YAxis = percentageCompleted;
        serDataCompletedPercentage.EnableDataLabel = false;
        serDataCompletedPercentage.Color = colorCode;
        this.pieChartConfig.SeriesData.push(serDataCompletedPercentage);

        // Remaining Goal Data
        const serDataRemainingPercentage = {} as SeriesData;
        serDataRemainingPercentage.Name = percentageRemaining;
        serDataRemainingPercentage.YAxis = percentageRemaining;
        serDataRemainingPercentage.EnableDataLabel = false;
        serDataRemainingPercentage.Color = GoalCompletedColorCode.None,
          this.pieChartConfig.SeriesData.push(serDataRemainingPercentage);

        item.HighchartOptions = this.highchartService.CreateHighChart(this.pieChartConfig);
        item.ShowDefaultImage = this.showDefaultImage(item);
      });
    }
  }

  tooltipFormatter(_seriesType: any, _seriesName: any, _yAxis: number, _color: string) {
    if (_color === GoalCompletedColorCode.None) {
      return 'Remaining:' + _yAxis + '%';
    } else {
      return 'Completed:' + _yAxis + '%';
    }


  }
  private showDefaultImage(goalItem: Goal): boolean {
    let imageName = '';
    if (this.goalConfiguration.ImagePreference === 'GoalType' && this.goalConfiguration.TypeImages && goalItem.GoalConfigType) {
      const obj = this.goalConfiguration.TypeImages.filter(data => data.typeTitle === goalItem.GoalConfigType)[0];
      imageName = obj ? obj['imagePath'] : null;
    } else if (this.goalConfiguration.ImagePreference === 'GoalStatus' && this.goalConfiguration.StatusImages
      && goalItem.GoalConfigStatus) {
      const obj = this.goalConfiguration.StatusImages.filter(data => data.statusTitle === goalItem.GoalConfigStatus)[0];
      imageName = obj ? obj['imagePath'] : null;
    } else if (this.goalConfiguration.ImagePreference === 'Standard') {
      imageName = this.imagePath;
    }
    if (imageName && imageName.length > 0) {
      return false;
    } else {
      return true;
    }
  }
  onClickAddButton() {
    if (this.selectedObserver !== undefined) {

      if (this.observerExist()) {
        this.toast.error('GoalStats_Error_EmployeeAlreadAdded', '');
        return;
      }
      this.goalDetails.Coaches.push({
        ObserverEmpId: this.selectedObserver.observerData.EmpID,
        ProfilePicUrl: this.selectedObserver.observerData.ProfileImageName,
        ObserverName: this.selectedObserver.observerData.FirstName + ' ' + this.selectedObserver.observerData.LastName,
      }
      );
      this.selectedObserver = null;
      this._eventEmiter.emit({ keyName: 'resetAutoComplete' });
    }
  }
  observerExist() {
    const filterData = this.goalDetails.Coaches.filter(
      observer => observer.ObserverEmpId === this.selectedObserver.observerData.EmpID);
    if (filterData.length > 0) {
      return true;
    }
    return false;
  }
  removeObserver(observerObj) {
    this.goalDetails.Coaches = this.goalDetails.Coaches.filter(
      observer => observer.ObserverEmpId !== observerObj.ObserverEmpId);
  }
  ngOnDestroy() {
    this._eventEmiter.unsubscribe(this.subscription);
  }
}
