import { Component, OnInit, OnChanges, SimpleChanges } from '@angular/core';
import { TrackService } from '../../services/track.service';
import { GoalRequest } from 'src/app/models/requests/goal-request';
import { Goal } from 'src/app/models/response/goal/goal-response';
import { UserDetails, GoalConfiguration, StatusImage, TypeImage } from 'src/app/models/user-details-result';
import { UserService } from 'src/app/services/user.service';
import { ActivatedRoute } from '@angular/router';
import { GoalResponseResolved } from 'src/app/models/response/goal/goal-response';
import { CreateGoalRequest } from 'src/app/models/requests/create-goal-request';
import { GoalsService } from 'src/app/services/goals.service';
import { IcftoasterService } from 'src/app/services/icftoaster.service';
import { DatePipe } from '@angular/common';
import { MatDialogConfig, MatDialog } from '@angular/material';
import { CreateGoalComponent } from './create-goal/create-goal.component';
import * as Highcharts from 'highcharts';
import { GoalCompletedColorRange, GoalCompletedColorCode, ChartType } from '../../helpers/enums/common-enums';
import { PieChartRequest, SeriesData } from '../..//models/requests/highchart-request';
import { HighchartService } from '../../services/highchart.service';
import { UserPermissions } from 'src/app/helpers/enums/common-enums';
import { TaskFeedbackComponent } from '../tasks/task-feedback/task-feedback.component';
// import { CreateGoalLinkingComponent } from './create-goal-linking/create-goal-linking.component';
import { ConnectapiService } from 'src/app/services/connectapi.service';
import { LinkedGoalDetailsComponent } from './linked-goal-details/linked-goal-details.component';
import { TaskService } from 'src/app/services/task.service';
import { SaveFeedbackCommentComponent } from './save-feedback-comment/save-feedback-comment.component';
//import { Coach } from 'src/app/models/response/goal/coach-response';
// import { EventEmiterService } from 'src/app/services/event.emmiter.service';
// import { Subscription } from 'rxjs';

@Component({
  selector: 'app-goals',
  templateUrl: './goals.component.html',
  styleUrls: ['./goals.component.scss']
})
export class GoalsComponent implements OnInit, OnChanges {
  highcharts = Highcharts;
  pieChartConfig = {} as PieChartRequest;
  goalType = 'I';
  selectedRepId = 0;
  userInfo: UserDetails;
  goalConfiguration: GoalConfiguration;
  // @Input() goalsListContainer: Goal[];

  goalRequest = new CreateGoalRequest();
  goalsListChart: Goal[];
  CoachesList = [{
    ObserverEmpId: '',
    ProfilePicUrl: '',
    ObserverName: '',
  }];
  weight: [];
  public chart: any;
  imagePath: string;
  errorMesaage: string;

  customLabelText: string;
  enableValue: boolean;
  goalLabelName: string;
  onOffValue: boolean;

  showGoalNameLabel = false;
  showGoalNameType = false;
  showGoalNameAction = false;
  showGoalNameImpact = false;
  showGoalNameWeight = false;
  showGoalNameDueDate = false;
  showGoalNameFeedback = false;

  goalNameType: string;
  goalNameAction: string;
  goalNameImpact: string;
  goalNameWeight: string;
  goalNameDueDate: string;
  goalNameFeedback: string;

  searchPanelVisible = false;
  goalStatuses: StatusImage[] = [];
  goalTypes: TypeImage[] = [];
  searchString: string;
  isSearchApply = false;
  filteredData: Goal[];
  isManageView = false;
  repId: number;
  goalCoaches: any;
  IsGoalRatingActionAllowed = false;
  slideOptions = {
    items: 4, dots: false, nav: true, responsive: {
      0: {
        items: 1
      },
      600: {
        items: 2
      },
      1000: {
        items: 3
      },
      1300: {
        items: 4
      }
    }
  };

  UserPermissions = UserPermissions;
  showGoalLinking = false;
  goalLinkingLabel: string;
  groupId = 0;
  dialogRef4TaskSlider: any;

  // private subscription: Subscription;

  constructor(private trackService: TrackService,
    private userService: UserService,
    private route: ActivatedRoute, private goalService: GoalsService,
    private toast: IcftoasterService, private datePipe: DatePipe,
    private dialog: MatDialog,
    private highchartService: HighchartService,
    private connectAPIService: ConnectapiService,
    private taskService: TaskService
  ) {
    const user = this.userService.getUserDetails();
    if (user !== undefined && user.CoacheeDetails !== undefined && user.IsRepView) {
      this.isManageView = true;
      this.repId = user.CoacheeDetails.UserDetails.EmpId;
    } else {
      this.isManageView = false;
    }
  }

  ngOnInit() {
    this.IsGoalRatingActionAllowed = this.userService.getUserDetails().UserDetails.IsGoalRatingActionAllowed;
    this.route.params.subscribe(params => {
      if (params) {

        if (params.groupId && params.groupId !== undefined) {
          this.groupId = params.groupId;
          // this.subscribeEvents();
        }
        const resolvedGoals: GoalResponseResolved = this.route.snapshot.data['getGoals'];
        if (resolvedGoals.goalResponse) {
          this.goalsListChart = resolvedGoals.goalResponse.TrackResult.MyGoals;
          this.filteredData = this.goalsListChart;
          this.filteredData.forEach(goal => {
            if (goal) {
              goal.GoalDescription = goal.GoalDescription === null ? '' : goal.GoalDescription.replace(/\n/ig, '<br />');
              goal.Impact = goal.Impact === null ? '' : goal.Impact.replace(/\n/ig, '<br />');
            }
          });
          this.loadGoalConfigData();
          this.setHighchartOptions(this.filteredData);
          this.errorMesaage = resolvedGoals.error;
        }
      }
    });
  }
  ngOnChanges(changes: SimpleChanges) {
    if (changes !== undefined) {
      this.filteredData = this.goalsListChart;
      this.loadGoalConfigData();
      this.setHighchartOptions(this.filteredData);
      // this.loadGoalData();
    }
  }

  // subscribeEvents() {

  //   this.subscription = this._eventEmiter.subscribe(eventData => {

  //     if (eventData.actionType === 'newgroupselected') {
  //       this.loadTeamGoals();
  //     }
  //   });
  // }

  private loadGoalConfigData() {
    this.weight = Array.apply(null, { length: 101 }).map(Number.call, Number);
    const user = this.userService.getUserDetails();
    // tslint:disable-next-line:max-line-length
    this.goalConfiguration = this.isManageView ? user.CoacheeDetails.GoalConfiguration : this.userService.getUserDetails().GoalConfiguration;

    for (let i = 0; i < this.goalConfiguration.Labels.length; i++) {
      this.goalLabelName = this.goalConfiguration.Labels[i].GoalLabelName;
      this.customLabelText = this.goalConfiguration.Labels[i].CustomLabelText;
      this.enableValue = this.goalConfiguration.Labels[i].EnableValue;
      this.onOffValue = this.goalConfiguration.Labels[i].OnOffValue;

      switch (this.goalLabelName.toLowerCase()) {
        case 'title':
          this.showGoalNameLabel = this.onOffValue; // Show Goal Title.
          break;
        case 'type':
          this.showGoalNameType = this.onOffValue; // Show Goal Type.
          this.goalNameType = this.enableValue ? this.customLabelText : this.goalLabelName; // Show Custom Label Text.
          break;
        case 'action':
          this.showGoalNameAction = this.onOffValue; // Show Goal Action.
          this.goalNameAction = this.enableValue ? this.customLabelText : this.goalLabelName; // Show Custom Label Text.
          break;
        case 'impact':
          this.showGoalNameImpact = this.onOffValue; // Show Goal Impact.
          this.goalNameImpact = this.enableValue ? this.customLabelText : this.goalLabelName; // Show Custom Label Text.
          break;
        case 'weight':
          this.showGoalNameWeight = this.onOffValue; // Show Goal Weight.
          this.goalNameWeight = this.enableValue ? this.customLabelText : this.goalLabelName; // Show Custom Label Text.
          break;
        case 'due date':
          this.showGoalNameDueDate = this.onOffValue; // Show Goal Due Date.
          this.goalNameDueDate = this.enableValue ? this.customLabelText : this.goalLabelName; // Show Custom Label Text.
          break;
        case 'feedback':
          this.showGoalNameFeedback = this.onOffValue; // Show Goal Due Date.
          this.goalNameFeedback = this.enableValue ? this.customLabelText : this.goalLabelName; // Show Custom Label Text.
          break;
        case 'goal linking':
          this.showGoalLinking = this.onOffValue; // Show Goal linking.
          this.goalLinkingLabel = this.enableValue ? this.customLabelText : this.goalLabelName; // Show Custom Label Text.
          break;
      }
    }

    if (this.goalConfiguration.TypeImages.length > 0) {
      this.goalTypes = [];
      for (let i = 0; i < this.goalConfiguration.TypeImages.length; i++) {
        if (this.goalConfiguration.TypeImages[i].OnOffValue) {
          this.goalTypes.push(this.goalConfiguration.TypeImages[i]);
        }
      }
    }

    if (this.goalConfiguration.StatusImages.length > 0) {
      this.goalStatuses = [];
      for (let i = 0; i < this.goalConfiguration.StatusImages.length; i++) {
        if (this.goalConfiguration.StatusImages[i].OnOffValue) {
          this.goalStatuses.push(this.goalConfiguration.StatusImages[i]);
        }
      }
    }

    if (this.goalConfiguration.ImagePreference !== 'Default') {
      // if (this.goalConfiguration.ImagePreference === 'Goal Type') {
      //   for (let i = 0; i < this.goalConfiguration.TypeImages.length; i++) {
      //     if()
      //   }
      // } else if (this.goalConfiguration.ImagePreference === 'Goal Status') {
      //   for (let i = 0; i < this.goalConfiguration.StatusImages.length; i++) {
      //   }
      // } else
      if (this.goalConfiguration.ImagePreference === 'Standard') {
        this.imagePath = this.goalConfiguration.StandardImages[0]['imagePath'];
      }
    }
    // for (let i = 0; i < this.goalsListChart.length; i++) {
    // tslint:disable-next-line:max-line-length
    //   this.initChart(this.buildGauge(), +this.goalsListChart[i].GoalId, +this.goalsListChart[i].GoalPercentageComplete, this.goalsListChart[i].GoalTitle);
    // }
  }

  openCreateGoalPopUp() {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.data = {
      selectedRepId: (this.groupId === 0 || this.groupId === undefined) ? this.selectedRepId : 0,
      goalType: this.goalType,
      groupId: this.groupId
    };
    dialogConfig.width = '600px';
    dialogConfig.disableClose = true;
    const dialogRef = this.dialog.open(CreateGoalComponent, dialogConfig);

    dialogRef.afterClosed().subscribe(value => {

      if (value === 'success') {

        if (this.groupId === 0 || this.groupId === undefined) {
          this.userInfo = this.userService.getUserDetails().UserDetails;
          const request = new GoalRequest();
          request.EmpId = this.isManageView ? this.repId : this.userInfo.EmpId;
          request.Type = 'Goal';

          // Adding below StatusFilter in request to load all the Goals (i.e. Completed as well)
          const status = this.userService.getUserDetails().GoalConfiguration.StatusImages;
          const statusFilter = [];
          status.forEach(objStatus => {
            if (objStatus.OnOffValue) {
              statusFilter.push(objStatus.statusTitle);
            }
          });
          request.Statusfilter = statusFilter.join(',');
          this.trackService.getGoals(request).subscribe(
            goals => {
              this.goalsListChart = goals.TrackResult.MyGoals;
              this.filteredData = this.goalsListChart;
              this.setHighchartOptions(this.filteredData);
              this.loadGoalConfigData();
            },
            errors => this.errorMesaage = <any>errors
          );
        } else {
          this.loadTeamGoals();
        }
      }
    });
  }

  private loadTeamGoals() {
    this.connectAPIService.getConnectGroupGoals(this.groupId).subscribe(
      goals => {
        this.goalsListChart = goals.TrackResult.MyGoals;
        this.filteredData = this.goalsListChart;
        this.setHighchartOptions(this.filteredData);
        this.loadGoalConfigData();
      },
      errors => this.errorMesaage = <any>errors
    );
  }

  statusUpdate(statusObject: any, goalInfo: Goal) {
    const reqObj = {
      fromVal: goalInfo.GoalConfigStatus,
      toVal: statusObject.statusTitle,
      direction: 'T',
      goalId: goalInfo.GoalId,
      taskId: '0',
      callback: this.changeCallBack,
      changedParam: 'status',
      category: 'Goal',
      details: goalInfo
    };
    this.openUpdateTaskModal(reqObj);

    this.goalRequest.GoalConfigStatus = statusObject.statusTitle;
    goalInfo.GoalConfigStatus = statusObject.statusTitle;

    this.goalRequest.GoalConfigType = goalInfo.GoalConfigType;
    this.goalRequest.DueDate = goalInfo.CompletionDate;
    this.goalRequest.Weight = goalInfo.GoalWeight;
    // Changing ShowDefaultImage to render the proper image
    if (this.goalConfiguration.ImagePreference === 'GoalStatus' && !goalInfo.GoalImageName) {
      goalInfo.ShowDefaultImage = false;
    }
  }

  weightUpdate(weight: any, goalInfo: Goal) {
    const reqObj = {
      fromVal: goalInfo.GoalWeight,
      toVal: weight,
      direction: `T`,
      goalId: goalInfo.GoalId,
      taskId: '0',
      callback: this.changeCallBack,
      changedParam: 'weight',
      category: 'Goal',
      details: goalInfo
    };
    this.openUpdateTaskModal(reqObj);
    this.goalRequest.Weight = weight;
    goalInfo.GoalWeight = weight;

    this.goalRequest.GoalConfigType = goalInfo.GoalConfigType;
    this.goalRequest.DueDate = goalInfo.CompletionDate;
    this.goalRequest.GoalConfigStatus = goalInfo.GoalConfigStatus;
  }

  typeUpdate(typeObject: any, goalInfo: Goal) {
    const reqObj = {
      fromVal: goalInfo.GoalConfigType,
      toVal: typeObject.typeTitle,
      direction: 'T',
      goalId: goalInfo.GoalId,
      taskId: '0',
      callback: this.changeCallBack,
      changedParam: 'type',
      category: 'Goal',
      details: goalInfo
    };
    this.openUpdateTaskModal(reqObj);
    this.goalRequest.GoalConfigType = typeObject.typeTitle;
    goalInfo.GoalConfigType = typeObject.typeTitle;

    this.goalRequest.GoalConfigStatus = goalInfo.GoalConfigStatus;
    this.goalRequest.DueDate = goalInfo.CompletionDate;
    this.goalRequest.Weight = goalInfo.GoalWeight;

    // Changing ShowDefaultImage to render the proper image
    if (this.goalConfiguration.ImagePreference === 'GoalType' && !goalInfo.GoalImageName) {
      goalInfo.ShowDefaultImage = false;
    }
  }

  dateUpdate(datePicker: any, goalInfo: Goal) {
    if (datePicker.isOpen) {
      const reqObj = {
        fromVal: this.datePipe.transform(goalInfo.CompletionDate, 'MM/dd/yyyy'),
        toVal: datePicker._bsValue,
        direction: 'T',
        goalId: goalInfo.GoalId,
        taskId: '0',
        callback: this.changeCallBack,
        changedParam: 'date',
        category: 'Goal',
        details: goalInfo
      };
      this.openUpdateTaskModal(reqObj);
      this.goalRequest.DueDate = datePicker._bsValue;
      goalInfo.CompletionDate = datePicker._bsValue;

      this.goalRequest.GoalConfigType = goalInfo.GoalConfigType;
      this.goalRequest.GoalConfigStatus = goalInfo.GoalConfigStatus;
      this.goalRequest.Weight = goalInfo.GoalWeight;
    }
  }

  changedDate(dueDate: any, goalInfo: Goal) {
    if (dueDate.isOpen) {
      setTimeout(() => {
        this.dateUpdate(dueDate, goalInfo);
      }, 300);
    }
  }

  changeCallBack(prevVal: any, changedParam: string, result: string, goalInfo: Goal) {
    if (result === 'Cancel') {
      this.goalRequest = new CreateGoalRequest();
      switch (changedParam) {
        case 'date':
          goalInfo.CompletionDate = prevVal;
          break;
        case 'status':
          goalInfo.GoalConfigStatus = prevVal;
          // Changing ShowDefaultImage to render the proper image
          if (this.goalConfiguration.ImagePreference === 'GoalStatus' && !goalInfo.GoalImageName) {
            goalInfo.ShowDefaultImage = true;
          }
          break;
        case 'weight':
          goalInfo.GoalWeight = prevVal;
          break;
        case 'type':
          goalInfo.GoalConfigType = prevVal;
          if (this.goalConfiguration.ImagePreference === 'GoalType' && !goalInfo.GoalImageName) {
            goalInfo.ShowDefaultImage = true;
          }
          break;
      }
    } else if (result === 'Success') {
      this.UpdateGoal(goalInfo);
    } else if (result === 'Failure') {
      this.toast.error('OperationFailedMessage');
    }

  }

  openUpdateTaskModal(statusObject: any) {
    if (this.dialogRef4TaskSlider) {
      this.dialogRef4TaskSlider.close();
    }

    const dialogConfig = new MatDialogConfig();
    dialogConfig.data = statusObject;
    dialogConfig.data.scope = this;
    dialogConfig.width = '600px';
    dialogConfig.disableClose = true;
    this.dialogRef4TaskSlider = this.dialog.open(SaveFeedbackCommentComponent, dialogConfig);
  }

  UpdateGoal(goalInfo: Goal) {
    this.goalRequest.GoalId = goalInfo.GoalId;
    this.goalRequest.GoalTitle = goalInfo.GoalTitle;
    this.goalRequest.Action = goalInfo.GoalDescription;
    if (goalInfo.Impact == null) {
      this.goalRequest.Impact = '';
    } else {
      this.goalRequest.Impact = goalInfo.Impact;
    }
    this.goalRequest.IsPublished = goalInfo.IsPublished;
    this.goalRequest.GoalType = goalInfo.GoalType;
    this.goalRequest.CreatedBy = this.userService.getUserDetails().UserDetails.EmpId;

    this.goalService.updateGoal(this.goalRequest).subscribe(response => {

      const updateGoalResult = response.SaveNewGoalResult;
      if (updateGoalResult.ResultStatusCode === '1040') {
        this.toast.success('GoalStats_GoalSavedMessage', '', () => { });
        this.getGoalData();
      } else {

        const errorMessage = updateGoalResult.ErrorMessage;
        this.toast.error(errorMessage);
      }
    });
  }

  showSearchPanel() {
    this.searchPanelVisible = !this.searchPanelVisible;
  }

  onSearchClicked() {

    let searchData: any[] = [];
    let isSelectedStatus = false;
    this.goalStatuses.forEach(objStatus => {
      if (objStatus.IsSelected) {
        isSelectedStatus = true;
        searchData = searchData.concat(this.filterTask(objStatus.statusTitle));
      }
    });

    if (!isSelectedStatus) {
      searchData = searchData.concat(this.filterTask(undefined));
    }

    if (searchData !== undefined) {
      if (searchData[0] !== undefined) {
        this.filteredData = searchData;
        this.isSearchApply = true;
        this.searchPanelVisible = false;
      }
    }
  }

  filterTask(status) {

    if (status !== undefined) {

      if (this.searchString !== undefined) {
        const filterData = this.goalsListChart.filter(
          objActData => (objActData.GoalConfigStatus === status
            && objActData.GoalTitle.toLowerCase().includes(this.searchString.toLowerCase())));
        return filterData;
      }
      // tslint:disable-next-line: one-line
      else {
        const filterData = this.goalsListChart.filter(
          objActData => objActData.GoalConfigStatus === status);
        return filterData;
      }
    } else if (this.searchString !== undefined) {
      const filterData = this.goalsListChart.filter(
        objActData => objActData.GoalTitle.toLowerCase().includes(this.searchString.toLowerCase()));
      return filterData;
    }
  }

  onClearSearch() {
    this.searchString = '';
    this.isSearchApply = false;
    this.searchPanelVisible = false;
    this.filteredData = this.goalsListChart;
    this.resetStatus();
  }

  private resetStatus() {

    this.goalStatuses.forEach(objStatus => {
      objStatus.IsSelected = false;
    });
  }

  setHighchartOptions(goal: Goal[]) {
    if (goal && goal.length > 0) {
      goal.forEach(item => {
        let percentageRemaining = 0;
        let percentageCompleted = 0;
        let colorCode = '';

        if (item.GoalPercentageComplete) {
          percentageCompleted = Math.round(+item.GoalPercentageComplete);
          percentageRemaining = 100 - percentageCompleted;

          if (percentageCompleted <= GoalCompletedColorRange.Low) {
            colorCode = GoalCompletedColorCode.Low;
          } else if (percentageCompleted <= GoalCompletedColorRange.Medium) {
            colorCode = GoalCompletedColorCode.Medium;
          } else if (percentageCompleted > GoalCompletedColorRange.Medium) {
            colorCode = GoalCompletedColorCode.High;
          }
        }
        // Pie chart option setting
        this.pieChartConfig.ChartType = ChartType.Pie;
        this.pieChartConfig.ChartSize = '75';
        this.pieChartConfig.ChartTitle = '<style="font-family:arial; font-size:16px;">' + percentageCompleted + '%</style>';
        this.pieChartConfig.TitleYAxis = 7;
        this.pieChartConfig.TooltipFormatterCallbackFun = this.tooltipFormatter;
        this.pieChartConfig.SeriesName = 'Goal';
        this.pieChartConfig.SeriesInnerSize = '70%';
        this.pieChartConfig.DataLabelsDistance = -40;
        this.pieChartConfig.SeriesData = [];

        // Completed Goal Data
        const serDataCompletedPercentage = {} as SeriesData;
        serDataCompletedPercentage.Name = percentageCompleted;
        serDataCompletedPercentage.YAxis = percentageCompleted;
        serDataCompletedPercentage.EnableDataLabel = false;
        serDataCompletedPercentage.Color = colorCode;
        this.pieChartConfig.SeriesData.push(serDataCompletedPercentage);

        // Remaining Goal Data
        const serDataRemainingPercentage = {} as SeriesData;
        serDataRemainingPercentage.Name = percentageRemaining;
        serDataRemainingPercentage.YAxis = percentageRemaining;
        serDataRemainingPercentage.EnableDataLabel = false;
        serDataRemainingPercentage.Color = GoalCompletedColorCode.None,
          this.pieChartConfig.SeriesData.push(serDataRemainingPercentage);

        item.HighchartOptions = this.highchartService.CreateHighChart(this.pieChartConfig);
        item.ShowDefaultImage = this.showDefaultImage(item);
      });
    }
  }

  tooltipFormatter(_seriesType: any, _seriesName: any, _yAxis: number, _color: string) {
    if (_color === GoalCompletedColorCode.None) {
      return 'Remaining:' + _yAxis + '%';
    } else {
      return 'Completed:' + _yAxis + '%';
    }
  }

  showGoalChatComponent(selectedGoal: Goal) {

    this.taskService.getGoalTasks(selectedGoal.GoalId).subscribe(response => {
      const dialogConfig = new MatDialogConfig();
      dialogConfig.width = 800 + 'px';
      dialogConfig.height = 600 + 'px';
      dialogConfig.disableClose = false;
      dialogConfig.data = { TaskId: selectedGoal.GoalId, Type: 'Goal', TaskCollection: response };
      this.dialog.open(TaskFeedbackComponent, dialogConfig);
    });
  }
  createGoalLinking(selectedGoal: Goal) {
    const userDetails = this.userService.getUserDetails().UserDetails;

    const dialogConfig = new MatDialogConfig();
    // tslint:disable-next-line:max-line-length
    dialogConfig.data = { empId: (this.isManageView ? this.repId : userDetails.EmpId), goalId: +selectedGoal.GoalId, goalNameGoalLinking: this.goalLinkingLabel };
    dialogConfig.width = '600px';
    dialogConfig.disableClose = true;
    this.dialog.open(LinkedGoalDetailsComponent, dialogConfig);
  }
  private showDefaultImage(goalItem: Goal): boolean {
    let imageName = '';
    if (this.goalConfiguration.ImagePreference === 'GoalType' && this.goalConfiguration.TypeImages && goalItem.GoalConfigType) {
      const obj = this.goalConfiguration.TypeImages.filter(data => data.typeTitle === goalItem.GoalConfigType)[0];
      imageName = obj ? obj['imagePath'] : undefined;
    } else if (this.goalConfiguration.ImagePreference === 'GoalStatus' && this.goalConfiguration.StatusImages
      && goalItem.GoalConfigStatus) {
      imageName = this.goalConfiguration.StatusImages.filter(data => data.statusTitle === goalItem.GoalConfigStatus)[0]['imagePath'];
    } else if (this.goalConfiguration.ImagePreference === 'Standard') {
      imageName = this.imagePath;
    }
    if (imageName && imageName.length > 0) {
      return false;
    } else {
      return true;
    }
  }
  private getGoalData() {
    this.userInfo = this.userService.getUserDetails().UserDetails;
    const user = this.userService.getUserDetails();
    const request = new GoalRequest();
    // Send Coach or Coachee Id based on ACT or Manage
    // tslint:disable-next-line:max-line-length
    request.EmpId = (user !== undefined && user.CoacheeDetails !== undefined && user.IsRepView) ? user.CoacheeDetails.UserDetails.EmpId : this.userInfo.EmpId;
    request.Type = 'Goal';
    // Adding below StatusFilter in request to load all the Goals (i.e. Completed as well)
    const status = user.GoalConfiguration.StatusImages;
    const statusFilter = [];
    status.forEach(objStatus => {
      if (objStatus.OnOffValue) {
        statusFilter.push(objStatus.statusTitle);
      }
    });

    request.Statusfilter = statusFilter.join(',');
    this.trackService.getGoals(request).subscribe(response => {
      this.goalsListChart = response.TrackResult.MyGoals;

      this.onSearchClicked();
      this.setHighchartOptions([]);
      this.setHighchartOptions(this.goalsListChart);
    });
  }
}
