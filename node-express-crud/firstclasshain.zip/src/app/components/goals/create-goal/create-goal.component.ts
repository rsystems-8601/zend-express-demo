import { Component, OnInit, Inject, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CreateGoalRequest } from '../../../models/requests/create-goal-request';
import { UserService } from '../../../services/user.service';
import { GoalsService } from 'src/app/services/goals.service';
import { IcftoasterService } from 'src/app/services/icftoaster.service';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialogConfig, MatDialog } from '@angular/material';
import { EventEmiterService } from 'src/app/services/event.emmiter.service';
import { Subscription } from 'rxjs';
import { CreateGoalLinkingComponent } from '../create-goal-linking/create-goal-linking.component';
import { Goal } from 'src/app/models/response/goal/goal-response';
import * as Highcharts from 'highcharts';
import { GoalConfiguration } from 'src/app/models/user-details-result';
import { GoalCompletedColorRange, GoalCompletedColorCode, ChartType } from 'src/app/helpers/enums/common-enums';
import { SeriesData, PieChartRequest } from 'src/app/models/requests/highchart-request';
import { HighchartService } from 'src/app/services/highchart.service';
import { CommonService } from 'src/app/services/common.service';

@Component({
  selector: 'app-create-goal',
  templateUrl: './create-goal.component.html',
  styleUrls: ['./create-goal.component.scss']
})

export class CreateGoalComponent implements OnInit, OnDestroy {
  msteam_popup_css = '';
  selectedObserver: any;
  selectedGoalType: 'hello';
  goalRequest = new CreateGoalRequest();
  userDetailsResult: any;
  userDetailsEmpId: any;
  goalForm: FormGroup;
  submitted = false;
  weightDataSources = Array();
  goalTypeSources = Array();
  calllingSource = 'Task';
  IsRequiredToShowTitle = false;
  IsRequiredToShowType = false;
  IsRequiredToShowAction = false;
  IsRequiredToShowImpact = false;
  IsRequiredToShowWeight = false;
  IsRequiredToShowDueDate = false;
  IsRequiredToShowSaveAndPublish = false;
  TitleLabel = 'Title';
  TypeLabel = 'Type';
  ActionLabel = 'Action';
  ImpactLabel = 'Impact';
  WeightLabel = 'Weight';
  DueDateLabel = 'Due Date';
  SaveAndPublishLabel = 'Save and Publish';
  IsGoalRatingActionAllowed = false;
  RepId: number;
  GoalType: string;
  public subscription: Subscription;

  goalNameGoalLinking = '';
  showGoalNameGoalLinking = false;
  isManageView = false;
  repId = 0;
  // GoalLinkingJson = '';
  goalsListChart: Goal[] = [];
  goalConfiguration: GoalConfiguration;
  imagePath: string;
  pieChartConfig = {} as PieChartRequest;
  highcharts = Highcharts;
  showGoalNameLabel = false;

  constructor(
    private _eventEmiter: EventEmiterService,
    private formBuilder: FormBuilder,
    private userService: UserService,
    private goalService: GoalsService,
    private toast: IcftoasterService,
    public dialogRef: MatDialogRef<CreateGoalComponent>,
    private dialog: MatDialog,
    private highchartService: HighchartService,
    private commonService: CommonService,
    @Inject(MAT_DIALOG_DATA) public data
  ) {
    for (let i = 0; i < 101; i++) {
      this.weightDataSources.push(i);
    }
    this.subscription = this._eventEmiter.subscribe(observerData => {

      if (observerData.keyName === 'AddObserver') {
        this.selectedObserver = observerData;
      }

    });

    const user = this.userService.getUserDetails();
    if (user !== undefined && user.CoacheeDetails !== undefined && user.IsRepView) {
      this.isManageView = true;
      this.repId = user.CoacheeDetails.UserDetails.EmpId;
    } else {
      this.isManageView = false;
    }
    this.goalConfiguration = user.GoalConfiguration;

  }

  ngOnInit() {
    this.goalForm = this.formBuilder.group({
      goleTitle: ['', Validators.required],
      ddlGoalType: [''],
      goalAction: [''],
      goalImpact: [''],
      ddlGoalWeight: [''],
      goalDueDate: ['', Validators.required],
    });
    this.IsGoalRatingActionAllowed = this.userService.getUserDetails().UserDetails.IsGoalRatingActionAllowed;
    this.RepId = this.data.selectedRepId;
    this.GoalType = this.data.goalType;
    this.userDetailsResult = this.userService.getUserDetails();
    this.goalTypeSources = this.userDetailsResult.GoalConfiguration.TypeImages.filter(x => x.OnOffValue === true);

    this.userDetailsResult.GoalConfiguration.Labels.some(label => {
      if (label.GoalLabelName.toLowerCase() === 'goal linking') {
        this.showGoalNameGoalLinking = label.OnOffValue;
        this.goalNameGoalLinking = label.EnableValue ? label.CustomLabelText : label.GoalLabelName;
        // return true;
      } else if (label.GoalLabelName.toLowerCase() === 'title') {
        this.showGoalNameLabel = label.OnOffValue;
      }
    });

    if (this.goalTypeSources && this.goalTypeSources.length > 0) {
      this.goalTypeSources = this.goalTypeSources.filter(x => x.OnOffValue === true);
    }
    this.userDetailsEmpId = this.userService.getUserDetails().UserDetails;
    this.goalRequest.init(this.userDetailsResult.UserDetails);
    this.updateUI();
    this.resetForm();
    if (this.commonService.getMSTeamViewConfig()) {
      this.msteam_popup_css = 'icf_msteam';
    } else {
      this.msteam_popup_css = '';
    }
  }

  // convenience getter for easy access to form fields
  get f() {
    return this.goalForm.controls;
  }
  ngOnDestroy() {
    this._eventEmiter.unsubscribe(this.subscription);
  }
  // Updating UI based on Flag on/off from admin
  updateUI() {
    for (const label of this.userDetailsResult.GoalConfiguration.Labels) {
      const controlCaption = label.EnableValue === true ? label.CustomLabelText : label.GoalLabelName;

      switch (label.GoalLabelId) {

        case 1:
          this.IsRequiredToShowTitle = label.OnOffValue ? true : false;
          this.TitleLabel = controlCaption;
          break;

        case 2:
          this.IsRequiredToShowType = label.OnOffValue ? true : false;
          this.TypeLabel = controlCaption;
          break;

        case 3:
          this.IsRequiredToShowAction = label.OnOffValue ? true : false;
          this.ActionLabel = controlCaption;
          break;

        case 4:
          this.IsRequiredToShowImpact = label.OnOffValue ? true : false;
          this.ImpactLabel = controlCaption;
          break;

        case 5:
          this.IsRequiredToShowWeight = label.OnOffValue ? true : false;
          this.WeightLabel = controlCaption;
          break;

        case 6:
          this.IsRequiredToShowDueDate = label.OnOffValue ? true : false;
          this.DueDateLabel = controlCaption;
          break;

        case 10:
          this.IsRequiredToShowSaveAndPublish = label.OnOffValue ? true : false;
          if (this.userDetailsResult !== undefined
            && this.userDetailsResult.CoacheeDetails !== undefined && this.userDetailsResult.IsRepView) {
            this.IsRequiredToShowSaveAndPublish = false;
          }
          if (controlCaption !== '') { this.SaveAndPublishLabel = controlCaption; }
          break;

        default:
          break;
      }
    }
  }

  resetForm() {

    this.goalRequest.GoalId = 0;
    this.goalRequest.GoalTitle = '';
    this.goalRequest.Action = '';
    this.goalRequest.Impact = '';
    this.goalRequest.Weight = 0;
    this.goalRequest.DueDate = '';
    this.goalRequest.IsPublished = false;
    if (this.goalTypeSources && this.goalTypeSources.length > 0) {
      this.goalRequest.GoalConfigType = this.goalTypeSources[0].typeTitle;
    }
    // this.goalRequest.GoalConfigType = this.userDetailsResult.GoalConfiguration.TypeImages[0].typeTitle;
    this.goalRequest.GoalConfigStatus = this.userDetailsResult.GoalConfiguration.StatusImages[0].statusTitle;
    this.f.goalDueDate.setValue('');

  }

  onSubmit(isSaveAndPublish: boolean) {
    this.submitted = true;
    if (this.goalForm.invalid) {
      return;
    }
    // TO DO Service Call

    // Check for manage section

    this.goalRequest.GoalId = 0;
    this.goalRequest.GoalType = this.GoalType;
    this.goalRequest.DueDate = this.f.goalDueDate.value;
    if (this.userDetailsResult !== undefined && this.userDetailsResult.CoacheeDetails !== undefined && this.userDetailsResult.IsRepView) {
      // tslint:disable-next-line:max-line-length
      this.goalRequest.IsPublished = true; // (this.userDetailsResult.UserDetails.EmpId === this.userDetailsResult.CoacheeDetails.UserDetails.EmpId) ? false : true;
      this.goalRequest.CreatedBy = this.userDetailsResult.UserDetails.EmpId;
      this.goalRequest.RepId = this.userDetailsResult.CoacheeDetails.UserDetails.EmpId;
      this.goalRequest.GoalConfigStatus = this.userDetailsResult.CoacheeDetails.GoalConfiguration.StatusImages[0].statusTitle;
    } else {
      this.goalRequest.IsPublished = false; // (this.userDetailsResult.UserDetails.EmpId === this.RepId) ? false : true;
      this.goalRequest.CreatedBy = this.userDetailsResult.UserDetails.EmpId;
      this.goalRequest.RepId = this.userDetailsResult.UserDetails.EmpId; // this.RepId;
      this.goalRequest.GoalConfigStatus = this.userDetailsResult.GoalConfiguration.StatusImages[0].statusTitle;
    }
    // If 'Save And Publish' button is disabled at company level or 'IsRepView' is true then in both case 'Save And Publish' button willn't be visible to user, so 'isPublish' property will be always true.
    if (isSaveAndPublish || !this.IsRequiredToShowSaveAndPublish) {
      this.goalRequest.IsPublished = true;
    }
    this.goalRequest.GroupId = this.data.groupId;
    this.goalRequest.XMLObserverIds = this.goalRequest.generateObserverXML();

    // ICF6-1109 To save linked goals
    if (this.goalsListChart.length > 0) {
      this.goalRequest.GoalLinkingJson = [];
      this.goalsListChart.forEach(item => {
        this.goalRequest.GoalLinkingJson.push({ 'ChildGoalId': item.GoalId });
      });
    }
    this.goalService.createGoal(this.goalRequest).subscribe(response => {

      const saveNewGoalResult = response.SaveNewGoalResult;
      if (saveNewGoalResult.ResultStatusCode === '1040') {
        // this._eventEmiter.emit({ actionType: 'ReloadGoal' });


        this.toast.success('Common_UpdateSuccess', '', () => {
          this.resetForm();
          // this.dialogRef.close('success');
        });
        this.dialogRef.close('success');
      } else {

        const errorMessage = saveNewGoalResult.ErrorMessage;
        this.toast.error(errorMessage);
      }

    });

  }
  onClickAddButton() {
    if (this.selectedObserver !== undefined) {

      if (this.observerExist()) {
        this.toast.error('GoalStats_Error_EmployeeAlreadAdded', '');
        return;
      }
      this.goalRequest.Observers.push({
        ObserverEmpId: this.selectedObserver.observerData.EmpID,
        ProfilePicUrl: this.selectedObserver.observerData.ProfileImageName,
        ObserverName: this.selectedObserver.observerData.FirstName + ' ' + this.selectedObserver.observerData.LastName,
      }
      );
      this.selectedObserver = null;
      this._eventEmiter.emit({ keyName: 'resetAutoComplete' });
    }
  }

  observerExist() {
    const filterData = this.goalRequest.Observers.filter(
      observer => observer.ObserverEmpId === this.selectedObserver.observerData.EmpID);
    if (filterData.length > 0) {
      return true;
    }
    return false;
  }
  removeObserver(observerObj) {
    this.goalRequest.Observers = this.goalRequest.Observers.filter(
      observer => observer.ObserverEmpId !== observerObj.ObserverEmpId);
  }

  cancelClick() {
    this.resetForm();
    this.dialogRef.close();
  }

  createGoalLinking() {
    const userDetails = this.userService.getUserDetails().UserDetails;
    const dialogConfig = new MatDialogConfig();
    dialogConfig.data = {
      empId: (this.isManageView ? this.repId : userDetails.EmpId),
      goalId: 0,
      goalNameGoalLinking: this.goalNameGoalLinking,
      isCreateGoal: true,
      callbackFn: this.showLinkedGoal,
      scope: this
    };
    dialogConfig.width = '600px';
    dialogConfig.disableClose = true;
    this.dialog.open(CreateGoalLinkingComponent, dialogConfig);
  }

  showLinkedGoal(linkedGoal: Goal) {
    let goalExist = -1;
    goalExist = this.goalsListChart.findIndex(x => x.GoalId === linkedGoal.GoalId);
    if (goalExist === -1) {
      this.goalsListChart.push(linkedGoal);
      this.setHighchartOptions(this.goalsListChart);
    }
  }

  setHighchartOptions(goal: Goal[]) {
    if (goal && goal.length > 0) {
      goal.forEach(item => {

        let percentageRemaining = 0;
        let percentageCompleted = 0;
        let colorCode = '';

        if (item.GoalPercentageComplete) {
          percentageCompleted = Math.round(+item.GoalPercentageComplete);
          percentageRemaining = 100 - percentageCompleted;

          if (percentageCompleted <= GoalCompletedColorRange.Low) {
            colorCode = GoalCompletedColorCode.Low;
          } else if (percentageCompleted <= GoalCompletedColorRange.Medium) {
            colorCode = GoalCompletedColorCode.Medium;
          } else if (percentageCompleted > GoalCompletedColorRange.Medium) {
            colorCode = GoalCompletedColorCode.High;
          }
        }
        // Pie chart option setting
        this.pieChartConfig.ChartType = ChartType.Pie;
        this.pieChartConfig.ChartSize = '75';
        this.pieChartConfig.ChartTitle = '<style="font-family:arial; font-size:16px;">' + percentageCompleted + '%</style>';
        this.pieChartConfig.TitleYAxis = 7;
        this.pieChartConfig.TooltipFormatterCallbackFun = this.tooltipFormatter;
        this.pieChartConfig.SeriesName = 'Goal';
        this.pieChartConfig.SeriesInnerSize = '70%';
        this.pieChartConfig.DataLabelsDistance = -40;
        this.pieChartConfig.SeriesData = [];

        // Completed Goal Data
        const serDataCompletedPercentage = {} as SeriesData;
        serDataCompletedPercentage.Name = percentageCompleted;
        serDataCompletedPercentage.YAxis = percentageCompleted;
        serDataCompletedPercentage.EnableDataLabel = false;
        serDataCompletedPercentage.Color = colorCode;
        this.pieChartConfig.SeriesData.push(serDataCompletedPercentage);

        // Remaining Goal Data
        const serDataRemainingPercentage = {} as SeriesData;
        serDataRemainingPercentage.Name = percentageRemaining;
        serDataRemainingPercentage.YAxis = percentageRemaining;
        serDataRemainingPercentage.EnableDataLabel = false;
        serDataRemainingPercentage.Color = GoalCompletedColorCode.None,
          this.pieChartConfig.SeriesData.push(serDataRemainingPercentage);

        item.HighchartOptions = this.highchartService.CreateHighChart(this.pieChartConfig);
        item.ShowDefaultImage = this.showDefaultImage(item);
      });
    }
  }
  showDefaultImage(goalItem: Goal): boolean {
    let imageName = '';
    if (this.goalConfiguration.ImagePreference === 'GoalType' && this.goalConfiguration.TypeImages && goalItem.GoalConfigType) {
      const obj = this.goalConfiguration.TypeImages.filter(data => data.typeTitle === goalItem.GoalConfigType)[0];
      imageName = obj ? obj['imagePath'] : null;
    } else if (this.goalConfiguration.ImagePreference === 'GoalStatus' && this.goalConfiguration.StatusImages
      && goalItem.GoalConfigStatus) {
        const obj = this.goalConfiguration.StatusImages.filter(data => data.statusTitle === goalItem.GoalConfigStatus)[0];
        imageName = obj ? obj['imagePath'] : null;
    } else if (this.goalConfiguration.ImagePreference === 'Standard') {
      const obj = this.goalConfiguration.StandardImages[0];
      imageName = obj ? obj['imagePath'] : null;
      this.imagePath = imageName;
    }
    if (imageName && imageName.length > 0) {
      return false;
    } else {
      return true;
    }
  }

  tooltipFormatter(_seriesType: any, _seriesName: any, _yAxis: number, _color: string) {
    if (_color === GoalCompletedColorCode.None) {
      return 'Remaining:' + _yAxis + '%';
    } else {
      return 'Completed:' + _yAxis + '%';
    }
  }

  deleteGoalLinking(goalDetails: Goal) {
    this.goalsListChart = this.goalsListChart.filter(x => x.GoalId !== goalDetails.GoalId);
    this.setHighchartOptions(this.goalsListChart);
  }

}
