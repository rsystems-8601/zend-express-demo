import { Component, OnInit, Inject } from '@angular/core';
import { IcftoasterService } from 'src/app/services/icftoaster.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { GoalsService } from 'src/app/services/goals.service';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { CreateMileStoneGoalRequest, MileStoneGoalRequest } from 'src/app/models/requests/create-milestone-request';
import { Milestone } from 'src/app/models/response/milestone/milestone-response';
import { DatePipe } from '@angular/common';
import { ConfirmationDialogService } from '../../shared/confirmation-dialog/confirmation-dialog.service';

@Component({
  selector: 'app-create-milestone',
  templateUrl: './create-milestone.component.html',
  styleUrls: ['./create-milestone.component.scss']
})
export class CreateMilestoneComponent implements OnInit {
  MileStoneGoalForm: FormGroup;
  milestoneRequest = new MileStoneGoalRequest();
  goalmilestoneRequest = new CreateMileStoneGoalRequest();
  submitted: boolean;
  addMilestone: boolean;
  MilestoneDetail: Milestone;
  selectedGoalId: number;
  empId: number;
  goalNameMilestone: string;

  constructor(private formBuilder: FormBuilder, private toast: IcftoasterService,
    private goalService: GoalsService, public dialogRef: MatDialogRef<CreateMilestoneComponent>,
    private confirmationDialogService: ConfirmationDialogService,
    @Inject(MAT_DIALOG_DATA) public data, private datePipe: DatePipe) { }

  ngOnInit() {
    this.MileStoneGoalForm = this.formBuilder.group({
      milestoneTitle: ['', Validators.required],
      milestoneStartDate: [''],
      milestoneEndDate: [''],
      milestoneDescription: [''],
      ddlMileStoneStatus: ['', Validators.required]
    });

    if (this.data !== undefined) {
      this.empId = this.data.empId;
      this.selectedGoalId = this.data.goalId;
      this.goalNameMilestone = this.data.goalNameMilestone;
      // Update Milestone
      if (this.data.milestoneDetails !== undefined) {
        this.addMilestone = false;
        // Update the details in the request object.
        this.milestoneRequest = this.data.milestoneDetails;
        if (this.milestoneRequest.StartDate != null) {
          const sDate = new Date(this.milestoneRequest.StartDate);
          this.milestoneRequest.StartDate = this.datePipe.transform(sDate, 'MM/dd/yyyy');
        }
        if (this.milestoneRequest.EndDate != null) {
          const eDate = new Date(this.milestoneRequest.EndDate);
          this.milestoneRequest.EndDate = this.datePipe.transform(eDate, 'MM/dd/yyyy');
        }
      } else { // Create Milestone
        this.milestoneRequest.MileStoneId = 0;
        this.addMilestone = true;
      }
    }
  }

  get f() {
    return this.MileStoneGoalForm.controls;
  }

  resetForm() {
    this.milestoneRequest.MileStoneId = 0;
    this.milestoneRequest.Title = '';
    this.milestoneRequest.StartDate = '';
    this.milestoneRequest.EndDate = '';
    this.milestoneRequest.Descriptions = '';
    this.milestoneRequest.StatusId = 0;
    this.f.milestoneStartDate.setValue('');
    this.f.milestoneEndDate.setValue('');
  }

  onSubmit() {
    this.submitted = true;
    if (this.MileStoneGoalForm.invalid) {
      return;
    }

    this.goalmilestoneRequest.GoalMileStoneRequest = JSON.stringify(this.milestoneRequest);
    this.goalmilestoneRequest.GoalId = +this.selectedGoalId;

    this.goalService.saveGoalMileStones(this.goalmilestoneRequest).subscribe(response => {

      if (response.ResultStatusCode === 'success') {
        if (this.addMilestone) {
          this.toast.success('Common_AddedSuccessfully', '', () => {
          });
          this.cancelClick();
        } else {
          this.toast.success('Common_UpdatedSuccessfully', '', () => {
          });
          this.cancelClick();
        }
      } else {
        const errorMessage = response.ErrorMessage;
        this.toast.error(errorMessage);
      }
    });
  }


  onDelete() {

    this.confirmationDialogService.confirm('Common_Confirm_Delete',
      'Common_Yes',
      'Common_No').subscribe(value => {

        if (value) {
          this.deleteMilstone();
        }
      });
  }

  deleteMilstone() {
    this.submitted = true;
    if (this.MileStoneGoalForm.invalid) {
      return;
    }

    this.goalService.deleteGoalMileStones(this.milestoneRequest.MileStoneId).subscribe(response => {
      if (response) {
        this.toast.success('Record successfully deleted', '', () => {
        });
        this.cancelClick();
      } else {
        const errorMessage = response.ErrorMessage;
        this.toast.error(errorMessage);
      }
    });
  }

  cancelClick() {
    this.resetForm();
    this.dialogRef.close('success');
  }
}
