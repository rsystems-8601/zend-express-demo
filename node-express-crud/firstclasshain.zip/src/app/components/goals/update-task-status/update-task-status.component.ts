import { Component, OnInit, Inject } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { EditGoalComponent } from '../edit-goal/edit-goal.component';
import { SaveGoalTaskCommentRequest } from 'src/app/models/requests/task-request';
import { UserService } from 'src/app/services/user.service';
import { IcftoasterService } from 'src/app/services/icftoaster.service';
import { TaskService } from 'src/app/services/task.service';
import { GoalTask } from 'src/app/models/response/goal/goal-task-response';

@Component({
  selector: 'app-update-task-status',
  templateUrl: './update-task-status.component.html',
  styleUrls: ['./update-task-status.component.scss']
})
export class UpdateTaskStatusComponent implements OnInit {

  updateTaskStatusForm: FormGroup;
  userDetails: any;
  submitted: any = false;
  GoalTaskDetails: GoalTask;
  ToValue: any;
  saveGoalTaskCommentRequest = new SaveGoalTaskCommentRequest();
  comment: string;
  statusChangeDirection: string;
  taskStatusId: number;
  taskStatusOption: string;
  previousValue: string;
  callback: any;
  checked = true;

  constructor(private formBuilder: FormBuilder,
    private dialogRef: MatDialogRef<EditGoalComponent>,
    private userService: UserService,
    private taskService: TaskService,
    private toast: IcftoasterService,
    @Inject(MAT_DIALOG_DATA) public data) { }

  ngOnInit() {
    this.userDetails = this.userService.getUserDetails();
    this.updateTaskStatusForm = this.formBuilder.group({
      taskStatusUpdateText: [''],
    });

    this.GoalTaskDetails = this.data.details;
    this.ToValue = this.data.updatedtaskstatus;
    this.statusChangeDirection = this.data.statuschangedirection;
    this.taskStatusId = this.data.updatedtaskstatusid;
    this.taskStatusOption = this.data.statusOption;
    this.previousValue = this.data.previousValue;
    if (this.data.callBack) {
      this.callback = this.data.callBack.bind(this.data.scope, this.data.previousValue);
    }
  }

  cancelClick() {
    this.dialogRef.close();
    if (typeof (this.callback) === 'function') {
      this.callback.call();
    }
  }

  resetForm() {
    this.comment = '';
  }

  get f() {
    return this.updateTaskStatusForm.controls;
  }

  onSubmit() {
    this.submitted = true;

    if (!this.checked &&
      (!this.f['taskStatusUpdateText'].value || this.f['taskStatusUpdateText'].value.trim() === '')) {
      this.f['taskStatusUpdateText'].setErrors({ 'required': true });
      return;
    }
    this.saveGoalTaskCommentRequest.CommentedBy = this.userDetails.UserDetails.EmpId;
    this.saveGoalTaskCommentRequest.GoalId = this.GoalTaskDetails.GoalId;
    this.saveGoalTaskCommentRequest.TaskId = this.GoalTaskDetails.ItemId || this.GoalTaskDetails.TaskId;
    this.saveGoalTaskCommentRequest.Category = this.GoalTaskDetails.TaskId ? 'Task' : 'Goal';
    const val = (this.previousValue || (this.previousValue && Number(this.previousValue)) === 0) ? this.previousValue : this.GoalTaskDetails.TaskStatus;
    this.comment = this.comment ? this.comment : '';
    this.saveGoalTaskCommentRequest.Comment = this.comment + '~' + val + '~' +
      this.ToValue + '~' + this.statusChangeDirection + '~' + this.saveGoalTaskCommentRequest.TaskId;

    const updateTaskRequest = {
      TaskId: this.saveGoalTaskCommentRequest.TaskId,
      StatusOption: this.taskStatusOption ? this.taskStatusOption : this.GoalTaskDetails.StatusOption,
      StatusId: this.taskStatusId,
      UpdatedBy: this.userDetails.UserDetails.EmpId
    };

    this.taskService.saveGoalTaskComment(this.saveGoalTaskCommentRequest).subscribe(response => {
      if (response.AddEmployeeSkillResult.ResultStatusCode === '1040') {
        this.taskService.updateTaskStatus(JSON.stringify(updateTaskRequest)).subscribe((statusUpdateResponse) => {
          if (statusUpdateResponse.UpdateTaskStatusResult.ResultStatusCode === '1040') {
            this.resetForm();
            this.dialogRef.close();
            this.toast.success('Common_UpdateSuccess', '', () => {
              // send the notification to update the feedback section.
              // this.getTaskGoalChatDetails();
            });
          } else {
            this.toast.error('Unable to update status.', '');
          }

        });
      } else {
        this.dialogRef.close();
      }
    });
  }
}
