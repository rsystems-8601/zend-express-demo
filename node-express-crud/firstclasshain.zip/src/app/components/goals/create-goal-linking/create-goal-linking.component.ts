import { Component, OnInit, Inject, OnDestroy } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { TrackService } from 'src/app/services/track.service';
import { SourceGoals } from 'src/app/models/response/goal/source-goals-response';
import { BaseRequest } from 'src/app/models/requests/base-request';
import { UserService } from 'src/app/services/user.service';
import { UserDetails } from 'src/app/models/user-details-result';
import { EventEmiterService } from 'src/app/services/event.emmiter.service';
import {
  GoalLinkingRequest, GoalLinkingJSON, GoalLinkedClassRequest,
  GetGoalsForLinking
} from 'src/app/models/requests/goal-linking-request';
import { IcftoasterService } from 'src/app/services/icftoaster.service';
import { Goal } from 'src/app/models/response/goal/goal-response';
import { Subscription } from 'rxjs';
import { GoalLinkingResponse } from 'src/app/models/response/goal-linking-response';
import { validateDropDownValue } from 'src/app/helpers/validation/dropdown-list-validation';

@Component({
  selector: 'app-create-goal-linking',
  templateUrl: './create-goal-linking.component.html',
  styleUrls: ['./create-goal-linking.component.scss']
})
export class CreateGoalLinkingComponent implements OnInit, OnDestroy {
  GoalLinkingForm: FormGroup;
  submitted = false;
  SourceGoalList: SourceGoals[];
  userInfo: UserDetails;
  ShowEmployeeSearch = false;
  calllingSource = 'goalLinking';
  selectedObserver: any;
  selectedGoalId: number;
  employeeId: number;
  goalLinkedClassRequest = new GoalLinkedClassRequest();
  goalLinkingTitle: string;
  goalSources: Goal[];
  isCreateGoal: boolean;

  private subscription: Subscription;

  callbackFn: any;
  parentScope: any;

  constructor(private formBuilder: FormBuilder,
    private dialogRef: MatDialogRef<CreateGoalLinkingComponent>,
    private trackService: TrackService,
    private userService: UserService,
    private _eventEmiter: EventEmiterService,
    @Inject(MAT_DIALOG_DATA) public data,
    private toast: IcftoasterService) {

    this.GoalLinkingForm = this.formBuilder.group({
      'ddlSourceOfGoals': new FormControl(0, [Validators.required, validateDropDownValue]),
      'ddlGoalToLink': new FormControl(0, [Validators.required, validateDropDownValue])
    });

    this.subscription = this._eventEmiter.subscribe(returnData => {
      if (returnData.keyName === 'AddObserver') {
        this.selectedObserver = returnData;
        // Show the goals related to the selected employee.

        const getGoalsForLinking = new GetGoalsForLinking();
        getGoalsForLinking.EmpId = this.employeeId;
        getGoalsForLinking.Id = this.selectedObserver.observerData.EmpID;
        getGoalsForLinking.Type = 'Other';

        this.getGoalsToBeLinked(getGoalsForLinking);
      }
    });
  }

  ngOnInit() {
    /*
     this.GoalLinkingForm = this.formBuilder.group({
       ddlSourceOfGoals: ['', Validators.required],
       ddlGoalToLink: ['', Validators.required]
     });
    */
    if (this.data !== undefined) {
      this.employeeId = this.data.empId;
      this.selectedGoalId = this.data.goalId;
      this.goalLinkingTitle = this.data.goalNameGoalLinking;
      if (this.data.isCreateGoal && this.data.callbackFn) {
        this.isCreateGoal = this.data.isCreateGoal;
        this.callbackFn = this.data.callbackFn;
        this.parentScope = this.data.scope;
      }

    }

    const request = new BaseRequest();
    request.EmpId = this.employeeId;
    this.trackService.getSourceOfGoals(request).subscribe(resultData => {
      const details = JSON.parse(JSON.stringify(resultData));
      this.SourceGoalList = details;
    });
    this.resetForm();
  }

  ngOnDestroy() {
    this._eventEmiter.unsubscribe(this.subscription);
  }

  resetForm() {
    this.goalLinkedClassRequest.SourceGoalId = 0;
    this.goalLinkedClassRequest.GoalLinkId = 0;
  }

  get f() {
    return this.GoalLinkingForm.controls;
  }

  onSourceGoalChange($event) {
    this.goalLinkedClassRequest.GoalLinkId = 0;

    if ($event !== undefined) {
      if (+$event === 0) {
        this.ShowEmployeeSearch = false;
        this.goalSources = [];
        return;
      }
      const result = this.SourceGoalList.filter(x => x.Id === +$event);

      if (result[0].FieldNameToIdentify === 'Other' && $event === '6') {
        this.ShowEmployeeSearch = true;
        this.goalSources = [];
      } else {
        this.ShowEmployeeSearch = false;
        const getGoalsForLinking = new GetGoalsForLinking();
        getGoalsForLinking.EmpId = this.employeeId;
        getGoalsForLinking.Id = result[0].FieldId;
        getGoalsForLinking.Type = result[0].FieldNameToIdentify;

        this.getGoalsToBeLinked(getGoalsForLinking);
      }
    }
  }

  getGoalsToBeLinked(getGoalsForLinking) {
    this.trackService.getGoalsForLinking(getGoalsForLinking).subscribe(response => {
      if (response.length > 0) {
        this.goalSources = JSON.parse(JSON.stringify(response));
      } else {
        this.goalSources = [];
      }
    });
  }

  onSubmit() {
    if (this.isCreateGoal) {
      this.submitted = true;
      if (this.GoalLinkingForm.invalid) {
        return;
      } else if (typeof (this.callbackFn) === 'function') {
        const goal: Goal[] = this.goalSources.filter(x => x.GoalId === +this.goalLinkedClassRequest.GoalLinkId);
        this.callbackFn.call(this.parentScope, goal[0]);
        this.cancelClick();
      }
    } else {
      this.submitted = true;
      if (this.GoalLinkingForm.invalid) {
        return;
      }
      this.userInfo = this.userService.getUserDetails().UserDetails;
      const goalLinkingJSONRequest = new GoalLinkingJSON();
      goalLinkingJSONRequest.ChildGoalId = +this.goalLinkedClassRequest.GoalLinkId;

      const request = new GoalLinkingRequest();
      request.ParentGoalId = this.selectedGoalId;
      request.EmpId = this.userInfo.EmpId;
      request.GoalLinkingJson = JSON.stringify(goalLinkingJSONRequest);

      this.trackService.saveGoalToGoalLinking(request).subscribe((response: GoalLinkingResponse) => {
        if (response.Status) {
          this.toast.success(response.ResponseMessage, '', () => {
            // this.cancelClick();
          });
          this.cancelClick();
        } else {
          this.toast.error(response.ResponseMessage, '');
        }
        this.submitted = false;
      });
    }

  }

  cancelClick() {
    this.resetForm();
    this.dialogRef.close('success');
  }

}
