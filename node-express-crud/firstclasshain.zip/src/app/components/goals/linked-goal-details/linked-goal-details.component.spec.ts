import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LinkedGoalDetailsComponent } from './linked-goal-details.component';

describe('LinkedGoalDetailsComponent', () => {
  let component: LinkedGoalDetailsComponent;
  let fixture: ComponentFixture<LinkedGoalDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LinkedGoalDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LinkedGoalDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
