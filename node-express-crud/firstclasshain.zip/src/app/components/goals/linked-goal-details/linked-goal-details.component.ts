import { Component, OnInit, Inject } from '@angular/core';
import { TrackService } from 'src/app/services/track.service';
import { Goal } from 'src/app/models/response/goal/goal-response';
import { PieChartRequest, SeriesData } from 'src/app/models/requests/highchart-request';
import { GoalCompletedColorRange, GoalCompletedColorCode, ChartType } from 'src/app/helpers/enums/common-enums';
import * as Highcharts from 'highcharts';
import { HighchartService } from 'src/app/services/highchart.service';
import { MilestoneRequest } from 'src/app/models/requests/milestone-request';
import { IcftoasterService } from 'src/app/services/icftoaster.service';
import { DeleteGoalLinkingRequest } from 'src/app/models/requests/goal-linking-request';
import { UserService } from 'src/app/services/user.service';
import { GoalConfiguration, TypeImage, StatusImage } from 'src/app/models/user-details-result';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialog, MatDialogConfig } from '@angular/material';
import { CreateGoalLinkingComponent } from '../create-goal-linking/create-goal-linking.component';

@Component({
  selector: 'app-linked-goal-details',
  templateUrl: './linked-goal-details.component.html',
  styleUrls: ['./linked-goal-details.component.scss']
})

export class LinkedGoalDetailsComponent implements OnInit {

  highcharts = Highcharts;
  goalsListChart: Goal[];
  pieChartConfig = {} as PieChartRequest;
  imagePath: string;
  goalConfiguration: GoalConfiguration;
  goalStatuses: StatusImage[] = [];
  goalTypes: TypeImage[] = [];

  showGoalNameLabel = false;
  customLabelText: string;
  enableValue: boolean;
  goalLabelName: string;
  onOffValue: boolean;

  showGoalLinking = false;
  goalLinkingLabel: string;

  employeeId: number;
  selectedGoalId: number;
  constructor(
    private trackService: TrackService,
    private highchartService: HighchartService,
    private toast: IcftoasterService,
    private userService: UserService,
    private dialogRef: MatDialogRef<LinkedGoalDetailsComponent>,
    private dialog: MatDialog,
    @Inject(MAT_DIALOG_DATA) public data, ) { }

  ngOnInit() {
    if (this.data !== undefined) {
      this.employeeId = this.data.empId;
      this.selectedGoalId = this.data.goalId;
    }
    this.loadGoalConfigData();
    this.getLinkedGoalDetails();
  }

  private loadGoalConfigData() {
    // this.weight = Array.apply(null, { length: 101 }).map(Number.call, Number);
    // const user = this.userService.getUserDetails();
    // tslint:disable-next-line:max-line-length
    this.goalConfiguration = this.userService.getUserDetails().GoalConfiguration;
    for (let i = 0; i < this.goalConfiguration.Labels.length; i++) {
      this.goalLabelName = this.goalConfiguration.Labels[i].GoalLabelName;
      this.customLabelText = this.goalConfiguration.Labels[i].CustomLabelText;
      this.enableValue = this.goalConfiguration.Labels[i].EnableValue;
      this.onOffValue = this.goalConfiguration.Labels[i].OnOffValue;

      switch (this.goalLabelName.toLowerCase()) {
        case 'title':
          this.showGoalNameLabel = this.onOffValue; // Show Goal Title.
          break;
        case 'goal linking':
          this.showGoalLinking = this.onOffValue; // Show Goal linking.
          this.goalLinkingLabel = this.enableValue ? this.customLabelText : this.goalLabelName; // Show Custom Label Text.
          break;
      }
    }

    if (this.goalConfiguration.TypeImages.length > 0) {
      for (let i = 0; i < this.goalConfiguration.TypeImages.length; i++) {
        if (this.goalConfiguration.TypeImages[i].OnOffValue) {
          this.goalTypes.push(this.goalConfiguration.TypeImages[i]);
        }
      }
    }

    if (this.goalConfiguration.StatusImages.length > 0) {
      this.goalStatuses = [];
      for (let i = 0; i < this.goalConfiguration.StatusImages.length; i++) {
        if (this.goalConfiguration.StatusImages[i].OnOffValue) {
          this.goalStatuses.push(this.goalConfiguration.StatusImages[i]);
        }
      }
    }

    if (this.goalConfiguration.ImagePreference !== 'Default') {
      if (this.goalConfiguration.ImagePreference === 'Standard') {
        this.imagePath = this.goalConfiguration.StandardImages[0]['imagePath'];
      }
    }
  }

  getLinkedGoalDetails() {
    const request = new MilestoneRequest();
    request.EmpId = this.employeeId;
    request.GoalId = this.selectedGoalId;
    this.trackService.getLinkedGoals(request).subscribe(linkedGoalresponse => {
      this.goalsListChart = JSON.parse(JSON.stringify(linkedGoalresponse));
      this.setHighchartOptions(this.goalsListChart);
    }
    );
  }

  deleteGoalLinking(goalDetails: Goal) {
    const request = new DeleteGoalLinkingRequest();
    request.ParentGoalId = this.selectedGoalId;
    request.ChildGoalId = goalDetails.GoalId;
    this.trackService.deleteGoalToGoalLinking(request).subscribe(response => {
      if (response) {
        this.toast.success('Goal linking deleted successfully.');
        this.getLinkedGoalDetails();
      }
    });
  }

  createGoalLinking() {
    // const userDetails = this.userService.getUserDetails().UserDetails;
    const dialogConfig = new MatDialogConfig();
    // tslint:disable-next-line:max-line-length
    dialogConfig.data = { empId: this.employeeId, goalId: this.selectedGoalId, goalNameGoalLinking: this.goalLinkingLabel };
    dialogConfig.width = '600px';
    dialogConfig.disableClose = true;
    // this.dialog.open(CreateGoalLinkingComponent, dialogConfig);
    const dialogRef = this.dialog.open(CreateGoalLinkingComponent, dialogConfig);
    dialogRef.afterClosed().subscribe(value => {
      if (value === 'success') {
        this.getLinkedGoalDetails();
      }
    });
  }

  setHighchartOptions(goal: Goal[]) {
    if (goal && goal.length > 0) {
      goal.forEach(item => {

        let percentageRemaining = 0;
        let percentageCompleted = 0;
        let colorCode = '';

        if (item.GoalPercentageComplete) {
          percentageCompleted = Math.round(+item.GoalPercentageComplete);
          percentageRemaining = 100 - percentageCompleted;

          if (percentageCompleted <= GoalCompletedColorRange.Low) {
            colorCode = GoalCompletedColorCode.Low;
          } else if (percentageCompleted <= GoalCompletedColorRange.Medium) {
            colorCode = GoalCompletedColorCode.Medium;
          } else if (percentageCompleted > GoalCompletedColorRange.Medium) {
            colorCode = GoalCompletedColorCode.High;
          }
        }
        // Pie chart option setting
        this.pieChartConfig.ChartType = ChartType.Pie;
        this.pieChartConfig.ChartSize = '75';
        this.pieChartConfig.ChartTitle = '<style="font-family:arial; font-size:16px;">' + percentageCompleted + '%</style>';
        this.pieChartConfig.TitleYAxis = 7;
        this.pieChartConfig.TooltipFormatterCallbackFun = this.tooltipFormatter;
        this.pieChartConfig.SeriesName = 'Goal';
        this.pieChartConfig.SeriesInnerSize = '70%';
        this.pieChartConfig.DataLabelsDistance = -40;
        this.pieChartConfig.SeriesData = [];

        // Completed Goal Data
        const serDataCompletedPercentage = {} as SeriesData;
        serDataCompletedPercentage.Name = percentageCompleted;
        serDataCompletedPercentage.YAxis = percentageCompleted;
        serDataCompletedPercentage.EnableDataLabel = false;
        serDataCompletedPercentage.Color = colorCode;
        this.pieChartConfig.SeriesData.push(serDataCompletedPercentage);

        // Remaining Goal Data
        const serDataRemainingPercentage = {} as SeriesData;
        serDataRemainingPercentage.Name = percentageRemaining;
        serDataRemainingPercentage.YAxis = percentageRemaining;
        serDataRemainingPercentage.EnableDataLabel = false;
        serDataRemainingPercentage.Color = GoalCompletedColorCode.None,
          this.pieChartConfig.SeriesData.push(serDataRemainingPercentage);

        item.HighchartOptions = this.highchartService.CreateHighChart(this.pieChartConfig);
        item.ShowDefaultImage = this.showDefaultImage(item);
      });
    }
  }
  private showDefaultImage(goalItem: Goal): boolean {
    let imageName = '';
    if (this.goalConfiguration.ImagePreference === 'GoalType' && this.goalConfiguration.TypeImages && goalItem.GoalConfigType) {
      imageName = this.goalConfiguration.TypeImages.filter(data => data.typeTitle === goalItem.GoalConfigType)[0]['imagePath'];
    } else if (this.goalConfiguration.ImagePreference === 'GoalStatus' && this.goalConfiguration.StatusImages
                && goalItem.GoalConfigStatus) {
      imageName = this.goalConfiguration.StatusImages.filter(data => data.statusTitle === goalItem.GoalConfigStatus)[0]['imagePath'];
    } else if (this.goalConfiguration.ImagePreference === 'Standard') {
      imageName = this.imagePath;
    }
    if (imageName && imageName.length > 0) {
      return false;
    } else {
      return true;
    }
  }
  tooltipFormatter(_seriesType: any, _seriesName: any, _yAxis: number, _color: string) {
    if (_color === GoalCompletedColorCode.None) {
      return 'Remaining:' + _yAxis + '%';
    } else {
      return 'Completed:' + _yAxis + '%';
    }
  }
  cancel() {
    this.dialogRef.close();
  }

}
