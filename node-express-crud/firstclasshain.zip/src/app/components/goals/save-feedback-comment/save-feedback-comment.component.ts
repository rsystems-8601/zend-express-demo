import { Component, OnInit, Inject } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { SaveGoalTaskCommentRequest } from 'src/app/models/requests/task-request';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { UserService } from 'src/app/services/user.service';
import { TaskService } from 'src/app/services/task.service';

@Component({
  selector: 'app-save-feedback-comment',
  templateUrl: './save-feedback-comment.component.html',
  styleUrls: ['./save-feedback-comment.component.scss']
})
export class SaveFeedbackCommentComponent implements OnInit {

  updateFeedbackCommentForm: FormGroup;
  userDetails: any;
  submitted: any = false;
  toValue: any;
  fromValue: any;
  saveGoalTaskCommentRequest = new SaveGoalTaskCommentRequest();
  comment: string;
  direction: string;
  callback: any;
  goalId: number;
  taskId: number;
  category: string;
  changedParam: string;
  callBackScope: any;
  goalDetails: any;
  checked = true;

  constructor(private formBuilder: FormBuilder,
    private dialogRef: MatDialogRef<SaveFeedbackCommentComponent>,
    private userService: UserService,
    private taskService: TaskService,
    @Inject(MAT_DIALOG_DATA) public data) { }

  ngOnInit() {
    this.userDetails = this.userService.getUserDetails();
    this.updateFeedbackCommentForm = this.formBuilder.group({
      taskStatusUpdateText: [''],
    });

    this.toValue = this.data.toVal;
    this.direction = this.data.direction;
    this.fromValue = this.data.fromVal;
    this.goalId = this.data.goalId;
    this.taskId = this.data.taskId;
    this.category = this.data.category;
    this.changedParam = this.data.changedParam;
    this.callBackScope = this.data.scope;
    this.goalDetails = this.data.details;
    if (this.data.callback) {
      this.callback = this.data.callback;
    }
  }

  cancelClick() {
    this.dialogRef.close();
    if (typeof (this.callback) === 'function') {
      this.callback.call(this.callBackScope, this.fromValue, this.changedParam, 'Cancel', this.goalDetails);
    }
  }

  resetForm() {
    this.comment = '';
  }

  get f() {
    return this.updateFeedbackCommentForm.controls;
  }

  onSubmit() {
    this.submitted = true;
    // Doing validation manually
    if (!this.checked &&
        (!this.f['taskStatusUpdateText'].value || this.f['taskStatusUpdateText'].value.trim() === '')) {
      this.f['taskStatusUpdateText'].setErrors({ 'required': true });
      return;
    }

    this.saveGoalTaskCommentRequest.CommentedBy = this.userDetails.UserDetails.EmpId;
    this.saveGoalTaskCommentRequest.GoalId = this.goalId;
    this.saveGoalTaskCommentRequest.TaskId = this.taskId;
    this.saveGoalTaskCommentRequest.Category = this.category;
    let fromVal = null;
    if (this.changedParam === 'date') {
      fromVal = `Date Changed from ${this.fromValue}`;
    }
    if (this.changedParam === 'status') {
      fromVal = `Status Changed from ${this.fromValue}`;
    }
    if (this.changedParam === 'weight') {
      fromVal = `Weight Changed from ${this.fromValue}`;
    }
    if (this.changedParam === 'type') {
      fromVal = `Type Changed from ${this.fromValue}`;
    }

    this.comment = this.comment ? this.comment : '';
    if (this.category === 'Goal') {
      this.saveGoalTaskCommentRequest.Comment =
        `TFIGoalStatusChange~${fromVal}~${this.toValue}~${this.direction}~${this.saveGoalTaskCommentRequest.TaskId}~${this.comment}`;
    } else if (this.category === 'Task') {
      this.saveGoalTaskCommentRequest.Comment =
        `${this.comment}~${fromVal}~${this.toValue}~${this.direction}~${this.saveGoalTaskCommentRequest.TaskId}`;
    }

    this.taskService.saveGoalTaskComment(this.saveGoalTaskCommentRequest).subscribe(response => {
      if (response.AddEmployeeSkillResult.ResultStatusCode === '1040') {
        this.resetForm();
        this.dialogRef.close();
        if (typeof (this.callback) === 'function') {
          this.callback.call(this.callBackScope, null, this.changedParam, 'Success', this.goalDetails);
        }
      } else {
        this.dialogRef.close();
        if (typeof (this.callback) === 'function') {
          this.callback.call(this.callBackScope, null, this.changedParam, 'Failure');
        }
      }
    });
  }

}
