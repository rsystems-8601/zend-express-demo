import { Component, OnInit, Inject } from '@angular/core';
import { UserService } from 'src/app/services/user.service';
import { IcftoasterService } from 'src/app/services/icftoaster.service';
import { MatDialogRef, MAT_DIALOG_DATA, MatSlideToggleChange } from '@angular/material';
import { UserDetails } from 'src/app/models/user-details-result';
// import { Router } from '@angular/router';
import { GoalsService } from 'src/app/services/goals.service';
import { CreateGoalRequest } from 'src/app/models/requests/create-goal-request';
import { GoalRatingResponse, GoalKRA } from 'src/app/models/response/goal/goal-rating-response';
import { GoalRatingSaveRequest, RatingProficiency } from 'src/app/models/requests/goal-rating-save-request';
import { IActBaseInterface } from 'src/app/models/act-base';
import { EventEmiterService } from 'src/app/services/event.emmiter.service';
import { EmpSkillGoalRequest } from 'src/app/models/requests/emp-skill-goal-request';
import { EmpSkillGoalResponse } from 'src/app/models/response/goal/emp-skills-goal.reponse';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-goal-rating',
  templateUrl: './goal-rating.component.html',
  styleUrls: ['./goal-rating.component.scss']
})

export class GoalRatingComponent implements OnInit {

  userDetails: UserDetails;
  ratingArr: any = [];
  userName: string;
  oberserverEmpId: number;
  goalRatingResponse: GoalRatingResponse = {} as GoalRatingResponse;
  goalKRAs: GoalKRA[];
  observerGoalRatingSaveRequest: GoalRatingSaveRequest[];
  parentData: IActBaseInterface;
  empSkillForGoal: Array<EmpSkillGoalResponse> = [];
  selectedItem: number;
  
  constructor(
    private userService: UserService,
    private toast: IcftoasterService,
    public dialogRef: MatDialogRef<GoalRatingComponent>,
    @Inject(MAT_DIALOG_DATA) public data,
    private goalService: GoalsService,
    private _eventEmiter: EventEmiterService,
    private route: ActivatedRoute
  ) { }

  ngOnInit() {
    if (this.data && this.data.dataToPass) {
      this.parentData = this.data.dataToPass;
      this.selectedItem = null;
    } else {
      this.selectedItem = Number(this.route.snapshot.url[2].path);
    }

    this.userDetails = this.userService.getUserDetails().UserDetails;
    this.userName = this.userService.getUserDetails().UserDetails.Name;
    const request = new CreateGoalRequest();
    request.EmpId = this.userDetails.EmpId;
    request.GoalId = this.parentData ? this.parentData.ItemId : this.selectedItem;
    this.goalService.getGoalRatingAndKRA(request).subscribe(response => {
      if (response) {
        this.goalRatingResponse = {} as GoalRatingResponse;
        this.goalRatingResponse = response;
        this.userName = this.goalRatingResponse.ObserverInfo[0].Name;
        this.goalKRAs = this.goalRatingResponse.GoalKRA;
        if (this.goalKRAs.length > 0) {
          this.goalKRAs.forEach(goalKRA => {
            if (goalKRA.Rating !== null) {
              goalKRA['SelectedProficiency'] = Number(goalKRA.Rating);
            } else {
              goalKRA['SelectedProficiency'] = 0;
            }
          });
        }
        this.getEpmloyeeSkillForGoal();
      }
    });
  }

  cancelClicked() {
    if (this.parentData) {
      this.dialogRef.close();
    }
  }

  onRatingChanged(data: any) {

    if (this.goalKRAs.length > 0) {
      this.goalKRAs.forEach(goalKRA => {
        if (goalKRA.Id === data.rowIndex.Id) {
          goalKRA.Rating = data.rating;
        }
      });
    }
  }

  isObserved(event: MatSlideToggleChange) {
    this.goalRatingResponse.GoalInfo.IsObserved = event.checked;
  }

  saveKRA(goalKRAs: GoalKRA[]): void {
    this.observerGoalRatingSaveRequest = [];
    goalKRAs.forEach(goalKRA => {
      const request = {} as GoalRatingSaveRequest;
      request.KRAId = goalKRA.Id;
      request.Type = goalKRA.Type;
      request.Rating = Number(goalKRA.Rating);
      request.Weightage = goalKRA.Weightage;
      request.CreatedBy = this.userDetails.EmpId;
      request.MemberOrgId = this.userDetails.MemberOrgID;
      request.GoalId = this.parentData ? this.parentData.ItemId : this.selectedItem;
      request.NotObserved = this.goalRatingResponse.GoalInfo.IsObserved;
      request.Comment = this.goalRatingResponse.GoalInfo.Comment;
      request.ObserverEmpId = this.userDetails.EmpId;
      if (goalKRA.Type === 'Default') {
        request.RatingProficiencies = null;
      } else if (goalKRA.Type === 'Custom') {
        request.RatingProficiencies = [];
        const ratingProfiency = {} as RatingProficiency;
        goalKRA.RatingProficiencies.forEach(prof => {
          if (prof.RatingProficiencySequence === Number(goalKRA['SelectedProficiency'])) {
            ratingProfiency.ProficiencyId = prof.RatingProficiencyId;
          }
        });
        request.RatingProficiencies.push(ratingProfiency);
      }
      this.observerGoalRatingSaveRequest.push(request);
    });
    if (this.observerGoalRatingSaveRequest && this.observerGoalRatingSaveRequest.length > 0) {
      this.goalService.saveObserverGoalRating(this.observerGoalRatingSaveRequest).subscribe(response => {
        if (response) {
          this.toast.success('Record saved successfully.');
          if (this.parentData) {
            this._eventEmiter.emit({ actionType: 'ReloadActData' });
            this.cancelClicked();
          } else {
            // For mobile
            window.location.href = 'http://icoachfirst/WebViewClose;';
          }
        } else {
          this.toast.error('Error_Duplicate_RP');
        }
      });
    }
  }
  getEpmloyeeSkillForGoal() {
    const request = {} as EmpSkillGoalRequest;
    this.userDetails = this.userService.getUserDetails().UserDetails;
    this.oberserverEmpId = this.goalRatingResponse.ObserverInfo[0].ObserverId;
    request.EmpId = this.oberserverEmpId; //this.userDetails.EmployeeId;
    request.IsInternalId = false;
    this.goalService.getEmployeeSkillForGoal(request).subscribe(response => {
      if (response) {
        this.empSkillForGoal = response;
      }
    });
  }

}
