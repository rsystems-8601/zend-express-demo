import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GoalRatingComponent } from './goal-rating.component';

describe('GoalRatingComponent', () => {
  let component: GoalRatingComponent;
  let fixture: ComponentFixture<GoalRatingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GoalRatingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GoalRatingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
