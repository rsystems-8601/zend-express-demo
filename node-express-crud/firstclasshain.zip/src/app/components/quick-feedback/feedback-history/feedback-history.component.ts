import { Component, OnInit, Inject, OnDestroy } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { DialogData } from 'src/app/models/dialog-data';
import { QuickFeedbackHistoryUrlBuilderService } from 'src/app/services/quick-feedback-history-url-builder.service';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';
import { SharedDataService } from 'src/app/services/shared-data.service';
import { CommonService } from 'src/app/services/common.service';

@Component({
  selector: 'app-feedback-history',
  templateUrl: './feedback-history.component.html',
  styleUrls: ['./feedback-history.component.scss']
})


export class FeedbackHistoryComponent implements OnInit, OnDestroy {

  urlString: string;
  callBackComplete = false;
  msteam_popup_css = '';
  constructor(
    public dialogRef: MatDialogRef<FeedbackHistoryComponent>,
    @Inject(MAT_DIALOG_DATA) public dialogData: DialogData,
    private quickFeedbackHistoryUrlBuilderService: QuickFeedbackHistoryUrlBuilderService,
    private router: Router,
    private authService: AuthService,
    private sharedDataService: SharedDataService,
    private commonService: CommonService
  ) {
    this.initUrlRequest(dialogData);
  }

  ngOnInit() {
    window.addEventListener('message', this.handleIframeTask.bind(this), false);
    if (this.commonService.getMSTeamViewConfig()) {
      this.msteam_popup_css = 'icf_msteam';
    } else {
      this.msteam_popup_css = '';
    }
  }

  initUrlRequest(urlRequest) {
    this.urlString = this.quickFeedbackHistoryUrlBuilderService.openQFHistoryUrl(urlRequest);
  }

  close() {
    this.dialogRef.close();
  }
  handleIframeTask(e) {
    window.removeEventListener('message', () => { });
    // Member variable this.callBackComplete will be false if user refreshes the url
    // and it will be true if user open this same component again and again
    // so added the check using variable
    if (!this.callBackComplete) {
      if (e.data.redirectTo === undefined && e.data.lockAngularScreen === undefined) {
        // the redirectTo will be undefined if user directly refreshes the url
        // added because this func is getting fired first if user refreshes url directly.
        return;
      }
      if (e.data.redirectTo && e.data.redirectTo === 'logout') {
        this.authService.commonLogout();
      }

      if (e.data.redirectTo === 'dashboard') {
        this.callBackComplete = true;
        let redirect = this.sharedDataService.getRedirectionValue();
        if (redirect !== undefined) {
          redirect = decodeURIComponent(redirect);
          this.router.navigate([`/${redirect}`]);
        } else {
          // If userdirectly refreshes the url the redirect value will will be undefined.
          this.router.navigate(['/iCoachFirst/dashboard']);
        }
      }
    }
  }

  ngOnDestroy() {
    this.callBackComplete = true;
    window.removeEventListener('message', () => { });
  }
}
