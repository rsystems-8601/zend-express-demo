import { Component, OnInit, Inject } from '@angular/core';
import { QuickFeedbackRequestPost } from 'src/app/models/requests/quick-feedback-request';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { IcftoasterService } from 'src/app/services/icftoaster.service';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { QuickFeedbackService } from 'src/app/services/quick-feedback.service';
import { EventEmiterService } from 'src/app/services/event.emmiter.service';
// import { User } from 'src/app/models/response/user-response';
import { UserDetails } from 'src/app/models/user-details-result';
import { UserService } from 'src/app/services/user.service';


@Component({
  selector: 'app-assign-quick-feedback',
  templateUrl: './assign-quick-feedback.component.html',
  styleUrls: ['./assign-quick-feedback.component.scss']
})
export class AssignQuickFeedbackComponent implements OnInit {

  quickFeedbackRequest = {} as QuickFeedbackRequestPost;
  ManagerId: number;
  CommentedBy: number;
  quickFeedbacForm: FormGroup;
  submitted = false;
  selection: string;
  // isOutOfHierarchy = false;
  IsRequestFeedback = false;
  RepId: number;
  feedbackUserDetails: any; // because it can be UserDetails or User interface
  feedbackPopUpTitle: string;
  userInfo: UserDetails;
  showMangerCanSeeAndPrivateOption: boolean;

  constructor(
    private formBuilder: FormBuilder,
    private toast: IcftoasterService,
    private feedbackService: QuickFeedbackService,
    public dialogRef: MatDialogRef<AssignQuickFeedbackComponent>,
    // private datePipe: DatePipe,
    private _eventEmiter: EventEmiterService,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private userService: UserService,
  ) {  }

  ngOnInit() {
    this.IsRequestFeedback = this.data.IsRequestFeedback;
    // this.isOutOfHierarchy = this.data.IsOutOfHierarchy;
    this.RepId = this.data.RepId;
    this.ManagerId = this.data.ManagerId;
    this.CommentedBy = this.data.CommentedBy;
    this.selection = 'selection';
    // this.IsMangerCanSeeAndPrivateOptionShow = (this.isOutOfHierarchy && this.data.IsMangerCanSeeAndPrivateOptionShow) ? true : false;
    this.feedbackUserDetails = this.data.feedbackUserDetails;
    this.setFieldVisibility();
    this.quickFeedbackRequest.AllowComments = true;
    this.quickFeedbacForm = this.formBuilder.group({
      feedbackComment: ['', Validators.required],
      radioGroup: [],
      checkAllowComments: []
    });
    this.feedbackPopUpTitle = this.data.feedbackPopUpTitle ? this.data.feedbackPopUpTitle : 'LeftPanel_MyTeam_QuickFeedback';
  }

  get f() {
    return this.quickFeedbacForm.controls;
  }

  onSubmit() {
    this.submitted = true;
    if (this.quickFeedbacForm.invalid) {
      return;
    }
    this.assignQuickFeedback();
  }

  assignQuickFeedback() {

    this.quickFeedbackRequest.FeedbackId = 0;
    this.quickFeedbackRequest.IsQFRequested = this.IsRequestFeedback;
    this.quickFeedbackRequest.commentedBy = this.CommentedBy;
    this.quickFeedbackRequest.managerId = this.ManagerId;
    this.quickFeedbackRequest.RepId = this.RepId;
    this.quickFeedbackRequest.AllowComments = this.quickFeedbackRequest.AllowComments;
    this.quickFeedbackRequest.IsSolicited = false;
    this.quickFeedbackRequest.ForRepEyes = this.selection === 'Private' ? false : true;
    this.quickFeedbackRequest.IsPrivate = this.selection === 'Private' ? true : false;
    // this.quickFeedbackRequest.CreatedDate = this.datePipe.transform(new Date(), 'yyyy-MM-dd hh:mm:ss');
    this.quickFeedbackRequest.Comments = this.quickFeedbackRequest.Comments;
    // this.quickFeedbackRequest.xmlQuickFeedback = this.quickFeedbackRequest.generateXML();
    this.quickFeedbackRequest.SessionID = 0;
    this.quickFeedbackRequest.RequestAcknowledgement = false;

    if (this.quickFeedbackRequest.Comments.trim() !== '') {
      this.feedbackService.saveQuickFeedback(this.quickFeedbackRequest).subscribe(response => {
        if (response.IsRequestSaved) {
          /*
          this.toast.success('Feedback_Created', '', () => {
            this._eventEmiter.emit({ actionType: 'AssignOrCloseQuickFeedback' });
            this.close();
          });
          */
         this.toast.success('Feedback_Created');
         this._eventEmiter.emit({ actionType: 'AssignOrCloseQuickFeedback' });
         this.close();
        } else if (response.QFClosed) {
          this.toast.error('Act_FeedBackClosed');
          this.close();
          this._eventEmiter.emit({ actionType: 'AssignOrCloseQuickFeedback' });
        } else {
          this.toast.error('Error');
        }
      });
    }

  }

  close() {

    this.dialogRef.close();
  }

  setFieldVisibility() {
    // If feedbackuser and loggedinuser have direct relationship of 'reporting manager' and 'employee' then only this fields will be hidden
    this.userInfo = this.userService.getUserDetails().UserDetails;
    if (this.feedbackUserDetails.ManagerId === this.userInfo.EmpId || this.feedbackUserDetails.EmpId === this.userInfo.ManagerId) {
      this.showMangerCanSeeAndPrivateOption = false;
    } else {
      this.showMangerCanSeeAndPrivateOption = true;
    }

  }
}
