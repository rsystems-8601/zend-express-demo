import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AssignQuickFeedbackComponent } from './assign-quick-feedback.component';

describe('AssignQuickFeedbackComponent', () => {
  let component: AssignQuickFeedbackComponent;
  let fixture: ComponentFixture<AssignQuickFeedbackComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssignQuickFeedbackComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssignQuickFeedbackComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
