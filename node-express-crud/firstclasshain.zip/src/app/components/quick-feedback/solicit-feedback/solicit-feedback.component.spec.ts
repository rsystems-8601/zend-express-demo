import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SolicitFeedbackComponent } from './solicit-feedback.component';

describe('SolicitFeedbackComponent', () => {
  let component: SolicitFeedbackComponent;
  let fixture: ComponentFixture<SolicitFeedbackComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SolicitFeedbackComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SolicitFeedbackComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
