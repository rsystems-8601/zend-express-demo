import { Component, OnInit, Inject, OnDestroy } from '@angular/core';
import { UserService } from 'src/app/services/user.service';
import { FormBuilder, FormGroup } from '@angular/forms';
import { IcftoasterService } from 'src/app/services/icftoaster.service';
import { QuickFeedbackService } from 'src/app/services/quick-feedback.service';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { EventEmiterService } from 'src/app/services/event.emmiter.service';
// import { DatePipe } from '@angular/common';
import { User } from 'src/app/models/response/user-response';
import { QuickFeedbackRequestPost } from 'src/app/models/requests/quick-feedback-request';
import { UtilityService } from 'src/app/services/utility.service';

import { Subscription } from 'rxjs';
import { CommonService } from 'src/app/services/common.service';

@Component({
  selector: 'app-solicit-feedback',
  templateUrl: './solicit-feedback.component.html',
  styleUrls: ['./solicit-feedback.component.scss']
})
export class SolicitFeedbackComponent implements OnInit, OnDestroy {

  EmpId: number;
  solicitFeedbackRequest = {} as QuickFeedbackRequestPost;
  calllingSource = 'Task';
  selectedEmployee: any;
  selection: string;

  forYourEyesOnly = false;
  teamMemberCanSee = false;

  solicitForm: FormGroup;
  submitted = false;


  private subscription: Subscription;

  constructor(private userService: UserService,
    private formBuilder: FormBuilder,
    private toast: IcftoasterService,
    private feedbackService: QuickFeedbackService,
    public dialogRef: MatDialogRef<SolicitFeedbackComponent>,
    // private datePipe: DatePipe,
    private _eventEmiter: EventEmiterService,
    @Inject(MAT_DIALOG_DATA) public data: User,
    private utilityService: UtilityService,
    private commonService: CommonService) {


    this.subscription = this._eventEmiter.subscribe(observerData => {

      if (observerData.keyName === 'AddObserver') {
        this.selectedEmployee = observerData;
      }

    });

  }

  ngOnInit() {
    this.selection = 'TeamMemberCanSee';
    this.EmpId = this.userService.getUserDetails().UserDetails.EmpId;
    this.solicitForm = this.formBuilder.group({
      feedbackComment: ['', this.commonService.requiredTrimValidation],
      radioGroup: [],
      checkAllowComments: []
    });

  }

  ngOnDestroy() {
    this._eventEmiter.unsubscribe(this.subscription);
  }

  get f() {
    return this.solicitForm.controls;
  }

  onSubmit() {

    this.submitted = true;

    if (this.solicitForm.invalid || this.selectedEmployee === undefined) {
      return;
    }

    this.assignQuickFeedback();
  }

  assignQuickFeedback() {

    this.solicitFeedbackRequest.FeedbackId = 0;
    this.solicitFeedbackRequest.commentedBy = this.EmpId;
    this.solicitFeedbackRequest.managerId = this.selectedEmployee.observerData.EmpID; // Selected Feedback From
    this.solicitFeedbackRequest.RepId = this.data.EmpId; // Selected Team Member
    // this.solicitFeedbackRequest.IsClose = false;
    this.solicitFeedbackRequest.AllowComments = true;
    this.solicitFeedbackRequest.IsSolicited = true;
    this.solicitFeedbackRequest.ForRepEyes = this.selection === 'TeamMemberCanSee' ? true : false;
    this.solicitFeedbackRequest.IsPrivate = false;
    // this.solicitFeedbackRequest.CreatedDate = this.datePipe.transform(new Date(), 'yyyy-MM-dd hh:mm:ss');
    this.solicitFeedbackRequest.Comments = this.utilityService.escapeSpecialCharacters(this.solicitFeedbackRequest.Comments);
    // this.solicitFeedbackRequest.xmlQuickFeedback = this.solicitFeedbackRequest.generateXML();
    this.solicitFeedbackRequest.SessionID = 0;
    this.solicitFeedbackRequest.RequestAcknowledgement = false;

    this.feedbackService.saveQuickFeedback(this.solicitFeedbackRequest).subscribe(response => {

      // const result = response.SaveQuickFeedbackCommentsResult;
      // if (result.StatusClass.ResultStatusCode === '1040') {

      if (response) {
        /*
        this.toast.success('Feedback_Created', '', () => {
          this._eventEmiter.emit({ actionType: 'AssignOrCloseQuickFeedback' });
          this.close();
        });
        */
       this.toast.success('Feedback_Created');
       this._eventEmiter.emit({ actionType: 'AssignOrCloseQuickFeedback' });
       this.close();
      } else {
        this.toast.error('Common_Error');
      }
    });

  }

  close() {

    this.dialogRef.close();
  }

}
