import { Component, OnInit, Inject } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { UserService } from 'src/app/services/user.service';
import { IcftoasterService } from 'src/app/services/icftoaster.service';
import { QuickFeedbackService } from 'src/app/services/quick-feedback.service';
import { QuickFeedbackDetailsRequest, QuickFeedbackRequestPost
} from 'src/app/models/requests/quick-feedback-request';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { DatePipe } from '@angular/common';
import { IActBaseInterface } from 'src/app/models/act-base';
import { IQuickFeedbackChatResult } from 'src/app/models/response/itask-goal-chat-response';
import { ConfirmationDialogService } from '../../shared/confirmation-dialog/confirmation-dialog.service';
import { EventEmiterService } from 'src/app/services/event.emmiter.service';
import { UtilityService } from 'src/app/services/utility.service';
import { CommonService } from 'src/app/services/common.service';
import { TranslatePipe } from 'src/app/pipes/translate.pipe';

@Component({
  selector: 'app-quick-feedback-details',
  templateUrl: './quick-feedback-details.component.html',
  styleUrls: ['./quick-feedback-details.component.scss']
})

export class QuickFeedbackDetailsComponent implements OnInit {
  solicitFeedbackRecommendComment: string;
  feedbackComment: string;
  EmpId: number;
  quickFeedbackDetailsResponse: IQuickFeedbackChatResult;
  quickFeedbackDetailsForm: FormGroup;
  submitted = false;
  quickFeedbackCommentRequest = {} as QuickFeedbackRequestPost;
  quickFeedbackRequest = new QuickFeedbackDetailsRequest();
  learningPathData: IActBaseInterface;
  isAllowCloseFeedback = false;
  isAllowComments = false;
  FromMessage: string;
  ToMessage: string;
  RequestedByMessage: string;
  RequestedFromMessage: string;

  constructor(
    private userService: UserService,
    private formBuilder: FormBuilder,
    private toast: IcftoasterService,
    private feedbackService: QuickFeedbackService,
    public dialogRef: MatDialogRef<QuickFeedbackDetailsComponent>,
    @Inject(MAT_DIALOG_DATA) public data: IActBaseInterface,
    private datePipe: DatePipe,
    private confirmationDialogService: ConfirmationDialogService,
    private _eventEmiter: EventEmiterService,
    private utilityService: UtilityService,
    private commonService: CommonService,
    private pipeTransform: TranslatePipe
  ) {
    this.learningPathData = JSON.parse(JSON.stringify(data));
    if ((this.learningPathData.ItemType === 'Feedback Request') && !this.learningPathData.IsSolicited) {
      // const repName = this.learningPathData.AssignedToName;
      // const repPicUrl = this.learningPathData.ToProfilePicUrl;
      // const managerName = this.learningPathData.ManagerName;
      // const managerPickUrl = this.learningPathData.ManagerProfilePicUrl;
      // this.learningPathData.ManagerName = repName;
      // this.learningPathData.ManagerProfilePicUrl = repPicUrl;
      // this.learningPathData.AssignedToName = managerName;
      // this.learningPathData.ToProfilePicUrl = managerPickUrl;
    }
  }

  ngOnInit() {
    this.EmpId = this.userService.getUserDetails().UserDetails.EmpId;
    this.quickFeedbackDetailsForm = this.formBuilder.group({
      feedbackComment: ['', this.commonService.requiredTrimValidation]
    });
    this.getQuickFeedbackDetails();
    /* To check Allow Comment or Not  START --- */
    // tslint:disable-next-line:max-line-length
    if (this.learningPathData.IsCompleted || ((this.learningPathData.AllowComments === false) && this.learningPathData.CreatedByEmpId !== this.EmpId)) {
      this.isAllowComments = false;
    } else {
      if (this.learningPathData.IsSolicited && this.learningPathData.CreatedByEmpId === this.EmpId) {
        this.isAllowComments = false;
      } else {
        // tslint:disable-next-line:max-line-length
        if (!this.learningPathData.IsSolicited && (this.EmpId !== this.learningPathData.AssignToEmpId) && (this.EmpId !== this.learningPathData.CreatedByEmpId)
          && (this.learningPathData.AllowComments === false)) {
          this.isAllowComments = false;
        } else {
          this.isAllowComments = true;
        }
      }
    }

    /* ICF6-922 Allow Comments should be true only for the two persons i.e.,
    The one who created the feedback(CreatedByEmpId) or the one who received the feedback(AssignToEmpId) or the
    one who is provding the feedback(ManagerId) */
    if (this.learningPathData.CreatedByEmpId !== this.EmpId && this.learningPathData.AssignToEmpId !== this.EmpId &&
      this.learningPathData.ManagerId !== this.EmpId) {
      this.isAllowComments = false;
    }

    /* -- END To check Allow Comment or Not */
    this.isAllowCloseFeedback = (this.learningPathData.ManagerId === this.EmpId && !this.learningPathData.IsCompleted) ? true : false;

    // request quick feedback
    // Changing it managerId, because there is no flag in database to check who has requested the feedback, so
    // who initiated the feedback will be createdBy and the one who provided the feedback will be saved in ManagerId,
    // irrespective two or three people involved.
    const managerId = this.learningPathData.ManagerId;
    if ((managerId === this.learningPathData.AssignToEmpId) && (managerId === this.learningPathData.CreatedByEmpId)) {
      this.RequestedByMessage = this.pipeTransform.transform('Requested_By');
      this.RequestedFromMessage = this.pipeTransform.transform('Common_From');
    } else if ((managerId !== this.learningPathData.AssignToEmpId) && (managerId !== this.learningPathData.CreatedByEmpId)) {
      this.RequestedByMessage = this.pipeTransform.transform('Common_From');
      this.RequestedFromMessage = this.pipeTransform.transform('Requested_By');
    } else {
      this.FromMessage = this.pipeTransform.transform('Common_From');
      this.ToMessage = this.pipeTransform.transform('Common_To');
    }
  }

  // tslint:disable-next-line:use-life-cycle-interface
  getQuickFeedbackDetails() {
    this.quickFeedbackRequest.EmpId = this.EmpId;
    this.quickFeedbackRequest.QuickFeedbackId = this.learningPathData.ItemId;
    this.feedbackService.getQuickFeedbackDetails(this.quickFeedbackRequest).subscribe(response => {
      this.quickFeedbackDetailsResponse = response;
      // // 'Response....' + this.quickFeedbackDetailsResponse.QuickFeedbackChatDetailsResult);
      if (this.quickFeedbackDetailsResponse.QuickFeedbackChatDetailsResult.length > 0) {
        if (this.learningPathData.IsSolicited) {
          this.solicitFeedbackRecommendComment = this.quickFeedbackDetailsResponse.QuickFeedbackChatDetailsResult[0].Comments;
          this.feedbackComment = this.quickFeedbackDetailsResponse.QuickFeedbackChatDetailsResult.length > 1 ?
            this.quickFeedbackDetailsResponse.QuickFeedbackChatDetailsResult[1].Comments : '';
          // this.quickFeedbackDetailsResponse.QuickFeedbackChatDetailsResult.splice(0, 2);
          this.feedbackComment = this.quickFeedbackDetailsResponse.QuickFeedbackChatDetailsResult[0].Comments;
          // } else if (this.learningPathData.ItemType === 'Feedback Request') {
          //   this.solicitFeedbackRecommendComment = '';
          //   this.feedbackComment = this.quickFeedbackDetailsResponse.QuickFeedbackChatDetailsResult[0].Comments;
          this.quickFeedbackDetailsResponse.QuickFeedbackChatDetailsResult.splice(0, 1);
          // }
        } else if (this.learningPathData.FeedbackRequest) {
          this.solicitFeedbackRecommendComment = this.quickFeedbackDetailsResponse.QuickFeedbackChatDetailsResult[0].Comments;
          this.feedbackComment = this.quickFeedbackDetailsResponse.QuickFeedbackChatDetailsResult.length > 1 ?
            this.quickFeedbackDetailsResponse.QuickFeedbackChatDetailsResult[1].Comments : '';
          // this.quickFeedbackDetailsResponse.QuickFeedbackChatDetailsResult.splice(0, 1);
          // } else if (this.learningPathData.ItemType === 'Feedback Request') {
          //   this.solicitFeedbackRecommendComment = '';
          //   this.feedbackComment = this.quickFeedbackDetailsResponse.QuickFeedbackChatDetailsResult[0].Comments;
          //   this.quickFeedbackDetailsResponse.QuickFeedbackChatDetailsResult.splice(0, 1);
          // }
        } else {
          this.solicitFeedbackRecommendComment = '';
          this.feedbackComment = this.quickFeedbackDetailsResponse.QuickFeedbackChatDetailsResult[0].Comments;
          this.quickFeedbackDetailsResponse.QuickFeedbackChatDetailsResult.splice(0, 1);
        }
      } else {
        this.solicitFeedbackRecommendComment = '';
        this.feedbackComment = '';
      }
    });
  }

  get f() {
    return this.quickFeedbackDetailsForm.controls;
  }

  onSubmit() {
    this.submitted = true;
    if (this.quickFeedbackDetailsForm.invalid) {
      return;
    }
    this.saveQuickFeedbackComment(false);
  }

  saveQuickFeedbackComment(isFeedbackClosed) {
    this.quickFeedbackCommentRequest.FeedbackId = this.learningPathData.ItemId;
    this.quickFeedbackCommentRequest.commentedBy = this.EmpId;
    this.quickFeedbackCommentRequest.managerId = this.learningPathData.ManagerId;
    this.quickFeedbackCommentRequest.RepId = this.learningPathData.AssignToEmpId;
    // this.quickFeedbackCommentRequest.IsClose = isFeedbackClosed;
    this.quickFeedbackCommentRequest.AllowComments = this.learningPathData.AllowComments;
    this.quickFeedbackCommentRequest.IsSolicited = this.learningPathData.IsSolicited;
    this.quickFeedbackCommentRequest.ForRepEyes = this.learningPathData.ForRepEyes;
    this.quickFeedbackCommentRequest.IsPrivate = this.learningPathData.IsPrivate;
    // this.quickFeedbackCommentRequest.CreatedDate = this.datePipe.transform(new Date(), 'yyyy-MM-dd hh:mm:ss');
    this.quickFeedbackCommentRequest.Comments = this.quickFeedbackCommentRequest.Comments === undefined ?
      '' : this.quickFeedbackCommentRequest.Comments;
    this.quickFeedbackCommentRequest.Comments = this.utilityService.escapeSpecialCharacters(this.quickFeedbackCommentRequest.Comments);
    // this.quickFeedbackCommentRequest.xmlQuickFeedback = this.quickFeedbackCommentRequest.generateXML();
    this.quickFeedbackCommentRequest.SessionID = 0;
    this.quickFeedbackCommentRequest.RequestAcknowledgement = false;
    this.feedbackService.saveQuickFeedback(this.quickFeedbackCommentRequest).subscribe(response => {
      // const result = response.SaveQuickFeedbackCommentsResult;
      // if (result.StatusClass.ResultStatusCode === '1040') {
      if (response) {
        this.resetForm();
        this.getQuickFeedbackDetails();
        let message = 'Feedback_Created';
        if (response.IsRequestSaved) {
          message = 'Feedback_Created';
          this.toast.success(message, '', () => { });
          if (isFeedbackClosed) {
            this._eventEmiter.emit({ actionType: 'AssignOrCloseQuickFeedback' });
          }
          this.close();
        } else if (response.QFClosed) {
          this.toast.error('Act_FeedBackClosed');
          this.close();
          this._eventEmiter.emit({ actionType: 'AssignOrCloseQuickFeedback' });
        }
      } else {
        this.toast.error('Common_Error');
      }
    });
  }

  closeQuickFeedbackComment(isFeedbackClosed) {
    this.feedbackService.closeQuickFeedback(this.learningPathData.ItemId).subscribe(response => {
      if (response) {
        this.resetForm();
        this.getQuickFeedbackDetails();
        let message = 'Feedback_Created';
        if (isFeedbackClosed === true) {
          message = 'Feedback_QuickFeedback_ClosedSuccessfully';
        }
        this.toast.success(message, '', () => { });
        if (isFeedbackClosed) {
          this._eventEmiter.emit({ actionType: 'AssignOrCloseQuickFeedback' });
        }
        this.close();
      } else {
        this.toast.error('Common_Error');
      }
    });
  }

  closeFeedback() {
    // tslint:disable-next-line:max-line-length
    this.confirmationDialogService.confirm('QuickFeedbackReport_CloseQFMsg',
      'Common_Yes',
      'Common_No').subscribe(value => {
        if (value) {
          this.closeQuickFeedbackComment(true);
        }
      });
  }

  resetForm() {
    this.quickFeedbackCommentRequest.Comments = '';
    this.submitted = false;
  }

  close() {
    this.dialogRef.close();
  }

  getUpdateDate(dateString) {
    const newString = dateString.replace(' ', 'T');
    const newDate = new Date(newString);
    return this.datePipe.transform(newDate, 'MMM dd, yyyy hh:mm:ss a');
  }

}
