import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { QuickFeedbackDetailsComponent } from './quick-feedback-details.component';

describe('QuickFeedbackDetailsComponent', () => {
  let component: QuickFeedbackDetailsComponent;
  let fixture: ComponentFixture<QuickFeedbackDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ QuickFeedbackDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QuickFeedbackDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
