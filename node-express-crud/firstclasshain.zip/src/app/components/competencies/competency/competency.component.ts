import { Component, OnInit, Input } from '@angular/core';
import { Competency } from 'src/app/models/response/act-response';
// import { SharedDataService } from 'src/app/services/shared-data.service';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-competency',
  templateUrl: './competency.component.html',
  styleUrls: ['./competency.component.scss']
})
export class CompetencyComponent implements OnInit {

  @Input() competency: Competency;
  showThumbnailImage = false;

  constructor( // private sharedDataService: SharedDataService,
    private router: Router) { }

  ngOnInit() {

    if (this.competency.ShowAsImageOnTrack && this.competency.TrackThumbnailURL != null) {
      this.showThumbnailImage = true;
      this.competency.TrackThumbnailURL.replace('https://DomainName', `${environment.domainName}`);
    }
  }

  showCompetencyDetails(competencyDrtail: Competency) {
    if (competencyDrtail.OnClickShowAsPDF) {
      const height = 570;
      const width = 600;
      const left = (screen.width / 2) - (width / 2);
      const top = (screen.height / 2) - (height / 2);
      window.open(competencyDrtail.OnClickPdfFileURL, 'Competency Pdf/Image File',
        'toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=no,' +
        'resizable = no, copyhistory = no, width = ' + width + ', height = ' + height + ', top = ' + top + ', left = ' + left);
      return false;
    } else {
      // this.sharedDataService.setData(this.competency);
      this.router.navigate(['/iCoachFirst/dashboard/competency-details', competencyDrtail.CompetencyDimensionId]);
    }
  }

}
