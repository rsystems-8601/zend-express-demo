import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CompetencydetailsComponent } from './competencydetails.component';

describe('CompetencydetailsComponent', () => {
  let component: CompetencydetailsComponent;
  let fixture: ComponentFixture<CompetencydetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CompetencydetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CompetencydetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
