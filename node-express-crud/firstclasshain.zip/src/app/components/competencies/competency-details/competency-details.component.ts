import { Component, OnInit, ViewChild } from '@angular/core';
import { CompetencyService } from 'src/app/services/competency.service';
import { TrainingCompetencyResponse, AssessmentCompetencyDetailsResponse } from 'src/app/models/response/competency-response';
import { CommonService } from 'src/app/services/common.service';
import { MatDialogConfig, MatDialog } from '@angular/material';
import { LearnModalPopupEnum } from 'src/app/helpers/enums/learn-enums';
import { LearnAssignComponent } from '../../learn/modal-popup/assign/learn-assign.component';
import { LearnBaseResponse } from 'src/app/models/response/learn/learn-response';
import { LearnSelfAssignComponent } from '../../learn/modal-popup/self-assign/learn-self-assign.component';
import { TrainingContentComponent } from '../../learn/modal-popup/training-content/training-content.component';
import { ActivatedRoute } from '@angular/router';
import { NgForm } from '@angular/forms';
import { IcftoasterService } from 'src/app/services/icftoaster.service';

@Component({
  selector: 'app-competency-details',
  templateUrl: './competency-details.component.html',
  styleUrls: ['./competency-details.component.scss']
})
export class CompetencyDetailsComponent implements OnInit {
  isFormSubmitted = false;
  url: String;
  competencyId: number;
  trainingCompetencyList: Array<TrainingCompetencyResponse> = [];
  competencyDetail: AssessmentCompetencyDetailsResponse;
  learnDetails = {} as LearnBaseResponse;
  charctersLength = 35;
  @ViewChild('myNotesForm') myNotesForm: NgForm;

  constructor(
    private competencyService: CompetencyService,
    private commonService: CommonService,
    private dialog: MatDialog,
    private route: ActivatedRoute,
    private toast: IcftoasterService, ) { }

  ngOnInit() {
    this.route.params.subscribe(params => {
      if (params.competencyId) {
        this.competencyId = (+params.competencyId);
      }
    });
    // this.getTrainingCompetency();
    this.getAssessmentCompetencyDetails();
  }

  getTrainingCompetency() {
    this.competencyService.getRoleBasedCompetenciesTrainings(this.competencyId).subscribe(resultData => {
      this.trainingCompetencyList = JSON.parse(JSON.stringify(resultData));
    },
      () => { }
    );
  }

  getAssessmentCompetencyDetails() {
    this.competencyService.getAssessmentCompetencyDetails(this.competencyId).subscribe(resultData => {
      this.competencyDetail = JSON.parse(JSON.stringify(resultData));
      if (this.competencyDetail && this.competencyDetail.CompetencyDetails.ShowResourceSectionInPopUp) {
        this.getTrainingCompetency();
      }
    },
      () => { }
    );
  }

  saveMyNotes() {
    if (!this.myNotesForm.valid) {
      this.isFormSubmitted = true;
      return;
    }
    this.competencyService.SaveCompetencyNotes(this.competencyId, this.competencyDetail.CompetencyDetails.MyNote).subscribe(resultData => {

      const apiResponse = JSON.parse(JSON.stringify(resultData));
      if (apiResponse.ResultStatusCode.toLowerCase() === 'success') {
        this.toast.success('Common_UpdateSuccess', '');
      } else {
        this.toast.error(apiResponse.ErrorMessage, '');
      }
    },
      () => { }
    );
  }

  getStarRatingArray(averageRating: number, isShowStar: boolean) {
    return this.commonService.getStarRatingArray(averageRating, isShowStar);
  }

  onClickBack() {
    history.back();
  }

  openAssignModal4Resources(tCompetency: TrainingCompetencyResponse) {
    this.getlearnDetailObject(tCompetency);

    const dialogConfig = new MatDialogConfig();
    dialogConfig.data = this.learnDetails;
    this.openAssignModal(dialogConfig);

  }


  openSelfAssignModal4Resources(tCompetency: TrainingCompetencyResponse) {
    this.getlearnDetailObject(tCompetency);

    const dialogConfig = new MatDialogConfig();
    dialogConfig.data = this.learnDetails;
    this.openSelfAssignModal(dialogConfig);
  }



  openPreviewModal4Resources(tCompetency: TrainingCompetencyResponse) {
    this.getlearnDetailObject(tCompetency);

    const dialogConfig = new MatDialogConfig();
    dialogConfig.data = this.learnDetails;

    if (dialogConfig.data.TypeName === 'Video' || dialogConfig.data.TypeName === 'Document') {
      this.openPreviewModal(dialogConfig);
    } else {
      window.open(dialogConfig.data.ReviewLink, '_blank');
      window.focus();
    }
  }

  private openAssignModal(dialogConfig: MatDialogConfig) {
    dialogConfig.width = LearnModalPopupEnum.AssignModalWidth + 'px';
    dialogConfig.disableClose = true;
    this.dialog.open(LearnAssignComponent, dialogConfig);

  }

  private openSelfAssignModal(dialogConfig: MatDialogConfig) {
    dialogConfig.width = LearnModalPopupEnum.SelfAssignModalWidth + 'px';
    dialogConfig.disableClose = true;
    this.dialog.open(LearnSelfAssignComponent, dialogConfig);
  }

  private openPreviewModal(dialogConfig: MatDialogConfig) {
    dialogConfig.width = LearnModalPopupEnum.PreviewModalWidth + 'px';
    dialogConfig.height = LearnModalPopupEnum.PreviewModalHeight + 'px';
    // dialogConfig.disableClose = true;
    // const dialogRef =
    this.dialog.open(TrainingContentComponent, dialogConfig);
    /* dialogRef.afterClosed().subscribe(responseData => {
         if (responseData.Refresh) {
             this.getLearnData();
         }
     });
     */
  }

  private getlearnDetailObject(tCompetency: TrainingCompetencyResponse) {
    this.learnDetails.ContentId = tCompetency.ContentId;
    this.learnDetails.CourseId = String(tCompetency.CourseId);
    this.learnDetails.AssignmentId = 0;
    this.learnDetails.TypeName = tCompetency.TypeDetails;
    this.learnDetails.ReviewLink = tCompetency.AttachFileName;
    this.learnDetails.TrainingName = tCompetency.Title;
    this.learnDetails.TrainingImageUrl = tCompetency.TitleImageName;
  }
  getLevelName(levelName: string) {
    return this.commonService.getFixedLengthCharsFromString(levelName, this.charctersLength);
  }

}
