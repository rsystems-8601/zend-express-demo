import { Component, OnInit } from '@angular/core';
import { ActService } from 'src/app/services/act.service';
import { ClusterRequest } from 'src/app/models/requests/act-request';
import { Competency } from 'src/app/models/response/act-response';
import { ActivatedRoute } from '@angular/router';
import { UserService } from 'src/app/services/user.service';


@Component({
  selector: 'app-competencies',
  templateUrl: './competencies.component.html',
  styleUrls: ['./competencies.component.scss', '../../learn/learn.component.scss']
})
export class CompetenciesComponent implements OnInit {

  competencyList: Competency[];

  // @Input() cluster: any;

  constructor(private route: ActivatedRoute, private actService: ActService,
    private userService: UserService) { }

  ngOnInit() {

    this.route.params.subscribe(params => {
      this.getCompetencyData(+params.clusterId);
    });
  }

  getCompetencyData(clusterId: number) {

    const userInfo = this.userService.getUserDetails().UserDetails;
    const request = new ClusterRequest();
    request.EmpId = userInfo.EmpId;
    request.ClusterId = clusterId;

    this.actService.getClusterCompetencies(request).subscribe(response => {
      this.competencyList = response;
    });
  }
}
