
import { BrowserModule, HAMMER_GESTURE_CONFIG } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { CommonModule } from '@angular/common';
import { NgSlimScrollModule, SLIMSCROLL_DEFAULTS } from 'ngx-slimscroll';
import { OwlModule } from 'ngx-owl-carousel';
import { ToastrModule } from 'ngx-toastr';
import { RouterModule } from '@angular/router';
import { DatePipe } from '@angular/common';
import { MatDialogModule, GestureConfig } from '@angular/material';
import { MatDialogRef, MAT_DIALOG_DATA, MAT_DIALOG_DEFAULT_OPTIONS } from '@angular/material';

// Custom
import { AppComponent } from './app.component';
import { LoginComponent } from './components/login/login.component';
import { EventEmiterService } from './services/event.emmiter.service';
import { AppRoutingModule } from './modules/app-routing.module';
import { CommonInterceptor } from './helpers/common.interceptor';
import { LoaderComponent } from './components/shared/loader/loader.component';
import { ErrorInterceptor } from './helpers/error.interceptor';
import { ForgotPasswordComponent } from './components/forgot-password/forgot-password.component';
import { ResetPasswordComponent } from './components/reset-password/reset-password.component';
import { LanguageSelectionComponent } from './components/user-settings/language-selection/language-selection.component';
import { PaginationApiService } from './services/pagination-api.service';
import { LocalizationService } from './services/localization.service';
import { SharedModule } from './modules/shared.module';
import { CalendarService } from './services/calendar.service';

import { NgxPubSubModule } from '@pscoped/ngx-pub-sub';
import { PulseSurveyEmailComponent } from './components/pulse-survey-email/pulse-survey-email.component';
import { SurveyCreatorComponent } from './components/shared/survey-creator/survey-creator.component';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    LoaderComponent,
    ForgotPasswordComponent,
    ResetPasswordComponent,
    LanguageSelectionComponent,
    
    PulseSurveyEmailComponent,
    SurveyCreatorComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    OwlModule,
    HttpClientModule,
    // HttpModule,
    RouterModule,
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    AppRoutingModule,
    NgSlimScrollModule,
    ToastrModule.forRoot({
      positionClass: 'toast-top-center',
      timeOut: 3000
    }),
    MatDialogModule,
    SharedModule,
    NgxPubSubModule
  ],
  exports: [
  ],

  providers: [
    EventEmiterService
    , { provide: SLIMSCROLL_DEFAULTS, useValue: { alwaysVisible: false } }
    , {
      provide: HTTP_INTERCEPTORS,
      useClass: CommonInterceptor,
      multi: true
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: ErrorInterceptor,
      multi: true
    },
    {
      provide: MatDialogRef, useValue: {}
    },
    {
      provide: MAT_DIALOG_DATA, useValue: []
    },
    {
      provide: MAT_DIALOG_DEFAULT_OPTIONS, useValue: { disableClose: true }
    },
    DatePipe,
    { provide: HAMMER_GESTURE_CONFIG, useClass: GestureConfig },
    PaginationApiService,
    LocalizationService,
    CalendarService
  ],

  bootstrap: [AppComponent],
  entryComponents: [
    LanguageSelectionComponent,
    SurveyCreatorComponent
  ]
})
export class AppModule {
}
