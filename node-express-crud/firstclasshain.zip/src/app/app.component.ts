import { Component, OnInit, EventEmitter  } from '@angular/core';
import { ISlimScrollOptions, SlimScrollEvent } from 'ngx-slimscroll';
import { environment } from 'src/environments/environment';
//
// import { Subscription } from 'rxjs';
// import { LoaderService } from './services/common/loader.service';
// import { LoaderState } from './models/response/common/loader-state';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
   // show = 0;
  // private subscription: Subscription;

  opts: ISlimScrollOptions;
  scrollEvents: EventEmitter<SlimScrollEvent>;
  loading = false;
  currentEnv = environment.envName;

  constructor(    ) {
    // router.events.subscribe((routerEvent: Event) => {-
    //   this.checkRouterEvent(routerEvent);
    // });
  }

  /*
  checkRouterEvent(routerEvent: Event): void {
    if(routerEvent instanceof NavigationStart) {
      this.loading = true;
    }

    if(routerEvent instanceof NavigationEnd ||
      routerEvent instanceof NavigationCancel ||
      routerEvent instanceof NavigationError) {
        this.loading = false;
      }
  }
*/
  ngOnInit() {
    // this.subscription = this.loaderService.loaderState
    // .subscribe((state: LoaderState) => {
    //     this.show = state.show;
    // });

    // SlimScroll Implements START
    this.scrollEvents = new EventEmitter<SlimScrollEvent>();
    this.opts = {
      position: 'right', // left | right
      barBackground: '#C9C9C9', // #C9C9C9
      barOpacity: '0.8', // 0.8
      barWidth: '5', // 10
      barBorderRadius: '10', // 20
      barMargin: '0', // 0
      gridBackground: '#D9D9D9', // #D9D9D9
      gridOpacity: '1', // 1
      gridWidth: '2', // 2
      gridBorderRadius: '20', // 20
      gridMargin: '0', // 0
      alwaysVisible: true, // true
      visibleTimeout: 1000 // 1000
      // scrollSensitivity?: 1; // 1
    };

    this.play();
    // SlimScroll Implements END
  }

  play(): void {
    let event = null;

    Promise.resolve()
      .then(() => this.timeout(3000))
      .then(() => {
        event = new SlimScrollEvent({
          type: 'scrollToBottom',
          duration: 2000,
          easing: 'inOutQuad'
        });

        this.scrollEvents.emit(event);
      })
      .then(() => this.timeout(3000))
      .then(() => {
        event = new SlimScrollEvent({
          type: 'scrollToTop',
          duration: 3000,
          easing: 'outCubic'
        });

        this.scrollEvents.emit(event);
      })
      .then(() => this.timeout(4000))
      .then(() => {
        event = new SlimScrollEvent({
          type: 'scrollToPercent',
          percent: 80,
          duration: 1000,
          easing: 'linear'
        });

        this.scrollEvents.emit(event);
      })
      .then(() => this.timeout(2000))
      .then(() => {
        event = new SlimScrollEvent({
          type: 'scrollTo',
          y: 200,
          duration: 4000,
          easing: 'inOutQuint'
        });

        this.scrollEvents.emit(event);
      });
  }

  timeout(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(() => resolve(), ms));
  }

//   ngOnDestroy() {
//     this.subscription.unsubscribe();
// }
}
